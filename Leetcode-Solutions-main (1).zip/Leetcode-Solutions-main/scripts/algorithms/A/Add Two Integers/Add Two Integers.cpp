// Runtime: 3 ms (Top 39.04%) | Memory: 5.8 MB (Top 95.13%)
class Solution {
public:
    int sum(int num1, int num2) {
        return num1+num2;
    }
};