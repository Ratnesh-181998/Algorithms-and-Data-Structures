// Runtime: 0 ms (Top 100.00%) | Memory: 6 MB (Top 31.29%)
class Solution {
public:
    double nthPersonGetsNthSeat(int n) {
        if(n==1)return (double)1;
        return (double)1/2;
    }
};