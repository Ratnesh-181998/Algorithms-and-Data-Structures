// Runtime: 0 ms (Top 100.00%) | Memory: 39 MB (Top 96.77%)
lass Solution {
    public double nthPersonGetsNthSeat(int n) {
       if(n==1)
           return (double)1;
        return (double)1/2;
    }
}