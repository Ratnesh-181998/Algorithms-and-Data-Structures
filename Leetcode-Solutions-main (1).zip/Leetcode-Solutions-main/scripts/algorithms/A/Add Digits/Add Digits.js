// Runtime: 101 ms (Top 63.77%) | Memory: 43.2 MB (Top 91.64%)
var addDigits = function(num) {
    return 1 + (num - 1) % 9;
};