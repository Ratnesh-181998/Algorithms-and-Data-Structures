
Q1. Task Scheduler

'''
Given a characters array tasks, representing the tasks a CPU needs to do, where each letter represents a different task. Tasks could be done in any order. Each task is done in one unit of time. For each unit of time, the CPU could complete either one task or just be idle.

However, there is a non-negative integer n that represents the cooldown period between two same tasks (the same letter in the array), that is that there must be at least n units of time between any two same tasks.

Return the least number of units of times that the CPU will take to finish all the given tasks.

 

Example 1:

Input: tasks = ["A","A","A","B","B","B"], n = 2
Output: 8
Explanation: 
A -> B -> idle -> A -> B -> idle -> A -> B
There is at least 2 units of time between any two same tasks.
Example 2:

Input: tasks = ["A","A","A","B","B","B"], n = 0
Output: 6
Explanation: On this case any permutation of size 6 would work since n = 0.
["A","A","A","B","B","B"]
["A","B","A","B","A","B"]
["B","B","B","A","A","A"]
...
And so on.
Example 3:

Input: tasks = ["A","A","A","A","A","A","B","C","D","E","F","G"], n = 2
Output: 16
Explanation: 
One possible solution is
A -> B -> C -> A -> D -> E -> A -> F -> G -> A -> idle -> idle -> A -> idle -> idle -> A
 

Constraints:

1 <= task.length <= 104
tasks[i] is upper-case English letter.
The integer n is in the range [0, 100].

'''
#Solution 


# Method-1
# Priority Queue (Max Heap) and Queue Solution | O(n) Time | O(n) Space
# * Priority Queue (Max Heap) and Queue Solution | O(n) Time | O(n) Space
# * n -> The length of tasks array
# queue
# priority-queue

class Solution:
    def leastInterval(self, tasks: List[str], n: int) -> int:
        if n <= 0:
            return len(tasks)
        task_counter = collections.Counter(tasks)
        # * Stores the task count.
        max_heap = [-task_count for task_count in task_counter.values()]
        heapq.heapify(max_heap)
        total_time = 0
        # * Stores a pair of count and available time.
        # * Pair -> (count, available_at)
        queue = collections.deque()

        while max_heap or queue:
            total_time += 1
            # * If the heap is empty then update total_time to 1st element in the queue
            # * since that's the idle time to process next task.
            if not max_heap:
                total_time = queue[0][1]
            else:
                heap_count = -heapq.heappop(max_heap)
                heap_count -= 1
                if heap_count:
                    queue.append((-heap_count, total_time + n))
            # * If the task is available to process
            if queue and queue[0][1] == total_time:
                heapq.heappush(max_heap, queue.popleft()[0])

        return total_time
                                 
                                 

#Method-2
# Counter + minHeap + deque
# python
# heap
# heap-priority-queue                            
  
import heapq
import collections

class Solution:
    def leastInterval(self, tasks: List[str], n: int) -> int:
        counter = {}
        for t in tasks:
            counter[t] = counter.get(t, 0) + 1
		# use neagive counts to turn minHeap into maxHeap
        heap = [-counter[t] for t in counter]
        heapq.heapify(heap)
        time_units = 0
        num_tasks = len(tasks)
        cooldown = collections.deque([None for _ in range(n + 1)])
        while num_tasks > 0:
            cd = cooldown.popleft()
            if cd:
                heapq.heappush(heap, cd)
            
            if heap:
                cur = heapq.heappop(heap)
                cur += 1
                if cur < 0:
                    cooldown.append(cur)
                else:
					# be careful here, we need a placeholder to keep the cooldown time
                    cooldown.append(None)
                num_tasks -= 1
            else:
				# be careful here, we need a placeholder to keep the cooldown time
                cooldown.append(None)
            time_units += 1
        return time_units

#Method-3
# O(n) Python Solution

from collections import Counter

class Solution:
    def leastInterval(self, tasks: List[str], n: int) -> int:
        # tasks = ["A","A","A","A","A","A","B","C","D","E","F","G"], n = 2
        # task_counter = [1, 1, 1, 1, 1, 1, 6]
        task_counter = sorted(Counter(tasks).values())
        
        # max_idle_spots = (6-1)*2 = 10
        max_idle_spots = (task_counter[-1] - 1) * n
        
        # max_idle_spots = 10 - 1 - 1 - 1 - 1 - 1 - 1 = 4
        for i in range(len(task_counter) - 1):
            max_idle_spots -= min(task_counter[i], task_counter[-1] - 1)
        
        # 4 + 12 = 16
        return max_idle_spots + len(tasks) if max_idle_spots > 0 else len(tasks)

#Method-4

import heapq
class Solution:
    def leastInterval(self, tasks: List[str], n: int) -> int:
        h = {}
        #tracking count of tasks
        for i in tasks:
            if i in h:
                h[i]+=1
            else:
                h[i] = 1
                
                
        heap = [-i for i in h.values()]
        #heapifying the heap        
        heapq.heapify(heap)
        #initialise the queue
        q = []
        time = 0 #our ans
        
        while heap or q:
            time+=1 #increment count by one unit
            #if heap is not empty
            if heap:
                '''
                incrementing by one as we assign negative value to build max heap
                '''
                curr_cnt = heapq.heappop(heap)+1
                #appending the current task in queue as it is remaining
                if curr_cnt:
                    q.append((time+n+1,curr_cnt)) #time+n+1 is because tiem+n+1 is the time when the curr task executes again
            #if queue is not empty and also first task of queue executes at time time+1
            if q and q[0][0]==time+1:
                heapq.heappush(heap,q.pop(0)[1])
            
        #returning answer
        return time
                     
        
# Method-5

# O(n) solution with just Math

# Find the most repeating task. The total number of time slots will be the sum of number of times this task has repeated (Let's call this max_task_count) and the 'n' idle/other slots between every repetition, i.e. n*(max_task_count-1). If there are multiple tasks with the same max_task_count, find the number of such additional tasks count_of_counts[max_task_count]-1, this would be the additional slots required.
# Hence, slots = max_task_count + (max_task_count-1) * n + count_of_counts[max_task_count]-1.

# But if n=0, then the number of slots is the number of elements. Hence, slots = max(len(tasks), slots)

# from collections import Counter

class Solution:
    def leastInterval(self, tasks, n):
        """
        :type tasks: List[str]
        :type n: int
        :rtype: int
        """
        task_counts, count_of_counts = Counter(), Counter()
        max_task_count = 0
        for task in tasks:
            task_counts[task] += 1
            max_task_count = max(max_task_count, task_counts[task])
        
        for char in task_counts:
            count_of_counts[task_counts[char]] += 1
        
        return max(len(tasks), max_task_count + (max_task_count-1) * n + count_of_counts[max_task_count]-1)

#Q2 Gas Station

'''

There are n gas stations along a circular route, where the amount of gas at the ith station is gas[i].

You have a car with an unlimited gas tank and it costs cost[i] of gas to travel from the ith station to its next (i + 1)th station. You begin the journey with an empty tank at one of the gas stations.

Given two integer arrays gas and cost, return the starting gas station's index if you can travel around the circuit once in the clockwise direction, otherwise return -1. If there exists a solution, it is guaranteed to be unique

 

Example 1:

Input: gas = [1,2,3,4,5], cost = [3,4,5,1,2]
Output: 3
Explanation:
Start at station 3 (index 3) and fill up with 4 unit of gas. Your tank = 0 + 4 = 4
Travel to station 4. Your tank = 4 - 1 + 5 = 8
Travel to station 0. Your tank = 8 - 2 + 1 = 7
Travel to station 1. Your tank = 7 - 3 + 2 = 6
Travel to station 2. Your tank = 6 - 4 + 3 = 5
Travel to station 3. The cost is 5. Your gas is just enough to travel back to station 3.
Therefore, return 3 as the starting index.
Example 2:

Input: gas = [2,3,4], cost = [3,4,3]
Output: -1
Explanation:
You can't start at station 0 or 1, as there is not enough gas to travel to the next station.
Let's start at station 2 and fill up with 4 unit of gas. Your tank = 0 + 4 = 4
Travel to station 0. Your tank = 4 - 3 + 2 = 3
Travel to station 1. Your tank = 3 - 3 + 3 = 3
You cannot travel back to station 2, as it requires 4 unit of gas but you only have 3.
Therefore, you can't travel around the circuit once no matter where you start.
 

Constraints:

n == gas.length == cost.length
1 <= n <= 105
0 <= gas[i], cost[i] <= 104

'''
#Solution 


# Method-1
# greedy
class Solution:
    def canCompleteCircuit(self, gas: List[int], cost: List[int]) -> int:
        first_station = 0
        available_gas = 0
        gas_cost_diff = 0
        for i in range(len(gas)):
            gas_cost_diff = gas_cost_diff + gas[i] - cost[i]
            available_gas = available_gas + gas[i] - cost[i]
            if available_gas < 0:
                available_gas = 0
                first_station = i + 1
        if gas_cost_diff >= 0:
            return first_station
        else:
            return -1

# Method-2
# BruteForce | Greedy | Inteview POV

# Pls solve JumpGame i,ii,iii before attempting this problem.
# If we are blank/stuck when such questions are asked think about the base/invalid conditions.Lets see what are all the handful of cases that we can intuitivly solve

# When the pertol_in_Tank+gas[index]<cost[index] ----> Cannot be a potential starting point as we cannot move to the next location.
# sum(gas)<sum(cost) , we cannot cover all the gas stations , hence return -1 directly.
# Based on the above points , lets try to solve/consider the potential Candidate at each index and lets see if that index is taking us to the solution.

class Solution:
    def canCompleteCircuit(self, gas: List[int], cost: List[int]) -> int:
        #BruteForce
        i=0
        while i<len(gas):
            petrolInTruck=0
            possibleCandidate=False
            if gas[i]>=cost[i]:
                possibleCandidate=True
                possibleStartingPoint=i
                while(possibleCandidate):
                    if(petrolInTruck+gas[j]>=cost[j]):
                        petrolInTruck=(petrolInTruck+gas[j])-cost[j]
						#For circular tour
                        possibleStartingPoint=(possibleStartingPoint+1)%(len(gas))
                        if possibleStartingPoint==i:
                            return possibleStartingPoint
                    else:
                        possibleCandidate=False
            i=i+1
        return -1  
 

# Method-3

# Alright , now we have solved the bruteForce and we are bit happy now, Lets move on to the optimal solution.
# Points to consider
# 1.It will always give us the solution.
# 2.Details that we have now pertolInTank,gas[index],cost[i],
# Based on the above brute force solution , can u form the potential starting point ?
# Yes, we can .
# Once it is formed , keep iterating to the next gasStation by constantly updating the pertol_in_tank
# and the moment when petrol_in_tank+gas[index]<cost[i]
# we can assume that the potential starting point to be index+1 and update if it is not .
# By this we can form the some basic idea ,

class Solution:
    def canCompleteCircuit(self, gas: List[int], cost: List[int]) -> int:
        if sum(gas)<sum(cost):
            return -1
        petrolInTruck=0
        startingPosition=0
        for i in range(len(cost)):
            if (petrolInTruck+gas[i])-cost[i]<0:
                petrolInTruck=0
                startingPosition=i+1
            else:
                petrolInTruck=(petrolInTruck+gas[i])-cost[i]
        return startingPosition


# Method-4    
# presum + two pass O(N)

# Just to share my solution with presum and then two pass, it's not as elegant as the one in solution section, but another point of view to see this question.

class Solution:
    def canCompleteCircuit(self, gas: List[int], cost: List[int]) -> int:
        # to be a start station need gas[i]>cost[i]
        # let margin m[i]=gas[i]-cost[i], 
        # start at i to get to j need sum(m[i:j])>=0, i.e. presum[k]>=presum[i] for k =i+1:j+1 when i< j < n
                                # and presum[n]+presum[j]>=presum[i] when j < i
        # two greedy pass and intersect O(2N), space O(N)
        
        n = len(gas)
        if n != len(cost): # wrong input
            return -1
        
        margin = [gas[i] - cost[i] for i in range(n)]
        
        presum = list(itertools.accumulate(margin, initial = 0))
        #presum[i] = 0:i up to i-1
        
        if presum[-1] < 0: # total sum is neg, cannot finish
            return -1
        
        # condition 1: candidate i can reach i+1 to n (0)
        # i.e. presum[k]>=presum[i] for k =i+1:j+1 when i< j <= n
        # has to be the so far smallest when scan from end, so can reach 0
        candidate_set1 = set()
        cur_min = presum[n]
        for i in range(n - 1, -1, -1):
            if presum[i] <= cur_min:
                candidate_set1.add(i)
                cur_min = presum[i]
        
        if 0 in candidate_set1: # means 0 can reach 1->n(0 self) a loop
            return 0
        
        # condition 2, candidate i can reach 1 to i - 1, bc total_sum is non-neg so then can reach i
        # has to meet presum[n]+presum[j]>=presum[i] for all 1 <= j < i,
        candidate_set2 = set()
        cur_min = presum[n] + presum[0]
        for i in range(1, n):
            if presum[i] <= cur_min:
                candidate_set2.add(i)
            cur_min = min(cur_min, presum[n] + presum[i])
        
        return list(candidate_set1 & candidate_set2)[0]
                
# Method-5

# As for the prob, it's equals to find a position i satisfies the condition that for j (j=i,i+1,...,l-1,0,1,...i-1) and
# sigma(gas[k]-cost[k]) >= 0 (k=i to j). It maybe confused here. But we may think it more deeply. If one position
# i satisfies the condition, any position p that can reach i MUST satisfy it. However, the prob claims that the
# position is unique if have. We CAN go on looking for the position at the failed position. Every point could
# never be scanned more than twice. The complexity is O(n) in general. Here is my code.;)

class Solution:
    # 134
    # @param {integer[]} gas
    # @param {integer[]} cost
    # @return {integer}
    def canCompleteCircuit(self, gas, cost):
        l = len(gas)
        cur = 0
        while cur<l:
            pos = cur
            bj = cur
            cnt = 0
            while True:
                if cnt + gas[cur] < cost[cur]:
                    break
                cnt = cnt + gas[cur] - cost[cur]
                cur = (cur + 1) % l
                if cur == pos: return pos
            if cur < bj: break
            cur += 1

        return -1


#Q3 Minimum Time to Make Rope Colorful

'''
Alice has n balloons arranged on a rope. You are given a 0-indexed string colors where colors[i] is the color of the ith balloon.

Alice wants the rope to be colorful. She does not want two consecutive balloons to be of the same color, so she asks Bob for help. Bob can remove some balloons from the rope to make it colorful. You are given a 0-indexed integer array neededTime where neededTime[i] is the time (in seconds) that Bob needs to remove the ith balloon from the rope.

Return the minimum time Bob needs to make the rope colorful.

 

Example 1:


Input: colors = "abaac", neededTime = [1,2,3,4,5]
Output: 3
Explanation: In the above image, 'a' is blue, 'b' is red, and 'c' is green.
Bob can remove the blue balloon at index 2. This takes 3 seconds.
There are no longer two consecutive balloons of the same color. Total time = 3.
Example 2:


Input: colors = "abc", neededTime = [1,2,3]
Output: 0
Explanation: The rope is already colorful. Bob does not need to remove any balloons from the rope.
Example 3:


Input: colors = "aabaa", neededTime = [1,2,3,4,1]
Output: 2
Explanation: Bob will remove the ballons at indices 0 and 4. Each ballon takes 1 second to remove.
There are no longer two consecutive balloons of the same color. Total time = 1 + 1 = 2.
 

Constraints:

n == colors.length == neededTime.length
1 <= n <= 105
1 <= neededTime[i] <= 104
colors contains only lowercase English letters.

'''
#Solution 

# Method-1
# 100% O(n) time O(1) space

class Solution:
	def minCost(self, colors: str, neededTime: List[int]) -> int:
		pval = 0
		prev = 0
		ln = len(colors)
		for i in range(1,ln):
			if colors[i] == colors[prev]:
				if neededTime[i] > neededTime[prev]:
					pval += neededTime[prev]
					prev = i
				else:
					pval += neededTime[i]
			else:
				prev = i
		return pval
    
    
# Method-2
# 1-D DP
# dynamic programming

class Solution:
	def minCost(self, colors: str, neededTime: List[int]) -> int:
		arr_len = len(colors)
		dp = [0]*arr_len
		for i in range(1,arr_len):
			if colors[i] != colors[i-1]:
				dp[i] = dp[i-1]
			elif neededTime[i-1]< neededTime[i]:
				dp[i] = dp[i-1]+min(neededTime[i],neededTime[i-1])
			else:
				dp[i] = dp[i-1]+min(neededTime[i],neededTime[i-1])
				neededTime[i],neededTime[i-1] = neededTime[i-1],neededTime[i]
		return dp[-1]

    
# Method-3   
# Min Heap & While Loops

class Solution:
    def minCost(self, colors: str, neededTime: List[int]) -> int:
        
        min_time = 0
        
        i = 0
                
        while i < len(colors) - 1:
            if colors[i] == colors[i + 1]:
                count = 0
                heap = []
                while i < len(colors) - 1 and colors[i] == colors[i + 1]:
                    heap.append(neededTime[i])
                    count += 1
                    i += 1
                heap.append(neededTime[i])
                
                heapify(heap)
                
                while count > 0:
                    min_time += heappop(heap)
                    count -= 1
              
            i += 1 
            
        return min_time


# Method-4

class Solution:
    def minCost(self, s: str, cost: List[int]) -> int:
        if len(cost) <= 1:
            return 0
        ans = 0
        start, end = 0, 1 
        while end < len(s):
            if s[start] == s[end]:
                if cost[start] <= cost[end]:
                    ans += cost[start]
                    start = end
                else:
                    ans += cost[end]
            else:
                 start = end
            end += 1
        return ans


#Method-5

# stack based solution


class Solution:
    def minCost(self, st: str, cost: List[int]) -> int:
        totalcost = 0
        s = [(x, cost[idx]) for idx, x in enumerate(st)]
        while (len(s) > 1):
            cur = s.pop()
            nxt = s.pop()
            if (cur[0] == nxt[0]):
                if (cur[1] < nxt[1]):
                    totalcost = totalcost + cur[1]
                    s.append(nxt)
                else:
                    totalcost = totalcost + nxt[1]
                    s.append(cur)
            else:
                s.append(nxt)
        return totalcost
    


#Q4 Maximum Number of Events That Can Be Attended
'''

You are given an array of events where events[i] = [startDayi, endDayi]. Every event i starts at startDayi and ends at endDayi.

You can attend an event i at any day d where startTimei <= d <= endTimei. You can only attend one event at any time d.

Return the maximum number of events you can attend.

 

Example 1:


Input: events = [[1,2],[2,3],[3,4]]
Output: 3
Explanation: You can attend all the three events.
One way to attend them all is as shown.
Attend the first event on day 1.
Attend the second event on day 2.
Attend the third event on day 3.
Example 2:

Input: events= [[1,2],[2,3],[3,4],[1,2]]
Output: 4
 

Constraints:

1 <= events.length <= 105
events[i].length == 2
1 <= startDayi <= endDayi <= 105

'''
#Solution 


#Method-1
# heap

class Solution:
    def maxEvents(self, events: List[List[int]]) -> int:
        events.sort() # sort by start time
        
        q, i, res = [], 0, 0
        for day in range(1, 100001):
            # for each day, add the active events' end time into q
            while i < len(events) and events[i][0] == day:
                heappush(q, events[i][1])
                i += 1
                
            # pop out the overdue (events' end time)
            while q and q[0] < day:
                heappop(q)
            
            # if there remain events, pop one out and update res
            if q: 
                heappop(q)
                res += 1
        return res

#Method-2
# Heap | Time O(NlogN)


class Solution:
    def maxEvents(self, events: List[List[int]]) -> int:
        # Solution - attend event with recent end from current day
        # Time - O(NlogN)
        # Space - O(N)
        
        events.sort()
        heap = []
        lastDay = max(events, key=lambda x: x[1])[1]
        
        i = 0
        attended = 0
        for curDay in range(1, lastDay + 1):
            
            while i < len(events) and events[i][0] == curDay:
                heapq.heappush(heap, events[i][1])
                i += 1
            
            while heap and heap[0] < curDay:
                heapq.heappop(heap)
            
            if heap:
                heapq.heappop(heap)
                attended += 1
        
        return attended

#Method-3
# Sorting | Time O(NlogN)

class Solution1:
    # TLE - attend event on last possible date of event
    # Time - O(NlogN) + O(N*(S-E))
    #     - N - no of events
    #     - E - end of event
    #     - S - start of event
    # Space - O(N)
    
    def maxEvents(self, events: List[List[int]]) -> int:
        days = [0] * ((10**5)+1)
        
        events.sort(key = lambda x: (-1*x[0], x[1]))
        
        count = 0
        
        for s, e in events:
            for day in reversed(range(s, e+1)):
                if days[day] == 0:
                    days[day] = 1
                    count += 1
                    break
        
        return count
    
#Method-4

# annotations priority queue no day increment

from heapq import heappop, heappush

class Solution:
    def maxEvents(self, events: List[List[int]]) -> int:
        events = sorted(events)
        start = 0
        on_heap = 0
        day = 0
        h = []
        attended, missed = [], []
        while start < len(events):
            day = max(events[start][0], day + 1)
            # print('day', day)
            # push all boxes with start <= day onto heap
            while on_heap < len(events) and events[on_heap][0] <= day:
                e = events[on_heap]
                heappush(h, (e[1], e))
                on_heap += 1

            # take box off heap
            cont = True
            while cont and h:
                attend = heappop(h)
                if attend[1][1] >= day:
                    # print('attended', attend[1])
                    attended.append(attend[1])
                    cont = False
                else:
                    # print('missed', attend[1])
                    missed.append(attend[1])
                    cont = True
            start += 1
        # print('attended', attended)
        # print('missed', missed)
        return len(attended) 
    
# Method-5    
# Greedy

# Here, I am using greedy approach to solve this problem. Sorting the array according to finish time, gives idea in choosing right events.

class Sloution:
    def maxEvents(self, events: List[List[int]]) -> int:
        # we will use this to store unique day value.
        unique_day = set()
        # First, we will sort the event list w.r.t finish time and start time (for event having same finish time)
        events.sort(key=lambda event: (event[1], event[0]))
        
        # We will check the start in unique day set. if it is not present, we simply add this.
        # else, we will check next start, and will add all start date until we reach to finish date
        for start, finish in events:
            if start not in unique_day:
                unique_day.add(start)
            else:
                temp = start + 1
                while temp in unique_day and temp <= finish:
                    temp += 1
                if temp <= finish:
                    unique_day.add(temp)
        return len(unique_day)


#Q5 Minimum Deletions to Make Character Frequencies Unique

'''
A string s is called good if there are no two different characters in s that have the same frequency.

Given a string s, return the minimum number of characters you need to delete to make s good.

The frequency of a character in a string is the number of times it appears in the string. For example, in the string "aab", the frequency of 'a' is 2, while the frequency of 'b' is 1.

 

Example 1:

Input: s = "aab"
Output: 0
Explanation: s is already good.
Example 2:

Input: s = "aaabbbcc"
Output: 2
Explanation: You can delete two 'b's resulting in the good string "aaabcc".
Another way it to delete one 'b' and one 'c' resulting in the good string "aaabbc".
Example 3:

Input: s = "ceabaacb"
Output: 2
Explanation: You can delete both 'c's resulting in the good string "eabaab".
Note that we only care about characters that are still in the string at the end (i.e. frequency of 0 is ignored).
 

Constraints:

1 <= s.length <= 105
s contains only lowercase English letters.

'''

#Solution 

#  Method-1
# Dict | Sort | Reverse

class Solution:
    def minDeletions(self, s: str) -> int:
        dict_ele = {}
        for ele in s : 
            try: 
                dict_ele[ele] +=1 
            except: 
                dict_ele[ele] = 1
        list_values = list(dict_ele.values())
        list_values.sort()
        list_values.reverse()
        i = 0
        count =0
        while(i<len(list_values)-1 and list_values[i]!=0):
            j = i+1
            while(j<len(list_values) and list_values[i]==list_values[j]):
                list_values[j]-=1
                count +=1 
                j+=1
            i+=1
        return count    
    
#  Method-2    
class Solution:
    def minDeletions(self, s: str) -> int:
        limit, res = float("inf"), 0
        for n in sorted(Counter(s).values(), reverse=True):            
            if n <= limit:
                limit = n - 1
            else:
                res += n - limit
                limit = max(limit - 1, 0)
        return res
 

#  Method-3    
# dictionary

class Solution:
    def minDeletions(self, s: str) -> int:
        
        c = Counter(s) 
        
        seen = set() 
        ans = 0 
        for k,v in c.items():
            if v not in seen:
                seen.add(v) 
            else:
                while c[k] in seen and c[k] > 0 :
                    c[k] -= 1 
                    ans += 1 
                    
                seen.add(c[k])
                        
        return ans
    
#  Method-4

#Approach is simple
#Firstly, for each element in sorted array of count
#Find the number of positions available smaller than the value
# (this work is done by Find function defined below)
#Decrement that count value and increment our answer variable

def find(l,n):
    l.sort()
    c=0
    for i in range(1,n):
        if(i not in l):
            c+=1
    return c        
class Solution:
    def minDeletions(self, s: str) -> int:
        s=list(s)
        c=collections.Counter(s)
        l=[]
        for i in c:
            l.append(c[i])    
        available=collections.defaultdict(int)
        l.sort()
        ans=0
        for i in range(len(l)):
            while(1):
                if(available[l[i]]==0):
                    if(l[i]==0):
                        break
                    else:
                        available[l[i]]=1
                        break
                else:
                    l[i]-=1
                    ans+=1
            
        return ans
    
#  Method-5   
class Solution:
    def minDeletions(self, s: str) -> int:
        
        maps = {}
        
        for x in s :
            if x not in maps :
                maps[x] = 0
            maps[x] += 1
        
        maps = [ [v,k] for k,v in maps.items()]
        maps.sort()
        
        counter = 0
        x = 1
        while x < len(maps) :
            if maps[x-1][0] > 0 :
                if maps[x][0] == maps[x-1][0] :
                    counter += 1
                    maps[x][0] -= 1
                    x -= 2
                    maps.sort()
            x += 1
        
        return counter
            


 #Q6 Remove K Digits
 '''

Given string num representing a non-negative integer num, and an integer k, return the smallest possible integer after removing k digits from num.

 

Example 1:

Input: num = "1432219", k = 3
Output: "1219"
Explanation: Remove the three digits 4, 3, and 2 to form the new number 1219 which is the smallest.
Example 2:

Input: num = "10200", k = 1
Output: "200"
Explanation: Remove the leading 1 and the number is 200. Note that the output must not contain leading zeroes.
Example 3:

Input: num = "10", k = 2
Output: "0"
Explanation: Remove all the digits from the number and it is left with nothing which is 0.
 

Constraints:

1 <= k <= num.length <= 105
num consists of only digits.
num does not have any leading zeros except for the zero itself.
'''

#Solution 


#Method-1

# MONOTONIC STACK (o^^o)

# In order to get the smallest possible number, we have to get rid of as many as possible big digits in the most significant places on the left. We can use a monotonically increasing stack to help us remove those big digits. When adding a new digit, we check whether the previous one is bigger than the current and pop it out. In the end, we concatenate the remaining elements from the stack and return the result.

# Time: O(n) - iteration
# Space: O(n) - stack



class Solution:
    def removeKdigits(self, num: str, k: int) -> str:
        st = list()
        for n in num:
            while st and k and st[-1] > n:
                st.pop()
                k -= 1
            
            if st or n is not '0': # prevent leading zeros
                st.append(n)
                
        if k: # not fully spent
            st = st[0:-k]
            
        return ''.join(st) or '0'
    
    
#Method-2

class Solution:
    def removeKdigits(self, num: str, k: int) -> str:
        if len(num)==k:
            return '0'
        num=list(num)
        ans=[]
        j=0
        for i in range(len(num)):
            while(ans and ans[-1]>num[i] and j<k):
                ans.pop(-1)
                j+=1
            ans.append(num[i])
            #print(ans)
        if j<k:
            ans=ans[:len(ans)-(k-j)]
        k=''.join(ans)
        if len(set(k))==1 and '0' in k:
            return '0'
        k=k.lstrip('0')
        return k

    
#Method-3    
# Brute force (TLE) to O(N) solution...


class Solution:
    def removeKdigits(self, num: str, k: int) -> str:
        
        # O(N2) - TLE
        # the idea is to remove first peak digit each iteration (k times)
        # input => 1432319
        # k = 1 => 132319
        # k = 2 => 12319
        # k = 3 => 1219
        
        if len(num) <= k:
            return "0"
        
        while k > 0:
            j = 0
            while j + 1 < len(num) and num[j] <= num[j+1]:
                # Find the first peak element
                j += 1
            num = num[:j] + num[j+1:]
            k -= 1
        return str(int(num))
    
    
#Method-4    
class Solution:
    def removeKdigits(self, num: str, k: int) -> str:
		 # Using stack
        stack = []

        for i in range(len(num)):
            while stack and stack[-1] > num[i] and k > 0:
                stack.pop()
                k -= 1
            stack.append(num[i])
        
        # if all the elements are equal or peak element is at last 
        # example 111 or 112
        while k > 0:
            stack.pop()
            k -= 1
        
        # If nothing is left in stack, add "0"
        if not stack:
            stack.append("0")
        
        return str(int("".join(stack)))
    
    
    
 #Method-5    
class Solution(object):
    def removeKdigits(self, num, k):
        """
        :type num: str
        :type k: int
        :rtype: str
        """
        from collections import deque

        sta = deque()
        sta.append(num[0])
        index, n = 1, len(num)
        if n == k:
            return '0'
        cnt = k
        while cnt > 0 and index < n:
            x = num[index]
            if x >= sta[-1]:
                if len(sta) < n - k:
                    sta.append(x)
            else:
                while sta and sta[-1] > x and len(sta) + n - index - 1 >= n - k:
                    sta.pop()
                    cnt -= 1
                sta.append(x)
            index += 1

        while index < n:
            sta.append(num[index])
            index += 1
        res = ''.join(list(sta))
        if not res.lstrip('0'):
            return '0'
        else:
            return res.lstrip('0')
        
        
        
 #Method-6 

class Solution(object):
    def removeKdigits(self, num, k):
        """
        :type num: str
        :type k: int
        :rtype: str
        """
        if len(num) <= k: return "0"
        digits = list(num)
        stack = []

        while digits and k:
            if not stack:
                stack.append(digits.pop(0))
            else:
                msd = digits.pop(0)
                while k and stack and stack[-1] > msd:
                        stack.pop()
                        k -= 1
                stack.append(msd)

        while k:
            # digits is empty
            stack.pop()
            k-=1
        
        digits = stack + digits
        # remove leading 0s
        while digits and digits[0] == "0":
            digits.pop(0)
        
        return "0" if not digits else ''.join(digits)

#Q7 Restore the Array From Adjacent Pairs

'''
There is an integer array nums that consists of n unique elements, but you have forgotten it. However, you do remember every pair of adjacent elements in nums.

You are given a 2D integer array adjacentPairs of size n - 1 where each adjacentPairs[i] = [ui, vi] indicates that the elements ui and vi are adjacent in nums.

It is guaranteed that every adjacent pair of elements nums[i] and nums[i+1] will exist in adjacentPairs, either as [nums[i], nums[i+1]] or [nums[i+1], nums[i]]. The pairs can appear in any order.

Return the original array nums. If there are multiple solutions, return any of them.

 

Example 1:

Input: adjacentPairs = [[2,1],[3,4],[3,2]]
Output: [1,2,3,4]
Explanation: This array has all its adjacent pairs in adjacentPairs.
Notice that adjacentPairs[i] may not be in left-to-right order.
Example 2:

Input: adjacentPairs = [[4,-2],[1,4],[-3,1]]
Output: [-2,4,1,-3]
Explanation: There can be negative numbers.
Another solution is [-3,1,4,-2], which would also be accepted.
Example 3:

Input: adjacentPairs = [[100000,-100000]]
Output: [100000,-100000]
 

Constraints:

nums.length == n
adjacentPairs.length == n - 1
adjacentPairs[i].length == 2
2 <= n <= 105
-105 <= nums[i], ui, vi <= 105
There exists some nums that has adjacentPairs as its pairs.

'''
#Solution

# Method-1
# dfs solution


class Solution:
    def restoreArray(self, adj: List[List[int]]) -> List[int]:
        ## RC ##
        ## APPROACH : GRAPH / DFS ##
        graph = collections.defaultdict(list)
        for u,v in adj:
            graph[u].append(v)
            graph[v].append(u)
        
        first = None
        for u in graph:
            if len(graph[u]) == 1:
                first = u
                break
        
        res = []
        visited = set()
        def dfs(node):
            if node in visited:
                return
            visited.add(node)
            res.append(node)
            for nei in graph[node]:
                dfs(nei)
        dfs(first)
        return res
    
    
#Method-2


# Create a double linked node for each value
# If node for this value already exist, get the node by value, and link new created node to this node
# After all node is linked, find one not fully linked(one of child is None) node as head, traverse over linked node

# I know my code is not good, can anyone suggest how could I improve the way I am coding?

# Why I come up with this idea, how should I think to get the right direction.

class DoubleLinkedNode:
    def __init__(self, val):
        self.val = val
        self.pre = None
        self.next = None

class Solution:
    def restoreArray(self, adjacentPairs: List[List[int]]) -> List[int]:
        
        mp = {}
        
        for d1,d2 in adjacentPairs:
            if d1 in mp and d2 in mp:
                node1 = mp[d1]
                node2 = mp[d2]
                
                if node1.pre:
                    node1.next = node2
                else:
                    node1.pre = node2
                
                if node2.pre:
                    node2.next = node1
                else:
                    node2.pre = node1
            elif d1 in mp:
                node = mp[d1]
                node2 = DoubleLinkedNode(d2)
                mp[d2] = node2
                node2.pre = node
                if node.pre:
                    node.next = node2
                else:
                    node.pre = node2
            
            elif d2 in mp:
                node = mp[d2]
                node2 = DoubleLinkedNode(d1)
                mp[d1] = node2
                node2.pre = node
                if node.pre:
                    node.next = node2
                else:
                    node.pre = node2
            else:
                node1 = DoubleLinkedNode(d1)
                node2 = DoubleLinkedNode(d2)
                node1.pre = node2
                node2.pre = node1
                mp[d1] = node1
                mp[d2] = node2
                
        cur = None
        for node in mp.values():
            if node.pre is None or node.next is None:
                cur = node
                break
        ans = []
        visited = set()
        while cur:
            ans.append(cur.val)
            visited.add(cur)
            if cur.pre and (cur.pre not in visited):
                cur = cur.pre
            elif cur.next and (cur.next not in visited):
                cur = cur.next
            else:
                cur = None
                
        
        return ans
    
    
#Method-3
# O(n)

# the trick is to find one of the two ends, and just go from there until the other end

class Solution:
    def restoreArray(self, adjacentPairs: List[List[int]]) -> List[int]:
        dct=collections.defaultdict(set)
        for a,b in adjacentPairs:
            dct[a].add(b)
            dct[b].add(a)
        res=[]
        seen=set()
        for el in dct:
            if len(dct[el])==1:
                cur=el
                seen.add(cur)
                res.append(cur)
                for _ in range(len(adjacentPairs)):
                    for el in dct[cur]:
                        if el not in seen:
                            cur=el
                            res.append(cur)
                            seen.add(cur)
                return res

#Method-4
# use dictionary straight forward solution


class Solution(object):
    def restoreArray(self, adjacentPairs):
        """
        :type adjacentPairs: List[List[int]]
        :rtype: List[int]
        """
        # find end points and prepare a neighbor dictionary
        d, ends = defaultdict(list), set()
        for x, y in adjacentPairs:
            d[x] += [y]
            d[y] += [x]
            if x in ends:
                ends.remove(x)
            else:
                ends.add(x)
            if y in ends:
                ends.remove(y)
            else:
                ends.add(y)    
        # restore nums
        start, end = list(ends)
        res = [start]
        while res[-1] != end:
            res += [x for x in d[res[-1]] if len(res) <= 1 or x != res[-2]]
        return res
    
#Method-5
# dictionary

#1743. Restore the Array From Adjacent Pairs
class Solution():
	def restoreArray(self, adjacentPairs):
		d={}
		for i, j in adjacentPairs:
			d[i]=d.get(i, [])+[j] # bracket is needed
			d[j]=d.get(j, [])+[i] # bracket is needed

		for i in d:
			if len(d[i])==1:
				current_pointer = i
				break

		ans=[]
		seen=set()

		while current_pointer != None:
			ans.append(current_pointer)
			seen.add(current_pointer)
			neighbors = d[current_pointer]
			current_pointer = None

			for neighbor in neighbors:
				if neighbor not in seen:
					current_pointer = neighbor

		return ans
        


#Q8 Non-overlapping Intervals
'''

Given an array of intervals intervals where intervals[i] = [starti, endi], return the minimum number of intervals you need to remove to make the rest of the intervals non-overlapping.

 

Example 1:

Input: intervals = [[1,2],[2,3],[3,4],[1,3]]
Output: 1
Explanation: [1,3] can be removed and the rest of the intervals are non-overlapping.
Example 2:

Input: intervals = [[1,2],[1,2],[1,2]]
Output: 2
Explanation: You need to remove two [1,2] to make the rest of the intervals non-overlapping.
Example 3:

Input: intervals = [[1,2],[2,3]]
Output: 0
Explanation: You don't need to remove any of the intervals since they're already non-overlapping.
 

Constraints:

1 <= intervals.length <= 105
intervals[i].length == 2
-5 * 104 <= starti < endi <= 5 * 104

'''
#Solution

#Method-1

class Solution:
    def eraseOverlapIntervals(self, intervals: List[List[int]]) -> int:
        intervals.sort(key = lambda x: x[1])
        removed = 0
        for i in range(1, len(intervals)):
            if intervals[i][0] < intervals[i-1][1]:
                removed += 1
                intervals[i] = intervals[i-1]
                
        return removed 
    
    
#Method-2

# Greedy Python Solution


class Solution:
    def eraseOverlapIntervals(self, intervals: List[List[int]]) -> int:
        
        def nonlap_interval(intvs):
            # return the maximum number of non-overlapping intervals
            if not intvs:
                return 0
            
            # sort by the end
            intvs.sort(key=lambda x:x[1])
            
            # initialize the first interval
            count = 1
            pre_end = intvs[0][1]
            for intv in intvs:
                if intv[0] >= pre_end:
                    count += 1
                    pre_end = intv[1]
                    
            return count
            
        return len(intervals) - nonlap_interval(intervals)
    
    
#Method-3
# greedy approach

class Solution:
    def eraseOverlapIntervals(self, intervals: List[List[int]]) -> int:
        #sorting the intervals by start value.If there is tie such as starts areb equal then sorting by end 
        intervals.sort()
        res = 0
        
        #Using the 1st end value as base case to start checking
        prevEnd = intervals[0][1]
        
        #Iterating after the 1st interval
        for start, end in intervals[1:]:
            #Check if 2nd start is greater than 1st end.Then moving forward and iterating similarly
            if start >= prevEnd:
                #If not overlapping
                prevEnd = end
            else:
                res += 1
                #Overlapping
                prevEnd = min(end, prevEnd)
        return res

#Method-4

class Solution:
    def eraseOverlapIntervals(self, intervals: List[List[int]]) -> int:
        if not intervals:
            return 0
        intervals = sorted(intervals, key = lambda x: x[1])
        curr = - float('inf')
        count = 0
        for i in range(len(intervals)):
            if intervals[i][0] >= curr:
                curr = intervals[i][1]
                count += 1
        return len(intervals) - count
    
#Method-5

        
class Solution:
    def eraseOverlapIntervals(self, intervals: List[List[int]]) -> int:
        intervals.sort()
        stop = len(intervals)
        p = 0
        for _ in range(stop-1):
            if intervals[p][1] > intervals[p+1][0]:
                if intervals[p][1] <= intervals[p+1][1]:
                    intervals.pop(p+1)
                else:
                    intervals.pop(p)
            else:
                p += 1
            
        return stop - len(intervals)


#Q9 Candy

'''
There are n children standing in a line. Each child is assigned a rating value given in the integer array ratings.

You are giving candies to these children subjected to the following requirements:

Each child must have at least one candy.
Children with a higher rating get more candies than their neighbors.
Return the minimum number of candies you need to have to distribute the candies to the children.

 

Example 1:

Input: ratings = [1,0,2]
Output: 5
Explanation: You can allocate to the first, second and third child with 2, 1, 2 candies respectively.
Example 2:

Input: ratings = [1,2,2]
Output: 4
Explanation: You can allocate to the first, second and third child with 1, 2, 1 candies respectively.
The third child gets 1 candy because it satisfies the above two conditions.
 

Constraints:

n == ratings.length
1 <= n <= 2 * 104
0 <= ratings[i] <= 2 * 104

'''
#Solution

#Method-1

class Solution:
    def candy(self, ratings: List[int]) -> int:
        candies=[1]*len(ratings)
        if len(ratings)==1:
            return 1
        for i in range(1,len(ratings)):
            if ratings[i]>ratings[i-1] and candies[i]<=candies[i-1]:
                candies[i]=candies[i-1]+1
        for j in range(len(ratings)-2,-1,-1):
            if ratings[j]>ratings[j+1] and candies[j]<=candies[j+1]:
                candies[j]=candies[j+1]+1
        return sum(candies)
        
#Method-2

class Solution:
    def candy(self, ratings: List[int]) -> int:
        length = len(ratings)
        candies = [1] * length
        for i in range(1, length):
            if ratings[i] > ratings[i-1] and candies[i] <= candies[i-1]:
                candies[i] = candies[i-1] + 1
        for i in range(length - 2, -1, -1):
            if ratings[i] > ratings[i + 1] and candies[i] <= candies[i+1]:
                candies[i] = candies[i+1] + 1
        return sum(candies)
    
#Method-3

# Approach 1: Brute -force to Optimal 

class Solution:
    def candy(self, ratings: List[int]) -> int:
    
        ans1,ans2,res=[1]*len(ratings),[1]*len(ratings),[]
        for i in range(1,len(ratings)):
            if ratings[i]>ratings[i-1]:
                ans1[i]=ans1[i-1]+1
            
        for i in range(len(ratings)-2,-1,-1):
            if ratings[i]>ratings[i+1]:
                ans2[i]=ans2[i+1]+1
        
        for j in range(len(ratings)):
            r=max(ans1[j],ans2[j])
            res.append(r)
        return sum(res)
    
#Method-4
class Solution:
    # @param {integer[]} ratings
    # @return {integer}
    def candy(self, ratings):
        n = len(ratings)
        if n == 0: return 0
        f = [1 for i in range(n)]
        for i in range(1, n):
            if ratings[i] > ratings[i-1]:
                f[i] = max(f[i], f[i-1] + 1) 
        f.reverse()
        ratings.reverse()
        for i in range(1, n):
            if ratings[i] > ratings[i-1]:
                f[i] = max(f[i], f[i-1] + 1) 
        ans = 0
        for i in f:
            ans += i
        return ans
    
#Method-5
class Solution(object):
    def candy(self, a):
        length = len(a)
        left, right = [1 for i in range(length)], [1 for i in range(length)]
        for i in range(length-1):
            if a[i] < a[i+1]: left[i+1] = (left[i] + 1)
            if a[length-i-1] < a[length-i-2]: right[length-i-2] = (right[length-i-1] + 1)
        return sum([max(x,y) for x,y in zip(left, right)])



#Q10.Minimum Number of Taps to Open to Water a Garden
'''


There is a one-dimensional garden on the x-axis. The garden starts at the point 0 and ends at the point n. (i.e The length of the garden is n).

There are n + 1 taps located at points [0, 1, ..., n] in the garden.

Given an integer n and an integer array ranges of length n + 1 where ranges[i] (0-indexed) means the i-th tap can water the area [i - ranges[i], i + ranges[i]] if it was open.

Return the minimum number of taps that should be open to water the whole garden, If the garden cannot be watered return -1.

 

Example 1:


Input: n = 5, ranges = [3,4,1,1,0,0]
Output: 1
Explanation: The tap at point 0 can cover the interval [-3,3]
The tap at point 1 can cover the interval [-3,5]
The tap at point 2 can cover the interval [1,3]
The tap at point 3 can cover the interval [2,4]
The tap at point 4 can cover the interval [4,4]
The tap at point 5 can cover the interval [5,5]
Opening Only the second tap will water the whole garden [0,5]
Example 2:

Input: n = 3, ranges = [0,0,0,0]
Output: -1
Explanation: Even if you activate all the four taps you cannot water the whole garden.
 

Constraints:

1 <= n <= 104
ranges.length == n + 1
0 <= ranges[i] <= 100


'''

#Solution

# Method-1
# greedy
# dynamic programming.

class Solution:
    def minTaps(self, n: int, ranges: List[int]) -> int:
        dp=[0 for i in range(n+1)]
        dp2=[0 for i in range(n+1)]
        for i,v in enumerate(ranges):
            l=max(0,i-v)
            r=min(n,i+v)
            dp[l]=max(dp[l],r-l)
        l=n+1
        for i in range(l-2,-1,-1):
            if i+dp[i]>=l-1:
                dp2[i]=1
            elif dp[i]==0:
                dp2[i]=float('inf')
            else:
                dp2[i]=min(dp2[i+1:i+dp[i]+1])+1
        return dp2[0] if dp2[0]!= float('inf') else -1
    
#Method-2

# LIS approach
# binary-search

class Solution:
    def minTaps(self, n: int, ranges: List[int]) -> int:
        maxRanges = [0]
        for i in range(len(ranges)):
            minIdx = max(i - ranges[i], 0)
            maxIdx = min(i + ranges[i], n)
            idx = bisect_left(maxRanges, minIdx)
            if idx == len(maxRanges) or maxIdx <= maxRanges[idx]: continue
            if idx == len(maxRanges) - 1:
                maxRanges.append(maxIdx)
            else:
                maxRanges[idx + 1] = max(maxRanges[idx + 1], maxIdx)
        if maxRanges[-1] < n:
            return -1
        else:
            return len(maxRanges) - 1
        
#Method-3

# greedy
# o(n)
class Solution:
    def minTaps(self, n: int, ranges: List[int]) -> int:
        taps = [0] * len(ranges) 
        for i,r in enumerate(ranges):
            left = max(0, i - r)
            taps[left] = max(taps[left], i + r)

        total = reach = nextReach = 0
        for i, r in enumerate(taps):
            nextReach = max(nextReach, r)
            
            if i == reach:
                if nextReach == reach: return -1
                
                total += 1
                reach = nextReach
                if (nextReach >= n): break
        
        return total

#Method-4

# You start off making sure you can cover the current target, the space at 0. Look for the tap which covers the current target and find the one which extends the furthest. While searching through the taps, remove any which already don't go far enough, since they definitely won't be needed later. For the tap which reaches the furthest, make that space the next target and repeat again until you reach the goal. If there are no taps which cover the current goal, return -1.


class Solution:
    def minTaps(self, n: int, ranges: List[int]) -> int:
        tap_ranges = [[i - ranges[i], i + ranges[i]] for i in range(n+1) if ranges[i] > 0]
        
        curr_target = 0      
        taps_used = 0
        
        while curr_target < n:
            good_taps = []
            i = 0
            while i < len(tap_ranges):
                if tap_ranges[i][1] <= curr_target:
                    del tap_ranges[i]
                elif tap_ranges[i][0] <= curr_target:
                    good_taps.append(i)
                    i += 1
                else:
                    i += 1
            if len(good_taps) == 0:
                
                return -1
            
            curr_target = max([ tap_ranges[tap][1] for tap in good_taps])
            taps_used += 1
        
        return taps_used

#Method-5
# dynamic programming
# greedy   
# O(n) 

class Solution:
    def minTaps(self, n: int, ranges: List[int]) -> int:
		# Holds the maximum right bound of intervals starting on a given index
        max_rights = [0] * (n + 1)
        for i, r in enumerate(ranges):
            left = max(0, i - r)
            max_rights[left] = max(max_rights[left], i + r)
        idx = 0  # current index in max_rights
        ans = 0  # number of opened taps
        pos = 0  # current position
        best_right = 0  # farther right we can go from current position
        while pos < n:
            while idx <= pos:
                best_right = max(best_right, max_rights[idx])
                idx += 1
            if best_right <= pos:
                return -1
            ans += 1
            pos = best_right
        return ans
    
    
# For example, if range[1] = 2, I represent that range by the pair (-1, 3), which means it covers the segments [-1, 0], [0, 1], [1, 2], [2, 3], or, equivalently, all segments of size 1 starting at -1, 0, 1, 2. This is therefore equivalent to the "slice" [-1 : 3]. Because I don't care about segments outside the garden, I will trim negative values and only consider [0 : 3].

# From there, I note in the array max_rights[i], the farther right I can reach from a slice starting at index i.

# The greedy algorithm will therefore simply require me to look at all values of max_rights for i before a given position, and look at the maximum among these values. This means I choose to open the tap that will cover the largest surface of the garden after my current position, assuming everything before is already watered.

# Because I don't need to look at indexes I already looked at (as they are all before the current position), this only requires a O(n) algorithm.

# The last point I wanted to raise is about when it's impossible to water the garden. If no interval starting from before the current position ends after the current position, then it's impossible to water the next segment right after the current position, and in that case we can directly return -1.


#Q11.  Create Maximum Number ( Doub)

'''

You are given two integer arrays nums1 and nums2 of lengths m and n respectively. nums1 and nums2 represent the digits of two numbers. You are also given an integer k.

Create the maximum number of length k <= m + n from digits of the two numbers. The relative order of the digits from the same array must be preserved.

Return an array of the k digits representing the answer.

 

Example 1:

Input: nums1 = [3,4,6,5], nums2 = [9,1,2,5,8,3], k = 5
Output: [9,8,6,5,3]
Example 2:

Input: nums1 = [6,7], nums2 = [6,0,4], k = 5
Output: [6,7,6,0,4]
Example 3:

Input: nums1 = [3,9], nums2 = [8,9], k = 3
Output: [9,8,9]
 

Constraints:

m == nums1.length
n == nums2.length
1 <= m, n <= 500
0 <= nums1[i], nums2[i] <= 9
1 <= k <= m + n

'''

#Solution 

# Method-1
# O(k(m+n))
# monotonically decreasing stack

# This solution is pretty efficient and intuitive.
# Time complexity is O(k(n+m)) where n and m is length of each list.

# To understand this solution you must also do other problems concerning monotonic stack like LC-402 which are pre-requisites for this problem.



class Solution:
    def maxNumber(self, nums1: List[int], nums2: List[int], k: int) -> List[int]:
        def maximum_num_each_list(nums: List[int], k_i: int) -> List[int]:
            # monotonically decreasing stack
            s = []
            m = len(nums) - k_i
            for n in nums:
                while s and s[-1] < n and m > 0:
                    s.pop()
                    m -= 1
                s.append(n)
            s = s[:len(s)-m] # very important
            return s
        def greater(a, b, i , j): # get the number which is lexiographically greater
            while i< len(a) or j < len(b): 
                if i == len(a): return False
                if j == len(b): return True
                if a[i] > b[j]: return True
                if a[i] < b[j]: return False
                i += 1 # we increment until each of their elements are same
                j += 1
        
        def merge(x_num, y_num):
            n = len(x_num)
            m = len(y_num)
            i = 0
            j = 0
            s = []
            while i < n or j < m:
                a = x_num[i] if i < n else float("-inf") 
                b = y_num[j] if j < m else float("-inf") 

                if a > b or greater(x_num, y_num, i , j):
# greater(x_num, y_num, i , j): this function is meant for check which list has element lexicographically greater means it will iterate through both arrays incrementing both at the same time until one of them is greater than other.
                    chosen = a
                    i += 1
                else:
                    chosen = b
                    j += 1
                s.append(chosen)
            return s

        max_num_arr = []
        for i in range(k+1): # we check for all values of k and find the maximum number we can create for that value of k and we repeat this for all values of k and then at eacch time merge the numbers to check if arrive at optimal solution
            first = maximum_num_each_list(nums1, i)
            second = maximum_num_each_list(nums2, k-i)
            merged = merge(first, second)
            # these two conditions are required because list comparison in python only compares the elements even if one of their lengths is greater, so I had to add these conditions to compare elements only if length is equal.
			# Alternatively you can avoid this and convert them both to int and then compare, but I wanted to this as  it is somewhat more efficient.
            if len(merged) == len(max_num_arr) and  merged > max_num_arr:
                max_num_arr = merged
            elif len(merged) > len(max_num_arr):
                max_num_arr = merged
        return max_num_arr
    
    
# Method-2

# Greedy + DP + Segment Tree for Range Query

# dynamic programming
# range query
# segmenttree

from typing import List
from collections import defaultdict


class Node(object):
    def __init__(self, beg, end):
        self.beg = beg
        self.end = end
        self.range_max = None
        self.left = None
        self.right = None

    def is_leaf(self):
        return self.beg == self.end

    def __repr__(self):
        if self.is_leaf():
            return f"{self.beg}: {self.range_max}"
        else:
            return f"{self.beg}~{self.end}: {self.range_max}"

    def query(self, beg, end):
        # Totally out of range
        if beg > self.end or end < self.beg:
            return float("-inf"), -1

        # Query range contains node range
        elif self.beg >= beg and self.end <= end:
            return self.range_max

        # Intersection
        else:
            return max(self.left.query(beg, end), self.right.query(beg, end))


def build_range_tree(a, beg, end):
    node = Node(beg, end)
    if beg == end:
        node.range_max = (a[beg], -beg)
    else:
        mid = (beg + end) // 2
        node.left = build_range_tree(a, beg, mid)
        node.right = build_range_tree(a, mid + 1, end)
        node.range_max = max(node.left.range_max, node.right.range_max)

    return node


def comp_array(a, b, beg_a, beg_b):
    for i, j in zip(range(beg_a, len(a)), range(beg_b, len(b))):
        if a[i] > b[j]:
            return 1
        elif a[i] < b[j]:
            return -1

    if len(a) - beg_a > len(b) - beg_b:
        return 1
    elif len(a) - beg_a < len(b) - beg_b:
        return -1
    else:
        return 0


def merge_2_arrays(a, b, beg_a, beg_b):
    ptr1 = beg_a
    ptr2 = beg_b

    while True:
        if ptr1 == len(a) or ptr2 == len(b):
            break
        comp_res = comp_array(a, b, ptr1, ptr2)
        if comp_res == 1:
            yield a[ptr1]
            ptr1 += 1
        else:
            yield b[ptr2]
            ptr2 += 1

    for i in range(ptr1, len(a)):
        yield a[i]

    for i in range(ptr2, len(b)):
        yield b[i]


def pick_k_numbers(a, tree_a, beg_a, k):
    if k == 0:
        return []
    len_a = len(a) - beg_a
    num_elements_to_drop = len_a - k
    if num_elements_to_drop == 0:
        return a[beg_a:]

    end_a = min(beg_a + num_elements_to_drop, len(a) - 1)

    max_val, max_idx = tree_a.query(beg_a, end_a)
    max_idx = -max_idx

    return [a[max_idx]] + pick_k_numbers(a, tree_a, max_idx + 1, k - 1)


def fetch_dp_table(a, b, tree_a, tree_b, beg_a, beg_b, k, dp_table):

    if k == 0:
        return []

    if (beg_a, beg_b, k) not in dp_table:

        len_a = len(a) - beg_a
        len_b = len(b) - beg_b

        num_elements_to_drop = len_a + len_b - k

        if num_elements_to_drop == 0:
            res = list(merge_2_arrays(a, b, beg_a, beg_b))

        elif len_b == 0:
            res = pick_k_numbers(a, tree_a, beg_a, k)

        elif len_a == 0:
            res = pick_k_numbers(b, tree_b, beg_b, k)

        else:
            end_a = min(beg_a + num_elements_to_drop, len(a) - 1)
            end_b = min(beg_b + num_elements_to_drop, len(b) - 1)

            max_val_a, max_idx_a = (
                tree_a.query(beg_a, end_a) if len_a > 0 else (float("-inf"), -1)
            )
            max_idx_a = -max_idx_a

            max_val_b, max_idx_b = (
                tree_b.query(beg_b, end_b) if len_b > 0 else (float("-inf"), -1)
            )
            max_idx_b = -max_idx_b

            if max_val_a > max_val_b:
                next_vals = fetch_dp_table(
                    a, b, tree_a, tree_b, max_idx_a + 1, beg_b, k - 1, dp_table
                )
                res = [max_val_a] + next_vals
            elif max_val_b > max_val_a:
                next_vals = fetch_dp_table(
                    a, b, tree_a, tree_b, beg_a, max_idx_b + 1, k - 1, dp_table
                )
                res = [max_val_b] + next_vals
            else:
                vala = fetch_dp_table(
                    a, b, tree_a, tree_b, max_idx_a + 1, beg_b, k - 1, dp_table
                )
                valb = fetch_dp_table(
                    a, b, tree_a, tree_b, beg_a, max_idx_b + 1, k - 1, dp_table
                )
                res = [max_val_a] + max(vala, valb)

        dp_table[(beg_a, beg_b, k)] = res
    else:
        pass

    return dp_table[(beg_a, beg_b, k)]


class Solution:
    def maxNumber(self, nums1: List[int], nums2: List[int], k: int) -> List[int]:
        tree_1 = build_range_tree(nums1, 0, len(nums1) - 1)
        tree_2 = build_range_tree(nums2, 0, len(nums2) - 1)
        dp_table = {}
        res = fetch_dp_table(nums1, nums2, tree_1, tree_2, 0, 0, k, dp_table)
        return res


if __name__ == "__main__":
    nums1 = [3,4,6,5]
    nums2 = [9,1,2,5,8,3]
    k = 5
    # res = Solution().maxNumber(nums1, nums2, k)
    # print(res)

    
# Method-3

import functools
class Solution:
    def maxNumber(self, nums1, nums2, k):
        """
        :type nums1: List[int]
        :type nums2: List[int]
        :type k: int
        :rtype: List[int]
        """
        n1,n2 = len(nums1),len(nums2)
        @functools.lru_cache(maxsize=2048)
        def recursive(i,j,k):
            if k == 0:
                return []

            m1 = -1
            if i < n1:
                m1 = max(nums1[i:min(n1,n1+n2-j-k+1)])

            m2 = -1
            if j < n2:
                m2 = max(nums2[j:min(n2,n1+n2-i-k+1)])

            if m1 > m2:
                ii = i + nums1[i:].index(m1) + 1
                return [m1] + recursive(ii,j,k-1)
            elif m2 > m1:
                jj = j + nums2[j:].index(m2) + 1
                return [m2] + recursive(i,jj,k-1)
            else:
                ii = i + nums1[i:].index(m1) + 1
                jj = j + nums2[j:].index(m2) + 1
                ans1 = [m1] + recursive(ii,j,k-1)
                ans2 = [m2] + recursive(i,jj,k-1)

                for a1,a2 in zip(ans1,ans2):
                    if a1 > a2:
                        return ans1
                    elif a2 > a1:
                        return ans2

                return ans1
        
        return recursive(0,0,k)
    
# Method-4
class Solution(object):
    def maxNumber(self, nums1, nums2, k):
        """
        :type nums1: List[int]
        :type nums2: List[int]
        :type k: int
        :rtype: List[int]
        """
        def helper(nums, slice_length):
            ans = []
            len_num = len(nums)
            for idx, val in enumerate(nums):
                while ans and ans[-1] < val and len_num - idx > slice_length - len(ans):
                    ans.pop()
                if len(ans) <= slice_length:
                    ans.append(val)
            return ans
        l1, l2 = len(nums1), len(nums2)
        #   0 <= sl < l1 + 1
        #   0 <= k - sl < l2 + 1  => sl >= max(0, k - l2)
        rs = []
        for sl in range(max(0, k - l2), l1 + 1):
            p1, p2 = helper(nums1, sl), helper(nums2, k - sl)
            rs = max(rs, [max(p1, p2).pop(0) for _ in range(k)])
        return rs
    
    
# Method-5

import math

class RMQ(object):
    def __init__(self, nums):
        self.nums = nums
        n = len(nums)
        if n:
            d = int(math.log(n, 2)) + 1;
            self.table = [[-1 for _ in range(n)] for _ in range(d)]
            for j in range(n):
                self.table[0][j] = j;
            for i in range(1, d):
                for j in range(n - (1 << i) + 1):
                    i1 = self.table[i-1][j]
                    i2 = self.table[i-1][j+(1<<(i-1))]
                    if nums[i1] >= nums[i2]:
                        self.table[i][j] = i1
                    else:
                        self.table[i][j] = i2

    def get(self, left, right):
        if right < left:
            return -1
        l = right - left + 1
        d = int(math.log(l, 2))
        i1 = self.table[d][left]
        i2 = self.table[d][right+1-(1<<d)]
        if self.nums[i1] >= self.nums[i2]:
            return i1
        return i2

class Solution(object):
    def maxNumber(self, nums1, nums2, k):
        """
        :type nums1: List[int]
        :type nums2: List[int]
        :type k: int
        :rtype: List[int]
        """

        n, m = len(nums1), len(nums2)
        rmq1, rmq2 = RMQ(nums1), RMQ(nums2)
        
        start_positions = {0: 0}
        
        res = []
        while k:
            max_digit = 0
            new_start_positions = {}
            for s1, s2 in start_positions.items():
                e1 = n - max(1, k - (m - s2))
                e2 = m - max(1, k - (n - s1))
    
                if s1 < n and s2 < m:
                    i1 = rmq1.get(s1, e1)
                    i2 = rmq2.get(s2, e2)
                    if nums1[i1] > nums2[i2]:
                        if nums1[i1] >= max_digit:
                            if nums1[i1] > max_digit:
                                max_digit = nums1[i1]
                                new_start_positions = {}
                            new_start_positions[i1 + 1] = s2
                    elif nums1[i1] < nums2[i2]:
                        if nums2[i2] >= max_digit:
                            if nums2[i2] > max_digit:
                                max_digit = nums2[i2]
                                new_start_positions = {}
                            new_start_positions[s1] = i2 + 1
                    else:
                        if nums1[i1] >= max_digit:
                            if nums1[i1] > max_digit:
                                max_digit = nums1[i1]
                                new_start_positions = {}
                            new_start_positions[i1 + 1] = s2
                            new_start_positions[s1] = i2 + 1
                elif s1 < n:
                    i = rmq1.get(s1, e1)
                    if nums1[i] >= max_digit:
                        if nums1[i] > max_digit:
                            max_digit = nums1[i]
                            new_start_positions = {}
                        new_start_positions[i + 1] = s2
                else:
                    i = rmq2.get(s2, e2)
                    if nums2[i] >= max_digit:
                        if nums2[i] > max_digit:
                            max_digit = nums2[i]
                            new_start_positions = {}
                        new_start_positions[s1] = i + 1
            res.append(max_digit)
            start_positions = new_start_positions
            k -= 1
        return res


#Q31.Unique Binary Search Trees II
'''

Given an integer n, return all the structurally unique BST's (binary search trees), which has exactly n nodes of unique values from 1 to n. Return the answer in any order.

 

Example 1:


Input: n = 3
Output: [[1,null,2,null,3],[1,null,3,2],[2,1,3],[3,1,null,null,2],[3,2,null,1]]
Example 2:

Input: n = 1
Output: [[1]]
 

Constraints:

1 <= n <= 8

'''

#Solution

# Definition for a binary tree node.
# class TreeNode:
#     def __init__(self, val=0, left=None, right=None):
#         self.val = val
#         self.left = left
#         self.right = right
# class Solution:
#     def generateTrees(self, n: int) -> List[Optional[TreeNode]]:
 
    
#  Method-1   
# Elegant & Short | Three lines | Top-down DP | LRU cache

class Solution:
	"""
	Time:   O(n^2)
	Memory: O(log(n))
	"""

	def generateTrees(self, n: int) -> List[Optional[TreeNode]]:
		return self._generate(1, n)

	@classmethod
	@lru_cache(None)
	def _generate(cls, lo: int, hi: int) -> list:
		if lo > hi:
			return [None]
		return [
			TreeNode(root, left, right)
			for root in range(lo, hi + 1)  # All possible roots for the current subarray
			for left in cls._generate(lo, root - 1)  # All possible trees to the left of the root element
			for right in cls._generate(root + 1, hi)  # All possible trees to the right of the root element
		]
    
#  Method-2

# Definition for a binary tree node.
# class TreeNode:
#     def __init__(self, val=0, left=None, right=None):
#         self.val = val
#         self.left = left
#         self.right = right
class Solution:
    def generateTrees(self, n: int) -> List[Optional[TreeNode]]:
        def bst(l, r):
            if r < l:
                return [None]
            if r == l:
                return [TreeNode(l)]
            current_res = []
            for i in range(l, r + 1):
                left_trees = bst(l, i - 1)
                right_trees = bst(i + 1, r)
                
                for left_tree in left_trees: 
                    for right_tree in right_trees:
                        candidate_root_node = TreeNode(i) #define here, so re_allocate a new root node for each possible tree!
                        candidate_root_node.left = left_tree
                        candidate_root_node.right = right_tree
                        current_res.append(candidate_root_node)
         
                    
            return current_res
        return bst(1, n)
    
#  Method-3

class Solution(object):
    def generateTrees(self, n):
        arr = range(1,n+1)
        self.N = len(arr)
        self.res = []
        return self.genTree(arr)
        #return self.res
        
    def genTree(self,arr):
        if len(arr) == 0:
            return []
            
        if len(arr) == 1:
            return [TreeNode(arr[0])]

        res = []
        for k in range(len(arr)):
            lefts = self.genTree(arr[:k])
            rights = self.genTree(arr[k+1:])
            if len(lefts)>0 and len(rights)>0:
                for l in lefts:
                    for r in rights:
                        node = TreeNode(arr[k])
                        node.left  = l
                        node.right = r
                        res.append(node)
            elif len(lefts) > 0:
                for l in lefts:
                    node = TreeNode(arr[k])
                    node.left  = l
                    res.append(node)
            else:
                for r in rights:
                    node = TreeNode(arr[k])
                    node.right  = r
                    
                    res.append(node)
        return res

    
#Method-4   

class Solution:
    def generateTrees(self, n: int) -> List[Optional[TreeNode]]:
        def H(N): return [None] if not N else [TreeNode(x,L,R) for i,x in enumerate(N) for L in H(N[:i]) for R in H(N[i+1:])]
        return H([i+1 for i in range(n)])
    
    
#Method-5

class Solution:
    def generateTrees(self, n: int) -> List[Optional[TreeNode]]:
        return self.makeSubTrees(1, n + 1)
    
    def makeSubTrees(self, start, end):
        if start == end:
            return [None]
        
        subTrees = []
        
        for val in range(start, end):
            leftSubTrees = self.makeSubTrees(start, val)
            rightSubTrees = self.makeSubTrees(val + 1, end)
            
            for leftSubTree in leftSubTrees:
                for rightSubTree in rightSubTrees:
                    subTree = TreeNode(val, leftSubTree, rightSubTree)
                    subTrees.append(subTree)
        
        return subTrees



#Q32.Kth Smallest Element in a BST

'''
Given the root of a binary search tree, and an integer k, return the kth smallest value (1-indexed) of all the values of the nodes in the tree.

 

Example 1:


Input: root = [3,1,4,null,2], k = 1
Output: 1
Example 2:


Input: root = [5,3,6,2,4,null,null,1], k = 3
Output: 3
 

Constraints:

The number of nodes in the tree is n.
1 <= k <= n <= 104
0 <= Node.val <= 104
 

Follow up: If the BST is modified often (i.e., we can do insert and delete operations) and you need to find the kth smallest frequently, how would you optimize?
'''
#Solution

# Definition for a binary tree node.
# class TreeNode:
#     def __init__(self, val=0, left=None, right=None):
#         self.val = val
#         self.left = left
#         self.right = right
# class Solution:
#     def kthSmallest(self, root: Optional[TreeNode], k: int) -> int:
        
    
    
# Method-1    
# Using inorder traversal


# Definition for a binary tree node.
# class TreeNode:
#     def __init__(self, val=0, left=None, right=None):
#         self.val = val
#         self.left = left
#         self.right = right

class Solution:
    
    def helper(self,root) :
        if root == None :
            return
        left = self.helper(root.left)
        if left : 
            return left
        self.k-=1
        if self.k == 0 :
                return root 
        return self.helper(root.right)
        
    def kthSmallest(self, root: Optional[TreeNode], k: int) -> int:
        self.k=k
        kthNode = self.helper(root)
        return kthNode.val
    
# Method-2

# divide and conquer


# Definition for a binary tree node.
# class TreeNode:
#     def __init__(self, val=0, left=None, right=None):
#         self.val = val
#         self.left = left
#         self.right = right
class Solution:
    def kthSmallest(self, root: Optional[TreeNode], k: int) -> int:
        def count(node):
            if not node:
                return 0
            return count(node.left) + count(node.right) + 1
        
        def kth(node, k):
            left = count(node.left)
            if left == k-1:
                return node.val
            elif left > k - 1:
                return kth(node.left, k)
            else:
                return kth(node.right, k - left - 1)
        return kth(root, k)
    
# Method-3
# O(n) time, O(h) space


class Solution:
    # @param {TreeNode} root
    # @param {integer} k
    # @return {integer}
    def kthSmallest(self, root, k):
        stack = []
        curr = root
        while stack or curr:
            if curr:
                stack.append(curr)
                curr = curr.left
            else:
                curr = stack.pop()
                k -= 1
                if k == 0:
                    return curr.val
                curr = curr.right

# Method-4
# traverse the tree(DFS, BSF)
class Solution:
    def kthSmallest(self, root, k):
        """
        :type root: TreeNode
        :type k: int
        :rtype: int
        """
        def inorder(r):
            return inorder(r.left) + [r.val] + inorder(r.right) if r else []
    
        return inorder(root)[k - 1]

# Method-5
# Iterative Inorder Traversal
class Solution:
    def kthSmallest(self, root, k):
        """
        :type root: TreeNode
        :type k: int
        :rtype: int
        """
        stack = []
        
        while True:
            while root:
                stack.append(root)
                root = root.left
            root = stack.pop()
            k -= 1
            if not k:
                return root.val
            root = root.right

#Q33.Redundant Connection

'''

In this problem, a tree is an undirected graph that is connected and has no cycles.

You are given a graph that started as a tree with n nodes labeled from 1 to n, with one additional edge added. The added edge has two different vertices chosen from 1 to n, and was not an edge that already existed. The graph is represented as an array edges of length n where edges[i] = [ai, bi] indicates that there is an edge between nodes ai and bi in the graph.

Return an edge that can be removed so that the resulting graph is a tree of n nodes. If there are multiple answers, return the answer that occurs last in the input.

 

Example 1:


Input: edges = [[1,2],[1,3],[2,3]]
Output: [2,3]
Example 2:


Input: edges = [[1,2],[2,3],[3,4],[1,4],[1,5]]
Output: [1,4]
 

Constraints:

n == edges.length
3 <= n <= 1000
edges[i].length == 2
1 <= ai < bi <= edges.length
ai != bi
There are no repeated edges.
The given graph is connected.
'''
#Solution

# class Solution:
#     def findRedundantConnection(self, edges: List[List[int]]) -> List[int]:
        
    
 #Method-1   
# DFS 
# Intuition and Algorithm

# For each edge (u, v), traverse the graph with a depth-first search to see if we can connect u to v. If we can, then it must be the duplicate edge.

   
class Solution(object):
    def findRedundantConnection(self, edges):
        graph = collections.defaultdict(set)

        def dfs(source, target):
            if source not in seen:
                seen.add(source)
                if source == target: return True
                return any(dfs(nei, target) for nei in graph[source])

        for u, v in edges:
            seen = set()
            if u in graph and v in graph and dfs(u, v):
                return u, v
            graph[u].add(v)
            graph[v].add(u)
            
#Method-2
# Union-find

class Solution:
    def findRedundantConnection(self, edges: List[List[int]]) -> List[int]:
        
        n = len(edges)
        root = [i for i in range(n+1)]
        rank = [1 for i in range(n+1)]
        
        def find(idx):
            while root[idx] != idx:
                idx = root[idx]
            return idx
        
        for _from, _to in edges:
            x = find(_from)
            y = find(_to)
            if x != y:
                if rank[x] == rank[y]:
                    rank[x] += 1
                    root[y] = x
                elif rank[x] > rank[y]:
                    root[y] = x                    
                elif rank[x] < rank[y]:
                    root[x] = y
                    
            else:
                return [_from, _to]
            
#Method-3
class Solution(object):
    def findRedundantConnection(self, edges):
        """
        :type edges: List[List[int]]
        :rtype: List[int]
        """
        ds = DisjointSet()
        result = []
        
        for u, v in edges:
            ds.make_set(u)
            ds.make_set(v)
            
        for u, v in edges:
            parent1 = ds.find_set(u)
            parent2 = ds.find_set(v)
            
            if parent1 == parent2: # cycle, add to result list
                result.append([u, v])
            else:
                ds.union(u, v)
            
        return result[-1]


class Node(object):
    def __init__(self, data, parent = None, rank = 0):
        self.data = data
        self.parent = parent
        self.rank = rank

    def __str__(self):
        return str(self.data)

    def __repr__(self):
        return self.__str__()


class DisjointSet(object):
    def __init__(self):
        self.map = {}
        self.num_sets = 0

    def make_set(self, data):
        node = Node(data)
        node.parent = node # very important!
        self.map[data] = node
        self.num_sets += 1 # make_set increases the number of disjoint sets by one

    def union(self, data1, data2):
        # gets nodes given data values
        node1 = self.map[data1]
        node2 = self.map[data2]

        # get parents given nodes
        parent1 = self.find_set_util(node1)
        parent2 = self.find_set_util(node2)

        # if they are part of same set do nothing
        if parent1.data == parent2.data:
            return

        # else whoever's rank is higher becomes parent of other
        if parent1.rank >= parent2.rank:
            # increment rank only if both sets have same rank
            if parent1.rank == parent2.rank:
                parent1.rank = parent1.rank + 1
            parent2.parent = parent1
        else:
            parent1.parent = parent2

        self.num_sets -= 1 # union decreases the number of disjoint sets by one

    # Finds the representative of this set
    def find_set(self, data):
        return self.find_set_util(self.map[data]) # pass in the node

    # Find the representative recursively and does path compression as well.
    def find_set_util(self, node):
        parent = node.parent
        if parent == node:
            return parent

        node.parent = self.find_set_util(node.parent) # path compression
        return node.parent
    
    
#Merhod-4
# Union

class Solution:
    def findRedundantConnection(self, edges):
        """
        :type edges: List[List[int]]
        :rtype: List[int]
        """
        def is_connected(arr, i, j):
            if parent(arr, i) == parent(arr, j): return True
            return False
            
        def parent(arr, i):
            while i != arr[i]:
                i = arr[i]
            return i
                    
        def union(arr, i, j):
            iroot = parent(arr, i)
            jroot = parent(arr, j)
            if iroot == jroot: return
            arr[iroot] = jroot
            
        _max = list(sorted([i for pair in edges for i in pair]))[-1]
        
        data = [i for i in range(0, _max+1)]

        found = []
        for i, j in edges:
            if is_connected(data, i, j):
                found.append([i, j])
            else:
                union(data, i, j)        
        return [i for pair in found for i in pair]
    
#Merhod-5

class Solution:
    def findRedundantConnection(self, edges: List[List[int]]) -> List[int]:
        graph = defaultdict(list)
        visited = set()
        def dfs(x, y):
            if x == y:
                return True
            if x in visited:
                return False
            visited.add(x)
            for child in graph[x]:
                if dfs(child, y):
                    return True
            return False

        for s, e in edges:
            if dfs(s, e):
                return [s, e]
            visited.clear()
            graph[s].append(e)
            graph[e].append(s)
