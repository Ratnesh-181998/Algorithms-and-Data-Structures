
# Designing Data Structure

#Q1.LRU Cache

''' 
Design a data structure that follows the constraints of a Least Recently Used (LRU) cache.

Implement the LRUCache class:

LRUCache(int capacity) Initialize the LRU cache with positive size capacity.
int get(int key) Return the value of the key if the key exists, otherwise return -1.
void put(int key, int value) Update the value of the key if the key exists. Otherwise, add the key-value pair to the cache. If the number of keys exceeds the capacity from this operation, evict the least recently used key.
The functions get and put must each run in O(1) average time complexity.

 

Example 1:

Input
["LRUCache", "put", "put", "get", "put", "get", "put", "get", "get", "get"]
[[2], [1, 1], [2, 2], [1], [3, 3], [2], [4, 4], [1], [3], [4]]
Output
[null, null, null, 1, null, -1, null, -1, 3, 4]

Explanation
LRUCache lRUCache = new LRUCache(2);
lRUCache.put(1, 1); // cache is {1=1}
lRUCache.put(2, 2); // cache is {1=1, 2=2}
lRUCache.get(1);    // return 1
lRUCache.put(3, 3); // LRU key was 2, evicts key 2, cache is {1=1, 3=3}
lRUCache.get(2);    // returns -1 (not found)
lRUCache.put(4, 4); // LRU key was 1, evicts key 1, cache is {4=4, 3=3}
lRUCache.get(1);    // return -1 (not found)
lRUCache.get(3);    // return 3
lRUCache.get(4);    // return 4
 

Constraints:

1 <= capacity <= 3000
0 <= key <= 104
0 <= value <= 105
At most 2 * 105 calls will be made to get and put.

'''

#Solution 


# class LRUCache:

#     def __init__(self, capacity: int):
        

#     def get(self, key: int) -> int:
        

#     def put(self, key: int, value: int) -> None:
        


# Your LRUCache object will be instantiated and called as such:
# obj = LRUCache(capacity)
# param_1 = obj.get(key)
# obj.put(key,value)


#Approach-1

from collections import OrderedDict
class LRUCache:
    
    def __init__(self, capacity: int):
        self.cache = OrderedDict()
        self.cap = capacity

    def get(self, key: int) -> int:
        if key not in self.cache: return -1
        val = self.cache[key]
        self.cache.move_to_end(key)
        return val

    def put(self, key: int, value: int) -> None:
        if key in self.cache: del self.cache[key]
        self.cache[key] = value
        if len(self.cache) > self.cap:
            self.cache.popitem(last=False)

#Approach-2

# OrderedSet

from collections import OrderedDict

class LRUCache:

    def __init__(self, capacity: int):
        self.d = OrderedDict()
        self.cap = capacity
        
    def get(self, key: int) -> int:
        if key not in self.d:
            return -1
        value = self.d[key]
        del self.d[key]
        self.d[key] = value
        return value
        
    def put(self, key: int, value: int) -> None:
        if key not in self.d:
            if len(self.d) == self.cap:
                k = next(iter(self.d))
                del self.d[k]
            self.d[key] = value
        else:
            del self.d[key]
            self.d[key] = value
 

#Approach-3

# Dict + Doubly Linked List


class Node:
    def __init__(self, k, v):
        self.key = k
        self.value = v
        self.prev = None
        self.next = None


class LRUCache:
    def __init__(self, capacity: int):
        self.capacity = capacity
        self.head = Node(0, 0)
        self.tail = Node(0, 0)
        self.head.next = self.tail
        self.tail.prev = self.head
        # a mapping of (k, Node)
        self.mappings = {}
        # current size
        self.size = 0
    
    
    def get(self, key: int) -> int:
        # if the key exists
        if key in self.mappings:
            # move the Node to the front
            self.remove(self.mappings[key])
            self.addToFirst(self.mappings[key])
            return self.mappings[key].value
        return -1
    

    def put(self, key: int, value: int) -> None:
        # if the key exists
        if key in self.mappings:
            # update the value
            self.mappings[key].value = value
            # move to the first
            self.remove(self.mappings[key])
            self.addToFirst(self.mappings[key])
        elif self.size < self.capacity:
            # create a node and add it to the front
            n = Node(key, value)
            self.addToFirst(n)
            self.size += 1
            # also add it to the map
            self.mappings[key] = n
        elif self.size >= self.capacity:
            lastNode = self.tail.prev
            # evit the last node
            self.remove(lastNode)
            # also need to remove the key from mapping
            self.mappings.pop(lastNode.key, None)
            # create a node and add it to the front
            n = Node(key, value)
            self.addToFirst(n)
            self.size += 1
            self.mappings[key] = n
    
    
    def addToFirst(self, node) -> None:
        """Add a node to the head """
        curFirst = self.head.next
        self.head.next = node
        node.next = curFirst
        curFirst.prev = node
        node.prev = self.head
        
        
    def remove(self, node) -> None:
        """Remove a node """
        p = node.prev
        p.next = node.next
        node.next.prev = p
        node.next = None
        node.prev = None
            


# Your LRUCache object will be instantiated and called as such:
# obj = LRUCache(capacity)
# param_1 = obj.get(key)
# obj.put(key,value)

#Approach-4

# Dict + DLinkedList with proper abstractions

class LinkedListNode:
    def __init__(self, key: int, val: int):
        self.key = key
        self.val = val
        self.prev = None
        self.next = None
        
class DLinkedList:
    def __init__(self):
        # Head and Tail are dummy nodes
        self.head = LinkedListNode(0, 0)
        self.tail = LinkedListNode(0, 0)
        
        # Link head and tail
        self.head.next = self.tail
        self.tail.prev = self.head
        
    def add(self, node: LinkedListNode) -> None:
        # Add node in the front after head
        head_next = self.head.next
        head_next.prev = node
        
        self.head.next = node
        
        node.prev = self.head
        node.next = head_next
        
    def remove(self, node: LinkedListNode) -> None:
        # Remove node from DLinkedList
        node_next = node.next
        node_prev = node.prev
        
        node_next.prev = node_prev
        node_prev.next = node_next
        
class LRUCache:
    def __init__(self, capacity: int):
        self.capacity = capacity
        self.cache = {}
        self.ll = DLinkedList()

    def get(self, key: int) -> int:
        if key not in self.cache:
            return -1
        
        node = self.cache[key]
        self.ll.remove(node)
        self.ll.add(node)
        
        return node.val

    def put(self, key: int, value: int) -> None:
        if key in self.cache:
            self.__replace_value_for_key(key, value)
            return
        
        if len(self.cache) >= self.capacity:
            self.__remove_least_recently_used()
        
        node = LinkedListNode(key, value)
        self.cache[key] = node
        self.ll.add(node)
       
    def __replace_value_for_key(self, key: int, value: int) -> None:
        if key not in self.cache:
            return
        
        node = self.cache[key]
        self.ll.remove(node)
        node.val = value
        self.ll.add(node)
        self.cache[key] = node
    
    def __remove_least_recently_used(self) -> None:
        if not self.cache:
            return
        
        lru = self.ll.tail.prev
        self.ll.remove(lru)
        self.cache.pop(lru.key)
        
# Your LRUCache object will be instantiated and called as such:
# obj = LRUCache(capacity)
# param_1 = obj.get(key)
# obj.put(key,value)


#Approach-5

# Hash Table and Doubly Linked List Solution | O(1) Time | O(n) Space
# * Hash Table and Doubly Linked List Solution | O(1) Time | O(n) Space
# * n -> The given input capacity


# Definition for a doubly linked list.
class Node:
    def __init__(self, key=0, val=0, prev=None, next=None):
        self.key = key
        self.val = val
        self.prev = prev
        self.next = next


class LRUCache:
    def __init__(self, capacity: int):
        """Initialize the LRU cache with positive size capacity."""
        self.capacity = capacity
        # * Stores a key-value pair where the key is the given key and value is a doubly linked list.
        self.cache = collections.defaultdict(Node)
        # * Dummy head and tail help us to easily manage LRU cache eviction.
        self.dummy_head = Node()
        self.dummy_tail = Node()
        self.dummy_head.next = self.dummy_tail
        self.dummy_tail.prev = self.dummy_head

    def get(self, key: int) -> int:
        """Returns the value of the key if the key exists, otherwise returns -1."""
        if key in self.cache:
            cur_node = self.cache[key]
            self._remove_from_list(cur_node)
            self._insert_into_head(cur_node)
            return cur_node.val

        return -1

    def put(self, key: int, value: int) -> None:
        """Updates the value of the key if the key exists.
        Otherwise, adds the key-value pair to the cache. If the number of keys
        exceeds the capacity from this operation then evicts the least recently used key.
        """
        # * Updates the value of the key if the key exists and removes the node from the list
        # * so as to insert the node to the front of the list as it's the MRU key.
        if key in self.cache:
            cur_node = self.cache[key]
            cur_node.val = value
            self._remove_from_list(cur_node)
        # * Adds the key-value pair to the cache.
        else:
            self.cache[key] = Node(key, value)

        # * Inserts the node to the front of the list as it's the MRU key.
        self._insert_into_head(self.cache[key])
        # * Evicts the LRU key if the cache exceeds the given capacity.
        if len(self.cache) > self.capacity:
            lru_node = self.dummy_tail.prev
            self._remove_from_list(lru_node)
            del self.cache[lru_node.key]

    def _insert_into_head(self, node):
        """Inserts a given node into the head.
        This is mainly used to insert the most recently used (MRU) key to the front of the list.
        """
        next = self.dummy_head.next
        node.next, next.prev = next, node
        self.dummy_head.next, node.prev = node, self.dummy_head

    def _remove_from_list(self, node):
        """Removes a given node from the list.
        This is mainly used to remove the least recently used (LRU) key from the list.
        """
        prev, next = node.prev, node.next
        prev.next, next.prev = next, prev


# Your LRUCache object will be instantiated and called as such:
# obj = LRUCache(capacity)
# param_1 = obj.get(key)
# obj.put(key,value)



#Q2. Find Median from Data Stream

'''
The median is the middle value in an ordered integer list. If the size of the list is even, there is no middle value and the median is the mean of the two middle values.

For example, for arr = [2,3,4], the median is 3.
For example, for arr = [2,3], the median is (2 + 3) / 2 = 2.5.
Implement the MedianFinder class:

MedianFinder() initializes the MedianFinder object.
void addNum(int num) adds the integer num from the data stream to the data structure.
double findMedian() returns the median of all elements so far. Answers within 10-5 of the actual answer will be accepted.
 

Example 1:

Input
["MedianFinder", "addNum", "addNum", "findMedian", "addNum", "findMedian"]
[[], [1], [2], [], [3], []]
Output
[null, null, null, 1.5, null, 2.0]

Explanation
MedianFinder medianFinder = new MedianFinder();
medianFinder.addNum(1);    // arr = [1]
medianFinder.addNum(2);    // arr = [1, 2]
medianFinder.findMedian(); // return 1.5 (i.e., (1 + 2) / 2)
medianFinder.addNum(3);    // arr[1, 2, 3]
medianFinder.findMedian(); // return 2.0
 

Constraints:

-105 <= num <= 105
There will be at least one element in the data structure before calling findMedian.
At most 5 * 104 calls will be made to addNum and findMedian.
 

Follow up:

If all integer numbers from the stream are in the range [0, 100], how would you optimize your solution?
If 99% of all integer numbers from the stream are in the range [0, 100], how would you optimize your solution?

'''
#Solution 

# class MedianFinder:

#     def __init__(self):
        

#     def addNum(self, num: int) -> None:
        

#     def findMedian(self) -> float:
        


# # Your MedianFinder object will be instantiated and called as such:
# # obj = MedianFinder()
# # obj.addNum(num)
# # param_2 = obj.findMedian()


# Approach-1: Max Min Heap
# min-heap
# priority-queue
# max-heap

class MedianFinder:

    def __init__(self):
        self.lo = []
        self.hi = []

    def addNum(self, num: int) -> None:
        heappush(self.lo, -num)

		# we only need to balance here if there are too many numbers in the lows,
		# or if the newly added number is larger than the smallest in the highs
        if len(self.lo) - len(self.hi) > 1 or (self.hi and -self.lo[0] > self.hi[0]):
            largest = heappop(self.lo)
            heappush(self.hi, -largest)
            
		# we need to shrink the highs if they grew from the previous step
        if len(self.hi) > len(self.lo):
            smallest = heappop(self.hi)
            heappush(self.lo, -smallest)
        
    def findMedian(self) -> float:
        if len(self.lo) == len(self.hi):
            return (-self.lo[0] + self.hi[0]) / 2

        return -self.lo[0]

    
# Approach-2:

# Two Priority Queues Solution | O(logn) Time | O(n) Space
# heap
# priority-queue

# * Two Priority Queues Solution | O(logn) Time | O(n) Space
# * n -> The number of addNum operations


class MedianFinder:
    def __init__(self):
        # * Stores all the elements <= to large_min_heap elements.
        self.small_max_heap = []
        # * Stores all the elements >= to small_max_heap elements.
        self.large_min_heap = []

    def addNum(self, num: int) -> None:
        heapq.heappush(self.small_max_heap, -num)
        # * All the elements in the small_max_heap should be <= large_min_heap.
        if (
            self.small_max_heap
            and self.large_min_heap
            and not -self.small_max_heap[0] <= self.large_min_heap[0]
        ):
            heapq.heappush(self.large_min_heap, -heapq.heappop(self.small_max_heap))

        # * Rebalance the heaps if the following condition fails
        # * |len(small_max_heap) - len(large_min_heap)| <= 1.
        if len(self.small_max_heap) > len(self.large_min_heap) + 1:
            heapq.heappush(self.large_min_heap, -heapq.heappop(self.small_max_heap))
        if len(self.large_min_heap) > len(self.small_max_heap) + 1:
            heapq.heappush(self.small_max_heap, -heapq.heappop(self.large_min_heap))

    def findMedian(self) -> float:
        # * If the heap lengths are odd.
        if len(self.small_max_heap) > len(self.large_min_heap):
            return -self.small_max_heap[0]
        if len(self.large_min_heap) > len(self.small_max_heap):
            return self.large_min_heap[0]

        # * If the heap lengths are even.
        return (-self.small_max_heap[0] + self.large_min_heap[0]) / 2


# Your MedianFinder object will be instantiated and called as such:
# obj = MedianFinder()
# obj.addNum(num)
# param_2 = obj.findMedian()


# Approach-3:

# Heap | Time Complexity : O(logn)
# heap
# min-heap

class MedianFinder:

    def __init__(self):
        self.small,self.large=[],[]
        

    def addNum(self, num: int) -> None:
        heapq.heappush(self.small,-1*num)
        if (self.small and self.large) and self.small[0]*-1>self.large[0]:
            val=heapq.heappop(self.small)*-1
            heapq.heappush(self.large,val)
        if len(self.small)>len(self.large):
            val=heapq.heappop(self.small)*-1
            heapq.heappush(self.large,val)
        if len(self.large)>len(self.small):
            val=heapq.heappop(self.large)
            heapq.heappush(self.small,val*-1)
            

    def findMedian(self) -> float:
        if len(self.small)>len(self.large):
            return self.small[0]*-1
        if len(self.large)>len(self.small):
            return self.large[0]
        return (self.small[0]*-1 +self.large[0])/2


# Your MedianFinder object will be instantiated and called as such:
# obj = MedianFinder()
# obj.addNum(num)
# param_2 = obj.findMedian()



# Approach-4: Two-Heap Solution
# Intuition:

# We can approach this problem by maintaining two heaps that are always "balanced"
# One is max heap, and the other is a min heap
# During insertion, we want to ensure
# max heap is always less than min heap
# both heaps are always balanced


import heapq
class MedianFinder:

    def __init__(self):
        # max_heap, all elements have to be smaller than the other heap
        self.max_heap = []
        # min heap, all ements have to be larger than the other heap
        self.min_heap = []
        self.count = 0

    def addNum(self, num: int) -> None:
        self.count += 1
    
        heapq.heappush(self.max_heap, -num)
        
        # make sure our max_heap is still smaller than min heap elements
        if self.max_heap and self.min_heap and -self.max_heap[0] > self.min_heap[0]:
            heapq.heappush(self.min_heap, -heapq.heappop(self.max_heap))
            
        # make sure the two heaps are balanced
        if len(self.max_heap) > len(self.min_heap) + 1:
            val = -heapq.heappop(self.max_heap)
            heapq.heappush(self.min_heap, val)
        
        # make sure the two heaps are balanced
        if len(self.min_heap) > len(self.max_heap) + 1:
            val = heapq.heappop(self.min_heap)
            heapq.heappush(self.max_heap, -val)

    def findMedian(self) -> float:
        if len(self.max_heap) > len(self.min_heap):
            return -self.max_heap[0]
        elif len(self.max_heap) < len(self.min_heap):
            return self.min_heap[0]
        else:
            return (-self.max_heap[0] + self.min_heap[0]) / 2


# Approach-5:

class MedianFinder:

    def __init__(self):
        self.arr = []
        

    def addNum(self, num: int) -> None:
        self.arr.append(num)

    def findMedian(self) -> float:
        if len(self.arr) % 2 == 0:
            self.arr.sort()
            return (self.arr[len(self.arr)//2 - 1] + self.arr[len(self.arr)//2])/2
        else:
            self.arr.sort()
            return self.arr[len(self.arr)//2]



#Q3.Design Underground System
'''
An underground railway system is keeping track of customer travel times between different stations. They are using this data to calculate the average time it takes to travel from one station to another.

Implement the UndergroundSystem class:

void checkIn(int id, string stationName, int t)
A customer with a card ID equal to id, checks in at the station stationName at time t.
A customer can only be checked into one place at a time.
void checkOut(int id, string stationName, int t)
A customer with a card ID equal to id, checks out from the station stationName at time t.
double getAverageTime(string startStation, string endStation)
Returns the average time it takes to travel from startStation to endStation.
The average time is computed from all the previous traveling times from startStation to endStation that happened directly, meaning a check in at startStation followed by a check out from endStation.
The time it takes to travel from startStation to endStation may be different from the time it takes to travel from endStation to startStation.
There will be at least one customer that has traveled from startStation to endStation before getAverageTime is called.
You may assume all calls to the checkIn and checkOut methods are consistent. If a customer checks in at time t1 then checks out at time t2, then t1 < t2. All events happen in chronological order.

 

Example 1:

Input
["UndergroundSystem","checkIn","checkIn","checkIn","checkOut","checkOut","checkOut","getAverageTime","getAverageTime","checkIn","getAverageTime","checkOut","getAverageTime"]
[[],[45,"Leyton",3],[32,"Paradise",8],[27,"Leyton",10],[45,"Waterloo",15],[27,"Waterloo",20],[32,"Cambridge",22],["Paradise","Cambridge"],["Leyton","Waterloo"],[10,"Leyton",24],["Leyton","Waterloo"],[10,"Waterloo",38],["Leyton","Waterloo"]]

Output
[null,null,null,null,null,null,null,14.00000,11.00000,null,11.00000,null,12.00000]

Explanation
UndergroundSystem undergroundSystem = new UndergroundSystem();
undergroundSystem.checkIn(45, "Leyton", 3);
undergroundSystem.checkIn(32, "Paradise", 8);
undergroundSystem.checkIn(27, "Leyton", 10);
undergroundSystem.checkOut(45, "Waterloo", 15);  // Customer 45 "Leyton" -> "Waterloo" in 15-3 = 12
undergroundSystem.checkOut(27, "Waterloo", 20);  // Customer 27 "Leyton" -> "Waterloo" in 20-10 = 10
undergroundSystem.checkOut(32, "Cambridge", 22); // Customer 32 "Paradise" -> "Cambridge" in 22-8 = 14
undergroundSystem.getAverageTime("Paradise", "Cambridge"); // return 14.00000. One trip "Paradise" -> "Cambridge", (14) / 1 = 14
undergroundSystem.getAverageTime("Leyton", "Waterloo");    // return 11.00000. Two trips "Leyton" -> "Waterloo", (10 + 12) / 2 = 11
undergroundSystem.checkIn(10, "Leyton", 24);
undergroundSystem.getAverageTime("Leyton", "Waterloo");    // return 11.00000
undergroundSystem.checkOut(10, "Waterloo", 38);  // Customer 10 "Leyton" -> "Waterloo" in 38-24 = 14
undergroundSystem.getAverageTime("Leyton", "Waterloo");    // return 12.00000. Three trips "Leyton" -> "Waterloo", (10 + 12 + 14) / 3 = 12
Example 2:

Input
["UndergroundSystem","checkIn","checkOut","getAverageTime","checkIn","checkOut","getAverageTime","checkIn","checkOut","getAverageTime"]
[[],[10,"Leyton",3],[10,"Paradise",8],["Leyton","Paradise"],[5,"Leyton",10],[5,"Paradise",16],["Leyton","Paradise"],[2,"Leyton",21],[2,"Paradise",30],["Leyton","Paradise"]]

Output
[null,null,null,5.00000,null,null,5.50000,null,null,6.66667]

Explanation
UndergroundSystem undergroundSystem = new UndergroundSystem();
undergroundSystem.checkIn(10, "Leyton", 3);
undergroundSystem.checkOut(10, "Paradise", 8); // Customer 10 "Leyton" -> "Paradise" in 8-3 = 5
undergroundSystem.getAverageTime("Leyton", "Paradise"); // return 5.00000, (5) / 1 = 5
undergroundSystem.checkIn(5, "Leyton", 10);
undergroundSystem.checkOut(5, "Paradise", 16); // Customer 5 "Leyton" -> "Paradise" in 16-10 = 6
undergroundSystem.getAverageTime("Leyton", "Paradise"); // return 5.50000, (5 + 6) / 2 = 5.5
undergroundSystem.checkIn(2, "Leyton", 21);
undergroundSystem.checkOut(2, "Paradise", 30); // Customer 2 "Leyton" -> "Paradise" in 30-21 = 9
undergroundSystem.getAverageTime("Leyton", "Paradise"); // return 6.66667, (5 + 6 + 9) / 3 = 6.66667
 

Constraints:

1 <= id, t <= 106
1 <= stationName.length, startStation.length, endStation.length <= 10
All strings consist of uppercase and lowercase English letters and digits.
There will be at most 2 * 104 calls in total to checkIn, checkOut, and getAverageTime.
Answers within 10-5 of the actual value will be accepted. 

'''
#Solution 


# class UndergroundSystem:

#     def __init__(self):
        

#     def checkIn(self, id: int, stationName: str, t: int) -> None:
        

#     def checkOut(self, id: int, stationName: str, t: int) -> None:
        

#     def getAverageTime(self, startStation: str, endStation: str) -> float:
        


# # Your UndergroundSystem object will be instantiated and called as such:
# # obj = UndergroundSystem()
# # obj.checkIn(id,stationName,t)
# # obj.checkOut(id,stationName,t)
# # param_3 = obj.getAverageTime(startStation,endStation)


#Approach-1

# O(1) solution using 2 dictionaries 

# Time complexity: O(1). All operations are executed in constant runtime.
# Space complexity: O(n^2) where n = number of stations. The number of possible permutations of stations is nP2 = n(n - 1) , thus self.routes will take space proportional to O(n^2)

# hashmap
# dictonary

class UndergroundSystem:
    def __init__(self):
        self.checked_in: Dict[int, Tuple[str, int]] = {}
        self.routes: Dict[str, Tuple[int, int]] = {}
        

    def checkIn(self, ID: int, stationName: str, t: int) -> None:
        self.checked_in[ID] = (stationName, t)
        

    def checkOut(self, ID: int, stationName: str, t: int) -> None:
        startStation, ts = self.checked_in[ID]
        del self.checked_in[ID]
        route = startStation + "->" + stationName
        time = t - ts
        
        n_clients, total_time = self.routes.get(route, (0,0))
        self.routes[route] = (n_clients + 1, total_time + time)
        

    def getAverageTime(self, startStation: str, endStation: str) -> float:
        route = startStation + "->" + endStation
        n_clients, total_time = self.routes[route]
        return total_time / n_clients

#Approach-2

class UndergroundSystem:
    
    # hashmap = {("Leyton", "Waterloo"): [15-3, 1]}
    # customerIn = {45: ("Leyton", 3), 32: ("Paradise", 8)}

    def __init__(self):
        self.hashmap = collections.defaultdict(lambda: [0, 0])
        self.customerIn = {}
        
    def checkIn(self, id: int, stationName: str, t: int) -> None:
        self.customerIn[id] = (stationName, t)

    def checkOut(self, id: int, stationName: str, t: int) -> None:
        start = self.customerIn[id][0]
        inTime = self.customerIn[id][1]
        if (start, stationName) in self.hashmap:
            self.hashmap[(start, stationName)][0] += t - inTime
            self.hashmap[(start, stationName)][1] += 1
        else:
            self.hashmap[(start, stationName)] = [t - inTime, 1]

    def getAverageTime(self, startStation: str, endStation: str) -> float:
        val = self.hashmap[(startStation, endStation)]
        return val[0] / val[1]

#Approach-3

class UndergroundSystem:

    def __init__(self):
        self.customersIn={}
        self.timeStations={}
        

    def checkIn(self, id: int, stationName: str, t: int) -> None:
        self.customersIn[id]=(t,stationName)
        
        

    def checkOut(self, id: int, stationName: str, t: int) -> None:
        stationIn=self.customersIn[id][1]
        timeForCustomer=t - self.customersIn[id][0]
        
        current=self.timeStations.get((stationIn,stationName),None)
        if not current:
            self.timeStations[(stationIn,stationName)]=[timeForCustomer,1]
        else:
            current[1] +=1
            current[0] += timeForCustomer
        
        
    def getAverageTime(self, startStation: str, endStation: str) -> float:
        timeAndCustomerNumber= self.timeStations[(startStation,endStation)]
        
        totalTime=timeAndCustomerNumber[0]
        customerNumber=timeAndCustomerNumber[1]
        
        return totalTime/customerNumber

#Approach-4

class UndergroundSystem:
    def __init__(self):
        self.checks = {}
        self.avg = defaultdict(list)
        
    def checkIn(self, id: int, stationName: str, t: int) -> None:
        if id not in self.checks:
            self.checks[id] = [stationName, t]
        
    def checkOut(self, id: int, stationName: str, t: int) -> None:
        if id in self.checks:
            src, time =  self.checks[id]
            self.avg[src].append([stationName, t - time])
            del self.checks[id]
        
    def getAverageTime(self, startStation: str, endStation: str) -> float:
        ans = 0
        n = 0
        for station in self.avg[startStation]:
            if station[0] == endStation:
                ans += station[1]
                n += 1
                
        return ans / n
 

#Approach-5    
# Hashmaps
class UndergroundSystem(object):

    def __init__(self):
        from collections import defaultdict
        self.in_and_out = dict()
        self.avg_dist = defaultdict(list)

    def checkIn(self, id, stationName, t):
        """
        :type id: int
        :type stationName: str
        :type t: int
        :rtype: None
        """
        self.in_and_out[id] = (stationName, t)
        
        

    def checkOut(self, id, stationName, t):
        """
        :type id: int
        :type stationName: str
        :type t: int
        :rtype: None
        """
        former_station, arrive_time = self.in_and_out[id]
        time_diff = t - arrive_time
        self.avg_dist[former_station + '@' + stationName].append(float(time_diff))
        

    def getAverageTime(self, startStation, endStation):
        """
        :type startStation: str
        :type endStation: str
        :rtype: float
        """
        lst = self.avg_dist[startStation + '@' + endStation]
        return sum(lst) / float(len(lst))

#Approach-6   
# Two hashmaps 
# two hashmaps, one for stats, one for record check in data

class UndergroundSystem:
    def __init__(self):
        # dict((start, end)) = times, averageT
        self.stats = {}
        # dict(id) = startStation, startT
        self.inStation = {}
        
    # put checkin data inside inStation dict
    def checkIn(self, id: int, stationName: str, t: int) -> None:
        self.inStation[id] = [stationName, t]

    # pop checkin data from inStation dict, and update stats
    def checkOut(self, id: int, stationName: str, t: int) -> None:
        startStation, startT = self.inStation.pop(id)
        endStation, endT = stationName, t
        
        if (startStation, endStation) in self.stats:
            times, averageT = self.stats[(startStation, endStation)]
        else:
            times, averageT = 0, 0
            
        self.stats[(startStation, endStation)] = ( (1 + times),
            (times * averageT + 1 * (endT -startT)) / (1 + times) )
        
    # get stats data
    def getAverageTime(self, startStation: str, endStation: str) -> float:
        return self.stats[(startStation, endStation)][1]


#Q4.LFU Cache

'''

Design and implement a data structure for a Least Frequently Used (LFU) cache.

Implement the LFUCache class:

LFUCache(int capacity) Initializes the object with the capacity of the data structure.
int get(int key) Gets the value of the key if the key exists in the cache. Otherwise, returns -1.
void put(int key, int value) Update the value of the key if present, or inserts the key if not already present. When the cache reaches its capacity, it should invalidate and remove the least frequently used key before inserting a new item. For this problem, when there is a tie (i.e., two or more keys with the same frequency), the least recently used key would be invalidated.
To determine the least frequently used key, a use counter is maintained for each key in the cache. The key with the smallest use counter is the least frequently used key.

When a key is first inserted into the cache, its use counter is set to 1 (due to the put operation). The use counter for a key in the cache is incremented either a get or put operation is called on it.

The functions get and put must each run in O(1) average time complexity.

 

Example 1:

Input
["LFUCache", "put", "put", "get", "put", "get", "get", "put", "get", "get", "get"]
[[2], [1, 1], [2, 2], [1], [3, 3], [2], [3], [4, 4], [1], [3], [4]]
Output
[null, null, null, 1, null, -1, 3, null, -1, 3, 4]

Explanation
// cnt(x) = the use counter for key x
// cache=[] will show the last used order for tiebreakers (leftmost element is  most recent)
LFUCache lfu = new LFUCache(2);
lfu.put(1, 1);   // cache=[1,_], cnt(1)=1
lfu.put(2, 2);   // cache=[2,1], cnt(2)=1, cnt(1)=1
lfu.get(1);      // return 1
                 // cache=[1,2], cnt(2)=1, cnt(1)=2
lfu.put(3, 3);   // 2 is the LFU key because cnt(2)=1 is the smallest, invalidate 2.
                 // cache=[3,1], cnt(3)=1, cnt(1)=2
lfu.get(2);      // return -1 (not found)
lfu.get(3);      // return 3
                 // cache=[3,1], cnt(3)=2, cnt(1)=2
lfu.put(4, 4);   // Both 1 and 3 have the same cnt, but 1 is LRU, invalidate 1.
                 // cache=[4,3], cnt(4)=1, cnt(3)=2
lfu.get(1);      // return -1 (not found)
lfu.get(3);      // return 3
                 // cache=[3,4], cnt(4)=1, cnt(3)=3
lfu.get(4);      // return 4
                 // cache=[4,3], cnt(4)=2, cnt(3)=3
 

Constraints:

0 <= capacity <= 104
0 <= key <= 105
0 <= value <= 109
At most 2 * 105 calls will be made to get and put.

'''
#Solution 

# class LFUCache:

#     def __init__(self, capacity: int):
        

#     def get(self, key: int) -> int:
        

#     def put(self, key: int, value: int) -> None:
        


# # Your LFUCache object will be instantiated and called as such:
# # obj = LFUCache(capacity)
# # param_1 = obj.get(key)
# # obj.put(key,value)


#Approach-1

class Node:
    
    def __init__(self, key, val, cnt=1, nxxt=None, prev=None):
        self.key = key
        self.val = val
        self.cnt = cnt
        self.nxxt = nxxt
        self.prev = prev
        
        
class NodeList(Node):
    
    def __init__(self):
        self.head = Node(0,0)
        self.tail = Node(0,0)
        self.head.nxxt = self.tail
        self.tail.prev = self.head
        self.size = 0
        
        
    def addFront(self, node):
        temp = self.head.nxxt
        self.head.nxxt = node
        node.prev = self.head
        node.nxxt = temp
        temp.prev = node
        
        self.size += 1
        
        
    def removeNode(self, node):
        delprev = node.prev
        delnxxt = node.nxxt
        delprev.nxxt = delnxxt
        delnxxt.prev = delprev
        
        self.size -= 1
        

class LFUCache(NodeList):

    def __init__(self, capacity: int):
        self.keyNode = {}
        self.freqNodeList = {}
        self.maxSizeCache = capacity
        self.currSize = 0
        self.minFreq = 0
        
        
    def updateFreqNodeList(self, node):
        del self.keyNode[node.key]
        nodelist = self.freqNodeList[node.cnt]
        nodelist.removeNode(node)
        
        if node.cnt == self.minFreq and self.freqNodeList[node.cnt].size == 0:
            self.minFreq += 1
            
        if (node.cnt+1) in self.freqNodeList:
            nextHigherFreqNodeList = self.freqNodeList[node.cnt+1]
        else:
            nextHigherFreqNodeList = NodeList()
            
        node.cnt += 1
        nextHigherFreqNodeList.addFront(node)
        
        self.freqNodeList[node.cnt] = nextHigherFreqNodeList
        self.keyNode[node.key] = node
        

    def get(self, key: int) -> int:
        if key in self.keyNode:
            node = self.keyNode[key]
            ans = node.val
            self.updateFreqNodeList(node)
            
            return ans
        
        else:
            return -1
        

    def put(self, key: int, value: int) -> None:
        if self.maxSizeCache == 0:
            return
        
        if key in self.keyNode:
            node = self.keyNode[key]
            node.val = value
            self.updateFreqNodeList(node)
            return
        
        else:
            if self.currSize == self.maxSizeCache:
                nodelist = self.freqNodeList[self.minFreq]
                del self.keyNode[nodelist.tail.prev.key]
                nodelist.removeNode(nodelist.tail.prev)
                self.currSize -= 1
                
            self.currSize += 1
            self.minFreq = 1
            
            if self.minFreq in self.freqNodeList:
                nodelist = self.freqNodeList[self.minFreq]
            else:
                nodelist = NodeList()
                
            node = Node(key, value)
            nodelist.addFront(node)
            
            self.keyNode[key] = node
            self.freqNodeList[self.minFreq] = nodelist
   
#Approach-2

# One dict + One Nested Linked List

# hashmap
# dict
# linkedlists


# To be honest I spent a couple of hours to come up with the solution. I don't think I'll be able to solve it during a real interview...

# This is probably not the best or cleanest implementation, but it's the one that makes the most sense to me. So I want to share it and maybe it can help you understand too!

# Diagram
# Note: The diagram maybe not very clear. I uploaded it google drive: https://drive.google.com/file/d/1XlndPfna83kUuezifvvV0DGJL5-AWVlH/view?usp=sharing



# Explanation
# Based on the LRU cache implementation, it's pretty natural to think that LFU cache can also be using something similar. However, it's much more involved when implementing LFU cache. I'll explain it step by step down below.

# Data Structure
# I'll start the data structure from bottom up

# DataNode
# DataNode is the first level of the linked list node. It's a container of cached data + linked list node. The FreqNode is the second level of the linked list node. Let's call the list formed by DataNode a DataList, and the list formed by FreqNode a FreqList. FreqList can contain multiple DataList. FreqNode will be explained below.

# DataNode
# - Fields
# 	- key: int
# 	- value: int
# 	- freq_node: FreqNode
# 	- prev: DataNode
# 	- next: DataNode
# - Methods
# 	- remove_self() # remove itself from the DataList
# FreqNode
# FreqNode is the second level of the linked list node. It contains the freq which stands for the frequency of all DataNode within the FreqList. In another word, all the DataNode within the same FreqList has the same frequency. The order of the DataNode in the list is from the least recently used to the most recently used.

# It maintains the head and tail, two sentinel nodes, to keep track of the DataNode inside the list.

# FreqNode
# - Fields
# 	- freq: int
# 	- head: DataNode
# 	- tail: DataNode
# 	- prev: FreqNode
# 	- next: FreqNode
# - Methods
# 	- append(node: DataNode) # Append a new DataNode to the end of the list
# 	- popleft() # Pop the left most DataNode from the list
# 	- freq_node_after_me() # Find the next FreqNode (b) so that b.freq == self.freq + 1
# FreqList
# This class isn't really needed, but I made it for convenience and readability sake. It contains variouse method to encapsulate the logic for the operations of the FreqNode.

# It maintains the head and tail, two sentinel nodes, to keep track of the FreqNode inside the list.

# FreqList
# - Fields
# 	- head: FreqNode
# 	- tail: FreqNode
# - Methods
# 	- increment_freq(node: DataNode) # Increase the frequency of the DataNode by 1
# 	- add(key:int, value: int) # Create and add a new DataNode with key and value, and frequency 1
# 	- pop_least_frequent() # Pop the least frequent DataNode from the FreqList
# LFUCache
# The actual cache class. It maintains the cache as a dictionary/hashmap. The mapping is from (key: int) to (value: DataNode). It also has a FreqList object so it can use it for the other operations.

# LFUCache
# - capacity: int
# - cache: Dict[int, DataNode]
# - freq_list: FreqList
# Invariants
# We want to keep these two invariants

# In the FreqList, ith element's freq will always be less than (i+1)th elelemt's freq.
# In the DataList, ith element is less recently used than (i+1)th element.
# With these two invariants, we can achieve the following with ease

# To get the least frequently used element (this is done in FreqList#pop_least_frequent()), get the left most/first DataNode from the left most/first FreqNode. O(1)
# To increase the frequency of a key (this is done in FreqList#increment_freq()), we can
# Find the DataNode (data) (using the cache dict). O(1)
# Remove data from the FreqNode (cur_freq) it belongs to. O(1)
# Get the next FreqNode (next_freq), and add data to that node.
# If there's no next_freq or next_freq.freq != data.freq + 1, created a new FreqNode (new_freq), insert it inbetween cur_freq and next_freq. O(1)
# Append data into the new_freq or next_freq. O(1)
# Code


from typing import Dict


class DataNode:

    def __init__(self, key: int = -1, val: int = -1, freq_node=None, prev=None, next=None):
        """
        Initializer.

        DataNode is a single node in the data linked list.

        :param key: key
        :param val: value
        :param freq_node: FreqNode object that contains the current data node
        :param prev: predecessor
        :param next: successor
        """
        self.key = key
        self.val = val
        self.freq_node: FreqNode = freq_node
        self.prev: DataNode = prev
        self.next: DataNode = next

    def remove_self(self):
        """
        Remove self from the data linked list

        :return: None
        """
        next = self.next
        prev = self.prev
        prev.next = next
        next.prev = prev
        self.next = self.prev = None


class FreqNode:

    def __init__(self, freq: int = -1, prev=None, next=None):
        """
        Initializer.

        FreqNode is a single node in the frequency linked list. It contains the head and tail reference
        of a data linked list. All the data node contained within the FreqNode has the same frequency.

        FreqNode can also be seen as a doubly linked list of DataNodes, with the freq field to track the
        frequency.

        The data node in the list is ordered by their access time. So the least recent accessed data is at the left/front
        of the list, and the most recent access data is at the right/back of the list

        :param freq: frequency of all data node within this list
        :param prev: predecessor
        :param next: successor
        """
        self.freq = freq
        self.head = DataNode()
        self.tail = DataNode(prev=self.head)
        self.head.next = self.tail

        self.prev: FreqNode = prev
        self.next: FreqNode = next

    def append(self, node: DataNode):
        """
        Append a data node to the end of the list

        :param node: data node
        :return: None
        """
        tail_prev = self.tail.prev
        tail_prev.next = node
        node.prev = tail_prev
        self.tail.prev = node
        node.next = self.tail

    def popleft(self) -> DataNode:
        """
        Pop the left most data node

        :return: The left most data node
        """
        res = self.head.next
        new_head_next = res.next
        self.head.next = new_head_next
        new_head_next.prev = self.head
        return res

    def freq_node_after_me(self):
        """
        Get the FreqNode object that has freq + 1 for the frequency.
        If that particular node doesn't exist, creat one and make that a
        successor of self

        :return: the successor FreqNode so that successor.freq == self.freq + 1
        """
        if self.next.freq != self.freq + 1:
            # create a new freq node to hold the data
            new_node = FreqNode(self.freq + 1, prev=self, next=self.next)
            self.next.prev = new_node
            self.next = new_node
        else:
            new_node = self.next
        return new_node

    def remove_self(self):
        """
        Remove self from the frequency linked list

        :return: None
        """
        next = self.next
        prev = self.prev
        next.prev = prev
        prev.next = next
        self.prev = self.next = None

    def is_empty(self):
        return self.head.next == self.tail


class FreqList:

    def __init__(self):
        """
        Initializer.

        FreqList is the abstraction for the frequency linked list. It uses the head and tail
        to track all the FreqNode objects within the list.

        The FreqNode in the list is ordered by the frequency. So i-th element will always
        have a lower frequency of i+1-th element
        """
        self.head = FreqNode()
        self.tail = FreqNode()
        self.head.next = self.tail
        self.tail.prev = self.head

    def increment_freq(self, data_node: DataNode):
        """
        Increment the frequency of the data node. This means two things
        1. Data node will be moved to a new linked list with freq + 1
        2. If the data linked list is empty after the data node is moved, we removed the list

        :param data_node: increase the frequency of the data node by 1
        :return: None
        """
        # remove data from cur freq node
        freq_node = data_node.freq_node
        if freq_node is not None:
            data_node.remove_self()
            # find or create the freq node with freq + 1
            new_node = freq_node.freq_node_after_me()
            new_node.append(data_node)
            data_node.freq_node = new_node
            # remove original freq node if it's empty
            if freq_node.is_empty():
                freq_node.remove_self()
        else:
            if self.head.next.freq != 1:
                freq_node = FreqNode(1, prev=self.head, next=self.tail)
                data_node.freq_node = freq_node
            else:
                data_node.freq_node = self.head.next
                self.head.next.append(data_node)

    def add(self, key: int, value: int):
        """
        Create a new DataNode object and add it the frequency linked list with frequency 1.

        :param key: key of the data node
        :param value: value of the data node
        :return: the appended data node
        """
        first = self.head.next
        if first.freq != 1:
            # the first freq linked list doesn't have a frequency of 1
            # so either it's the tail or it's a higher frequency list
            # thus we need to prepend a new freq list of frequency 1
            new_first = FreqNode(freq=1, prev=self.head, next=first)
            self.head.next = new_first
            first.prev = new_first
            first = new_first
        node = DataNode(key, value, first)
        first.append(node)
        return node

    def pop_least_frequent(self):
        """
        Pop the least frequent used DataNode

        :return: the popped DataNode object
        """
        # pop from the first freq list
        first_freq = self.head.next
        first_data = first_freq.popleft()
        # make sure we remove the freq list itself if it's empty after popping
        if first_freq.is_empty():
            first_freq.remove_self()
        return first_data


class LFUCache:

    def __init__(self, capacity: int):
        self.capacity = capacity
        self.cache: Dict[int, DataNode] = {}  # stores key -> data node
        self.freq_list = FreqList()

    def get(self, key: int) -> int:
        if key not in self.cache:
            return -1

        data_node = self.cache[key]
        self.freq_list.increment_freq(data_node)
        return data_node.val

    def put(self, key: int, value: int) -> None:
        if self.capacity == 0:
            return

        if key in self.cache:
            data_node = self.cache[key]
            data_node.val = value
            self.freq_list.increment_freq(data_node)
            return

        # pop LFU entry
        if len(self.cache) == self.capacity:
            removed = self.freq_list.pop_least_frequent()
            del self.cache[removed.key]

        node = self.freq_list.add(key, value)
        self.cache[key] = node

        
#Approach-3

# dict of Nodes by key and dict of DoublyLinkedList by frequency

# doubly linked list
# dictonary

from collections import defaultdict

class Node:
  def __init__(self, freq, key, val):
    self.freq = freq
    self.key = key
    self.val = val
    self.next = None
    self.prev = None
    
class DoublyLinkedList:
  def __init__(self):
    self.head = None
    self.tail = None
    self.size = 0
    
  def insert(self, node):
    if self.head is None:
      self.head = self.tail = node
      node.next = node.prev = None
    else:
      next_node = self.head
      self.head = node
      node.prev = None
      node.next = next_node
      next_node.prev = node
    self.size += 1
    
  def remove(self, node):
    if node.prev is None and node.next is None:
      self.head = self.tail = None
    elif node.prev is None:
      self.head = node.next
      node.next.prev = None
    elif node.next is None:
      self.tail = node.prev
      node.prev.next = None
    else:
      node.prev.next = node.next
      node.next.prev = node.prev
      
    self.size -= 1
  
  def print(self):
    node = self.head
    while node:
      print(f"{node.val}({node.freq}) -> ", end = ' ')
      node = node.next
    print()
    print(f"tail = {self.tail.val}({self.tail.freq})")
          
  def remove_at_tail(self):
    self.remove(self.tail)

class LFUCache:

    def __init__(self, capacity: int):
      self.capacity = capacity
      self.min_freq = 1
      self.cache = dict()
      self.freq_cache = defaultdict(lambda: DoublyLinkedList())
      self.size = 0
        

    def get(self, key: int) -> int:
      node = self.cache.get(key)
      if node is None:
        return -1
      dll = self.freq_cache[node.freq]
      dll.remove(node)
      if dll.size == 0 and self.min_freq == node.freq:
        self.min_freq += 1
      node.freq += 1
      self.freq_cache[node.freq].insert(node)
      
      return node.val

        

    def put(self, key: int, value: int) -> None:
      if self.capacity == 0:
        return
      if self.get(key) != -1:
        node = self.cache.get(key)
        node.val = value
        return value
      # it is a new Node
      node = Node(1, key, value)
      # if we didn't reach capacity
      if self.size < self.capacity:
        self.cache[key] = node
        self.freq_cache[1].insert(node) # insert at the front now it is most recently used
        self.size += 1
      else: # we reached capacity evict least frequently used and in case of tie least recently used
        # eviction
        dll = self.freq_cache[self.min_freq]
        del self.cache[dll.tail.key] # remove from cache
        dll.remove_at_tail()
        
        # insert
        self.cache[key] = node
        self.freq_cache[1].insert(node)
         
      self.min_freq = 1
        



#Approach-4  

# 2 maps and double link lists
# Using a dict {key:freq} and another one {freq:freq_node}, in each freq_node, there is a double link list. All ops O(1).

class LinkNode(object):
    def __init__(self, k=-1, v=-1, prev=None, next=None):
        self.val=v
        self.key=k
        self.prev, self.next = prev, next

class FreqNode(object):
    def __init__(self,):
        self.k2n={}
        self.head = LinkNode()
        self.tail = LinkNode(prev=self.head)
        self.head.next = self.tail
    
    def getval(self,key): return self.k2n[key].val
    def setval(self,key,val): self.k2n[key].val = val
        
    def unlinknode(self,node):
        node.prev.next = node.next
        node.next.prev = node.prev
    
    def removekey(self,key):
        node = self.k2n[key]
        self.unlinknode(node)
        del self.k2n[key]
        return key
        
    def insert(self,key,val):
        node = LinkNode(key, val, self.head, self.head.next)
        self.head.next = node
        node.next.prev = node
        self.k2n[key]=node
    
    def evict(self,):
        node = self.tail.prev
        return self.removekey(node.key)
        

class LFUCache(object):

    def __init__(self, capacity):
        """
        :type capacity: int
        """
        self.cap = capacity
        self.k2f={}
        self.f2n={}
        self.minfreq=1

    def get(self, key):
        if key not in self.k2f: 
            return -1
        freq = self.k2f[key]
        fnode = self.f2n[freq]
        val = fnode.getval(key)
        fnode.removekey(key)
        if len(fnode.k2n)==0: # freq bucket is empty.
            del self.f2n[freq]
            if freq== self.minfreq:
                self.minfreq=freq+1
        freq+=1
        self.k2f[key]=freq
        if freq not in self.f2n:
            self.f2n[freq]= FreqNode()
        fnode = self.f2n[freq]
        fnode.insert(key,val)
        return val

    def put(self, key, value):
        if 0==self.cap: return 
        if key in self.k2f:
            self.get(key) # increase count.
            freq = self.k2f[key]
            fnode = self.f2n[freq]
            fnode.setval(key,value)
            return
        if len(self.k2f)==self.cap:
            fnode = self.f2n[self.minfreq]
            ekey = fnode.evict()
            del self.k2f[ekey]
            if len(fnode.k2n)==0: # freq bucket is empty.
                del self.f2n[self.minfreq]
        self.minfreq=1
        freq=self.minfreq
        self.k2f[key]=freq
        if freq not in self.f2n:
            self.f2n[freq]= FreqNode()
        fnode = self.f2n[freq]
        fnode.insert(key,value)


#Approach-4

# Using Dict and Priority Queue

import heapq
import itertools

class LFUCache:

    def __init__(self, capacity: int):
        self.cap = capacity
        self.data = {} # size of dict indicate the usage
        self.queue = [] # size of queue is inaccurate as when update value for an existing key, key is soft-removed in queue
        self.counter = itertools.count() # track the timing of key insert LRU

    def get(self, key: int) -> int:
        count = next(self.counter)
        if key in self.data:
            freq, _, _, value = self.data[key]
            self.delete_key(key)
            
            entry = [freq+1, count, key, value]
            self.data[key] = entry
            heappush(self.queue, entry)
            
            return value
        return -1
        
    def put(self, key: int, value: int) -> None:
        if self.cap == 0:
            return
        count = next(self.counter)
        if key in self.data:
            freq, _, _, _ = self.data[key]
            self.delete_key(key)
            # update the value of key
            freq = freq+1
        else:
            # delete first
            while len(self.data) == self.cap and self.queue:
                #print(self.data, self.queue)
                _, _, ky, _ = heapq.heappop(self.queue)
                if ky != -1:
                    del self.data[ky]
                #print(self.data, self.queue, '\n')
            freq = 1
        entry = [freq, count, key, value]
        self.data[key] = entry
        heappush(self.queue, entry)
            
    def delete_key(self, key):
        entry = self.data.pop(key) # key is removed in dict
        entry[-2] = -1 # mark the key in queue as removed
        

# Your LFUCache object will be instantiated and called as such:
# obj = LFUCache(capacity)
# param_1 = obj.get(key)
# obj.put(key,value)



#Approach-5
# dict + list + DLL

class Node:
    def __init__(self, key, val, freq):
        self.key = key
        self.val = val
        self.freq = freq
        self.next = None
        self.prev = None

class LFUCache:
    def __init__(self, capacity: int):
        self.freqs = []
        self.d = {}
        self.cap = capacity
        self.minfreq = None
        
    def create_DLL(self, node):
        head = Node(None, None, None)
        tail = Node(None, None, None)
        head.next = tail
        tail.prev = head
        self.addAtHead(node, head)
        return (head, tail)
        
    def addAtHead(self, node, head):
        node.next = head.next
        head.next.prev = node
        head.next = node
        head.next.prev = head
    
    def remove(self, node):
        node_next = node.next
        node_prev = node.prev
        node_next.prev = node_prev
        node_prev.next = node_next

    def update(self, node):
        freq = node.freq
        if len(self.freqs) == freq+1:
            self.remove(node)
            self.freqs.append(self.create_DLL(node))
        else:
            self.remove(node)
            self.addAtHead(node, self.freqs[freq+1][0])
        if self.minfreq == freq and not self.freqs[freq][0].next.val:
            self.minfreq += 1
        node.freq += 1
        
    def get(self, key: int) -> int:
        if self.cap == 0:
            return -1
        if key not in self.d:
            return -1
        node = self.d[key]
        self.update(node)
        return node.val
            
    def put(self, key: int, value: int) -> None:
        if self.cap:
            if key in self.d:
                node = self.d[key]
                node.val = value
                self.update(node)
            else:
                if len(self.d) == self.cap:
                    del self.d[self.freqs[self.minfreq][1].prev.key]
                    self.remove(self.freqs[self.minfreq][1].prev)
                node = Node(key, value, 0)
                self.d[key] = node
                if not self.freqs:
                    self.freqs.append(self.create_DLL(node))
                else:
                    self.addAtHead(node, self.freqs[0][0])
                self.minfreq = 0




#Q5. Tweet Counts Per Frequency

'''
A social media company is trying to monitor activity on their site by analyzing the number of tweets that occur in select periods of time. These periods can be partitioned into smaller time chunks based on a certain frequency (every minute, hour, or day).

For example, the period [10, 10000] (in seconds) would be partitioned into the following time chunks with these frequencies:

Every minute (60-second chunks): [10,69], [70,129], [130,189], ..., [9970,10000]
Every hour (3600-second chunks): [10,3609], [3610,7209], [7210,10000]
Every day (86400-second chunks): [10,10000]
Notice that the last chunk may be shorter than the specified frequency's chunk size and will always end with the end time of the period (10000 in the above example).

Design and implement an API to help the company with their analysis.

Implement the TweetCounts class:

TweetCounts() Initializes the TweetCounts object.
void recordTweet(String tweetName, int time) Stores the tweetName at the recorded time (in seconds).
List<Integer> getTweetCountsPerFrequency(String freq, String tweetName, int startTime, int endTime) Returns a list of integers representing the number of tweets with tweetName in each time chunk for the given period of time [startTime, endTime] (in seconds) and frequency freq.
freq is one of "minute", "hour", or "day" representing a frequency of every minute, hour, or day respectively.
 

Example:

Input
["TweetCounts","recordTweet","recordTweet","recordTweet","getTweetCountsPerFrequency","getTweetCountsPerFrequency","recordTweet","getTweetCountsPerFrequency"]
[[],["tweet3",0],["tweet3",60],["tweet3",10],["minute","tweet3",0,59],["minute","tweet3",0,60],["tweet3",120],["hour","tweet3",0,210]]

Output
[null,null,null,null,[2],[2,1],null,[4]]

Explanation
TweetCounts tweetCounts = new TweetCounts();
tweetCounts.recordTweet("tweet3", 0);                              // New tweet "tweet3" at time 0
tweetCounts.recordTweet("tweet3", 60);                             // New tweet "tweet3" at time 60
tweetCounts.recordTweet("tweet3", 10);                             // New tweet "tweet3" at time 10
tweetCounts.getTweetCountsPerFrequency("minute", "tweet3", 0, 59); // return [2]; chunk [0,59] had 2 tweets
tweetCounts.getTweetCountsPerFrequency("minute", "tweet3", 0, 60); // return [2,1]; chunk [0,59] had 2 tweets, chunk [60,60] had 1 tweet
tweetCounts.recordTweet("tweet3", 120);                            // New tweet "tweet3" at time 120
tweetCounts.getTweetCountsPerFrequency("hour", "tweet3", 0, 210);  // return [4]; chunk [0,210] had 4 tweets
 

Constraints:

0 <= time, startTime, endTime <= 109
0 <= endTime - startTime <= 104
There will be at most 104 calls in total to recordTweet and getTweetCountsPerFrequency.

'''
#Solution  

# class TweetCounts:

#     def __init__(self):
        

#     def recordTweet(self, tweetName: str, time: int) -> None:
        

#     def getTweetCountsPerFrequency(self, freq: str, tweetName: str, startTime: int, endTime: int) -> List[int]:
        


# # Your TweetCounts object will be instantiated and called as such:
# # obj = TweetCounts()
# # obj.recordTweet(tweetName,time)
# # param_2 = obj.getTweetCountsPerFrequency(freq,tweetName,startTime,endTime)


#Approach-1
# straightforwad O(N)

import collections
class TweetCounts:

    def __init__(self):
        self.record_dict = collections.defaultdict(list)
        # self.max_time = 0
        # self.min_time = 0
        

    def recordTweet(self, tweetName: str, time: int) -> None:
        self.record_dict[tweetName].append(time)
        # self.max_time = max(self.max_time, time)
        # self.min_time = min(self.min_time, time)
        

    def getTweetCountsPerFrequency(self, freq: str, tweetName: str, startTime: int, endTime: int) -> List[int]:
        period_mapping = {
            "minute": 60,
            "hour": 3600,
            "day": 86400
        }
        period = period_mapping[freq]
        chunks = (endTime - startTime) // period + 1
        res = [0] * chunks
        for time in self.record_dict[tweetName]:
            if startTime <= time <= endTime:
                res[(time-startTime)//period] += 1
        return res
        
        
#Approach-2

# Binary Search

class TweetCounts:

    def __init__(self):
        
        self.dict_mapper = defaultdict(list)

    
    def get_chunks(self,freq,start,end):
        
        size = 0
        
        if(freq == 'minute'):
            size = 60
            
        elif(freq == 'hour'):
            size = 3600
            
        else:
            size = 86400
            
        
        intervals = []
        
        while start + size <= end:
            
            intervals.append([start,start+size-1])
            start += size
        
        intervals.append([min(start,end),end])
        
        return intervals
    
    
    def index_based_bs(self,arr,target):
        
        lo = 0
        hi = len(arr)-1
        
        
        while lo <= hi:
            
            mid = lo+(hi-lo)//2
            
            if(arr[mid] >= target):
                hi = mid - 1
                
            else:
                lo = mid + 1
                
        
        if(lo < 0):
            return 0
        
        return lo
    
    
    def binary_search(self,arr,time):
        
        
        lo = 0
        hi = len(arr)-1
        
        while lo <= hi:
            mid = lo + (hi-lo)//2
            
            if(arr[mid] == time):
                return arr[:mid] + [time] + arr[mid:]
            
            elif(arr[mid] > time):
                hi = mid - 1
                
            else:
                lo = mid + 1
                
        return arr[:lo]+[time]+arr[lo:]
    
    
    def recordTweet(self, tweetName: str, time: int) -> None:
        
        self.dict_mapper[tweetName] = self.binary_search(self.dict_mapper[tweetName],time)
        
    def getTweetCountsPerFrequency(self, freq: str, tweetName: str, startTime: int, endTime: int) -> List[int]:
        
        intervals = self.get_chunks(freq,startTime,endTime)
        arr = self.dict_mapper[tweetName]
        
        
        
        ans = []
        for intv in intervals:
            
            if(intv[0] > arr[-1] or intv[1] < arr[0]):
                ans.append(0)
                continue
                
            if(intv[0] == intv[1]):
                if(intv[0] in arr):
                    ans.append(1)
                    continue
                    
            l_indx = self.index_based_bs(arr,intv[0])
            r_indx = self.index_based_bs(arr,intv[1])
            ans.append(r_indx-l_indx)
            
        return ans

    
#Approach-3

# Binary search (time > 100%, mem < 100%)


class TweetCounts(object):
    
    def __init__(self):
        self.tweets = defaultdict(list)
        
        
    def recordTweet(self, name, time):
        """
        :type tweetName: str
        :type time: int
        :rtype: None
        """
        if name not in self.tweets:
            self.tweets[name].append(time)
        else:
            idx = bisect.bisect(self.tweets[name], time)
            self.tweets[name].insert(idx, time)
            
        
    def getTweetCountsPerFrequency(self, freq, name, start, end):
        """
        :type freq: str
        :type tweetName: str
        :type startTime: int
        :type endTime: int
        :rtype: List[int]
        """
        if name not in self.tweets:
            return []
        
        def get_interval(freq):
            if freq == "minute":
                return 60
            elif freq == "hour":
                return 3600
            elif freq == "day":
                return 86400
        
        interval = get_interval(freq)
        size = ((end - start)/interval) + 1
        buckets = [0]* int(size)
        
        i = bisect.bisect_left(self.tweets[name], start)
        j = bisect.bisect_right(self.tweets[name], end)
        times = self.tweets[name][i:j]
        for t in times:
            k = (t-start)//interval
            buckets[k] += 1
        
        return buckets
    
#Approach-4   
# using dict and array

class TweetCounts:

    def __init__(self):
        self.record = {}
        
    def recordTweet(self, tweetName: str, time: int) -> None:
        if tweetName not in self.record:
            self.record[tweetName] = [time]
        else:
            self.record[tweetName].append(time)

    def getTweetCountsPerFrequency(self, freq: str, tweetName: str, startTime: int, endTime: int) -> List[int]:
        if freq == "minute":
            delta = 60
        elif freq == "hour":
            delta = 3600
        else:
            delta = 216000
        
        ans = [0 for i in range((endTime - startTime) // delta + 1)]
        if tweetName not in self.record:
            return ans
        else:
            data = sorted(self.record[tweetName])
            for num in data:
                if num >= startTime and num <= endTime:
                    ans[(num - startTime) // delta] += 1
                    
        return ans
                    

#Approach-5

# linear scan
# Analysis:
# Time complexity O(N)
# Space complexity O(N)

# Algorithm:
# Scan through the time for a given tweetName and add the count in the corresponding interval.

# Implementation:

class TweetCounts:

    def __init__(self):
        self.tweets = dict()

    def recordTweet(self, tweetName: str, time: int) -> None:
        self.tweets.setdefault(tweetName, []).append(time)

    def getTweetCountsPerFrequency(self, freq: str, tweetName: str, startTime: int, endTime: int) -> List[int]:
        if freq == "minute": seconds = 60 
        elif freq == "hour": seconds = 3600
        else: seconds = 86400
        
        ans = [0] * ((endTime - startTime)//seconds + 1)
        for t in self.tweets[tweetName]:
            if startTime <= t <= endTime: ans[(t-startTime)//seconds] += 1
        return ans 


#Q6. All O`one Data Structure

'''

Design a data structure to store the strings' count with the ability to return the strings with minimum and maximum counts.

Implement the AllOne class:

AllOne() Initializes the object of the data structure.
inc(String key) Increments the count of the string key by 1. If key does not exist in the data structure, insert it with count 1.
dec(String key) Decrements the count of the string key by 1. If the count of key is 0 after the decrement, remove it from the data structure. It is guaranteed that key exists in the data structure before the decrement.
getMaxKey() Returns one of the keys with the maximal count. If no element exists, return an empty string "".
getMinKey() Returns one of the keys with the minimum count. If no element exists, return an empty string "".
Note that each function must run in O(1) average time complexity.

 

Example 1:

Input
["AllOne", "inc", "inc", "getMaxKey", "getMinKey", "inc", "getMaxKey", "getMinKey"]
[[], ["hello"], ["hello"], [], [], ["leet"], [], []]
Output
[null, null, null, "hello", "hello", null, "hello", "leet"]

Explanation
AllOne allOne = new AllOne();
allOne.inc("hello");
allOne.inc("hello");
allOne.getMaxKey(); // return "hello"
allOne.getMinKey(); // return "hello"
allOne.inc("leet");
allOne.getMaxKey(); // return "hello"
allOne.getMinKey(); // return "leet"
 

Constraints:

1 <= key.length <= 10
key consists of lowercase English letters.
It is guaranteed that for each call to dec, key is existing in the data structure.
At most 5 * 104 calls will be made to inc, dec, getMaxKey, and getMinKey.

'''

#Solution


# class AllOne:

#     def __init__(self):
        

#     def inc(self, key: str) -> None:
        

#     def dec(self, key: str) -> None:
        

#     def getMaxKey(self) -> str:
        

#     def getMinKey(self) -> str:
        


# # Your AllOne object will be instantiated and called as such:
# # obj = AllOne()
# # obj.inc(key)
# # obj.dec(key)
# # param_3 = obj.getMaxKey()
# # param_4 = obj.getMinKey()


#Approach-1
# [doubly-linked-list] [hashmap]
# hashmap
# doubly-linked list

class ListNode:
    
    def __init__(self, val = None, prev = None, nextt = None):
        self.val = val
        self.prev = prev
        self.next = nextt
        self.keys = set()
    
    def unlink(self):
        self.prev.next = self.next
        self.next.prev = self.prev
        
    def create_before(self, val = None):
        val = self.val - 1 if val == None else val
        new_node = ListNode(val, self.prev, self)
        self.prev = new_node
        new_node.prev.next = new_node
        return new_node
    
    def create_after(self, val = None):
        val = self.val + 1 if val == None else val
        new_node = ListNode(val, self, self.next)
        self.next = new_node
        new_node.next.prev = new_node
        return new_node
    
    def add_key(self, key):
        self.keys.add(key)
        
    def remove_key(self, key):
        self.keys.remove(key)
        
    def peek_key(self):
        if self.val == -1:
            return ""
        else:
            key = self.keys.pop()
            self.keys.add(key)
            return key

    

class AllOne:

    def __init__(self):
        self.min_ptr = ListNode(-1)
        self.max_ptr = ListNode(-1)
        self.min_ptr.next = self.max_ptr
        self.max_ptr.prev = self.min_ptr
        self.key_to_node = {}

    def inc(self, key: str) -> None:
        if key in self.key_to_node:
            node = self.key_to_node[key]
            if len(node.keys) == 1:
                if node.val + 1 == node.next.val:
                    new_node = node.next
                    self.key_to_node[key] = new_node
                    new_node.add_key(key)
                    node.unlink()
                else:
                    node.val += 1
            else:
                if node.val + 1 == node.next.val:
                    new_node = node.next
                    self.key_to_node[key] = new_node
                    node.remove_key(key)
                    new_node.add_key(key)
                else:
                    new_node = node.create_after()
                    node.remove_key(key)
                    new_node.add_key(key)
                    self.key_to_node[key] = new_node
        else:
            first_node = self.min_ptr.next
            if first_node.val == 1:
                first_node.add_key(key)
                self.key_to_node[key] = first_node
            else:
                new_node = self.min_ptr.create_after(1)
                new_node.add_key(key)
                self.key_to_node[key] = new_node


    def dec(self, key: str) -> None:
        node = self.key_to_node[key]
        if node.val == 1:
            if len(node.keys) == 1:
                node.unlink()
            else:
                node.remove_key(key)
            del self.key_to_node[key]
        else:
            if len(node.keys) == 1:
                if node.prev.val + 1 == node.val:
                    new_node = node.prev
                    self.key_to_node[key] = new_node
                    new_node.add_key(key)
                    node.unlink()
                else:
                    node.val -= 1
            else:
                if node.prev.val + 1 == node.val:
                    new_node = node.prev
                    self.key_to_node[key] = new_node
                    node.remove_key(key)
                    new_node.add_key(key)
                else:
                    new_node = node.create_before()
                    node.remove_key(key)
                    new_node.add_key(key)
                    self.key_to_node[key] = new_node

    def getMaxKey(self) -> str:
        return self.max_ptr.prev.peek_key()

    def getMinKey(self) -> str:
        return self.min_ptr.next.peek_key()

    
#Approach-2

class Bucket:
    
    def __init__(self, count):
        self.val = count    # Holds the count for this bucket
        self.keys = set()   # Holds all the keys with the same count
        self.prev = None    # The previous bucket will be the one with less count 
        self.next = None    # The next bucket will be the one with more count

class AllOne:

    def __init__(self):
        self.head = Bucket(float('-inf'))  # Holds the min count
        self.tail = Bucket(float('inf'))   # Holds the max count
        
		# A "bucket chain" will be created when more buckets are added
		# It is ordered according to the count bucket holds
        self.head.next = self.tail
        self.tail.prev = self.head
        
        self.keyToCount = {}     # Every key will be mapped to its count
        self.countToBucket = {}  # Every count will be mapped to Bucket holds that count

    def _updateKey(self, key, offset):
	    # Helper function to increase/decrease the key, depends on offset +1/-1
        currCount = self.keyToCount[key]
        newCount = self.keyToCount[key] + offset
        self.keyToCount[key] = newCount
        
        currBucket = self.countToBucket[currCount]
        
        if newCount in self.countToBucket:
		   # The bucket with the newCount exists
            newBucket = self.countToBucket[newCount]
        else:
		    # Create a new bucket with the newCount since it doesn't exist
            newBucket = Bucket(newCount)
            self.countToBucket[newCount] = newBucket
			# Insert the bucket to the "bucket chain"
            self._addBucketAfter(newBucket, currBucket if offset == 1 else currBucket.prev)
            
		# Insert key to the newBucket and remove it from the oldBucket
        newBucket.keys.add(key)
        self._removeKeyFromBucket(key, currBucket)
        
    def _removeKeyFromBucket(self, key, bucket):
        bucket.keys.remove(key)
		
		# If the bucket has nothing after the last key is removed, we remove the bucket as well
        if len(bucket.keys) == 0:
            self._removeBucket(bucket)
            del self.countToBucket[bucket.val]
            
    def _removeBucket(self, bucket):
		# Remove the bucket from the "bucket chain"
        bucket.prev.next = bucket.next
        bucket.next.prev = bucket.prev
        
    def _addBucketAfter(self, newBucket, prevBucket):
		# Add the bucket to the "bucket chain"
        newBucket.prev = prevBucket
        newBucket.next = prevBucket.next
        prevBucket.next.prev = newBucket
        prevBucket.next = newBucket
        
    def inc(self, key: str) -> None:
		# Check if the key exists
        if key in self.keyToCount:
            self._updateKey(key, 1)
        else:
            self.keyToCount[key] = 1
			
			# Check if the bucket with count=1 exists
            if self.head.next.val != 1:
                self._addBucketAfter(Bucket(1), self.head)
                
            self.head.next.keys.add(key)
            self.countToBucket[1] = self.head.next

    def dec(self, key: str) -> None:
        if key in self.keyToCount:
            currCount = self.keyToCount[key]
            
            if currCount == 1:
				# The last count of the key is removed
                del self.keyToCount[key]
                self._removeKeyFromBucket(key, self.countToBucket[currCount])
            else:
                self._updateKey(key, -1)

    def getMaxKey(self) -> str:
		# Check if there is any bucket in the "bucket chain"
        if self.tail.prev == self.head:
            return ""
        else:
			# Randomly pop one key from the bucket
            popKey = self.tail.prev.keys.pop()
            self.tail.prev.keys.add(popKey)
            
            return popKey

    def getMinKey(self) -> str:
        if self.head.next == self.tail:
            return ""
        else:
            popKey = self.head.next.keys.pop()
            self.head.next.keys.add(popKey)
            
            return popKey
        
        
#Approach-3

# doubleLinkedNode+Dict
# hashmap
# doubly-linked list

class DoubleLinkedNode:
    def __init__(self, key_set = {}, count = 0, prev = None, next = None):
        self.key_set = key_set
        self.count = count
        self.prev = prev
        self.next = next
    
    def connect(self, other):
        self.next = other
        other.prev = self
    
    def insertNewNode(self, new_node):
        next_node = self.next
        self.connect(new_node)
        new_node.connect(next_node)
    
    def removeNode(self):
        prev_node, next_node = self.prev, self.next
        prev_node.connect(next_node)

class AllOne:

    def __init__(self):
        """
        Initialize your data structure here.
        """
        self.key2node = dict()
        self.head, self.tail = DoubleLinkedNode(), DoubleLinkedNode()
        self.head.connect(self.tail)

    def inc(self, key: str) -> None:
        """
        Inserts a new key <Key> with value 1. Or increments an existing key by 1.
        """
        # not exist
        if key not in self.key2node:
            cur_node = self.head # with 0 count
        # exist
        else:
            cur_node = self.key2node[key]
        
        # block 1: add/update the key in new node
        # does not have the next node with the count+1
        if cur_node.count + 1 != cur_node.next.count:
            # create a new node
            next_node = DoubleLinkedNode({key}, cur_node.count + 1)
            cur_node.insertNewNode(next_node)
        # has the next node with the count+1
        else:
            next_node = cur_node.next
            next_node.key_set.add(key)
        
        # block 2: remove the current key_set/node if necessary
        # if exist: remove key in the key_set of the current node
        if cur_node != self.head:
            cur_node.key_set.remove(key)
            # if key_set of the current node is empty, delete the current node
            if not cur_node.key_set:
                cur_node.removeNode()
        
        # block 3: update the hashmap
        self.key2node[key] = next_node

    def dec(self, key: str) -> None:
        """
        Decrements an existing key by 1. If Key's value is 1, remove it from the data structure.
        """
        # it is guaranteed that key exists
        cur_node = self.key2node[key]
        
        # key's count is 1: directly remove it
        if cur_node.count == 1:
            cur_node.key_set.remove(key)
            if not cur_node.key_set:
                cur_node.removeNode()
            del self.key2node[key]
        else:
            # block 1: add/update the key in new node
            # does not have the previous node with the count-1
            if cur_node.count - 1 != cur_node.prev.count:
                # create a new node
                prev_node = DoubleLinkedNode({key}, cur_node.count - 1)
                cur_node.prev.insertNewNode(prev_node)
            # has the previous node with the count-1
            else:
                prev_node = cur_node.prev
                prev_node.key_set.add(key)

            # block 2: remove the current key_set/node if necessary
            cur_node.key_set.remove(key)
            if not cur_node.key_set:
                cur_node.removeNode()
            
            # block 3: update the hashmap
            self.key2node[key] = prev_node

    def getMaxKey(self) -> str:
        """
        Returns one of the keys with maximal value.
        """
        # no elementes
        if not self.key2node:
            return ""
        
        # has at least one element
        node_with_max = self.tail.prev
        # randomly get one key from the key_set
        random_key = node_with_max.key_set.pop()
        node_with_max.key_set.add(random_key)
        
        return random_key

    def getMinKey(self) -> str:
        """
        Returns one of the keys with Minimal value.
        """
        if not self.key2node:
            return ""
        
        node_with_min = self.head.next
        random_key = node_with_min.key_set.pop()
        node_with_min.key_set.add(random_key)
        
        return random_key

#Q7.Design Browser History

'''

You have a browser of one tab where you start on the homepage and you can visit another url, get back in the history number of steps or move forward in the history number of steps.

Implement the BrowserHistory class:

BrowserHistory(string homepage) Initializes the object with the homepage of the browser.
void visit(string url) Visits url from the current page. It clears up all the forward history.
string back(int steps) Move steps back in history. If you can only return x steps in the history and steps > x, you will return only x steps. Return the current url after moving back in history at most steps.
string forward(int steps) Move steps forward in history. If you can only forward x steps in the history and steps > x, you will forward only x steps. Return the current url after forwarding in history at most steps.
 

Example:

Input:
["BrowserHistory","visit","visit","visit","back","back","forward","visit","forward","back","back"]
[["leetcode.com"],["google.com"],["facebook.com"],["youtube.com"],[1],[1],[1],["linkedin.com"],[2],[2],[7]]
Output:
[null,null,null,null,"facebook.com","google.com","facebook.com",null,"linkedin.com","google.com","leetcode.com"]

Explanation:
BrowserHistory browserHistory = new BrowserHistory("leetcode.com");
browserHistory.visit("google.com");       // You are in "leetcode.com". Visit "google.com"
browserHistory.visit("facebook.com");     // You are in "google.com". Visit "facebook.com"
browserHistory.visit("youtube.com");      // You are in "facebook.com". Visit "youtube.com"
browserHistory.back(1);                   // You are in "youtube.com", move back to "facebook.com" return "facebook.com"
browserHistory.back(1);                   // You are in "facebook.com", move back to "google.com" return "google.com"
browserHistory.forward(1);                // You are in "google.com", move forward to "facebook.com" return "facebook.com"
browserHistory.visit("linkedin.com");     // You are in "facebook.com". Visit "linkedin.com"
browserHistory.forward(2);                // You are in "linkedin.com", you cannot move forward any steps.
browserHistory.back(2);                   // You are in "linkedin.com", move back two steps to "facebook.com" then to "google.com". return "google.com"
browserHistory.back(7);                   // You are in "google.com", you can move back only one step to "leetcode.com". return "leetcode.com"
 

Constraints:

1 <= homepage.length <= 20
1 <= url.length <= 20
1 <= steps <= 100
homepage and url consist of  '.' or lower case English letters.
At most 5000 calls will be made to visit, back, and forward.

'''

#Solution 

# class BrowserHistory:

#     def __init__(self, homepage: str):
        

#     def visit(self, url: str) -> None:
        

#     def back(self, steps: int) -> str:
        

#     def forward(self, steps: int) -> str:
        


# # Your BrowserHistory object will be instantiated and called as such:
# # obj = BrowserHistory(homepage)
# # obj.visit(url)
# # param_2 = obj.back(steps)
# # param_3 = obj.forward(steps)

#Approach-1

class BrowserHistory:

	def __init__(self, homepage: str):
		self.back_stack = []
		self.forward_stack = []
		self.cur = homepage

	def visit(self, url: str) -> None:
		self.back_stack.append(self.cur)
		self.cur = url
		self.forward_stack.clear()

	def back(self, steps: int) -> str:
		while self.back_stack and steps > 0:
			self.forward_stack.append(self.cur)
			self.cur = self.back_stack.pop()
			steps -= 1
		return self.cur

	def forward(self, steps: int) -> str:
		while self.forward_stack and steps > 0:
			self.back_stack.append(self.cur)
			self.cur = self.forward_stack.pop()
			steps -= 1
		return self.cur
    
#Approach-2

# Double Linked List Python

class Node(object):
    def __init__(self, url):
        self.url = url
        self.next = None
        self.prev = None
        
class BrowserHistory:

    def __init__(self, homepage: str):
        self.curNode = Node(homepage)

    def visit(self, url: str) -> None:
        #print(f"visit")
        # sanity check
        if not url: 
            raise ValueError("Invalid url!")
        
        visitNode = Node(url)
        visitNode.prev = self.curNode
        
        self.curNode.next = visitNode
        self.curNode = self.curNode.next
        
        #print(f"curNode: {self.curNode.url}")
        #print(f"prevNode: {self.curNode.prev.url}")
        #print()
        
        return

    def back(self, steps: int) -> str:
        #print(f"back: {steps}")
        while steps > 0 and self.curNode.prev:
            self.curNode = self.curNode.prev
            steps -= 1
        
        #print(f"node after: {self.curNode.url}")
        
        return self.curNode.url
        

    def forward(self, steps: int) -> str:
        #print(f"forward: {steps}")
        while steps > 0 and self.curNode.next:
            self.curNode = self.curNode.next
            steps -= 1
            
        #print(f"node after: {self.curNode.url}")
            
        return self.curNode.url
    
    
#Approach-3: doubly-linked list


class BrowserHistory:
    class Node:
        def __init__(self, page=None, prev=None):
            self.page = page
            self.prev = prev
            self.next = None

    def __init__(self, homepage: str):
        self.curr = self.Node(homepage)
        
    def visit(self, url: str) -> None:
        self.curr.next = self.Node(url, self.curr)
        self.curr = self.curr.next

    def back(self, steps: int) -> str:
        for _ in range(steps):
            if self.curr.prev:
                self.curr = self.curr.prev
            else:
                break
                
        return self.curr.page

    def forward(self, steps: int) -> str:
        for _ in range(steps):
            if self.curr.next:
                self.curr = self.curr.next
            else:
                break
        
        return self.curr.page


        
