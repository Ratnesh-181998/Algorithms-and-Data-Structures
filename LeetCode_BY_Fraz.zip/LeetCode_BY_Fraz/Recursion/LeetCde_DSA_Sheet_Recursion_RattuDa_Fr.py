 
#Recursion

#Q1 Pow(x, n)
'''

Implement pow(x, n), which calculates x raised to the power n (i.e., xn).

 

Example 1:

Input: x = 2.00000, n = 10
Output: 1024.00000
Example 2:

Input: x = 2.10000, n = 3
Output: 9.26100
Example 3:

Input: x = 2.00000, n = -2
Output: 0.25000
Explanation: 2-2 = 1/22 = 1/4 = 0.25
 

Constraints:

-100.0 < x < 100.0
-231 <= n <= 231-1
-104 <= xn <= 104

'''
#Solution

#Method-1
class Solution:
    def myPow(self, x: float, n: int) -> float:
        return x**n
    
#Another way 
class Solution:
	def myPow(self, x: float, n: int) -> float:
		return pow(x,n)        
        
#Method-2

# I multiplied the number with itself and doubled the power.
# For an odd number, i would just divide by the power difference.

# For example:
# for calculating 2^10:

# 2x2=4
# 4x4=16
# 16x16=256
# 256x256=2^8
# 2^8x2^8=2^16

# now the power 16>10 hence divide by 2^(16-10) which is returned as 2^16/2^6

class Solution:
    def myPow(self, x: float, n: int) -> float:
        if(n==0):
            return 1
        power=1
        init=x
        while(power<n):
            x=x*x
            power=power*2
        if(power==n):
            return x
        z=self.myPow(init,power-n)
        if(math.isnan(z)):
            return 0
        return x/z
    
#Method-3
# 2^-1 = 1 / 2^1
# 2^4 = 2 * 2 * 2 * 2 = (2^2)^2 = half * half
# 2^5 = 2 * 2 * 2 * 2 * 2 = 2 * (2^2)^2 = 2 * half * half

class Solution:
    def myPow(self, x: float, n: int) -> float:
        if n == 0:
            return 1

        if n < 0:
            return 1 / self.myPow(x, -n)

        half = self.myPow(x, n // 2)
        if n % 2 == 0:
            return half * half

        return x * half * half
    
#Method-4

#Divide and Conquer Solution

class Solution:
    def myPow(self, x: float, n: int) -> float:
        #Base Case
        if(n == 0):
            return 1
        if(x == 0):
            return 0
        if(x == 1):
            return 1
        if(n == 1):
            return x
        if(n < 0):
            return 1/self.myPow(x,-1*n)
        #Divide and Conquer
        half = self.myPow(x,n//2)
        
        #Combine
        if(n % 2 == 0):
            return half*half
        else:
            return x*(half*half)
        
#Method-5

class Solution:
    def myPow(self, x: float, n: int) -> float:
        def recurMe(m,n):
            if n==0:
                return 1
            if n==1:
                return m
            else:
                temp=recurMe(m,n//2)
                if n%2!=0:
                    return temp*temp*m
                else:
                    return temp*temp
        if n<0:
            return (1/recurMe(x,abs(n)))
        return recurMe(x,abs(n))



#Q2 . Valid Palindrome

'''
A phrase is a palindrome if, after converting all uppercase letters into lowercase letters and removing all non-alphanumeric characters, it reads the same forward and backward. Alphanumeric characters include letters and numbers.

Given a string s, return true if it is a palindrome, or false otherwise.

 

Example 1:

Input: s = "A man, a plan, a canal: Panama"
Output: true
Explanation: "amanaplanacanalpanama" is a palindrome.
Example 2:

Input: s = "race a car"
Output: false
Explanation: "raceacar" is not a palindrome.
Example 3:

Input: s = " "
Output: true
Explanation: s is an empty string "" after removing non-alphanumeric characters.
Since an empty string reads the same forward and backward, it is a palindrome.
 

Constraints:

1 <= s.length <= 2 * 105
s consists only of printable ASCII characters.


'''

#Solution

#Method-1
#solution using two pointer

class Solution:
    def isPalindrome(self, s: str) -> bool:
        s=s.lower()
        a=set("abcdefghijklmnopqrstuvwxyz0123456789")
        left=0
        right=len(s)-1
        while left<right:
            if s[left] not in a:
                left +=1
                continue
            if s[right] not in a:
                right -= 1
                continue
            if s[left] != s[right]:
                return False
            left += 1
            right -= 1
        return True
 
#Another way 

class Solution(object):
    def isPalindrome(self, s):
        """
        :type s: str
        :rtype: bool
        """
        s = ''.join(item for item in s if item.isalnum()).lower()
        if len(s)>0:
            first_pointer = 0
            second_pointer = len(s)-1
            while second_pointer >= first_pointer:
                if s[first_pointer] != s[second_pointer]:
                    return False
                else:
                    first_pointer += 1
                    second_pointer -= 1
        return True


#Method-2
# Without using in-built function 
class Solution:
    def isPalindrome(self, s: str) -> bool:
        str = ""
        lst=['"', "'", ',',':','.',' ','@','!','#','$','%','^','&','*','(',')','[',']','{','}','<','>','?','/','\\',';','_','+','-','|','~','`']
        for i in s.lower():
          if i not in lst:
            str += i
        return str[::-1]  == str.lower()
    
#Method-3    
class Solution:   
    def isPalindrome(self, s: str) -> bool:
        res = [i.lower() for i in s if i.isalnum()]
        return res==res[::-1]

#Method-4    
class Solution:
    def isPalindrome(self, s: str) -> bool:
        sen = []
        for i in s:
            if i.isalnum():
                sen.append(i.lower())
        return sen == sen[::-1]
  

#Method-5    
class Solution(object):
    def isPalindrome(self, s):
        # extract alphanumeric characters
        alnum_str = ''.join([i for i in s if i.isalnum()])
    
        # decide if it is a palindrome
        if alnum_str.lower() == alnum_str[::-1].lower() or alnum_str == []:
            return True
        else:
            return False




#Q3. Subsets

'''

Given an integer array nums of unique elements, return all possible subsets (the power set).

The solution set must not contain duplicate subsets. Return the solution in any order.

 

Example 1:

Input: nums = [1,2,3]
Output: [[],[1],[2],[1,2],[3],[1,3],[2,3],[1,2,3]]
Example 2:

Input: nums = [0]
Output: [[],[0]]
 

Constraints:

1 <= nums.length <= 10
-10 <= nums[i] <= 10
All the numbers of nums are unique.

'''

#Solution:

# Method-1
# Bit Manipulation

class Solution:
    def subsets(self, nums: list[int]) -> list[list[int]]:
        ret_val = []

        for n in range(2 ** len(nums)):
            subset = []
            idx = 0

            while n:
                if n & 1:
                    subset.append(nums[idx])

                n >>= 1
                idx += 1

            ret_val.append(subset)

        return ret_val
#Method-1
class Solution:
    def subsets(self, nums: List[int]) -> List[List[int]]:
        ans=[]
        for i in range(len(nums)+1):
            ans.extend(combinations(nums,i))
        return ans
    
    

#Method-2    
# Time and space complexity O(2^n)
class Solution:
    def subsets(self, nums: List[int]) -> List[List[int]]:
        subset=[[]]
        for number in nums:
            n=len(subset)
            for i in range(n):
                newSet=list(subset[i])
                newSet.append(number)
                subset.append(newSet)
        return subset

#Method-3        
#Using itertools
import itertools	
class Solution:
    # @param S, a list of integer
    # @return a list of lists of integer
    def subsets(self, S):
    	return_list = []
    	S = sorted(S)
    	for i in range(len(S)+1):
    		return_list.extend (list(x) for x in itertools.combinations(S,i))
    	return return_list
    
    
#Method-4
#Recursive and Loop

class Solution:
    """
    @param S: The set of numbers.
    @return: A list of lists. See example.
    """
    def subsets(self, S):
        n=len(S)
        if n==0:
            return []
        elif n==1:
            return [[],[S[0]]]
        S.sort()
        re=[[],[S[0]]]
        for i in range(1,n):
            re=[x+[S[i]] for x in re]+re
        return re

    
    
class Solution:
    def subsets(self, S):
        n=len(S)
        if n==0:
            return [[]]
        elif n==1:
            return [[],S]
        S.sort()
        re=[]
        for x in self.subsets(S[:n-1]):
            re.append(x)
            re.append(x+[S[n-1]])
        return re

    
#Method-5    
#Backtracking solution

class Solution(object):
    def subsets(self, nums):
        """
        :type nums: List[int]
        :rtype: List[List[int]]
        """
        nums.sort()
        ans,stack,x,n=[[]],[],0,len(nums)
        while True:
            if x<n:
                stack+=[(x,nums[x])]
                ans=ans+[zip(*stack)[1]]
                x+=1
            elif stack:
                x=stack.pop()[0]+1
            else:
                return ans
            
            
#one liner using bit manipulation

class Solution(object):
    def subsets(self, nums):
        """
        :type nums: List[int]
        :rtype: List[List[int]]
        """
        return [[nums[j] for j in range(len(nums)) if i>>j&1] for i in range(2**len(nums))]  




#Q4.Permutations
'''
Given an array nums of distinct integers, return all the possible permutations. You can return the answer in any order.

 

Example 1:

Input: nums = [1,2,3]
Output: [[1,2,3],[1,3,2],[2,1,3],[2,3,1],[3,1,2],[3,2,1]]
Example 2:

Input: nums = [0,1]
Output: [[0,1],[1,0]]
Example 3:

Input: nums = [1]
Output: [[1]]
 

Constraints:

1 <= nums.length <= 6
-10 <= nums[i] <= 10
All the integers of nums are unique. 

'''

#Solution :


# Method-1
# Backtracking 

class Solution:
    def permute(self, nums):
        ans = []
        
        def backtrack(cur, shown):
            if len(cur) == len(nums):
                ans.append(cur.copy())
            
            for n in nums:
                if n not in shown:
                    cur.append(n)
                    shown.add(n)
                    backtrack(cur, shown)
                    cur.pop()
                    shown.remove(n)
        
        backtrack([], set())
        return ans

# Another way Backtracking

class Solution:
    def permute(self, nums: List[int]) -> List[List[int]]:
        def backtrack(current, index):
            if index == len(nums):
                result.append(current.copy())
                return
            for swap_index in range(index, len(nums)):
                current[swap_index], current[index] = current[index], current[swap_index]
                backtrack(current, index+1)
                current[swap_index], current[index] = current[index], current[swap_index]
            return
        
        result = []
        backtrack(nums, 0)
        return result   
    
    
    
# Method-2    
class Solution:    
    def permute(self, nums: List[int]) -> List[List[int]]:
        return [list(x) for x in itertools.permutations(nums)]
    
    
    
#Method-3
# Backtracking - Efficient and Simple Solution using defaultdict 

from collections import defaultdict

class Solution:
    def permute(self, nums: List[int]) -> List[List[int]]:
        
        res = []
        taken = defaultdict(bool)
        n = len(nums)
        def gen_perm(li, taken, _len):
            
            if _len == n:
                res.append(li.copy())
                return
            
            for i in nums:
                if not taken[i]:
                    taken[i] = True
                    li.append(i)
                    _len += 1 
                    gen_perm(li, taken, _len)
                    taken[i] = False
                    li.pop()
                    _len -= 1
        
        gen_perm([], taken, 0)
        return res
    
#Method-4
# Backtracking and Itertools

from itertools import permutations
class Solution:
    # Using itertools
    def permute(self, nums: List[int]) -> List[List[int]]:
        # return list of all subsets of length k
        return list(map(list,permutations(nums)))

    # Backtracking: For each position i, trigger a call with a next element and swap with it
    def permute(self, nums: List[int]) -> List[List[int]]:
        res = []                                        # result list of permutations

        def backtrack(i):
            if i == len(nums):                          # if reached at required length
                res.append(nums.copy())                 # add a copy of current permutation into result

            for j in range(i, len(nums)):
                nums[i], nums[j] = nums[j], nums[i]     # swap numbers at i and j
                backtrack(i+1)                          # check for next permutation
                nums[i], nums[j] = nums[j], nums[i]     # revert/swap numbers at i and j

        backtrack(0)
        return res

    
    
#Method-5   
# Recursive DP and Backtracking 


class Solution(object):
    def permute(self, nums):
        """
        :type nums: List[int]
        :rtype: List[List[int]]
        """
        if (len(nums)==1):
            return [nums]
        ret = []
        for i in range(0,len(nums)):
            sub_res = self.permute(nums[0:i]+nums[i+1:])
            ret += [sub_res_element+[nums[i]] for sub_res_element in sub_res]
        return ret
    
    
class Solution(object):
    def permute(self, nums):
        """
        :type nums: List[int]
        :rtype: List[List[int]]
        """
        res = []
        self.wawa(nums,[],res)
        return(res)
        
    def wawa(self,nums,cur,res):
        if (len(nums) == 0):
            res.append(cur)
            return
        for i in range(len(nums)):
            nums[0],nums[i] = nums[i],nums[0]
            self.wawa(nums[1:], cur+[nums[0]], res)  

# -10 <= nums[i] <= 10  


#Q5. Permutations II  


'''
Given a collection of numbers, nums, that might contain duplicates, return all possible unique permutations in any order.

 

Example 1:

Input: nums = [1,1,2]
Output:
[[1,1,2],
 [1,2,1],
 [2,1,1]]
Example 2:

Input: nums = [1,2,3]
Output: [[1,2,3],[1,3,2],[2,1,3],[2,3,1],[3,1,2],[3,2,1]]
 

Constraints:

1 <= nums.length <= 8
-10 <= nums[i] <= 10


'''


#Solution


#Method-1

class Solution:
    def permuteUnique(self, nums: List[int]) -> List[List[int]]:
        res = []
        used = [0]*len(nums)
        self.backtrack(nums, res, [], used)
        return res
    def backtrack(self, nums, res, curr, used):
        if len(curr) == len(nums) and curr[:] not in res:
            res.append(curr[:])
        for i in range(0, len(nums)):
            if used[i] or nums[i] == nums[i-1] and i>0 and used[i-1]:
                continue
            curr.append(nums[i])
            used[i] = True
            self.backtrack(nums, res, curr, used)
            used[i] = False
            curr.pop()
            
#Method-2
# recursion backtracking
class Solution:
    def permuteUnique(self, nums: List[int]) -> List[List[int]]:
        
        ans=set()
        visited=collections.defaultdict(int)
        length=0
        n=len(nums)
        arr=[]

        def solve(ans,nums,visited,length,arr):
            if length==n:
                ans.add(tuple(arr.copy()))
                
            for i in range(n):
                if visited[i]==0:
                    visited[i]=1
                    arr.append(nums[i])
                    solve(ans,nums,visited,length+1,arr)
                    arr.pop()
                    visited[i]=0
                    
        solve(ans,nums,visited,length,arr)
        return ans

    
#Method-3
# Recursion + Backtracking

class Solution:
    #Time-Complexity: O(n^n), since branching factor is worst case n and height of rec. tree
    #is at most n!
    #Space-Complexity: O(n) for call stack max depth due to recursion, O(n) for boolean_array,
    #tracker set can have at most around n elements and is created at every rec. call ->
    #n * n^n -> O(n^n+1) -> O(n^n)
    
    def permuteUnique(self, nums: List[int]) -> List[List[int]]:
        #Approach: We will start with empty array!
        #For every next empty spot, we will recurse from indicies 0 to n-1 and consider
        #each index postion element if unused and not already recursed from current call!
        
        #We will keep track of already recursed added elements using a set at each rec. call
        #and we will use boolean array to indicate whether we already used a particular
        #element at certain index pos or not -> which will be pass by ref across rec. calls!
        
        #Also, we need to sort input array beforehand to check for duplicates!
        #If current index element is equal to element beforehand, this will generate
        #redundant permutation so we can simply skip over it!
        n = len(nums)
        #intialize all boolean flags off!
        bool_arr = [0] * n
        ans = []
        def helper(cur, b):
            nonlocal n, ans, nums
            #base case
            if(len(cur) == n):
                ans.append(cur[::])
                return
            tracker = set()
            #if not base case, iterate through indices 0 to n-1!
            for i in range(0, n):
                #check for current index ith element is already used!
                if(b[i] == 1):
                    continue
                #if it's not used, check if it already has been recursed and added the element!
                if(nums[i] in tracker):
                    continue
                #otherwise, if current index pos element is not used and there exists
                #no prev. recursive path that adds the particular element, we can go 
                #ahead recurse!
                cur.append(nums[i])
                #set the flag on!
                b[i] = 1
                #before recursing, we need to mark the current element as already added
                #for recursion so we don't recurse along same path!
                tracker.add(nums[i])
                helper(cur, b)
                #once rec. call returns, we need to set flag off again and restore cur state!
                cur.pop()
                b[i] = 0
        
        helper([], bool_arr)
        return ans
    
    
#Method-4
# backtracking

class Solution:
    def permuteUnique(self, nums: List[int]) -> List[List[int]]:
        ans = []
        visited = set()
        def backtrack(numbers, combo):
            if not numbers:
                ans.append(combo[:])
            for i in range(len(numbers)):
                string = ",".join([str(c) for c in combo+[numbers[i]]])
                if string not in visited:
                    combo.append(numbers[i])
                    visited.add(string)
                    backtrack(numbers[:i]+numbers[i+1:], combo)
                    combo.pop()
                
        backtrack(nums, [])
        return ans
    
#Method-5    
class Solution:
    def permuteUnique(self, nums: List[int]) -> List[List[int]]:
        track, res = [], []
        used = [False] * len(nums)
        nums = sorted(nums)
        
        def backtrack(nums):
            if len(track) == len(nums):
                res.append(track[:])
            if len(track) > len(nums):
                return
            
            for i in range(len(nums)):
                if used[i]:
                    continue
                if i>0 and nums[i] == nums[i-1] and not used[i-1]: ## Make sure the relative order of same elements stay the same
                    continue
                used[i] = True
                track.append(nums[i])
                backtrack(nums)
                track.pop()
                used[i] = False
        
        backtrack(nums)
        return res



 #Q6. Subsets II
'''

Given an integer array nums that may contain duplicates, return all possible subsets (the power set).

The solution set must not contain duplicate subsets. Return the solution in any order.

 

Example 1:

Input: nums = [1,2,2]
Output: [[],[1],[1,2],[1,2,2],[2],[2,2]]
Example 2:

Input: nums = [0]
Output: [[],[0]]
 

Constraints:

1 <= nums.length <= 10

'''

#Solution 

# Method-1
# Recursion

import copy
class Solution:
    def subsetsWithDup(self, nums: List[int]) -> List[List[int]]:
        nums = sorted(nums)
        ans = []
        def rec(index, lst):
            ans.append(copy.deepcopy(lst))
            if index >= len(nums):
                return 
            
            for i in range(index, len(nums)):
                if i > index and nums[i] == nums[i-1]:
                    continue
                lst.append(nums[i])
                rec(i+1, lst)
                lst.pop(-1)
        
        rec(0, [])
        return ans
                
        
        
# Method-2        
# BackTracking

class Solution:
    def subsetsWithDup(self, nums: List[int]) -> List[List[int]]:
        
        nums.sort()
        
        def backtracking(start : int, currList : List[int]):
            ans.append(currList[:])
            
            for i in range(start, n):
                if i != start and nums[i] == nums[i-1]:
                    continue
                currList.append(nums[i])
                backtracking(i+1, currList)
                currList.pop()
        
        ans = []
        n = len(nums)
        
        backtracking(0, [])


        return ans 
    
    
# Method-3
# Simple Recursive Backtracking Solution O(2^N)

class Solution:
    #Time-Complexity: O(2^n), since we are recursing with branching factor of 2
    #to make 2 choices for each and every of the n elements!
    #Space-Complexity: O(2^n), due to the max stack depth!
    def subsetsWithDup(self, nums: List[int]) -> List[List[int]]:
        
        
        #Approach: Utilize backtracking!
        #Here, since there may be duplicates, if we ignore element x, we should also
        #ignore all other elements with values == x -> to avoid generating duplicate
        #subsets! In order to check whether nums[i] have duplicates, it would be
        #convenient to sort the input array beforehand so we can simply check 
        #adjacent positions!
        nums.sort()
        
        
        
        ans = []
        def helper(i, tmp):
            nonlocal nums, ans 
            
            #base case: if i == len(nums), then we know we have exhausted all options!
            #add tmp to ans output!
            if(i == len(nums)):
                ans.append(tmp[::])
                return
            
            #otherwise, we need to make two rec. calls -> one rec. call will generate
            #all subsets that contains nums[i] and other rec. call will 
            #generate all subsets without nums[i] -> 2 decisions to make for each and
            #every element n total!
            
            #1. do include nums[i]
            tmp.append(nums[i])
            helper(i+1, tmp)
            #once this rec. call ends, we need to make sure to remove nums[i] when
            #backtracking!
            tmp.pop()
            #since there may be duplicates, if we don't choose to include nums[i],
            #we should also ignore further elements that matches nums[i]!
            while(i < len(nums) -1 and nums[i] == nums[i+1]):
                i += 1
                
            helper(i+1, tmp)
        
        helper(0, [])
        return ans

    
# Method-4
# Solution using Recursion


class Solution:
    def subsetsWithDup(self, nums: List[int]) -> List[List[int]]:
        nums.sort()
        ans = []
        def sub(index, arr):
            ans.append(arr[:])
            for i in range(index, len(nums)):
                if i > index and nums[i] == nums[i-1]:
                    continue
                    
                arr.append(nums[i])
                sub(i+1, arr)
                arr.pop()
        sub(0, [])
        return ans
    
    
    
# Method-5           
# DFS solution Explained CleenCode

"""Algorithm 
TC : O(n * 2^n) + nlogn
Sc : O(n * 2^n) memory stack

Intutions 

* power set == subset of a set
but here as input we don't have a set.
code wil be simialr to what we should do for subset problem. but here it will generate same subsets due to duplicate present in "nums".

*** Find duplicate subsets***

we need to sort nums..
So, that the duplicate subsets would be similar and can be preveneted in prevention setep mentioned above

LVI = lowest valid input"""

class Solution:
    def subsetsWithDup(self, nums: List[int]) -> List[List[int]]:
        
        #Global variables
        res = []
        subset= []
        
        def dfs(i):
            
            #Base Case
            if i >= len(nums): #LVI
                if subset.copy() not in res:#Preventon step
                    res.append(subset.copy())
                return
            
            subset.append(nums[i])
            #RightSubtree
            dfs(i+1)
            subset.pop()
            #Left subtree
            dfs(i+1)
        
        #To get the extra combinations of similar subset  **[1,4,4,4]** present in "res" same as **[1,4,4,4]** not as **[4,1,4,4]**
        nums.sort()
        
        dfs(0)
        return res
    
# A BIT MORE EFFICIENT CODE

class Solution:
    def subsetsWithDup(self, nums: List[int]) -> List[List[int]]:
        
        #Global variables
        res = []
        subset= []
        
        def dfs(i):
            
            #Base Case
            if i >= len(nums): #LVI
                res.append(subset.copy())
                return
            
            subset.append(nums[i])
            #RightSubtree
            dfs(i+1)
            subset.pop()
            
            while i+1 < len(nums) and nums[i] == nums[i+1]:#Preventon step
                i += 1
            #Left subtree
            dfs(i+1)
        
        #To get the extra combinations of similar subset  **[1,4,4,4]** present in "res" same as **[1,4,4,4]** not as **[4,1,4,4]**
        nums.sort()
        
        dfs(0)
        return res
    
"""
Algorithm 
TC : O(n * 2^n) + nlogn
Sc : O(n * 2^n) memory stack

Intutions 

* power set == subset of a set
but here as input we don't have a set.
code wil be simialr to what we should do for subset problem. but here it will generate same subsets due to duplicate present in "nums".

"""

#Q7. Combinations

'''
Given two integers n and k, return all possible combinations of k numbers chosen from the range [1, n].

You may return the answer in any order.

 

Example 1:

Input: n = 4, k = 2
Output: [[1,2],[1,3],[1,4],[2,3],[2,4],[3,4]]
Explanation: There are 4 choose 2 = 6 total combinations.
Note that combinations are unordered, i.e., [1,2] and [2,1] are considered to be the same combination.
Example 2:

Input: n = 1, k = 1
Output: [[1]]
Explanation: There is 1 choose 1 = 1 total combination.
 

Constraints:

1 <= n <= 20
1 <= k <= n

'''

#Solution 

# Method-1
# Recursive solution

class Solution:
    def combine(self, n: int, k: int) -> List[List[int]]:
        lst = []
        ans = []
        for i in range(0,n):
            lst.append(i+1)
        
        def bt(index, aux, auxlen):
            if auxlen == k:
                ans.append(aux[:])
                return
            if index >= n:
                return
            # take element in aux
            aux.append(lst[index])
            bt(index+1, aux, auxlen+1)
            aux.pop(-1)
            # do not take element in aux
            bt(index+1, aux, auxlen)
        
        bt(0, [], 0)
        return(ans)
    
    
    
# Method-2    
# Solutions: DFS and Itertools

from itertools import combinations
class Solution:
    # Using itertools
    def combine(self, n: int, k: int) -> List[List[int]]:
        # return list of all subsets of length k
        return list(map(list,combinations(range(1,n+1), k)))

    # using DFS
    def combine(self, n: int, k: int) -> List[List[int]]:
        result = []

        def dfs(start, result, comb):
            if len(comb) == k:                      # if length of combination is equal to k
                result.append(comb)                 # - add current combination to result
                return

            for i in range(start, n+1):             # range [start, n], n is inclusive
                dfs(i+1, result, comb+[i])          # keep adding i into combination
        
        # find and save all combinations of length k into result
        dfs(1, result, [])
        return result

    
# Method-3
# Solved Using Backtracking + Recursion

class Solution:
	#Time-Complexity: O(n + n^k) -> O(n^k), since the branching factor is at worst n
	#at main root rec. call and height of tree is about k edges along longest path
	#from root to leaf node in rec. tree structure!
	#Space-Complexity: O(n + k) -> O(n)
    def combine(self, n: int, k: int) -> List[List[int]]:
        
        #Approach: Use index i to indicate the index we are considering from!
        #Also, I will pass on the current combination across multiple recursive calls
        #as pass by ref!
        #nums array will have numbers from 1 to n!
        nums = [i for i in range(1, n+1)]
        ans = []
        def helper(i, cur):
            nonlocal k, nums, ans
            #base case: len(cur) == k!
            if(len(cur) == k):
                #make sure to append current built up combination of length k as 
                #deep copy as we return up to parent caller in rec. tree, we might
                #have to undo elements we added when we recursed!
                ans.append(cur[::])
                return
            
            #if it's not the base case, we have to consider adding one element at a time
            #from index i to len(nums)-1, last index position!
            
            #Basically, building up the combination incrementally one by one until
            #it hits base case of length k, which indicates it's a valid combination!
            
            for a in range(i, len(nums)):
                cur.append(nums[a])
                helper(a+1, cur)
                #remove the element at the end before backtracking to parent caller!
                cur.pop()
                #once we are done with recursive call along one branch, we still
                #have other branches to explore!
                #more specifically, the other branches where we add the different element
                #in the next position w/ respect to current built-up combination local
                #to this current rec. helper call!
        
        helper(0, [])
        return ans
    
#  Method-4 
class Solution:
     def combine(self, n, k):
        def search(cur, remain):
            if remain == 0:
                return [[]]
            return [[c] + next
                    for c in range(cur, n+2-remain)
                    for next in search(c+1, remain-1)]
        return search(1, k)
    
    
# Method-5
# Intuitive Python Solution 

class Solution:
    def combine(self, n: int, k: int) -> List[List[int]]:
        result = [] 
        
        def dfs(elements, start: int, k: int): 
            if k == 0:
                result.append(elements[:]) 
                return 
                
            for i in range(start, n + 1): 
                elements.append(i) 
                
                dfs(elements, i + 1, k - 1) 
                
                elements.pop()
        
        dfs([], 1, k) 
        return result 

#Q8 Combination Sum

'''
Given an array of distinct integers candidates and a target integer target, return a list of all unique combinations of candidates where the chosen numbers sum to target. You may return the combinations in any order.

The same number may be chosen from candidates an unlimited number of times. Two combinations are unique if the frequency of at least one of the chosen numbers is different.

It is guaranteed that the number of unique combinations that sum up to target is less than 150 combinations for the given input.

 

Example 1:

Input: candidates = [2,3,6,7], target = 7
Output: [[2,2,3],[7]]
Explanation:
2 and 3 are candidates, and 2 + 2 + 3 = 7. Note that 2 can be used multiple times.
7 is a candidate, and 7 = 7.
These are the only two combinations.
Example 2:

Input: candidates = [2,3,5], target = 8
Output: [[2,2,2,2],[2,3,3],[3,5]]
Example 3:

Input: candidates = [2], target = 1
Output: []
 

Constraints:

1 <= candidates.length <= 30
1 <= candidates[i] <= 200
All elements of candidates are distinct.
1 <= target <= 500


'''
#Solution 

# Method-1
class Solution:
    # @param {integer[]} candidates
    # @param {integer} target
    # @return {integer[][]}
    def combinationSum(self, candidates, target):
        candidates.sort()
        ans = []
        self.help(candidates, target, [], 0, ans)
        return ans

    def help(self, a, target, cur, s, ans):
        if target == 0:
            ans.append(cur[:])
        if target < 0 or a[s] > target:
            return
        while s < len(a):
            cur.append(a[s])
            r = self.help(a, target - a[s], cur, s, ans)
            cur.pop()
            if target - a[s] < 0:
                break
            s += 1


            

# Method-2            
# Recursive -> Backtracking 
class Solution:
    def combinationSum(self, candidates: List[int], target: int) -> List[List[int]]:
        res=[]
        def rec_backtrack(i,curr,total):
            if total==target:
                res.append(curr.copy())
                return
            if i>=len(candidates) or total>target:
                return
            curr.append(candidates[i])
            rec_backtrack(i,curr,total+candidates[i])
            curr.pop()
            rec_backtrack(i+1,curr,total)
        rec_backtrack(0,[],0)
        return res
    
    
# Method-3

# DP 

class Solution:
    def combinationSum(self, candidates: List[int], target: int) -> List[List[int]]:
        min_el = min(candidates)
        @cache
        def dp(target):
            if target < min_el:
                return []
            res = [[cand] + x for cand in candidates if cand<=target \
                for x in dp(target-cand) if len(x)>0 and x[0]>= cand]
            if target in candidates:
                res.append([target])
            return res
        return dp(target)
    
# Method-4    
#Dynamic Programming Solution

class Solution:
    def combinationSum(self, nums: List[int], target: int) -> List[List[int]]:
        dp = [[] for i in range(target+1)]
        dp[0] = [[]]
        for num in nums:
            for i in range(num,target+1):
                dp[i] += [x + [num] for x in dp[i-num]]
        return dp[-1] 

    
# Method-5    
#Recursive
class Solution:
    def combinationSum(self, candidates, target):
        candidates.sort()
        return self._combinationSum(candidates, target, [])
    
    
    def _combinationSum(self, candidates, target, item):
        if not candidates:
            return []
    
        c = candidates[0]
        if c > target:
            return []
        if c == target:
            return [item+[c]]
    
        return self._combinationSum(candidates[1:], target, item)+self._combinationSum(candidates, target-c, item+[c])


  #Q9.Combination Sum II
  '''
Given a collection of candidate numbers (candidates) and a target number (target), find all unique combinations in candidates where the candidate numbers sum to target.

Each number in candidates may only be used once in the combination.

Note: The solution set must not contain duplicate combinations.

 

Example 1:

Input: candidates = [10,1,2,7,6,1,5], target = 8
Output: 
[
[1,1,6],
[1,2,5],
[1,7],
[2,6]
]
Example 2:

Input: candidates = [2,5,2,1,2], target = 5
Output: 
[
[1,2,2],
[5]
]
 

Constraints:

1 <= candidates.length <= 100
1 <= candidates[i] <= 50
1 <= target <= 30

'''

#Solution 

# Method-1

class Solution:
    def combinationSum2(self, candidates: List[int], target: int) -> List[List[int]]:
        candidates.sort()
        ans = []

        def helper(start,temp,num):
            if num == 0:
                ans.append(temp[::])
                return
            for i in range(start,len(candidates)):
                if i==start or (candidates[i] != candidates[i-1]):
                    if candidates[i]<=num:
                        temp.append(candidates[i])
                        helper(i+1,temp,num-candidates[i])
                        temp.pop()
                    else:
                        break
            return
        helper(0,[],target)
        return ans
    
# Method-2
# Backtracking

class Solution:
    def combinationSum2(self, candidates: List[int], target: int) -> List[List[int]]:
        res = []
        candidates.sort()

        def backtracking(cur, cur_sum, idx):
            if cur_sum > target:
                return
            if cur_sum == target:
                res.append(cur)
                return
            for i in range(idx, len(candidates)):
                if i > idx and candidates[i] == candidates[i-1]:
                    continue
                backtracking(cur + [candidates[i]], cur_sum + candidates[i], i+1)

        backtracking([], 0, 0)
        return res
    
# Method-3
# Another way backtracking

class Solution:
    def combinationSum2(self, candidates: List[int], target: int) -> List[List[int]]:
        res, track = [], []
        candidates.sort()
        
        def backtrack(first, track):
            if sum(track) == target:
                res.append(list(track))
                return
            elif sum(track) > target:
                return
            
            for i in range(first, len(candidates)):
                if i > first and candidates[i] == candidates[i-1]:
                    continue
                track.append(candidates[i])
                backtrack(i+1, track)
                track.pop()
        
        backtrack(0, track)
        return res
   

# Method-4 
# dfs with recursion

class Solution:
    def combinationSum2(self, candidates: List[int], target: int) -> List[List[int]]:
	    # These variables are frequently accessed by the recursion function,
		# so make them global instead of passing them into the function
        self.candidates = candidates
        self.candidates.sort()
        self.ncand = len(self.candidates)
        return self.recur(-1, target)
        
    def recur(self, prev_ind: int, sub_target: int) -> List[List[int]]:
        r = []
		# Check only those have not been checked in previous recursions
        for i in range(prev_ind+1, self.ncand):
		    # If the current number (self.candidates[i]) is equal to the previous (self.candidates[i-1]), 
			# then calling the recursion function on this number will necessarily lead to the same
			# return, causing duplication. We thus skip the number if it's the same as the previous.
            if i > prev_ind+1 and self.candidates[i] == self.candidates[i-1]:
                continue
            num = self.candidates[i]
            if num == sub_target:
                r.append([num])
            elif num < sub_target:
                l = self.recur(i, sub_target-num)
                for elem in l:
                    elem.insert(0, num)
                r.extend(l)
            else:
                break
        return r

# Method-5

class Solution:
    def combinationSum2(self, nums: List[int], target: int) -> List[List[int]]:
        nums.sort()
        res = []
        curr = []
        
        def backtrack(first):
            if sum(curr) == target:
                res.append(curr[:])
                return
            elif sum(curr) > target:
                return
            
            for i in range(first, len(nums)):
                if i > first and nums[i] == nums[i - 1]:
                    continue
                curr.append(nums[i])
                backtrack(i + 1)
                curr.pop()
        
        backtrack(0)
        return res


#Q10. Combination Sum III

'''

Find all valid combinations of k numbers that sum up to n such that the following conditions are true:

Only numbers 1 through 9 are used.
Each number is used at most once.
Return a list of all possible valid combinations. The list must not contain the same combination twice, and the combinations may be returned in any order.

 

Example 1:

Input: k = 3, n = 7
Output: [[1,2,4]]
Explanation:
1 + 2 + 4 = 7
There are no other valid combinations.
Example 2:

Input: k = 3, n = 9
Output: [[1,2,6],[1,3,5],[2,3,4]]
Explanation:
1 + 2 + 6 = 9
1 + 3 + 5 = 9
2 + 3 + 4 = 9
There are no other valid combinations.
Example 3:

Input: k = 4, n = 1
Output: []
Explanation: There are no valid combinations.
Using 4 different numbers in the range [1,9], the smallest sum we can get is 1+2+3+4 = 10 and since 10 > 1, there are no valid combination.
 

Constraints:

2 <= k <= 9
1 <= n <= 60

'''
#Solution 

# Method-1
# Recursion

class Solution:
    def combinationSum3(self, k: int, n: int) -> List[List[int]]:
        arr=[1,2,3,4,5,6,7,8,9]
        ans=[]
        def helper(ind, count, curr):
            if ind==len(arr):
                if count==k and sum(curr)==n:
                    return ans.append(curr[:])
                return 
            helper(ind+1, count, curr)
            curr.append(arr[ind])
            count+=1
            helper(ind+1, count, curr)
            curr.pop()
            count-=1
            return
        helper(0, 0, [])
        return ans
    
# Method-2
class Solution:
    def helper(self,k,n,_sum,array,nums,result,index):
        if(len(nums)>k or _sum > n):
            return 
        for i in range(index,len(array)):
            newSum = _sum + array[i]
            nums.append(array[i])
            if(newSum > n or len(nums)>k):
                break
            if(newSum == n and len(nums) == k):
                result.append(nums[:])
            self.helper(k,n,newSum,array,nums[:],result,i+1)
            nums.pop()

    def combinationSum3(self, k: int, n: int) -> list[list[int]]:
        numbers = []
        result = []
        for i in range(1,10):
            if(i<n):
                numbers.append(i)
        self.helper(k,n,0,numbers,[],result,0)

        return result
    
# Method-3
# recursive
class Solution:
    def combinationSum3(self, k: int, n: int) -> List[List[int]]:
        def recurse(k, n, nums="123456789", path=""):
            if k == 0 and n == 0: return [[int(digit) for digit in path]]
            if len(nums) < k or n <= 0: return []
            ans = []
            for i, digit in enumerate(nums): ans.extend(recurse(k - 1, n - int(digit), nums[i+1:], path + digit))
            return ans
        return recurse(k, n)
    
# Method-4

class Solution(object):
    def combinationSum3(self, k, n):
        if k<1 or k> 9 or n<1 or n>45:
            return []
        path, res, index = [], [], 1
        self.dfs(k, n, index, path, res)
        return res
    
    def dfs(self, k, n, index, path, res):
        if n < 0 or len(path)>k:
            return
        if n == 0 and len(path)==k:
            res.append(path)
        for i in range(index, 10):
            self.dfs(k, n-i, i+1, path+[i], res)

        
# Method-5

class Solution:
    def combinationSum3(self, k: int, n: int) -> List[List[int]]:
        def backtrack(n, d_start, p):
            if n == 0 and len(p) == k:
                result.append(p.copy())
                return
            
            if n < 0 or len(p) > k:
                return
            
            for d in range(d_start, 10):
                p.append(d)
                backtrack(n - d, d + 1, p)
                p.pop()
                
        result = [] 
        backtrack(n, 1, [])
    
        return result


#Q11 Partition to K Equal Sum Subsets
'''
Given an integer array nums and an integer k, return true if it is possible to divide this array into k non-empty subsets whose sums are all equal.

 

Example 1:

Input: nums = [4,3,2,3,5,2,1], k = 4
Output: true
Explanation: It is possible to divide it into 4 subsets (5), (1, 4), (2,3), (2,3) with equal sums.
Example 2:

Input: nums = [1,2,3,4], k = 3
Output: false
 

Constraints:

1 <= k <= nums.length <= 16
1 <= nums[i] <= 104
The frequency of each element is in the range [1, 4].

'''
#Solution

# Method-1
# Backtracking without using index in the signature

class Solution:
    def canPartitionKSubsets(self, nums: List[int], k: int) -> bool:
        s = sum(nums) / k
        if s % 1 != 0:
            return False
        for i in nums:
            if i > s:
                return False
        s = int(s)
        
        memoize = set()
        def recursion(cur_sum, s, st):
            if tuple(sorted(st)) in memoize:
                return False
            if cur_sum > s:
                return False
            if cur_sum == s:
                if len(st) == 0:
                    return True
                cur_sum = 0
            tf = False
            for i in st:
                st.remove(i)
                tf = tf or recursion(cur_sum + nums[i], s, st)
                if tf:
                    return tf
                st.add(i)
            memoize.add(tuple(sorted(st)))
            return tf
        return recursion(0, s, set([i for i in range(len(nums))])) 
   

# Method-2
# backtracking with bitmanipulation

class Solution:
    def canPartitionKSubsets(self, arr: List[int], k: int) -> bool:    
        total_array_sum = sum(arr)
  
        if total_array_sum % k != 0:
            return False

        target_sum = total_array_sum // k

        # Sort in decreasing order can prune more branches.
        arr.sort(reverse=True)
        used = 0
        self.memo = {}
        self.k = k
        self.arr = arr
        return self.backtrack(0, 0, 0, used, target_sum)
  
    def backtrack(self, index, count, cur_sum, used, target_sum):
        if count == self.k:
            return True

        if cur_sum > target_sum:
            return False

        if used in self.memo:
            return self.memo[used]

        if cur_sum == target_sum:
            self.memo[used] = self.backtrack(0, count + 1, 0, used, target_sum)
            return self.memo[used]

        for j in range(index, len(self.arr)):
            if used & (1 << j) == 0:
                used |= (1 << j)
                if self.backtrack(j + 1, count, cur_sum + self.arr[j], used, target_sum):
                    return True
                # Backtrack step.
                used ^= (1 << j)

        self.memo[used] = False
        return self.memo[used]
    
# Method-3
# DP TOPDOWN  || Bounded Knapsack || sequence donot matter so we need Tuple

class Solution:
    def canPartitionKSubsets(self, nums: List[int], k: int) -> bool:
        
        subset_num = sum(nums) 
        if subset_num % k != 0 :
            return False
        
        val_subset = subset_num // k
        
        @cache
        def dp(mask, c,  remains):
            
            if not mask:
                if remains == 0:
                    return True
                else:
                    return False
            
            
            mask_list = list(mask)
            
            
            for i, v in enumerate(mask):
                mask_tuple = mask_list[:i] + mask_list[i+1:]
                if c + v == val_subset:
                    temp = dp(tuple(mask_tuple), 0, remains - 1)
                    if temp == True:
                        return True
                elif c + v > val_subset:
                    return False
                else:
                    temp = dp(tuple(mask_tuple), c + v, remains)
                    if temp == True:
                        return True
            
            return False
        
        return dp(tuple(nums), 0, k)

    
# Method-4

class Solution(object):
    def canPartitionKSubsets(self, nums, k):
        target, m = divmod(sum(nums), k)
        
        if m: return False
        
        dp = [0]*k
        n = len(nums)
        nums.sort(reverse=True)
        
        def dfs(i):
            if i == n:
                return len(set(dp)) == 1
            for j in range(k):
                dp[j] += nums[i]
                if dp[j] <= target and dfs(i+1):
                    return True
                dp[j] -= nums[i]
                if not dp[j]: break
            return False
        
        return nums[0] <= target and dfs(0)
    
# Method-5
class Solution:
    def canPartitionKSubsets(self, arr: List[int], k: int) -> bool:
        n = len(arr)
    
        total_array_sum = sum(arr)
        
        # If the total sum is not divisible by k, we can't make subsets.
        if total_array_sum % k != 0:
            return False

        target_sum = total_array_sum // k

        # Sort in decreasing order.
        arr.sort(reverse=True)

        taken = ['0'] * n
        
        memo = {}
        
        def backtrack(index, count, curr_sum):
            n = len(arr)
            
            taken_str = ''.join(taken)
      
            # We made k - 1 subsets with target sum and the last subset will also have target sum.
            if count == k - 1:
                return True
            
            # No need to proceed further.
            if curr_sum > target_sum:
                return False
            
            # If we have already computed the current combination.
            if taken_str in memo:
                return memo[taken_str]
            
            # When curr sum reaches target then one subset is made.
            # Increment count and reset current sum.
            if curr_sum == target_sum:
                memo[taken_str] = backtrack(0, count + 1, 0)
                return memo[taken_str]
            
            # Try not picked elements to make some combinations.
            for j in range(index, n):
                if taken[j] == '0':
                    # Include this element in current subset.
                    taken[j] = '1'
                    # If using current jth element in this subset leads to make all valid subsets.
                    if backtrack(j + 1, count, curr_sum + arr[j]):
                        return True
                    # Backtrack step.
                    taken[j] = '0'
                    
            # We were not able to make a valid combination after picking 
            # each element from the array, hence we can't make k subsets.
            memo[taken_str] = False
            return memo[taken_str] 
        
        return backtrack(0, 0, 0)


#Q12  Maximum Length of a Concatenated String with Unique Characters

'''
You are given an array of strings arr. A string s is formed by the concatenation of a subsequence of arr that has unique characters.

Return the maximum possible length of s.

A subsequence is an array that can be derived from another array by deleting some or no elements without changing the order of the remaining elements.

 

Example 1:

Input: arr = ["un","iq","ue"]
Output: 4
Explanation: All the valid concatenations are:
- ""
- "un"
- "iq"
- "ue"
- "uniq" ("un" + "iq")
- "ique" ("iq" + "ue")
Maximum length is 4.
Example 2:

Input: arr = ["cha","r","act","ers"]
Output: 6
Explanation: Possible longest valid concatenations are "chaers" ("cha" + "ers") and "acters" ("act" + "ers").
Example 3:

Input: arr = ["abcdefghijklmnopqrstuvwxyz"]
Output: 26
Explanation: The only string in arr has all 26 characters.
 

Constraints:

1 <= arr.length <= 16
1 <= arr[i].length <= 26
arr[i] contains only lowercase English letters.

'''

#Solution

# Method-1
# set solution

class Solution:
    def maxLength(self, arr: List[str]) -> int:
        s = ""
        def helper(arr,i,s):
            if i == len(arr):
                freq = [0] * 26
                for k in range(len(s)):
                    if freq[abs(ord(s[k]) - 97)] == 1:
                        return 0
                    freq[abs(ord(s[k]) - 97)] +=1
                return len(s)
            op1 = op2 = 0
            if len(s) + len(arr[i]) <=26:
                op1 = helper(arr,i+1,s+arr[i])
            op2 = helper(arr,i+1,s)
            return max(op1,op2)
        return helper(arr,0,s)
    
# Method-2

# The idea is very simple we have two choices :

# Check if two strings can be added such that there is no repeated character if yes add them
# Do not add the two strings at alll
# We do this for every index from 0 to n and keep track of the element occuring in our
# super string

class Solution:
    def maxLength(self, arr: List[str]) -> int:
        ans = 0
        count = [0]*26
        counts = []
        new_arr = []
        
        for string in arr:
            flag = True
            tmp = [0]*26
            for ch in string:
                if tmp[ord(ch) - 97] == True:
                    flag = False
                    break
                else:
                    tmp[ord(ch) - 97] = True
            
            if flag == False:continue
            counts.append(tmp)
            new_arr.append(string)
            
        n = len(new_arr)  
        
        def compatible(a,b):
            for i in range(26):
                if a[i] == True and b[i] == True: return False
            return True
        
        def addUp(a,b):
            for i in range(26):
                if b[i] == True: a[i] = True
        
        def solve(index,count):
            if index == n:return 0
            cpy = count.copy()
            ch1 = -inf
            if compatible(count,counts[index]):
                addUp(count,counts[index])
                ch1 = solve(index+1,count) + len(new_arr[index])
            ch2 = solve(index+1 , cpy)
            ans = max(ch1,ch2)
            return ans
        
        return solve(0,count)

    
# Method-3
# set operations and stack

class Solution:
    def maxLength(self, arr: List[str]) -> int:
        A=[set()]+[set(s) for s in arr if len(set(s))==len(s)]
        n=len(A)
        answ=0
        stack=[[set(),0]]
        while stack:
            B,i=stack.pop()
            answ=max(answ,len(B))
            for j in range(i+1,n):
                if not B.intersection(A[j]):
                    stack.append([B.union(A[j]),j])
        return answ
    
# Method-4
# backtracking and bit manuipulation
class Solution:
    def maxLength(self, arr: List[str]) -> int:
        def validate(s: str) -> bool:
            return len(s) == len(set(s))
        
        # bad string removal
        q = []
        for s in arr:
            if validate(s):
                if len(s) < 26:
                    q.append(s)
                else:
                    return 26
        if not q: return 0
        
        # create bit masks
        N = len(q)
        masks = [0] * N
        orda = ord('a')
        for i, s in enumerate(q):
            for c in s:
                masks[i] += 1<<(ord(c)-orda)
        
        # suffix length sum for early exit checking
        sf = [0] * N
        sf[-1] = len(q[-1])
        for i in range(N-2, -1, -1):
            sf[i] = len(q[i]) + sf[i+1]
        
        def backtrack(i: int, l: int, bm: int):
            nonlocal ans
            l += len(q[i])
            ans = max(ans, l)
            bm += masks[i]
            for j in range(i+1, N):
                if l + sf[j] <= ans: break # maximum possible not exceeding current answer
                if not masks[j] & bm:
                    backtrack(j, l, bm)
        
        ans = 0
        for i in range(N):
            if sf[i] <= ans: break # maximum possible not exceeding current answer
            backtrack(i, 0, 0)
        return ans
    
 # Method-5   
# bit mask + DFS solution
# Similar question using bit mask on String: 318. Maximum Product of Word Lengths
# Bit mask note:
# number &1 << n: Check if nth digit has already been recorded
# number | 1 << n: put "1" on nth digit as a record.

class Solution:
    def maxLength(self, arr: List[str]) -> int:
        n = len(arr)
        memo, length = [0 for _ in range(n)], [0 for _ in range(n)]
        
        for j in range(n):
            length[j] = len(arr[j])
            for i in arr[j]:
                if memo[j] & 1 << (ord(i) - ord('a')):
                    length[j] = -1
                    break
                memo[j] |= 1 << (ord(i) - ord('a'))
                
        def dfs(cur, path):
            if cur == n:
                return 0
            if length[cur] < 0 or path & memo[cur]:
                return dfs(cur + 1, path)
            return max(dfs(cur + 1, path), length[cur] + dfs(cur + 1, path | memo[cur]))
        
        return dfs(0, 0)


#Q13.Flood Fill
'''
An image is represented by an m x n integer grid image where image[i][j] represents the pixel value of the image.

You are also given three integers sr, sc, and color. You should perform a flood fill on the image starting from the pixel image[sr][sc].

To perform a flood fill, consider the starting pixel, plus any pixels connected 4-directionally to the starting pixel of the same color as the starting pixel, plus any pixels connected 4-directionally to those pixels (also with the same color), and so on. Replace the color of all of the aforementioned pixels with color.

Return the modified image after performing the flood fill.

 

Example 1:


Input: image = [[1,1,1],[1,1,0],[1,0,1]], sr = 1, sc = 1, color = 2
Output: [[2,2,2],[2,2,0],[2,0,1]]
Explanation: From the center of the image with position (sr, sc) = (1, 1) (i.e., the red pixel), all pixels connected by a path of the same color as the starting pixel (i.e., the blue pixels) are colored with the new color.
Note the bottom corner is not colored 2, because it is not 4-directionally connected to the starting pixel.
Example 2:

Input: image = [[0,0,0],[0,0,0]], sr = 0, sc = 0, color = 0
Output: [[0,0,0],[0,0,0]]
Explanation: The starting pixel is already colored 0, so no changes are made to the image.
 

Constraints:

m == image.length
n == image[i].length
1 <= m, n <= 50
0 <= image[i][j], color < 216
0 <= sr < m
0 <= sc < n

'''
 #Solution 

 # Method-1

class Solution:
    def floodFill(self, image: List[List[int]], sr: int, sc: int, color: int) -> List[List[int]]:
        old_c = image[sr][sc]
        
        if old_c == color:
            return image
        
        dirx = [0,0,1,-1]
        diry = [1,-1,0,0]
        n = len(image)
        m = len(image[0])
        
        def dfs(i, j):
            image[i][j] = color
            
            for d in range(4):
                ni = i+dirx[d]
                nj = j+diry[d]
                
                if ni >= 0 and nj >= 0 and ni < n and nj < m and image[ni][nj] == old_c:
                    dfs(ni, nj)
        
        dfs(sr, sc)
        return image
 

# Method-2
   
class Solution:
    def floodFill(self, image: List[List[int]], sr: int, sc: int, color: int) -> List[List[int]]:
        
        q = [(sr,sc)]
        dirs = [(-1,0),(1,0),(0,1),(0,-1)] 
        ori = image[sr][sc]
        if image[sr][sc] != color:
            image[sr][sc] = color
        while q:
            r,c = q.pop(0)
            for ir,ic in dirs:
                if (r+ir)< len(image) and (c + ic) < len(image[0]) and (r+ir)>=0 and (c + ic)>=0:
                    if image[r + ir][c + ic] == ori and image[r + ir][c + ic] != color:
                        image[r + ir][c + ic] = color
                        q.append((r + ir,c + ic))
        return image
    
    
# Method-3    
# BFS Iterative, Very easy to understand%

class Solution:
    def floodFill(self, image: List[List[int]], sr: int, sc: int, color: int) -> List[List[int]]:
        
        ROWS, COLS = len(image), len(image[0])
        
        oldColor = image[sr][sc]
        
        def bfs(i, j):
            directions = [[1, 0], [-1, 0], [0, 1], [0, -1]]
            queue = collections.deque([])
            queue.append((i, j))
            image[i][j] = color
            
            while queue:
                x, y = queue.popleft()
                
                for (dx, dy) in directions:
                    curx, cury = x+dx, y+dy
                    if (0 <= curx < ROWS) and (0 <= cury < COLS) and image[curx][cury] == oldColor:  # Made a mistake with the limits a couple of times, be careful!
                        image[curx][cury] = color
                        queue.append((curx, cury))
                
        if oldColor != color:
            bfs(sr, sc)
            
        return image
    
    
# Method-4    
# short DFS 

class Solution:
    def floodFillHelper(self, image, sr, sc, newColor, oldColor, visited):
        if not (0 <= sr < len(image) and 0 <= sc < len(image[0])) or visited[sr][sc] or image[sr][sc] != oldColor:
            return image
        image[sr][sc], visited[sr][sc], offsets = newColor, True, [[-1, 0], [1, 0], [0, -1], [0, 1]]
        for off in offsets:
            image = self.floodFillHelper(image, sr + off[0], sc + off[1], newColor, oldColor, visited)
        return image

    def floodFill(self, image, sr, sc, newColor):
        visited, old_color = [[0] * len(image[0]) for _ in range(len(image))], image[sr][sc]
        return self.floodFillHelper(image, sr, sc, newColor, old_color, visited)


    
# Method-5

class Solution:
    def floodFill(self, image, sr, sc, newColor):
        """
        :type image: List[List[int]]
        :type sr: int
        :type sc: int
        :type newColor: int
        :rtype: List[List[int]]
        """
        # The length of image and image[0] will be in the range [1, 50].
        # The given starting pixel will satisfy 0 <= sr < image.length and 0 <= sc < image[0].length.
        # The value of each color in image[i][j] and newColor will be an integer in [0, 65535].
        NR, NC, startColor = len(image), len(image[0]), image[sr][sc]
        if startColor == newColor:
            return image

        def floodFillHelper(r, c):
            if image[r][c] == startColor:
                image[r][c] = newColor
                # try to fill up, down, left, right if possible
                if r+1 < NR: floodFillHelper(r+1, c)
                if r-1 >= 0: floodFillHelper(r-1, c)
                if c+1 < NC: floodFillHelper(r, c+1)
                if c-1 >= 0: floodFillHelper(r, c-1)

        floodFillHelper(sr, sc)
        return image


#Q14. Word Search
'''
Given an m x n grid of characters board and a string word, return true if word exists in the grid.

The word can be constructed from letters of sequentially adjacent cells, where adjacent cells are horizontally or vertically neighboring. The same letter cell may not be used more than once.

 

Example 1:


Input: board = [["A","B","C","E"],["S","F","C","S"],["A","D","E","E"]], word = "ABCCED"
Output: true
Example 2:


Input: board = [["A","B","C","E"],["S","F","C","S"],["A","D","E","E"]], word = "SEE"
Output: true
Example 3:


Input: board = [["A","B","C","E"],["S","F","C","S"],["A","D","E","E"]], word = "ABCB"
Output: false
 

Constraints:

m == board.length
n = board[i].length
1 <= m, n <= 6
1 <= word.length <= 15
board and word consists of only lowercase and uppercase English letters.
 

Follow up: Could you use search pruning to make your solution faster with a larger board?

'''
#Solution

#Method-1
#index search

class Solution:
    def exist(self, board: List[List[str]], word: str) -> bool:
        m = len(board)
        n = len(board[0])
        
        def check(i, j):
            return 0 <= i < m and 0 <= j < n
        
        def search(i, j, indx):
            if indx == len(word):
                return True
            if not check(i, j) or board[i][j] != word[indx]:
                return
            board[i][j] = "*"
            for nx, ny in [[i+1, j], [i-1, j], [i, j+1], [i, j-1]]:
                if search(nx, ny, indx+1):
                    return True
            board[i][j] = word[indx]
            return False
        
        for i in range(m):
            for j in range(n):  
                if board[i][j] == word[0]:
                    if search(i, j, 0):
                        return True
        return False

    
#Method-2
#DFS solution
# Time Limit Exceeded

class Solution:
    # @param board, a list of lists of 1 length string
    # @param word, a string
    # @return a boolean
    # 3:42
    def exist(self, board, word):
        visited = {}

        for i in range(len(board)):
            for j in range(len(board[0])):
                if self.getWords(board, word, i, j, visited):
                    return True
        
        return False

    def getWords(self, board, word, i, j, visited, pos = 0):
        if pos == len(word):
            return True

        if i < 0 or i == len(board) or j < 0 or j == len(board[0]) or visited.get((i, j)) or word[pos] != board[i][j]:
            return False

        visited[(i, j)] = True
        res = self.getWords(board, word, i, j + 1, visited, pos + 1) \
                or self.getWords(board, word, i, j - 1, visited, pos + 1) \
                or self.getWords(board, word, i + 1, j, visited, pos + 1) \
                or self.getWords(board, word, i - 1, j, visited, pos + 1)
        visited[(i, j)] = False

        return res
    
#Method-3

# Backtracing

class Solution(object):
    def exist(self, board, word):
        if board==[]:
            return 0
        
        for r in range(len(board)):
             for c in range(len(board[0])):
                    if board[r][c]==word[0]:
                        if self.helper(board[:],word[1:],r,c):
                            return True
        return False
        
    def helper(self,board,word,r,c):
        if word=="":
            return True
    
        tmp=board[r][c]
        board[r][c]="#"
        #print r,c,board,word
    
        if r-1>=0 and board[r-1][c]==word[0]:
             if self.helper(board[:],word[1:],r-1,c):
                return True

        if r+1<=len(board)-1 and board[r+1][c]==word[0]:
            if self.helper(board[:],word[1:],r+1,c):
                return True
        
        if c-1>=0 and board[r][c-1]==word[0]:
            if self.helper(board[:],word[1:],r,c-1):
                return True
    
        if c+1<=len(board[0])-1 and board[r][c+1]==word[0]:
             if self.helper(board[:],word[1:],r,c+1):
                return True
    
        board[r][c]=tmp
        return False


#Method-4
#Recursive DFS Solution

class Solution:
    def dfs(self,board,index,recursionStack,word,i,j):
        #we will do dfs from the index i,j in order to complete the word on the board
        if index == len(word)-1:
            return True
        recursionStack.add((i,j))
        result = False
        if i > 0:
            if (i-1,j) not in recursionStack and board[i-1][j] == word[index+1]:
                result = result or self.dfs(board,index+1,recursionStack,word,i-1,j)
        if i < len(board)-1:
            if (i+1,j) not in recursionStack and board[i+1][j] == word[index+1]:
                result = result or self.dfs(board,index+1,recursionStack,word,i+1,j)
        if j > 0:
            if (i,j-1) not in recursionStack and board[i][j-1] == word[index+1]:
                result = result or self.dfs(board,index+1,recursionStack,word,i,j-1)
        if j < len(board[0])-1:
            if (i,j+1) not in recursionStack and board[i][j+1] == word[index+1]:
                result = result or self.dfs(board,index+1,recursionStack,word,i,j+1)
        recursionStack.remove((i,j))
        return result
    def exist(self, board: List[List[str]], word: str) -> bool:
        for i in range(len(board)):
            for j in range(len(board[0])):
                if board[i][j] == word[0]:
                    if self.dfs(board,0,set({}),word,i,j):
                        return True
        return False

#Q15 . N-Queens

'''
The n-queens puzzle is the problem of placing n queens on an n x n chessboard such that no two queens attack each other.

Given an integer n, return all distinct solutions to the n-queens puzzle. You may return the answer in any order.

Each solution contains a distinct board configuration of the n-queens' placement, where 'Q' and '.' both indicate a queen and an empty space, respectively.

 

Example 1:


Input: n = 4
Output: [[".Q..","...Q","Q...","..Q."],["..Q.","Q...","...Q",".Q.."]]
Explanation: There exist two distinct solutions to the 4-queens puzzle as shown above
Example 2:

Input: n = 1
Output: [["Q"]]
 

Constraints:

1 <= n <= 9
'''
#Solution

# Method-1
# dfs with recursion

class Solution(object):
    def solveNQueens(self, n):
        
        def dfs(path,res):
            if len(path)==n:
                res.append(path)
            for i in range(n):
                test=True
                for item in path:
                    if  abs(item[1]-i)==abs(len(path)-item[0]) or item[1]==i:
                        test=False
                if test:
                    dfs(path+[[len(path),i]],res)
        res=[]
        dfs([],res)
        for i in range(len(res)):
            for j in range(n):
                res[i][j]="."*(res[i][j][1])+"Q"+"."*(n-1-res[i][j][1])
        return res
    
    
    
 # Method-2 

# DFS
# Time complexity
# I use Hash set to reduce the time complexity of check if a new queen is placed in a valid location from O(n) to O(1).
# The overall time complexity is O(N!).

# Space complexity
# O(N^2)
# backtracking

class Solution:
    def solveNQueens(self, n: int) -> List[List[str]]:
        self.n = n
        self.res = []
        self.nQueensRec([], set(), set(), set())
        return self.res
    
    def nQueensRec(self, placed: List[int], ys: Set[int], xy_sums: Set[int], xy_diffs: Set[int]) -> None:
        """Placed the next queen. Here we use additional sets to reduce the time complexity by storing all
        the "y"s, sums/diff of "x" and "y" we have seen so far in the placed queen locations.

        Args:
            placed (List[int]): the queens already placed on the board.
        """
        if len(placed) == self.n:
            # All the n queens are placed
            self.appendToRes(placed)
        
        x = len(placed)
        for y in range(self.n):
            # Test if (x, y) is a valid location for the new queen
            if y in ys or x + y in xy_sums or x - y in xy_diffs:
                continue
            ys.add(y)
            xy_sums.add(x+y)
            xy_diffs.add(x-y)
            self.nQueensRec(placed + [y], ys, xy_sums, xy_diffs)
            xy_diffs.remove(x-y)
            xy_sums.remove(x+y)
            ys.remove(y)

    def appendToRes(self, placed: List[int]) -> None:
        # Form a solution and append to self.res
        sol = ["".join([("Q" if j == placed[i] else ".")
                         for j in range(self.n)]) 
                for i in range(self.n)]

        self.res.append(sol)


# Method-3
class Solution:
    def solveNQueens(self, n: int) -> List[List[str]]:
        ret, cur = set(), [['e' for i in range(n)] for i in range(n)]
        used = set()
        def backtrack(r, n, cur):
            if r == n:
                temp = []
                for i in range(n):
                    temp.append(''.join(cur[i]))
                ret.add(''.join(temp))
                return
            
            for c in range(n):
                if cur[r][c] == 'e':
                    cur_copy = [x[:] for x in cur]
                    cur_copy[r][c] = 'Q'
                    
                    row, col = r, c
                    while row > 0:
                        row -= 1
                        cur_copy[row][col] = '.'
                    row, col = r, c
                    while row < n - 1:
                        row += 1
                        cur_copy[row][col] = '.'
                    row, col = r, c
                    while col > 0:
                        col -= 1
                        cur_copy[row][col] = '.'
                    row, col = r, c
                    while col < n - 1:
                        col += 1
                        cur_copy[row][col] = '.'
                            
                    row, col = r, c
                    while (row > 0) and (col > 0) :
                        row -= 1
                        col -= 1
                        cur_copy[row][col] = '.'
                    row, col = r, c
                    while (row > 0) and (col < n - 1) :
                        row -= 1
                        col += 1
                        cur_copy[row][col] = '.'
                    row, col = r, c
                    while (row < n - 1) and (col > 0) :
                        row += 1
                        col -= 1
                        cur_copy[row][col] = '.'
                    row, col = r, c
                    while (row < n - 1) and (col < n - 1) :
                        row += 1
                        col += 1
                        cur_copy[row][col] = '.'
                    backtrack(r + 1, n, cur_copy)
           
            return
        backtrack(0, n, cur)
        ret_list = []
        for s in ret:
            ret_list.append([s[i : i+n] for i in range(0, len(s), n)])
        return ret_list
    
    
#MEthod-4

# dfs and backtracking solutions with brief explanation
# Consider n-queen problem, therefore, there is an associated n by n grid M[i, j] with 0<=i, j <= n-1.

# First, we need to make clear the non-attacking conditions for two queens. Assume Q_1(x, y), Q_2(a, b). When Q_1 and Q_2 in the same row (y==b), or in the same column (x==a), or in the diagonal (either both in a line with slope 1, or both in a line with slope -1; in the former, x-y == a-b, and in the latter x+y = a +b), therefore, the non-attacking condition is:

# (y != b) and (x!=a) and ((x-y != a-b) and (x+y != a+b)).

# Second, in practice, we can manually gradually increase the row index of the n queens so that each queen lies in a distinct row. Therefore, we just need to check the following condition:

# (x!=a) and ((x-y != a-b) and (x+y != a+b)).

# Finally, we use backtracking (DFS) to find all the possible solutions. As DFS involves, we use auxiliary stacks.

class Solution:
    def solveNQueens(self, n):
        """
        :type n: int
        :rtype: List[List[str]]
        """
        res, y_stack, x_minus_y_stack, x_plus_y_stack = [], [], [], []
        
        def dfs(x=0):
            if x == n:
                res.append(['.'*y + 'Q' + '.'*(n-1-y) for y in y_stack])
                return
            for y in range(n):
                if (y not in y_stack) and (x-y not in x_minus_y_stack) and (x+y not in x_plus_y_stack):
                    y_stack.append(y)
                    x_minus_y_stack.append(x-y)
                    x_plus_y_stack.append(x+y)
                    dfs(x+1)  # increasing depth
                    y_stack.pop()
                    x_minus_y_stack.pop()
                    x_plus_y_stack.pop()
        dfs()  # default is x = 0
        return res

    
# Method-5
# Backtracking format

class Solution:
    def solveNQueens(self, n: int) -> List[List[str]]:
        
        res = [] # hold possible configuration
        
        # hold cols, positive diags and negative diags that we could not put "Q" again
        cols, posDiag, negDiag = set(), set(), set()
        board = [["."] * n for _ in range(n)]
        
        # backtrack helper function
        def backtrack(r):
            if r == n:
                copy = ["".join(row) for row in board]
                res.append(copy)
                return
            
            for c in range(n):
                if c in cols or (r + c) in posDiag or (r - c) in negDiag:
                    continue
                
                # backtracking block
                cols.add(c); posDiag.add(r + c); negDiag.add(r - c)
                board[r][c] = "Q"
                backtrack(r + 1)
                # the back step in backtracking block
                cols.remove(c); posDiag.remove(r + c); negDiag.remove(r - c)
                board[r][c] = "."
        
        # backtracking
        backtrack(0)
        
        return res


#Q16 Swap Nodes in Pairs
'''
Given a linked list, swap every two adjacent nodes and return its head. You must solve the problem without modifying the values in the list's nodes (i.e., only nodes themselves may be changed.)

 

Example 1:


Input: head = [1,2,3,4]
Output: [2,1,4,3]
Example 2:

Input: head = []
Output: []
Example 3:

Input: head = [1]
Output: [1]
 

Constraints:

The number of nodes in the list is in the range [0, 100].
0 <= Node.val <= 100

'''
#Solution

#Method-1

class Solution:
    def swapPairs(self, head: Optional[ListNode]) -> Optional[ListNode]:
        def swap(prev,cur,head):
            # base case for recursion
            if cur is None or cur.next is None:
                return head
            # only attain new head value on the first swap
            if cur == head:
                head = cur.next
            next_ = cur.next
            # swap the current and next nodes 
            cur.next, next_.next = next_.next, cur
            # if there is a previous node change its next attr.
            if prev:
                prev.next = next_
            return swap(cur,cur.next,head)
        # call recursion func with initial attr. values
        return swap(None, head, head)
    

    
#Method-2    
#Single pass with O(1) space using 2 pointers

class Solution:
    def swapPairs(self, head: Optional[ListNode]) -> Optional[ListNode]:
        
        if head == None or head.next == None:
            return head
        
        solution = head.next
        
        left_ptr = head
        right_ptr = head.next
        
        while left_ptr and right_ptr:
            temp = right_ptr.next
            
            right_ptr.next = left_ptr
            left_ptr.next = temp if temp == None else (temp if temp.next == None else temp.next)
            
            
            left_ptr = temp
            if temp:
                right_ptr = temp.next
            
        return solution
    
#Method-3
# O(N) || Iterative

class Solution:
    def swapPairs(self, head: Optional[ListNode]) -> Optional[ListNode]:
        if not head or not head.next:
            return head
        
        dummy_head = node1 = ListNode(next=head)
        node2 = head
        node3 = head.next
        
        while node3:
            node1.next = node3
            node2.next = node3.next
            node3.next = node2
            
            node1 = node2
            node2 = node2.next
            if node2 and node2.next:
                node3 = node2.next
            else:
                node3 = None
        
        return dummy_head.next
    
#Method-4
# Swap Nodes in Pairs
class Solution:
    def swapPairs(self, head: Optional[ListNode]) -> Optional[ListNode]:
        dummy = cur = ListNode(0)
        while head:
            if head.next:
                cur.next = ListNode(head.next.val)
                cur.next.next = ListNode(head.val)
                head = head.next
                head = head.next
                cur = cur.next
                cur = cur.next
            else:
                cur.next = ListNode(head.val)
                head = head.next
                cur = cur.next
        return dummy.next

#Method-5    
class Solution:
    def swapPairs(self, head: Optional[ListNode]) -> Optional[ListNode]:
        if head == None or head.next == None:
            return head
        
        dummy = ListNode()
        dummy.next = head
        prev = dummy
        while prev.next and prev.next.next:
            p1 = prev.next
            p2 = prev.next.next
            
            p1.next = p2.next
            prev.next = p2
            p2.next = p1
            
            prev = p1
            
        return dummy.next
        

#Q17 Maximize Number of Nice Divisors
'''
You are given a positive integer primeFactors. You are asked to construct a positive integer n that satisfies the following conditions:

The number of prime factors of n (not necessarily distinct) is at most primeFactors.
The number of nice divisors of n is maximized. Note that a divisor of n is nice if it is divisible by every prime factor of n. For example, if n = 12, then its prime factors are [2,2,3], then 6 and 12 are nice divisors, while 3 and 4 are not.
Return the number of nice divisors of n. Since that number can be too large, return it modulo 109 + 7.

Note that a prime number is a natural number greater than 1 that is not a product of two smaller natural numbers. The prime factors of a number n is a list of prime numbers such that their product equals n.

 

Example 1:

Input: primeFactors = 5
Output: 6
Explanation: 200 is a valid value of n.
It has 5 prime factors: [2,2,2,5,5], and it has 6 nice divisors: [10,20,40,50,100,200].
There is not other value of n that has at most 5 prime factors and more nice divisors.
Example 2:

Input: primeFactors = 8
Output: 18
 

Constraints:

1 <= primeFactors <= 109

'''
#Solution


# Method-1
# New Method | Convex Optimization | Binary Search | O(log primeFactors)
# n = p1^q1p2^q2...pk^qk
# p1, p2, p3,..., pk are distinct prime numbers
# then q1 + q2 + q3 + ... + qk = primeFactors
# therefore, the number of nice divsors of n is q1q2q3*...qk
# q1q2q3*...qk is maximized when q1, q2, ..., qk are almost equal
# nNiceDivisors(k) is the number of nice divisors when we use k distinct prime numbers
# nNiceDivisors(k) is convex function of k
# So we do binary search for the function nNiceDivisors(k) to find the optimum k
# Instead of nNiceDivisors(k) we use log(nNiceDivisors(k)) which is nNiceDivisorsLog(k) to save computation

import math
class Solution:
    def maxNiceDivisors(self, primeFactors: int) -> int:
        M = 10**9+7
        def nNiceDivisorsLog(k):
            q, r = divmod(primeFactors, k)
            return r*math.log(q+1)+(k-r)*math.log(q)
        def nNiceDivisors(k):
            q, r = divmod(primeFactors, k)
            return pow(q+1,r,M)*pow(q,k-r,M)
        l, r = 1, primeFactors
        while l < r:
            m = (l+r)//2
            if nNiceDivisorsLog(m) < nNiceDivisorsLog(m+1):
                l = m + 1
            else:
                r = m
        return nNiceDivisors(l)%M
 

# Method-2

import math
class Solution:
    def maxNiceDivisors(self, m):
        mod = 10**9 + 7
    
        if m == 1:
            return 1
    
        if m%3 == 0:
            return pow(3,m//3,mod)
    
        if m%3 == 1:
            return (4*pow(3,m//3-1,mod))%mod
    
        if m%3 == 2:
            return (2*pow(3,m//3,mod))%mod


#Q18 Power of Four
'''

Given an integer n, return true if it is a power of four. Otherwise, return false.

An integer n is a power of four, if there exists an integer x such that n == 4x.

 

Example 1:

Input: n = 16
Output: true
Example 2:

Input: n = 5
Output: false
Example 3:

Input: n = 1
Output: true
 

Constraints:

-231 <= n <= 231 - 1
 

Follow up: Could you solve it without loops/recursion?

'''
#Solution

# Method-1
import math
class Solution:
    def isPowerOfFour(self, n: int) -> bool:
        if n<=0:
            return 0
        return pow(4,int(log2(n)/log2(4)))==n
    
    
    
# Method-2
class Solution:
    def isPowerOfFour(self, n: int) -> bool:
        if n==0:
            return False
        
        while n!=1:
            if n%4!=0:
                return False
            n=n/4
        return True

# Time Complexity = O(N)
# Space Complexity = O(1)


#Q19.  Count Good Numbers
'''
A digit string is good if the digits (0-indexed) at even indices are even and the digits at odd indices are prime (2, 3, 5, or 7).

For example, "2582" is good because the digits (2 and 8) at even positions are even and the digits (5 and 2) at odd positions are prime. However, "3245" is not good because 3 is at an even index but is not even.
Given an integer n, return the total number of good digit strings of length n. Since the answer may be large, return it modulo 109 + 7.

A digit string is a string consisting of digits 0 through 9 that may contain leading zeros.

 

Example 1:

Input: n = 1
Output: 5
Explanation: The good numbers of length 1 are "0", "2", "4", "6", "8".
Example 2:

Input: n = 4
Output: 400
Example 3:

Input: n = 50
Output: 564908303
 

Constraints:

1 <= n <= 1015
'''

#Solution

class Solution:
    def countGoodNumbers(self, n: int) -> int:
        fours = n // 2
        fives = (n + 1) // 2
        mod = 10**9 + 7
        ans = pow(4, fours, mod) * pow(5, fives, mod)
        return ans % mod
