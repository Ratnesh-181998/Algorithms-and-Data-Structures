

# STRING 

#Q1 Add Strings

'''
Given two non-negative integers, num1 and num2 represented as string, return the sum of num1 and num2 as a string.

You must solve the problem without using any built-in library for handling large integers (such as BigInteger). You must also not convert the inputs to integers directly.

 

Example 1:

Input: num1 = "11", num2 = "123"
Output: "134"
Example 2:

Input: num1 = "456", num2 = "77"
Output: "533"
Example 3:

Input: num1 = "0", num2 = "0"
Output: "0"
 

Constraints:

1 <= num1.length, num2.length <= 104
num1 and num2 consist of only digits.
num1 and num2 don't have any leading zeros except for the zero itself.

'''
#Solution 


# Method-1

# Solution simply using ord() and chr()

# Use built-in functions ord() and chr()

# For example,
# ord('a') returns the integer 97
# chr(97) returns the string 'a'


class Solution(object):
    def addStrings(self, num1, num2):
        i, j, carry, res = 0, 0, 0, []

        while i < len(num1) or j < len(num2) or carry:
            if i < len(num1):                       # get the value and move on
                carry, i = carry+ord(num1[::-1][i])-48, i+1
            if j < len(num2):
                carry, j = carry+ord(num2[::-1][j])-48, j+1
            res += carry%10,
            carry //= 10                            # carry to next digit

        return "".join([chr(c+48) for c in res[::-1]])
    
    
# Method-2

#easy string manipulation


class Solution:
    def addStrings(self, num1: str, num2: str) -> str:
        result = []
        i, j = len(num1)-1, len(num2)-1
        carry = 0
        
        while i >= 0 and j >= 0:
            s = int(num1[i]) + int(num2[j]) + carry
            
            if s > 9:
                carry = 1
                s = s % 10
            else:
                carry = 0
            result.append(str(s))    
            i -= 1
            j -= 1
            
            
        while i >= 0 or j >= 0:
            if i >= 0:
                s = int(num1[i]) + carry
                i -= 1
            else:
                s = int(num2[j]) + carry
                j -= 1
            if s > 9:
                carry = 1
                s = s % 10
            else:
                carry = 0
            result.append(str(s))
        if carry == 1:
            result.append(str(carry))
        return ''.join(result[::-1])

    
    
# Method-3    
# One line solution

class Solution:
    def addStrings(self, num1: str, num2: str) -> str:
        return str(eval(f'{num1}+{num2}'))
    
    
# Method-4

class Solution:
    def addStrings(self, num1: str, num2: str) -> str:
        s1,s2=int(num1), int(num2) # as the provided numbers are string we cant add them, so first we are making them as int to perform addition. 
        total = s1+s2 # adding 2 number. We cant add 2 numbers if their type is str using +, as it will result in concatenation. 
        return str(total) # converting back the integer adding to a string result as per the question requirement. 
    
    
    
    
# Method-5    
#Lets optimize above solution:-

class Solution:
    def addStrings(self, num1: str, num2: str) -> str:
        return str(int(num1)+int(num2)) # doing the same as in the above solution just in one line.



#Q2 Longest Common Prefix

'''
Write a function to find the longest common prefix string amongst an array of strings.

If there is no common prefix, return an empty string "".

 

Example 1:

Input: strs = ["flower","flow","flight"]
Output: "fl"
Example 2:

Input: strs = ["dog","racecar","car"]
Output: ""
Explanation: There is no common prefix among the input strings.
 

Constraints:

1 <= strs.length <= 200
0 <= strs[i].length <= 200
strs[i] consists of only lowercase English letters.

'''

# Solution 


#Method-1

class Solution:
    def longestCommonPrefix(self, strs: List[str]) -> str:
        mm,m=max(strs),min(strs)
        if m :
            for i in range(len(m)):

                if m[i] !=mm[i]:
                    return m[:i]
        return m

     
#Method-2        
# O(n) solution


class Solution:
    def longestCommonPrefix(self, strs: List[str]) -> str:
        if len(strs) <= 1: #Base condition, if only one word exists returns that word, not truly neccesary
            return strs[0] 
        
        lst = [len(word) for word in strs] 
        #Find shortest string: the maximum prefix can only be as long as the shortest word. 
        # Time complexity of len() is O(1)
        
        print(lst)
        for i in range(min(lst)): #Goes over the letters, from index 0 up until index equal to amount of characters in the shortest word 
            letter = strs[0][i] #Set letter to: ith letter in the first word
            for g in range(1, len(strs)): #Goes over the words, starting from the 2nd word
                if strs[g][i] != letter: #Checks if the letter in the ith position in the gth word is equal to letter
                    return strs[0][0:i] 

        return strs[0][:min(lst)] #Longest possible prefix is the length of the shortest word.


# Number of words = W, Minimum number of characters in all strings = C, C*W >= total length of chars in all words combined.         
# Time Complexity == O(W) + O(C*(W-1)) == O(C*W-C+W) == O(C*W) 

# Solution is O(n), where n is number of total characters in the array str




#Method-3

# Solution using sort and for loops

class Solution:
    def longestCommonPrefix(self, strs: List[str]) -> str:
        if len(strs) == 1:
            return strs[0]
    
        common = ''
        count = 0
    
        strs.sort()
    
        for letter in strs[0]:
            for word in range(1, len(strs)):
                if(strs[word][count] == letter):
                    continue
                else:
                    return common
            common += letter
            count += 1
        return common
	

# #Method-4   
# O(mn) solution

class Solution:
    def longestCommonPrefix(self, strs: List[str]) -> str:
        if len(strs) == 1:
            return strs[0]
        res = ""
        for ptr in range(min(map(len, strs))):
            for i in range(len(strs) - 1):
                if strs[i][ptr] != strs[i + 1][ptr]:
                    return res
            res += strs[i][ptr]
        return res
    

# #Method-5  
# python with zip() and len(set())


class Solution(object):
    def longestCommonPrefix(self, strs):
        """
        :type strs: List[str]; rtype: str
        """
        sz, ret = zip(*strs), ""
        # looping corrected based on @StefanPochmann's comment below
        for c in sz:
            if len(set(c)) > 1: break
            ret += c[0]
        return ret
    

    
#Method-6

class Solution:
    def longestCommonPrefix(self, strs: List[str]) -> str:
        digits = min([len(str) for str in strs])
        i = 0
        output = []
        while i < digits:
            if len(set([str[i] for str in strs])) == 1:
                output.append(strs[0][i])
            else:
                break
            i += 1
        return "".join(output)


#Method-7
#Longest Common Prefix Python Solution

class Solution:
    def longestCommonPrefix(self, strs: List[str]) -> str:
        common = ""
        
        for i in range(len(strs[0])):
            for j in strs:
                if(i == len(j) or j[i]!=strs[0][i]):
                    return common
            common += strs[0][i]
        
        return common


 #Q3 Valid Palindrome II
 '''
Given a string s, return true if the s can be palindrome after deleting at most one character from it.

 

Example 1:

Input: s = "aba"
Output: true
Example 2:

Input: s = "abca"
Output: true
Explanation: You could delete the character 'c'.
Example 3:

Input: s = "abc"
Output: false
 

Constraints:

1 <= s.length <= 105
s consists of lowercase English letters.

 '''

 # Solution 

 #Method-1

class Solution:
    def validPalindrome(self, s: str) -> bool:
        l, r = 0, len(s)-1
        while l < r:
            if s[l] != s[r]:
                delete_l = s[l+1:r+1] # delete one elements from left side
                delete_r = s[l:r] # delete one elements from right side
                return delete_l == delete_l[::-1] or delete_r == delete_r[::-1]
            l+=1
            r-=1
        return True
 
    
    
    
    
#Method-2
#solution using Two-Pointer approach

class Solution:
    def validPalindrome(self, s: str) -> bool:
        s=list(s)
        f=0
        l=len(s)-1
        while f<l:
            if s[f]==s[l]:
                f=f+1
                l=l-1
            else:
                return self.palindrome(s,f+1,l) or self.palindrome(s,f,l-1)
        return True
                
    def palindrome(self,s,f,l):
        while f<l:
            if s[f]==s[l]:
                f=f+1
                l=l-1
            else:
                return False
        return True
    
    
class Solution(object):
    def validPalindrome(self, s):
        """
        :type s: str
        :rtype: bool
        """
        if s[:] == s[::-1]: #Check if it is a straightforward palindrome
            return True 
        
        start = 0
        end = len(s) - 1
        while start < end:
            if s[start] == s[end]:
                start += 1
                end -= 1
            else:
                break   # check for the first pair of mismatch characters.
   
       # We have 2 options now: Create temp1 after removing the 1 character from the above pair. Create temp2 after removing the other character. If one of them is palindrome then we can satisfy the 'remove at most 1 character' condition.     
        
        temp1 = ''
        if start == 0:
            temp1 = s[start+1:]
        else:
            temp1 = s[0:start] + s[start+1:]
        
        temp2 = ''
        if end == len(s)-1:
            temp2 = s[:end]
        else:
            temp2 = s[0:end] + s[end+1:]
        
        return (temp1[:] == temp1[::-1]) or (temp2[:] == temp2[::-1])



#Method-3
#Top-down (dfs)

# use i and j to track the character which will be matched, i is on the left side of the s, j is on the right side of s, k is to track how many deletion is used, dfs(l, r, k) is to find how many insertions to make s[l:r+1] palindrone. i and j and k are state of the dfs.

# if s[i] is matched with s[j], we can reduce search space to [i+1, j-1], move to next two characters s[i-1] and s[j+1]
# if not, if the only one deletion is not used, we can delete one of them (s[i] and s[j])
# if used, just return False
# the base cases have two, one is deletion time not meet the problem requirement, return False
# another is i and j are at the same character or i is after j
# cache is to store sub result.
# tc is O(N^2), sc is the same as tc

class Solution:
    def validPalindrome(self, s: str) -> bool:
        @cache
        def dfs(i, j, k):
            if k > 1: return False
            if j - i <= 0: return True
            if s[i] == s[j]:
                return dfs(i+1, j-1, k)
            else:
                if k == 0:
                    return dfs(i+1, j, k+1) or dfs(i, j-1, k+1)
                else: return False
        return dfs(0, len(s) - 1, 0)

    
       
#Method-4

class Solution(object):
    def validPalindrome(self, s):
        h, t = 0, len(s) - 1  # head and tail
        while h < t:
            if s[h] != s[t]:  # delete s[h] or s[t] and validate palindrome finally
                 return s[h:t] == s[h:t][::-1] or s[h + 1:t + 1] == s[h + 1:t + 1][::-1]
            h, t = h + 1, t - 1
        return True


#Method-5

# Algorithm
# Initialize i and j to 0 and len(s)-1.
# Now while i < j, test if s[i] is equal to s[j]. When s[i] == s[j], then advance i and reduce j. If we find no mismatch and i >= j, then return True.
# Otherwise, on the first mismatch, say at i1, j1, test if s[i1+1:j1+1] or s[i1:j1] are palindromes.
# Linear time and no extra space is required.


class Solution:
    def test(self, s, i, j):
        while i<j:
            if s[i] != s[j]:
                return False
            i, j = i+1, j-1
        return True
    
    def validPalindrome(self, s):
        """
        :type s: str
        :rtype: bool
        """
        i, j = 0, len(s)-1
        while i < j:
            if s[i] != s[j]:
                return self.test(s,i+1,j) or self.test(s, i, j-1)
            i,j = i+1, j-1
        return True  

    



#Q4 Roman to Integer
''''
Roman numerals are represented by seven different symbols: I, V, X, L, C, D and M.

Symbol       Value
I             1
V             5
X             10
L             50
C             100
D             500
M             1000
For example, 2 is written as II in Roman numeral, just two ones added together. 12 is written as XII, which is simply X + II. The number 27 is written as XXVII, which is XX + V + II.

Roman numerals are usually written largest to smallest from left to right. However, the numeral for four is not IIII. Instead, the number four is written as IV. Because the one is before the five we subtract it making four. The same principle applies to the number nine, which is written as IX. There are six instances where subtraction is used:

I can be placed before V (5) and X (10) to make 4 and 9. 
X can be placed before L (50) and C (100) to make 40 and 90. 
C can be placed before D (500) and M (1000) to make 400 and 900.
Given a roman numeral, convert it to an integer.

 

Example 1:

Input: s = "III"
Output: 3
Explanation: III = 3.
Example 2:

Input: s = "LVIII"
Output: 58
Explanation: L = 50, V= 5, III = 3.
Example 3:

Input: s = "MCMXCIV"
Output: 1994
Explanation: M = 1000, CM = 900, XC = 90 and IV = 4.
 

Constraints:

1 <= s.length <= 15
s contains only the characters ('I', 'V', 'X', 'L', 'C', 'D', 'M').
It is guaranteed that s is a valid roman numeral in the range [1, 3999].
'''

#Solution

# #Method-1
class Solution:
    def romanToInt(self, s: str) -> int:
        a={"I":1,"V":5,"X":10,"L":50,"C":100,"D":500,"M":1000}
        sum=0
        l=[]
        for x in s:
            l.append(x)
        x=0
        while x<len(l):
            if x<len(l)-1 and a[l[x]]<a[l[x+1]]:
                sum += (a[l[x+1]] - a[l[x]])
                x += 2
            else:
                sum += a[l[x]]
                x += 1
        return sum


# #Method-2

class Solution:
	def romanToInt(self, s: str) -> int:
		# Create empty list to append to
		tmp = [] 
		# Loop through each character in input string and append the numerical equivalent
		for i in s:
			if i == "I":
				tmp.append(1)
			elif i == "V":
				tmp.append(5)
			elif i == "X":
				tmp.append(10)
			elif i == "L":
				tmp.append(50)
			elif i == "C":
				tmp.append(100)
			elif i == "D":
				tmp.append(500)
			elif i == "M":
				tmp.append(1000)

		# Loop through the list and compare current value with the next value to determine whether to add or subract
		for i in range(len(tmp)):
			try:
				next = tmp[i+1] 
			except:
				next = 0
			if tmp[i] >= next:
				continue
			else:
				tmp[i] = -tmp[i] # If the current value is less than the next, it negates it, so it will subract when summing the total.
		return sum(tmp)


#Method-3

# First sum up all single roman numerals, then if we find currValue > prevValue, we subtract 2 * prevValue, e.g. CM, first we get 1100, then we subtract 200, the result is 900.

class Solution:
    def romanToInt(self, s):
        value, prevValue, result = {'M': 1000, 'D': 500, 'C': 100, 'L': 50, 'X': 10, 'V': 5, 'I': 1}, None, 0
        for ch in s:
            currValue = value[ch]
            result += currValue
            if prevValue and currValue > prevValue: result -= 2 * prevValue
            prevValue = currValue
        return result

    
    
#Method-4   
class Solution:    
    def romanToInt(self, s):
        """
        :type s: str
        :rtype: int
        """
        memo, val = {'I':1,'V':5,'X':10,'L':50,'C':100,'D': 500,'M':1000}, 0
        for i,v in enumerate(s):
            val += -memo[v] if memo[s[min(len(s)-1,i+1)]] > memo[v] else memo[v]
        return val




#Method-5
#Simple Python Solution Using HashMap | Dictionary 

class Solution:
	def romanToInt(self, s: str) -> int:

		d = {'I':1, 'V':5, 'X':10, 'L':50, 'C':100, 'D':500, 'M':1000}

		number = []

		for i in s:

			number.append(d[i])

		for index in range(len(number) - 1):

			if number[index] < number[index + 1]:

				number[index] = -number[index]

		return sum(number)



#Q5 Implement strStr()

'''
Implement strStr().

Given two strings needle and haystack, return the index of the first occurrence of needle in haystack, or -1 if needle is not part of haystack.

Clarification:

What should we return when needle is an empty string? This is a great question to ask during an interview.

For the purpose of this problem, we will return 0 when needle is an empty string. This is consistent to C's strstr() and Java's indexOf().

 

Example 1:

Input: haystack = "hello", needle = "ll"
Output: 2
Example 2:

Input: haystack = "aaaaa", needle = "bba"
Output: -1
 

Constraints:

1 <= haystack.length, needle.length <= 104
haystack and needle consist of only lowercase English characters.

'''

#Solution 

# Method-1
class Solution:
    def strStr(self, haystack: str, needle: str) -> int:
        
        for i in range(len(haystack)-len(needle)+1):
            if haystack[i:i+len(needle)]==needle:
                return i
        return -1
  


# Method-2

class Solution:   
    def strStr(self, haystack: str, needle: str) -> int:
        return haystack.find(needle) # It returns -1 if string not found
    
    
    
    
# Method-3    
# Python using Dictionaries

class Solution:
    def strStr(self, haystack: str, needle: str) -> int:

        d = {}
        
        for x in range(0,len(haystack)):
            if x + len(needle)-1 == len(haystack):
                break
            d[haystack[x: x + len(needle)]] = d.get(haystack[x: x + len(needle)], x)

        
        return d.get(needle, -1)


    
# Method-4
# Time O(N*M) Space O(1)
# Do we need to really use KMP in the interview? I just had a few interviews but personally I really can not remember those fantastic algorithms in that short period of time in pressure. Maybe I was nervous and needed more programming practice..

class Solution:
    def strStr(self, haystack, needle):
        if needle == "":
            return 0
        for i in range(len(haystack)-len(needle)+1):
            for j in range(len(needle)):
                if haystack[i+j] != needle[j]:
                    break
                if j == len(needle)-1:
                    return i
        return -1
    
  
# Method-5

class Solution:
    # @param haystack, a string
    # @param needle, a string
    # @return an integer
    def strStr(self, haystack, needle):
        ln = len(needle)
        lh = len(haystack)
        if ln > lh:
            return -1
        if ln == 0:#if needle is '' then return 0 for empty string is the substring of any string
            return 0
        for i in range(lh - ln + 1):#we only need consider the length of lh - ln
            j = 0
            while haystack[i + j] == needle[j]:
                j += 1
                if j == len(needle):
                    return i
        return -1





 #Q6 Longest Substring Without Repeating Characters

'''
Given a string s, find the length of the longest substring without repeating characters.

 

Example 1:

Input: s = "abcabcbb"
Output: 3
Explanation: The answer is "abc", with the length of 3.
Example 2:

Input: s = "bbbbb"
Output: 1
Explanation: The answer is "b", with the length of 1.
Example 3:

Input: s = "pwwkew"
Output: 3
Explanation: The answer is "wke", with the length of 3.
Notice that the answer must be a substring, "pwke" is a subsequence and not a substring.
 

Constraints:

0 <= s.length <= 5 * 104
s consists of English letters, digits, symbols and spaces.
'''

# Solution 

# #Method-1

# simple solution. O(n)
# hashmap

class Solution:
    def lengthOfLongestSubstring(self, s: str) -> int:
        if len(s) == 0:
            return 0
        
        global_max = 1
        left = 0
        used = {}
        
        for right in range(0,len(s)):
            if s[right] in used:
                left = max(left, used[s[right]]+1)
            used[s[right]] = right
            
            global_max = max(right-left+1, global_max)
        return global_max


#Method-2
# 2 pointer 

# We will take two pointers i and j where i <= j < len(s)

# i and j will be used to find the substring that we will consider for the calcuation i.e. s[i:j+1]

# If the length of substring s[i:j+1] = len of the set of the same substring, then it means that we have all unique characters in that substring so we will store the length of the substring in res
# example:
# s = abcd
# i = 0, j = 3
# len(s[i:j+1]) = 4
# len(set(s[i:j+1])) = 4

# Now we increase the size of substring by incrementing j by 1.

# As soon as our condition fails, it means that starting from s[i] we have found the longest substring that can be formed from s[i] with unique elements.
# example:
# s = abcda
# i = 0, j = 4
# len(s[i:j+1]) = 5
# len(set(s[i:j+1])) = 4

# So now we move to the next starting element of our new substring by incrementing i by 1 and bring j back to i + 1


class Solution:
    def lengthOfLongestSubstring(self, s: str) -> int:
        if len(s) == 0:
            return 0
        
        elif len(s) == len(set(s)):
            return len(s)
        
        else:
            i = 0
            j = i + 1
            res = 1
            while i < len(s) and j < len(s):
                if len(s[i:j+1]) == len(set(s[i:j+1])):
                    res = max(res, len(s[i:j+1]))
                    j += 1
                else:
                    i += 1
                    j = i + 1
            return res

        
#Method-3

class Solution:
    # @return an integer
    def lengthOfLongestSubstring(self, s):
        char_dict = dict()
        start, length = 0, 0
        for n, char in enumerate(s):
            if char in char_dict:
                start = max(start, char_dict[char]+1)
            char_dict[char] = n
            length = max(length, n - start+1)
        return length


#Method-4

# O(n) linear time solution using hashTable and slice window

class Solution:
    def lengthOfLongestSubstring(self, s: str) -> int:
        dic = {}
        result = 0
        count = 0
        start = 0
        
        for i in range(len(s)):
            if s[i] not in dic.keys():
                dic[s[i]] = i
                count += 1
            elif s[i] in dic.keys() and dic[s[i]] < start:
                count += 1
                dic[s[i]] = i
            else:
                if count > result:
                    result = count
                start = dic[s[i]] + 1
                count = i - start + 1
                dic[s[i]] = i
                
        return result if result > count else count
    

#Method-5
#O(n) time and O(n) space - two pointers

class Solution:
    def lengthOfLongestSubstring(self, s: str) -> int:
        """
		two pointers
		- start pointer and end pointer comprises a window of valid substring
		- move the end pointer on every iteration and adjust the start pointer as we go along
		- use a map to keep track of what chars has been seen with its index
		- make sure that once the end pointer sees a duplicate that we adjust the start pointer accordingly
		  - if the seen value is behind the start pointer, do nothing
		  - if the seen value is on where the start pointer is or ahead of it, move the start pointer so it is end pointer + 1
        """
        start_ptr = 0
        end_ptr = 0
        max_len = 0
        char_map = {}

        while end_ptr < len(s):
            curr_len = 0
            if s[end_ptr] not in char_map:
                char_map[s[end_ptr]] = end_ptr
            else:
                if start_ptr <= char_map[s[end_ptr]]:
                    start_ptr = char_map[s[end_ptr]] + 1
                char_map[s[end_ptr]] = end_ptr
            curr_len = end_ptr - start_ptr  + 1
            max_len = max(max_len, curr_len)
            end_ptr += 1

        return max_len



#Q7 Minimum Remove to Make Valid Parentheses
'''
Given a string s of '(' , ')' and lowercase English characters.

Your task is to remove the minimum number of parentheses ( '(' or ')', in any positions ) so that the resulting parentheses string is valid and return any valid string.

Formally, a parentheses string is valid if and only if:

It is the empty string, contains only lowercase characters, or
It can be written as AB (A concatenated with B), where A and B are valid strings, or
It can be written as (A), where A is a valid string.
 

Example 1:

Input: s = "lee(t(c)o)de)"
Output: "lee(t(c)o)de"
Explanation: "lee(t(co)de)" , "lee(t(c)ode)" would also be accepted.
Example 2:

Input: s = "a)b(c)d"
Output: "ab(c)d"
Example 3:

Input: s = "))(("
Output: ""
Explanation: An empty string is also valid.
 

Constraints:

1 <= s.length <= 105
s[i] is either'(' , ')', or lowercase English letter.

'''
#Solution 

# #Method-1

class Solution:
    def minRemoveToMakeValid(self, s) :
        stack=[]
        split_str=list(s)
        for i in range(len(s)):
            if s[i]=='(':
                # if current char is '(' then push it to stack
                stack.append(i)
            elif s[i]==')':
                # if current char is ')' then pop top of the stack
                if len(stack) !=0:
                    stack.pop()
                else:
                    # if our stack is empty then we can't pop so make  current char as ''
                    split_str[i]=""
        for i in stack:
            split_str[i]=""
        return '' .join(split_str)


#Method-2
# moving forward and backword


class Solution:
    def minRemoveToMakeValid(self, s: str) -> str:
        res = ''
        
        l = []
        
        for i in s:
            if i == ')':
                if l and l[-1] == '(':
                    res = res + i
                    l.pop()
            elif i =='(':
                l.append(i)
                res = res +i
            else:
                res += i
        
        if len(l) == 0:
            return res
        
        l =[]
        s = res
        res =''
        
        for i in s[::-1]:
            if i == '(':
                if l and l[-1] == ')':
                    res = i +res
                    l.pop()
            elif i ==')':
                l.append(i)
                res = i + res
            else:
                res = i+res
                
        return res
    

#Method-3 
#Stack 
class Solution:   
    def minRemoveToMakeValid(self, s: str) -> str:
        stack=[]
        close=[]
        res=[]
        for i,string in enumerate(s):
            if string=='(':
                stack.append(i)
            elif string==')':
                if stack:
                    stack.pop()
                else:
                    close.append(i)
        to_be_delete=set(close+stack)
        for i,string in enumerate(s):
            if i in to_be_delete:
                continue
            res.append(string)
        return "".join(res)

#Method-4    
#  O(n) single iteration

# Solution is straight forward. Just remove invalid parentheses as we go.

# Iterate through the string once, storing the index of open parentheses in a stack.

# When we come to a closing parentheses, it is valid if the stack isn't empty. If the stack isn't empty, we pop from the stack, otherwise we remove the closing parentheses from the string.

# Finally, remove invalid open parentheses.

# Time complexity: O(n)
# Space complexity: O(n)

class Solution:
                   
    def minRemoveToMakeValid(self, s: str) -> str:
        
        stack = [] # store indexes of unclosed open parentheses

        i = 0
        while i < len(s):
            char = s[i]
            
            # add index of open parentheses to stack
            if char == '(':
                stack.append(i)
                
            # check if closing parentheses is valid, removing if not
            if char == ')':
                if not stack:
                    s = s[:i] + s[i+1:]
                    i-=1 # we don't want to increment the index in the case of invalid closing parentheses
                else:
                    stack.pop()
            i+=1
            
        # remove unclosed open parentheses
        while stack:
            i = stack.pop()
            s = s[:i] + s[i+1:]
            
        return s
    
    
#Method-5    
#o(n) solution


class Solution:
    def minRemoveToMakeValid(self, s: str) -> str:
        s1=[]

        for j,i in enumerate(s):
            if i.isalpha():
                continue
            elif i=='(':
                s1.append((i,j))
            else:
                if s1:
                    if s1[-1][0]=="(":
                        s1.pop()
                    else:
                        s1.append((i,j))
                else:
                    s1.append((i,j))
        res=[]
        t=[i for j,i in s1]
        print(t,s1)
        if s1:
            for i,j in enumerate(s):
                if i in t:
                    continue
                res.append(j)
            return ''.join(res)
        return s
                
        
        
# Another Way 
#Count
class Solution:
    def minRemoveToMakeValid(self, s):
        count = 0
        a = []
        for i in s:
            if i == '(': 
                count +=1
                a.append(i)
            elif i == ')': 
                if count > 0:
                    a.append(i)
                    count -= 1
            else: a.append(i)
        
        l = len(a) - 1
        while l >=0 and count > 0:
            if a[l] == '(':
                count -= 1
                del a[l]
            l -= 1
        return ''.join(a)



 #Q 8 . Minimum Remove to Make Valid Parentheses


 '''
Given a string s of '(' , ')' and lowercase English characters.

Your task is to remove the minimum number of parentheses ( '(' or ')', in any positions ) so that the resulting parentheses string is valid and return any valid string.

Formally, a parentheses string is valid if and only if:

It is the empty string, contains only lowercase characters, or
It can be written as AB (A concatenated with B), where A and B are valid strings, or
It can be written as (A), where A is a valid string.
 

Example 1:

Input: s = "lee(t(c)o)de)"
Output: "lee(t(c)o)de"
Explanation: "lee(t(co)de)" , "lee(t(c)ode)" would also be accepted.
Example 2:

Input: s = "a)b(c)d"
Output: "ab(c)d"
Example 3:

Input: s = "))(("
Output: ""
Explanation: An empty string is also valid.
 

Constraints:

1 <= s.length <= 105
s[i] is either'(' , ')', or lowercase English letter.

 '''

 # Solution 

 # #Method-1

# class Solution:
#     def minRemoveToMakeValid(self, s) :
#         stack=[]
#         split_str=list(s)
#         for i in range(len(s)):
#             if s[i]=='(':
#                 # if current char is '(' then push it to stack
#                 stack.append(i)
#             elif s[i]==')':
#                 # if current char is ')' then pop top of the stack
#                 if len(stack) !=0:
#                     stack.pop()
#                 else:
#                     # if our stack is empty then we can't pop so make  current char as ''
#                     split_str[i]=""
#         for i in stack:
#             split_str[i]=""
#         return '' .join(split_str)


#Method-2
# moving forward and backword


# class Solution:
#     def minRemoveToMakeValid(self, s: str) -> str:
#         res = ''
        
#         l = []
        
#         for i in s:
#             if i == ')':
#                 if l and l[-1] == '(':
#                     res = res + i
#                     l.pop()
#             elif i =='(':
#                 l.append(i)
#                 res = res +i
#             else:
#                 res += i
        
#         if len(l) == 0:
#             return res
        
#         l =[]
#         s = res
#         res =''
        
#         for i in s[::-1]:
#             if i == '(':
#                 if l and l[-1] == ')':
#                     res = i +res
#                     l.pop()
#             elif i ==')':
#                 l.append(i)
#                 res = i + res
#             else:
#                 res = i+res
                
#         return res
    

#Method-3 
#Stack 
class Solution:   
    def minRemoveToMakeValid(self, s: str) -> str:
        stack=[]
        close=[]
        res=[]
        for i,string in enumerate(s):
            if string=='(':
                stack.append(i)
            elif string==')':
                if stack:
                    stack.pop()
                else:
                    close.append(i)
        to_be_delete=set(close+stack)
        for i,string in enumerate(s):
            if i in to_be_delete:
                continue
            res.append(string)
        return "".join(res)

#Method-4    
#  O(n) single iteration

# Solution is straight forward. Just remove invalid parentheses as we go.

# Iterate through the string once, storing the index of open parentheses in a stack.

# When we come to a closing parentheses, it is valid if the stack isn't empty. If the stack isn't empty, we pop from the stack, otherwise we remove the closing parentheses from the string.

# Finally, remove invalid open parentheses.

# Time complexity: O(n)
# Space complexity: O(n)

class Solution:
                   
    def minRemoveToMakeValid(self, s: str) -> str:
        
        stack = [] # store indexes of unclosed open parentheses

        i = 0
        while i < len(s):
            char = s[i]
            
            # add index of open parentheses to stack
            if char == '(':
                stack.append(i)
                
            # check if closing parentheses is valid, removing if not
            if char == ')':
                if not stack:
                    s = s[:i] + s[i+1:]
                    i-=1 # we don't want to increment the index in the case of invalid closing parentheses
                else:
                    stack.pop()
            i+=1
            
        # remove unclosed open parentheses
        while stack:
            i = stack.pop()
            s = s[:i] + s[i+1:]
            
        return s
    
    
#Method-5    
#o(n) solution


class Solution:
    def minRemoveToMakeValid(self, s: str) -> str:
        s1=[]

        for j,i in enumerate(s):
            if i.isalpha():
                continue
            elif i=='(':
                s1.append((i,j))
            else:
                if s1:
                    if s1[-1][0]=="(":
                        s1.pop()
                    else:
                        s1.append((i,j))
                else:
                    s1.append((i,j))
        res=[]
        t=[i for j,i in s1]
        print(t,s1)
        if s1:
            for i,j in enumerate(s):
                if i in t:
                    continue
                res.append(j)
            return ''.join(res)
        return s
                

#Q9   Longest Palindromic Substring

'''
Given a string s, return the longest palindromic substring in s.

 

Example 1:

Input: s = "babad"
Output: "bab"
Explanation: "aba" is also a valid answer.
Example 2:

Input: s = "cbbd"
Output: "bb"
 

Constraints:

1 <= s.length <= 1000
s consist of only digits and English letters.


'''
# Solution 

#Method-1

class Solution:
    def longestPalindrome(self, s: str) -> str:
        res = ""
        for i in range(len(s)):
            s1 = self.findPalindrome(s, i, i)
            s2 = self.findPalindrome(s, i, i+1)
            res = s1 if len(res) < len(s1) else res
            res = s2 if len(res) < len(s2) else res
        return res
    def findPalindrome(self, s: str, l: int, r: int) -> str:
        while l >= 0 and r < len(s) and s[l] == s[r]:
            l -= 1
            r += 1
        return s[l + 1 : r] 
    
    
#Method-2

# Iterate over each and every index and assume it as the middle element of a substring (odd length) and check the length of longest palindrome present around it and one of the two middle element in case of (even length) substring.
# Complexity
# TIme - O(n2)
# Space - O(1)
# Solution

class Solution:
    def longestPalindrome(self, s: str) -> str:
        """
        """
        n = len(s)
        def longest(start, end):
            while start >= 0 and end < n and s[start] == s[end]:
                start -= 1
                end += 1
            return start + 1, end, end - start
        
        store = [0, 0, 0]
        for i in range(n):
            store = max(store, longest(i, i), longest(i, i + 1), key=lambda x : x[2])
        return s[store[0]:store[1]]

#Method-3
class Solution:
	def longestPalindrome(self, s: str) -> str:
		"""
		time complexity: O(N^2)
		space compleixty: O(1)
		"""
		def helper(l, r):
			while l >= 0 and r <= len(s) - 1 and s[l] == s[r]:
					l -= 1
					r += 1                                 
			return l + 1, r - 1


		longest_l, longest_r = 0, 0
		for i in range(len(s)):
			#check the longest palindrome in odd palindrome
			odd_l, odd_r = helper(i, i)
			if odd_r - odd_l + 1 > longest_r - longest_l + 1:
				longest_l, longest_r = odd_l, odd_r

			#check the longest palindrome in even palindrome
			even_l, even_r = helper(i, i + 1)
			if even_r - even_l + 1 > longest_r - longest_l + 1:
				longest_l, longest_r = even_l, even_r

		return s[longest_l:longest_r + 1]        

#Method-4

class Solution(object):
    def longestPalindrome(self, s):
        n = len(s)
        if n<2:
            return s
        dp =[[False]*n for _ in range(n)] # var dp
        start, max_L = 0, 1 
        for right in range(n):
            for left in range(0, right+1):
                L = right - left + 1
                if L == 1:  # case1
                    dp[left][right] = True
                elif L ==2: # case2
                    dp[left][right] = s[left]==s[right]
                else:       # case3
                    dp[left][right] = dp[left+1][right-1] and s[left]==s[right]
                
                if dp[left][right]: #update
                    if L > max_L:
                        max_L = L
                        start = left
        return s[start:start+max_L]
 

#Method-5   
#DP optimized

class Solution:
    def longestPalindrome(self, s: str) -> str:
		# pivot ---> center element of the palindrome, 
        # if odd length pivot = [pivot], if even length pivot = [pivot, pivot+1]
		# sway ---> how far it can spread from the pivot
		# Make sure that   pivot (+/-) sway   always within length
		
        def maxPal(s,pivot):
            length = len(s)
            
			# for odd length
            sway = 0
            for sway in range(min(pivot,length-1-pivot)+1):
                if s[pivot-sway] != s[pivot+sway]:
                    break
                sway+=1                 
            temp =  s[pivot-(sway-1):pivot+(sway-1)+1] 

			# for even length
            for sway in range(min(pivot+1,length-pivot-1)):
                if s[pivot-sway] != s[pivot+sway+1]:
                    break
                sway+=1           

            # len(s[pivot-(sway-1):pivot+(sway-1)+2]) simplifies to   sway*2, you can check
            if len(temp) > sway*2:
                return temp
            else:
                return s[pivot-(sway-1):pivot+(sway-1)+2]
            
            
        maxStr = ""
        for piv in range(len(s)):
            Str = maxPal(s,piv)
            if len(maxStr) < len(Str):
                maxStr = Str
                
        return maxStr
	
    
#Method-6   
    
# Python O(n) Faster than Manachers algorithm


class Solution:
    def longestPalindrome(self, s: str) -> str:
        if s == s[::-1]:
            return s
        
        q = 0
        e = ''
        
        ansT = []
        
        double = s
        d = len(s)
        i = 0
        iR = 2
        
        triple = s
        t = len(s)
        j = 0
        jR = 3

        while d:
            if double[i] == double[i-1]:
                while double[q] == double[q+1]:
                    e += double[q]
                    q += 1
                e += double[q]            
                ansT.append(e)
                e = ''
            d -= 1
            if double[i:iR] == double[i:iR][::-1]:
                ansT.append(double[i:iR])
                if i > -1:
                    while double[i:iR] == double[i:iR][::-1]:
                        ansT.append(double[i:iR])
                        i -= 1
                        iR += 1   
            else:
                i += 1
                iR += 1
                continue
                
        while t:
            t -= 1
            if triple[j:jR] == triple[j:jR][::-1]:
                ansT.append(triple[j:jR])
                
                if j > 0:
                    while triple[j:jR] == triple[j:jR][::-1]:
                        ansT.append(triple[j:jR])
                        j -= 1
                        jR += 1             
            else:
                j += 1
                jR += 1
                continue
            j += 1
            jR += 1
        
        
        if not ansT:
            return s[0]
        else:
            ans = max(ansT, key=len)
        
        return ans

#Q 10 Group Anagrams

'''
Given an array of strings strs, group the anagrams together. You can return the answer in any order.

An Anagram is a word or phrase formed by rearranging the letters of a different word or phrase, typically using all the original letters exactly once.

 

Example 1:

Input: strs = ["eat","tea","tan","ate","nat","bat"]
Output: [["bat"],["nat","tan"],["ate","eat","tea"]]
Example 2:

Input: strs = [""]
Output: [[""]]
Example 3:

Input: strs = ["a"]
Output: [["a"]]
 

Constraints:

1 <= strs.length <= 104
0 <= strs[i].length <= 100
strs[i] consists of lowercase English letters.


'''

#Solution 

# Method-1
#Dictionaries

class Solution:
    def groupAnagrams(self, strs: List[str]) -> List[List[str]]:
        #empty dict to check occurences
        dict = {}
        #loop thru words in strs
        for word in strs:
            #sort the word(all anagrams will be the same sorted)
            key = tuple(sorted(word))
            #if key exists, get existing words (as a list), add word to it, if not, create it
            dict[key]=dict.get(key, []) +[word]
        #return the values (which comes out as a list anyway)
        return dict.values()



# Method-2  
# Using Dictionary

class Solution:
    def groupAnagrams(self, strs: List[str]) -> List[List[str]]:
        dict={}
        out=[]
        for i in range(len(strs)):
            l=list(strs[i])
            l.sort()
            s=str(l)
            if s in dict:
                temp=dict[s]
                temp.append(strs[i])
                dict[s]=temp
            else:
                dict[s]=[strs[i]]
        for i in dict:
            temp=dict[i];
            temp.sort
            out.append(temp)
        return out
    

    

#Q11 Generate Parentheses
'''
Given n pairs of parentheses, write a function to generate all combinations of well-formed parentheses.

 

Example 1:

Input: n = 3
Output: ["((()))","(()())","(())()","()(())","()()()"]
Example 2:

Input: n = 1
Output: ["()"]
 

Constraints:

1 <= n <= 8

'''

# Solution 

# Method-1 
# Recursion backtracking 
# intution: we can't close a paranthesis without opening it so whenever we are closing a parathesis its counter part should already be opened at some 
# point so we carry the count of number of parathesis opened and closed on every recursion. once opened parathesis reaches point n the string can't have 
# any more opening parathesis it can only have closing paranthesis from then on. if opening paranthesis is greater than closed paranthesis and opening 
# hasn't reached its max limit we can form both opening and closing paranthesis as next character. if opened is not greater than closed then we have to 
# open a paranthesis as we cant close without its counter open already existing.

class Solution:
    def generateParenthesis(self, n: int) -> List[str]:
        def para(opened,closed,l,k,n):
            if closed>n:
                l.append(k)
                return l
            if opened<=n:
                if opened>closed:
                    l=para(opened+1,closed,l,k+'(',n)
                    l=para(opened,closed+1,l,k+')',n)
                else:
                    l=para(opened+1,closed,l,k+'(',n)
            else:
                l=para(opened,closed+1,l,k+')',n)
            return l
        opened=1
        closed=1
        k=''
        l=[]
        l=para(opened,closed,l,k,n)
        return l
    
    
# Method-2
#Backtracking + Recursion With a Rule Regarding Closing Character


class Solution:
    #Time-Complexity: O(2^(2*n - 1)), since branching factor of rec. tree is 2 at worst case
    #and the height of tree is 2*n - 1 -> O(2^n)
    #Space-Complexity:O(2*n - 1) -> O(n) due to max call stack depth due to recursion!
    def generateParenthesis(self, n: int) -> List[str]:
        #Approach: We can recursively exhaust all possible paths and generate all
        #valid well-formed combination strings that consist of 2*n parentheses characteres!
        
        #Rule: We can only add closing character if current number of closing characters
        #we have so far in built-up string < number of opening chars in current str!
        
        #Also, we can't add opening characters is open == n!(This means we used it all!)
        
        #Also, when we backtrack, make sure to popoff the last character!
        
        #Also, be aware of cur built-up string being modified throughout many rec. calls ->
        #make sure to append deep copy to avoid its contents being changed inside ans container!
        
        ans = set()

        #cur: current built up string!
        #o = counter for open chars currently in cur!
        #c = similar to o but for closing char!
        def helper(cur, o, c):
            nonlocal n
            #base case: if length of current string consists of 2* n characters!
            if(len(cur) == 2 * n):
                ans.add(cur[::])
                return
            
            #otherwise, recurse accordingly by the rules!
            if(o < n):
                #modify cur!
                cur += "("
                helper(cur, o + 1, c)
                #once we return from recursion restore cur!
                cur = cur[:len(cur)-1]
            
            #check if o > c!
            if(c < o):
                cur += ")"
                helper(cur, o, c + 1)
                cur = cur[:len(cur)-1]
        helper("(", 1, 0)
        return list(ans)
 


# Method-3      
#Backtracking


import copy
class Solution:
    def generateParenthesis(self, n: int) -> List[str]:
        def isvalid(s):
            a=[]
            for i in s:
                if i=='(': a.append('(')
                else:
                    try:
                        q=a.pop()
                        if q!='(': return False
                    except:
                        return False
            return True
        def choices(s,n):
            l,r=n,n
            for i in s:
                if i=='(': 
                    l-=1
                else:
                    r-=1
            if l>0 and r>0:
                return ['(',')']
            elif l>0:
                return ['(']
            elif r>0:
                return [')']
            else:
                return []
        Ans=[]
        def solve(s,n):
            if len(s)==2*n:
                if isvalid(s) and s not in Ans: Ans.append(s)
            else:
                for i in choices(s,n):
                    a=copy.deepcopy(s)
                    a+=i
                    solve(a,n)
        solve('',n)
        return Ans   

    
# Method-4
#Non-recursive solution

class Solution(object):
    def generateParenthesis(self, n):
        """
        :type n: int
        :rtype: List[str]
        """
        res = [('', 0, n)] 
        maxn = n 
        while maxn > 0:
            maxn = 0 
            l = len(res)
            for i in range(l):
                s, b, k = res[i]
                if k > maxn: maxn = k
                if k > 0:
                    res[i] = (s+'(', b+1, k-1)
                    if b > 0:
                        res.append((s+')', b-1, k))
                elif b > 0:
                    res[i] = (s+')', b-1, k)
        return [s[0] for s in res]

     
# Method-5
#Using Generators


class Solution:
    def generateParenthesis(self, n):
        """
        :type n: int
        :rtype: List[str]
        """
	#cur is current string
        #n is the number of left parenthesis available
        #R is number of right parenthesis available
        def helper(cur, n, R):
            if n != 0:
                yield from helper(cur + "(", n-1, R + 1)
            if R != 0:
                yield from helper(cur + ')', n, R - 1)
            if n == 0 and R == 0:
                yield cur
        cur = ''
        return list(helper(cur, n, 0))
    
    
    
 #Q12 Basic Calculator II
'''
Given a string s which represents an expression, evaluate this expression and return its value. 

The integer division should truncate toward zero.

You may assume that the given expression is always valid. All intermediate results will be in the range of [-231, 231 - 1].

Note: You are not allowed to use any built-in function which evaluates strings as mathematical expressions, such as eval().

 

Example 1:

Input: s = "3+2*2"
Output: 7
Example 2:

Input: s = " 3/2 "
Output: 1
Example 3:

Input: s = " 3+5 / 2 "
Output: 5
 

Constraints:

1 <= s.length <= 3 * 105
s consists of integers and operators ('+', '-', '*', '/') separated by some number of spaces.
s represents a valid expression.
All the integers in the expression are non-negative integers in the range [0, 231 - 1].
The answer is guaranteed to fit in a 32-bit integer.

'''
#Solution 

#Method-1

class Solution:
    def calculate(self, s: str) -> int:
        stack = []
        currentNumber = 0
        operator = '+'
        operations = '+-/*'
        for i in range(len(s)):
            ch = s[i]
            if ch.isdigit():
                currentNumber = currentNumber * 10 + int(ch)
            
            if ch in operations or i == len(s) - 1:
                if operator == '+':
                    stack.append(currentNumber)
                
                elif operator == '-':
                    stack.append(-currentNumber)
                
                elif operator == '*':
                    stack.append(stack.pop() * currentNumber)
                    
                elif operator == '/':
                    stack.append(int(stack.pop()/currentNumber))
                
                currentNumber =0
                operator = ch
        
        return sum(stack)
                

#Method-2

class Solution:
    def calculate(self, s: str) -> int:
        _len = len(s)
        
        if _len == 0:
            return 0
        
        current_num = 0
        operation = '+'
        cur_char =  ''
        stack = []
        
        for i in range(_len):    
            cur_char = s[i]
        
            if cur_char.isdigit():
                current_num = (current_num * 10) + int(cur_char)
            
            if (not cur_char.isdigit() and not cur_char.isspace()) or i == _len - 1:
                if operation == '-':
                    stack.append(-current_num)
                elif operation == '+':
                    stack.append(current_num)
                elif operation == '*':
                    elem = stack.pop()
                    stack.append(elem * current_num)
                else:
                    elem = stack.pop()
                    if elem // current_num < 0 and elem % current_num != 0:
                        stack.append(elem // current_num + 1)
                    else:
                        stack.append(elem // current_num )
                
                current_num = 0
                operation = cur_char
        
        res = 0
        while stack:
            res += stack.pop()
        
        return res
    

#Method-3 
class Solution:
    def calculate(self, s: str) -> int:
        s = s.strip()
        op = []
        s_use = s
        num = s_use.replace('+',' ').replace('-',' ').replace('*',' ').replace('/',' ').split()
        for i in s:
            if i == '+' or i == '-' or i=='*' or i=='/':
                op.append(i)
        i = 0
        while i < len(op):
            if op[i] == '*':
                num[i] = int(num[i]) * int(num[i+1])
                del num[i+1]
                del op[i]
                i -= 1
            elif op[i] =='/':
                num[i] = int(num[i]) // int(num[i+1])
                del num[i+1]
                del op[i]
                i -= 1
            i += 1
        result = int(num[0])
        for i in range(len(op)):
            if op[i] == '+':
                result += int(num[i+1])
            if op[i] == '-':
                result -= int(num[i+1])
        return result
    
    
#Method-4

class Solution:
    def calculate(self, s: str) -> int:
        s = s.replace(" ", "")
        s += '+0'
        reduce = False
        stack = []
        stack.append(s[0])
        for i in range(1,len(s)):
            
            if s[i] in '+-':
                if reduce == False:
                    stack.append(s[i])
                else:
                    a = int(stack.pop(-1))
                    op = stack.pop(-1)
                    b = int(stack.pop(-1))
                    if op == '*':
                        stack.append(a * b)
                    else:
                        stack.append(b // a)
                    stack.append(s[i])
                    reduce = False
                
            elif s[i] in '*/':
                if reduce == False:
                    stack.append(s[i])
                else:
                    a = int(stack.pop(-1))
                    op = stack.pop(-1)
                    b = int(stack.pop(-1))
                    if op == '*':
                        stack.append(a * b)
                    else:
                        stack.append(b // a)
                    stack.append(s[i])
                reduce = True
                
            
            else:
                if stack[-1] not in '+/-*':
                    if stack[-1][0] != '0':
                        stack[-1] += s[i]
                    else:
                        stack[-1] = s[i]      
                else:
                    stack.append(s[i])
    
        stack.reverse()
        while stack:
            a = stack.pop(-1)
            op = stack.pop(-1)
            b = stack.pop(-1)
            if op == '-':
                stack.append(str(int(a) - int(b)))
            else:
                stack.append(str(int(b) + int(a)))
            try:
                x = stack[1]
            except IndexError:
                return stack[0]
                    
#single stack
#Method-5

class Solution:
    def calculate(self, s: str) -> int:
        s = s.replace(' ','')
        stack = [] # stack to restore all + - parts, temporarily store * / parts
        num = 0 # current number being processed
        n = len(s)
        op = '+'
        for i, c in enumerate(s):
            if c >= '0':
                num = 10*num + int(c)
            if i==n-1 or c < '0':
                if op == '+':
                    stack.append(num)
                elif op == '-':
                    stack.append(-num)
                elif op == '*':
                    num = stack.pop()*num
                    stack.append(num)
                elif op == '/':
                    num = int(stack.pop()/num)
                    stack.append(num)                
                op = c
                num = 0
        print(stack)
            
        return sum(stack)


 #Q 13 Integer to Roman

'''
Roman numerals are represented by seven different symbols: I, V, X, L, C, D and M.

Symbol       Value
I             1
V             5
X             10
L             50
C             100
D             500
M             1000
For example, 2 is written as II in Roman numeral, just two one's added together. 12 is written as XII, which is simply X + II. The number 27 is written as XXVII, which is XX + V + II.

Roman numerals are usually written largest to smallest from left to right. However, the numeral for four is not IIII. Instead, the number four is written as IV. Because the one is before the five we subtract it making four. The same principle applies to the number nine, which is written as IX. There are six instances where subtraction is used:

I can be placed before V (5) and X (10) to make 4 and 9. 
X can be placed before L (50) and C (100) to make 40 and 90. 
C can be placed before D (500) and M (1000) to make 400 and 900.
Given an integer, convert it to a roman numeral.

 

Example 1:

Input: num = 3
Output: "III"
Explanation: 3 is represented as 3 ones.
Example 2:

Input: num = 58
Output: "LVIII"
Explanation: L = 50, V = 5, III = 3.
Example 3:

Input: num = 1994
Output: "MCMXCIV"
Explanation: M = 1000, CM = 900, XC = 90 and IV = 4.
 

Constraints:

1 <= num <= 3999

'''

# Solution 

#Method-1

class Solution:
    def intToRoman(self, num: int) -> str:
        
        lookup = {
                  1000: 'M',  900: 'CM', 
                  500: 'D', 400: 'CD',
                  100: 'C', 90: 'XC',  
                  50: 'L', 40: 'XL', 
                  10: 'X', 9: 'IX',
                  5: 'V', 4: 'IV', 1: 'I', 
                 }
        
        res = ""
        for key, val in lookup.items():
            res += val * (num // key)
            num -= key * (num // key)
        return res
 

# Method-2
   
class Solution:
    def intToRoman(self, num: int) -> str:

        legend = {
            1: "I",
            4: "IV",
            9: "IX",
            5: "V",
            10: "X",
            40: "XL",
            50: "L",
            90: "XC",
            100: "C",
            400: "CD",
            500: "D",
            900: "CM",
            1000: "M",
        }
        target = num
        roman = ""
        while target > 0:
            
            closest = list(filter(lambda x: x <= target, legend.keys()))
         

            roman = roman + legend[max(closest)]
            target = target - max(closest)

        return roman
    
#Method-3
#Using match


class Solution:
    def intToRoman(self, num: int) -> str:
        res = ""
        
        res += "M" * (num // 1000)
        
        match (num // 100) % 10:
            case 4: res += "CD"
            case 9: res += "CM"
            case x if x < 5: res += "C" * x
            case x: res += "D" + "C" * (x - 5)
        
        match (num // 10) % 10:
            case 4: res += "XL"
            case 9: res += "XC"
            case x if x < 5: res += "X" * x
            case x: res += "L" + "X" * (x - 5)
        
        match num % 10:
            case 4: res += "IV"
            case 9: res += "IX"
            case x if x < 5: res += "I" * x
            case x: res += "V" + "I" * (x - 5)
        
        return res
 

#Method-4

class Solution(object):
    def intToRoman(self, num):
        """
        :type num: int
        :rtype: str
        """
        ans=''
        ans+='M'*(num//1000)
        num%=1000
        if num>=900:
            ans+='CM'
        elif num>=500:
            ans+='D'+'C'*(num//100-5)
        elif num>=400:
            ans+='CD'
        else:
            ans+='C'*(num//100)
        num%=100
        if num>=90:
            ans+='XC'
        elif num>=50:
            ans+='L'+'X'*(num//10-5)
        elif num>=40:
            ans+='XL'
        else:
            ans+='X'*(num//10)
        num%=10
        if num==9:
            ans+='IX'
        else:
            if num>=5:
                ans+='V'
                num-=5
            ans+='IV' if num==4 else 'I'*num
        return ans
    
#Method-5
#O(len(str(n)))


class Solution:
	def intToRoman(self, num: int) -> str:

		thou = num//1000

		ans = "M"*thou

		num = num%1000

		rom1 = ['M','C','X','I']
		rom2 = ['M','D','L','V']

		for i in range(1,4):

			part = num//(10**(3-i))
			num = num%(10**(3-i))

			if part == 1:     
				s = rom1[i]
			elif part == 2:
				s = rom1[i]*2
			elif part == 3:
				s = rom1[i]*3
			elif part == 4:
				s = rom1[i] + rom2[i]
			elif part == 5:
				s = rom2[i]
			elif part == 6:
				s = rom2[i] + rom1[i]
			elif part == 7:
				s = rom2[i] + rom1[i]*2
			elif part == 8:
				s = rom2[i] + rom1[i]*3
			elif part == 9:
				s = rom1[i] + rom1[i-1]
			else:
				s = ""
			ans+=s
		return ans



#Q14 Reverse Words in a String
'''
Given an input string s, reverse the order of the words.

A word is defined as a sequence of non-space characters. The words in s will be separated by at least one space.

Return a string of the words in reverse order concatenated by a single space.

Note that s may contain leading or trailing spaces or multiple spaces between two words. The returned string should only have a single space separating the words. Do not include any extra spaces.

 

Example 1:

Input: s = "the sky is blue"
Output: "blue is sky the"
Example 2:

Input: s = "  hello world  "
Output: "world hello"
Explanation: Your reversed string should not contain leading or trailing spaces.
Example 3:

Input: s = "a good   example"
Output: "example good a"
Explanation: You need to reduce multiple spaces between two words to a single space in the reversed string.
 

Constraints:

1 <= s.length <= 104
s contains English letters (upper-case and lower-case), digits, and spaces ' '.
There is at least one word in s.
 

Follow-up: If the string data type is mutable in your language, can you solve it in-place with O(1) extra space?
'''

# Solution

#Method-1

class Solution(object):
    def reverseWords(self, s):
        s = s.strip().split()
        res = ''
        for i in range(len(s) - 1, 0, -1):
            res = res + s[i] + ' '
        return res + s[0]

#Method-2

class Solution(object):
    def reverseWords(self, s):
        l=s.split()
        ans=""
        for i in range(len(l)-1,-1,-1):
            ans=ans+"".join(l[i])
            if i>0:
                ans=ans+" "
        return ans
    
    
#Method-3    
class Solution:
    def reverseWords(self, s: str) -> str:
        s=s.split()
        return ' '.join(s[::-1])

#Method-4 

class Solution:
    def reverseWords(self, s: str) -> str:
        out=""
        for i in s.split(" "):
            if i==" " or i=="":
                continue
            else:
                if out=="":
                    out+=i
                else:
                    out=i+" "+out
        return out


# #Method-5

class Solution:
    # @param s, a string
    # @return a string
    def reverseWords(self, s):
        # Step 1 : split the given string into a list of words - with " " as the seperator
        s = s.split(" ")
        # Step 2 : filter out the white spaces in the list and reverse the list
        s = [element for element in s if element != ''][::-1]
        # Step 3 : join them and return 
        return ' '.join(s)


#Q15 Simplify Path

'''
Given a string path, which is an absolute path (starting with a slash '/') to a file or directory in a Unix-style file system, convert it to the simplified canonical path.

In a Unix-style file system, a period '.' refers to the current directory, a double period '..' refers to the directory up a level, and any multiple consecutive slashes (i.e. '//') are treated as a single slash '/'. For this problem, any other format of periods such as '...' are treated as file/directory names.

The canonical path should have the following format:

The path starts with a single slash '/'.
Any two directories are separated by a single slash '/'.
The path does not end with a trailing '/'.
The path only contains the directories on the path from the root directory to the target file or directory (i.e., no period '.' or double period '..')
Return the simplified canonical path.

 

Example 1:

Input: path = "/home/"
Output: "/home"
Explanation: Note that there is no trailing slash after the last directory name.
Example 2:

Input: path = "/../"
Output: "/"
Explanation: Going one level up from the root directory is a no-op, as the root level is the highest level you can go.
Example 3:

Input: path = "/home//foo/"
Output: "/home/foo"
Explanation: In the canonical path, multiple consecutive slashes are replaced by a single one.
 

Constraints:

1 <= path.length <= 3000
path consists of English letters, digits, period '.', slash '/' or '_'.
path is a valid absolute Unix path.

'''
#Solution


#Method-1

class Solution(object):
    def simplifyPath(self, path):
        places = [p for p in path.split("/") if p!="." and p!=""]
        from collections import deque
        stack = deque()
        inserted = 0
        for p in places:
            if p == "..":
                if inserted > 0:
                    stack.pop()
                    inserted-=1
            else:
                stack.append(p)
                inserted+=1
        return "/" + "/".join(stack)
# Time : O(N)
# Space : O(N)



#Method-2
#split, process, merge

import re
class Solution:
    def simplifyPath(self, path: str) -> str:
        stack = []
		# split the string on '/', regex will get rid of multiple consecutive delimiters
		# but path.split('/') would stil work too
        path_list = re.split('/+',path)

        for subpath in path_list:
            if subpath != '' and subpath != '.':# do nothing if it's delimiter (could be in front) or curent directory ('.')
                if subpath == '..':
					# roll back one directory if the stack is not empty
                    if stack:
                        stack.pop()
                else:
					# append reguar directory
                    stack.append(subpath)
        
        return '/' + '/'.join(stack) 
    
    
#Method-3
class Solution:
    def simplifyPath(self, path: str) -> str:
        path = path.split('/') 
        stack = [] 
        for i in path:
            if i =='.' or i =='': # skip the . and //
                continue
            elif i == '..':  #if ".." is present we don't need anything before that so we pop all elements in the stack
                if stack: 
                    stack.pop()
            else:
                stack.append(i)            
        return '/' + '/'.join(stack)
    
    
    
#Method-4   
#State Machine Solution


INIT = -1
DOT = 0
SLASH = 1
ALPHA = 2
DOT2 = 3

class StateMachine(object):
    def __init__(self):
        self.paths = []
        self.start = 0
        self.state = INIT
    
    def transfer(self, i, c, path):
        
        if self.state == INIT:
            if c == '/':
                self.state = SLASH
            elif c == '.':
                self.start = i
                self.state = DOT
            else:
                self.state = ALPHA
                self.start = i

        elif self.state == DOT:
            if c == '.':
                self.state = DOT2
            elif c == '/':
                self.state = SLASH
            else:
                self.state = ALPHA
            
        elif self.state == DOT2:
            if c == '/':
                self.state = SLASH
                if self.paths:
                    self.paths.pop()
            # elif c == '.':
                # pass
            else:
                self.state = ALPHA

        elif self.state == SLASH:
            if c == '.':
                self.state = DOT
                self.start = i
            elif c == '/':
                pass
            else:
                self.state = ALPHA
                self.start = i
        else:
            if c == '/':
                if self.start != i:
                    self.paths.append(path[self.start : i])

                self.state = SLASH
            # else:
                # pass

class Solution(object):
        
    
    def simplifyPath(self, path):
        """
        :type path: str
        :rtype: str
        """
        
        path += '/'
        
        machine = StateMachine()

        for (i, c) in enumerate(path):
            machine.transfer(i, c, path)
        
        return '/' + '/'.join(machine.paths)

    
#Method-5    
# Without Stack  - Reverse Traversal

'''
Pseudo Code
------------------
traverse in reverse order
when ever" /"" is encountered
if it is "." then ignore it proceed to find next "/"
if it is ".." then increment ignoreParent variable
else add it to newPath only if ignoreParent is 0
otherwise decrement ignoreParent and go to next index
check if first char is / and last char is not /
'''
class Solution:
    def simplifyPath(self, path: str) -> str:
        i = len(path)-1
        newPath = ""
        temp = ""
        ignoreParent = 0
        while i > -1:
            if path[i] == "/":
                if temp == ".":
                    temp = ""
                elif temp == "..":
                    ignoreParent += 1
                    temp = ""
                else:
                    if ignoreParent > 0 and temp != "":
                        ignoreParent -= 1
                        temp = ""
                    elif temp != "":
                        newPath = temp + "/" + newPath
                        temp = ""
            else:
                temp = path[i] + temp
            i = i -1
        newPath = "/" + newPath[:-1]
        return newPath

#Q16 Zigzag Conversion

'''
The string "PAYPALISHIRING" is written in a zigzag pattern on a given number of rows like this: (you may want to display this pattern in a fixed font for better legibility)

P   A   H   N
A P L S I I G
Y   I   R
And then read line by line: "PAHNAPLSIIGYIR"

Write the code that will take a string and make this conversion given a number of rows:

string convert(string s, int numRows);
 

Example 1:

Input: s = "PAYPALISHIRING", numRows = 3
Output: "PAHNAPLSIIGYIR"
Example 2:

Input: s = "PAYPALISHIRING", numRows = 4
Output: "PINALSIGYAHRPI"
Explanation:
P     I    N
A   L S  I G
Y A   H R
P     I
Example 3:

Input: s = "A", numRows = 1
Output: "A"
 

Constraints:

1 <= s.length <= 1000
s consists of English letters (lower-case and upper-case), ',' and '.'.
1 <= numRows <= 1000

'''
#Solution 


#Method-1
# Logic:
# Create numRows list of strings.
# Track Forward and Backward pass.
# Iterate over input string.
# Append string character at i index of List.

class Solution:
    def convert(self, s: str, numRows: int) -> str:
        all_list = ['']*numRows
        counter = 0
        forward, backward = True, False
        for i in s:
            all_list[counter] =  all_list[counter] + i
            if forward:
                if (counter < numRows-1):
                    counter+=1
                else:
                    forward, backward = False, True
                    counter-=1
            else:
                if (counter>0): 
                    counter-=1
                else:
                    forward, backward = True, False
                    counter+=1

        return "".join(all_list)
    
# Time : O(N)
# Space : O(M*N)



#Method-2
#Matrix Solution | with detailed thought process


# Thought process:
    
# we try to create a matrix of length len(s)*numRows and we fill it up with value 0
# we can have our two variables row and col, we use these variables to keep track of the zigzag position where we are going to insert our string value into the matrix.
# now let's take another variable which tells us in which direction we are supposed to move . like for an example , do we need to move up and change our column?, or move down without changing the column?. so initially we will be moving down
# if flow is "down" then we go ahead and increase our row value untile it exceeds numRows. then we set it back to numRows if exceeded and we change our flow to "topchangerow" .
# if flow is "topchangerow" then we need to decrease row value and increase column count. until our row value goes below 0. if it's less than 0, then we will set it back to 0. and change our flow to "down" again.
# we need to return a string as an output so another variable newstring.
# convert matrix to string. if matrix value is nonzero? append it to the string.
# return our resultant string


class Solution:
    def convert(self, s: str, numRows: int) -> str:
        
        matrix=[[0 for i in range((len(s)))] for j in range(numRows) ] 
        
        row=0
        col=0
        
        flow="down"
        
        for i in range(len(s)):
            matrix[row][col]=s[i]
            if flow=="down":
                row+=1
                if row>=numRows:
                    flow="topchangerow"
                    row-=1
                    
            if flow=="topchangerow":
                row-=1
                col+=1
                if row<=0:
                    row=0
                    flow="down"
        
        newstring=""
        for i in matrix:
            for j in i:
                if j!=0:
                    newstring+=j
                    
        return newstring
    
    
#Method-3

class Solution:
    def convert(self, s, numRows):
        if numRows == 1:
            return s
        string = ""
        step = (numRows - 1)*2
        down = 0 
        for i in range(numRows):
            if i < len(s):
                string += s[i]
            j = i
            while j < len(s):
                j += step
                if(step and j < len(s)): 
                    string += s[j]
                j += down
                if(down and j <len(s)):
                    string += s[j]
            step -= 2
            down += 2
        return string
    
#Method-4

class Solution:
	def convert(self, s: str, numRows: int) -> str:
		dic = {}
		row = 1
		for string in s:
			#concating existing and current characters to the dictionary
			dic[row] = dic.get(row, '')+string
			if row == numRows:
				is_row_decrementing = True
			if row == 1:
				is_row_decrementing =False

			if is_row_decrementing:
				row-=1
			else:
				row+=1
		#concatination dic values to a string
		return ''.join(map(str, dic.values()))

#Method-5
# Just prepare strong for each row and store characters in the given string in zig zag order
# to the rows, then join all rows.

class Solution(object):
    def convert(self, s, numRows):
        leng = len(s)
        if leng == 0:      return ''
        if numRows <= 0:   return ''
        elif numRows == 1: return s
        
        resRows = [''] * numRows
        
        i = 0
        resRowNum = 0
        step = 1
        while i < leng:
            resRows[resRowNum] += s[i]
            
            if (step == 1 and resRowNum == numRows - 1) or (step == -1 and resRowNum == 0):
                step = -1 * step
            
            resRowNum += step
            i += 1
        
        return ''.join(resRows)

#Q17  Text Justification

'''
Given an array of strings words and a width maxWidth, format the text such that each line has exactly maxWidth characters and is fully (left and right) justified.

You should pack your words in a greedy approach; that is, pack as many words as you can in each line. Pad extra spaces ' ' when necessary so that each line has exactly maxWidth characters.

Extra spaces between words should be distributed as evenly as possible. If the number of spaces on a line does not divide evenly between words, the empty slots on the left will be assigned more spaces than the slots on the right.

For the last line of text, it should be left-justified, and no extra space is inserted between words.

Note:

A word is defined as a character sequence consisting of non-space characters only.
Each word's length is guaranteed to be greater than 0 and not exceed maxWidth.
The input array words contains at least one word.
 

Example 1:

Input: words = ["This", "is", "an", "example", "of", "text", "justification."], maxWidth = 16
Output:
[
   "This    is    an",
   "example  of text",
   "justification.  "
]
Example 2:

Input: words = ["What","must","be","acknowledgment","shall","be"], maxWidth = 16
Output:
[
  "What   must   be",
  "acknowledgment  ",
  "shall be        "
]
Explanation: Note that the last line is "shall be    " instead of "shall     be", because the last line must be left-justified instead of fully-justified.
Note that the second line is also left-justified because it contains only one word.
Example 3:

Input: words = ["Science","is","what","we","understand","well","enough","to","explain","to","a","computer.","Art","is","everything","else","we","do"], maxWidth = 20
Output:
[
  "Science  is  what we",
  "understand      well",
  "enough to explain to",
  "a  computer.  Art is",
  "everything  else  we",
  "do                  "
]
 

Constraints:

1 <= words.length <= 300
1 <= words[i].length <= 20
words[i] consists of only English letters and symbols.
1 <= maxWidth <= 100
words[i].length <= maxWidth
Accepted
265,825
Submissions


'''

#Solution 

#Method-1
class Solution:
    def fullJustify(self, words: List[str], maxWidth: int) -> List[str]:
        """
        1. Determine x words that can be fit in a row
        2. If x == 1: then left justify (append extra spaces to the right)
        3. If x > 1: 
            * If not last row: determine y spaces left on the right. Distribute y among the spaces between words
            * If last row: left justify
        
        There are x-1 spaces. The extra ' ' each space can get is y//(x-1)
        The first y%(x-1) spaces each get one ' '.
        """
        ans = []
        word_pointer = 0
        
        while word_pointer < len(words):
            row = []
            spaces_occupied = 0
            begin_word_pointer = word_pointer
            while word_pointer < len(words) and spaces_occupied + len(words[word_pointer]) <= maxWidth:
                spaces_occupied += len(words[word_pointer]) + 1
                word_pointer += 1
            spaces_occupied -= 1 # the last word does not need a space after
            # number of words x fit in this row 
            num_words = word_pointer - begin_word_pointer
            # number of spaces left y
            spaces_left = maxWidth - spaces_occupied
            # if only 1 word, left justify
            if num_words == 1:
                row += [words[begin_word_pointer], ' '*spaces_left]
                # continue
            else:
                if word_pointer < len(words):
                    extra_spaces_each_gets = spaces_left // (num_words-1)
                    num_first_spaces_for_extra_space = spaces_left % (num_words-1)
                    for i in range(begin_word_pointer, word_pointer):
                        row.append(words[i])
                        spaces_string = ''
                        if i!= word_pointer-1:
                            spaces_string = ' '
                            if extra_spaces_each_gets > 0:
                                spaces_string += ' '*extra_spaces_each_gets
                            if i-begin_word_pointer<num_first_spaces_for_extra_space:
                                spaces_string += ' '
                        row.append(spaces_string)
                else:
                    for i in range(begin_word_pointer, word_pointer):
                        row.append(words[i])
                        if i!= word_pointer-1:
                            spaces_string = ' '
                        else:
                            spaces_string = ' '*spaces_left
                        row.append(spaces_string)
            ans.append(''.join(row))
        return ans
    
#Method-2    
#Dynamic programming solution 

class Solution:
    def fullJustify(self, words: List[str], maxWidth: int) -> List[str]:
        # Dynamic programming to solve the problem
        # Time complexity: O(n^2) 
        # Space complexity: O(n) 
        # Memoize the result
        
        res = []
        # Helper functiom for recursion
        def recursiveHelper(words, maxWidth):
            # Badness is difference in length. Discard negative length.
            badness = lambda i,j : (maxWidth - len(' '.join(words[i:j+1])))
            
            # Initial word break index.
            breakIndex = 0
            
            # Maximum cost at start
            cost = float('inf')
            # Calculate the cost until we have break index.
            while cost >= 0 and breakIndex < len(words):
                cost = badness(0, breakIndex)
                if (cost >= 0):
                    breakIndex += 1
            # Get the subword for inserting the 
            # spaces in between.
            subword = ' '.join(words[0:breakIndex])
            spaces = maxWidth - len(subword)
            
            # Break condition. If breakindex is the last word exit the
            # recursion.
            if breakIndex >= len(words):
                return res.append(' '.join(words[0:breakIndex]) + ' ' * spaces)
            # If last word is single word
            lastIndex = (breakIndex-1) if breakIndex > 1 else 1 
            # The number of spaces for each word within line
            num = spaces // len(words[0:lastIndex])
            if(num > 0):
                for k in range(0, len(words[0:lastIndex])):
                    words[k] += ' ' * num
            # Extra space from the left
            rem = spaces % len(words[0:lastIndex])
            if(rem):
                for k in range(0, len(words[0:rem])):
                    words[k] += ' '
            # Append the result       
            res.append(' '.join(words[0:breakIndex]))
            return recursiveHelper(words[breakIndex:], maxWidth)
        # Run recursive helper
        recursiveHelper(words, maxWidth)
        return res

    
    
#Method-3

class Solution:
    def fullJustify(self, words: List[str], maxWidth: int) -> List[str]:
        l = 0
        le = 0
        
        subs = []
        res = []
        
        def getJustified(wds, width, end):
            # If the end of the feed or only 1 word to place then justify left only
            if end or len(wds) == 1:
                sentence = ' '.join(wds)
                return sentence + ' ' * (maxWidth - len(sentence))
            else:
                sentence = []
                n = len(wds)
                
                # spaces generation
                # -----------------
                # creation of len(words) - 1 spaces of length (maxWidth - wordsWidth) // (len(words) - 1)
                # then add a space to the first (maxWidth - wordsWidth) % (len(words) - 1) spaces
                spaces = [' ' * ((maxWidth - width) // (n-1))] * (n-1)
                
                for i in range((maxWidth - width) % (n-1)):
                    spaces[i] += ' '
                    
                for i in range(n-1):
                    sentence += [wds[i], spaces[i]]
                return ''.join(sentence) + wds[n-1]
        
        # The trick is to handle spaces to keep separation between words
        for word in words:
            cur = len(word)
            if l + cur + len(subs) > maxWidth: # len(subs) is the number of spaces needed to insert word on the current line
                res += [getJustified(subs, l, False)]
                l = cur
                subs = [word]
            else:
                l += cur
                subs += [word]
        
        res += [getJustified(subs, l, True)]
        
        return res

#Method-4
 
class Solution:
    def fullJustify(self, words: List[str], maxWidth: int) -> List[str]:
        # Decide how many words can be on one line, 
        # Calculate how many extra spaces, distribute the spaces 
        # Handle the last line
        length = 0
        res = []
        line = []

        for i in range(len(words)):
            if length + len(words[i]) <= maxWidth:
                line.append(words[i])
                line.append(" ")
                length += len(words[i]) + 1
            else:
                # Transform line into proper format
                if len(line) > 2 or length > maxWidth: # [this, " ", is, " ", an, " "] or [listen, " "] maxWidth = 6
                    line.pop() # Pop the last " ", now line = [this, " ", is, " ", an], 
                    length -= 1 # length = 10
                    
                # [acknowledgement, " "] keeps the last " "
                extra_spaces = maxWidth - length # 16 - 10 = 6
                j = 0
                while extra_spaces > 0:
                    if line[j].isspace():
                        line[j] += " "
                        extra_spaces -= 1
                    j += 1
                    j %= len(line)
                                        
                res.append("".join(line))
                line = [words[i], " "]
                length = len(words[i]) + 1
        
        extra_spaces = maxWidth - length
        if extra_spaces < 0: # [for, " ", your, " ", country, " "], length = 17
            line.pop()
        else:
            line[-1] += " " * extra_spaces
        res.append("".join(line))
            
        return res
    
#Method-5
#solution with corner cases reminder
# This solution is just following the instructions given by the question.
# Be careful of the following corner cases:

# a word whose length is same as the maxWidth
# a line that has only one word -> no gap required
# pad the last line

'''
min required gaps = words count - 1
'''
class Solution:
    def fullJustify(self, words: List[str], maxWidth: int) -> List[str]:
        ans, tmp = [], []
        chars = 0
        for word in words:
            gaps = len(tmp) - 1 if tmp else 0
            if tmp and chars + gaps + len(word) + 1 > maxWidth: # "if tmp" is for case len(word) = maxWidth and the word is the first one
                # process tmp list
                free_spaces = maxWidth - chars
                avg_spaces = free_spaces//gaps if gaps > 0 else free_spaces # tmp = ["one_word"]
                extra_spaces = free_spaces - avg_spaces*gaps if gaps > 0 else 0 # tmp = ["one_word"]
                s = ""
                for i, tmp_word in enumerate(tmp):
                    s += tmp_word
                    if extra_spaces:
                        s += " "*(avg_spaces+1)
                        extra_spaces -= 1
                    elif len(tmp) == 1 or i < len(tmp)-1: # don't pad spaces for the last word
                        s += " "*avg_spaces
                ans.append(s)
                tmp = [word]
                chars = len(word)
            else:
                tmp.append(word)
                chars += len(word) 
                
        # process last line
        ans.append(" ".join(tmp)) 
        # pad to maxWidth
        ans[-1] += " "*(maxWidth-len(ans[-1]))
            
        return ans


#Q 18 Integer to English Words
'''
Convert a non-negative integer num to its English words representation.

 

Example 1:

Input: num = 123
Output: "One Hundred Twenty Three"
Example 2:

Input: num = 12345
Output: "Twelve Thousand Three Hundred Forty Five"
Example 3:

Input: num = 1234567
Output: "One Million Two Hundred Thirty Four Thousand Five Hundred Sixty Seven"
 

Constraints:

0 <= num <= 231 - 1

'''
#Solution



#Method-1
#O(len(str(n))

class Solution:
	def numberToWords(self, num: int) -> str:
		if num == 0:
			return "Zero"

		def func(n):
			if n == 0:
				return ""
			if n in dic:
				return dic[n]
			else:

				tens = n%100
				hun = n//100

				if hun:
					if tens:
						if tens not in dic:
							dic[tens] = dic[tens - tens%10]  + " " + dic[tens%10]

						dic[n] = dic[hun] + " " + "Hundred" + " " + dic[tens]
					else:
						dic[n] = dic[hun] + " " + "Hundred"
				else:
					dic[n] = dic[n - n%10]  + " " + dic[n%10]
				return dic[n]


		dic = {1:"One", 2:"Two", 3: "Three", 4: "Four", 5: "Five", 6: "Six", 7: "Seven", 8: "Eight", 9: "Nine", 10: "Ten", 11: "Eleven", 12: "Twelve", 13: "Thirteen" , 14: "Fourteen", 15: "Fifteen", 16: "Sixteen", 17: "Seventeen", 18: "Eighteen", 19: "Nineteen", 20: "Twenty", 30: "Thirty", 40: "Forty", 50: "Fifty", 60: "Sixty", 70: "Seventy", 80: "Eighty", 90: "Ninety"}

		ans = ""

		for i in range(3):
			div = 10**(9-(i*3))
			if i == 0:          
				s = "Billion "    
			elif i == 1:         
				s = "Million "
			else:         
				s= "Thousand "

			part = num//div

			if part:
				ans += func(part) + " " + s
			num = num%(div)     

		ans+= func(num)

		return ans.strip()
    
    
#Method-2

#Divide and conquer
class Solution:
    def numberToWords(self, num: int) -> str:
        
        self.ones = {
            "0": "Zero",
            "1": "One",
            "2": "Two",
            "3": "Three",
            "4": "Four",
            "5": "Five",
            "6": "Six",
            "7": "Seven",
            "8": "Eight",
            "9": "Nine"
        } 
        
        self.twos = {
            "10": "Ten",
            "11": "Eleven",
            "12": "Twelve",
            "13": "Thirteen",
            "14": "Fourteen",
            "15": "Fifteen",
            "16": "Sixteen",
            "17": "Seventeen",
            "18": "Eighteen",
            "19": "Nineteen",
            "2": "Twenty",
            "3": "Thirty",
            "4": "Forty",
            "5": "Fifty",
            "6": "Sixty",
            "7": "Seventy",
            "8": "Eighty",
            "9": "Ninety"
        }
        
        self.scale = {
            0: " ",
            1: " Thousand ",
            2: " Million ",
            3: " Billion "
        }
        
        nums = []
        
        if num == 0:
            return "Zero"
        
        while num != 0:
        
            nums.append(num % 1000)
            num //= 1000
        
    
        ans = ""
        k = 0
        print(nums)
        
        for i in range(len(nums)):
        
            ans = self.convert(ans, k, nums[i])
            
            k += 1
        
        return ans.strip(" ")
    
    
    
    def one(self, number):
        if number[0] == "0":
            return ""
        else:
            return self.ones[number[0]]
    
    def two(self, number):
        if number[0] == "0":
            return self.one(number[1:])
        elif number[0] == "1":
            return self.twos[number]
        else:
            if self.one(number[1:]) == "":
                return self.twos[number[0]] 
            else:
                return self.twos[number[0]] + " " + self.one(number[1:])

    def three(self, number):
  
        if number[0] == "0":
            return self.two(number[1:])
        else:
            if self.two(number[1:]) == "":
                return self.ones[number[0]] + " Hundred"
            else:
                return self.ones[number[0]] + " Hundred " + self.two(number[1:]) 
        
    
    def convert(self, ans, k, nums):
        
        nums = str(nums)
        if len(nums) == 3:
            temp = self.three(nums)
        elif len(nums) == 2:
            temp = self.two(nums)
        else:
            temp = self.one(nums)

        scale = self.scale[k] if nums != "0" else ""
            
        # if len(temp) > 0 and temp[-1] == " ":
        return temp + scale + ans
    
    
#Method-3

class Solution:
    def numberToWords(self, num: int) -> str:
        # This approach handles the number in 3 digit chunks. Let's start by creating some maps of english words - ones, tens, yuck, and mult
        #   These have aligned indecies. ones[1] = "one". tens[4] = "forty".
        #   the 'yuck' map will help us with teen numbers that don't follow the usual pattern
        #   and the 'mult' map will help us with multiples of thousands
        
        # First, break the input into a list. We're going to then look at that list in 3 digit chunks. This is because three hundred and forty two thousand requires
        # the same processing as three hundred and forty two - just with a thousand thrown on the end. The same goes for million and billion
        
        # The function thous_group will handle these 3 -digit chunks
        #   First handle the hundreds - located at the first digit (group[0]). If the digit is 0, we add nothing, other wise we add one[digit] plus 'hundred'
        #   Then we can check for teens. If the second digit (group[1]) is 1, we know we can just add the third digit's teen value
        #   If not a teen, we can add the tens[at group[1]] and ones[at group[2]] directly
        #   Finally, we can add the thousands, which is inferred from the input parameter mulitplier which we will set in our main loop later
        #       - Note that we only add a thousands suffix if there is actually an output! The number 1,000,000 is not written One Million Zero Thousand
        
        # Once the function works (test it out with some 3 digit numbers), we can write our main loop that calls the function on different chunks of the input num
        #   We will start at the end of the number and work our way to the front. The iterator i keeps track of our place, and the multiplier variable keeps track of which
        #   multiple of 'thousand' we are on.
        #   We can call our function on these three digit chunks, adding their output each time.
        #   However, if the last chunk does not have 3 digits (ex. 12,345) then we can simply pad it out with some zeroes to make it 3 digits -> 012,345
        output = ''
        
        # Handle zero case
        if num == 0: return 'Zero'
        
        # Create mappings to english words
        ones = ['', ' One', ' Two', ' Three', ' Four', ' Five', ' Six', ' Seven', ' Eight', ' Nine']
        tens = ['','',' Twenty', ' Thirty', ' Forty', ' Fifty', ' Sixty', ' Seventy', ' Eighty', ' Ninety']
        yuck = [' Ten', ' Eleven', ' Twelve', ' Thirteen', ' Fourteen', ' Fifteen', ' Sixteen', ' Seventeen', ' Eighteen', ' Nineteen']
        mult = ['', ' Thousand', ' Million', ' Billion']
        
        # Function that handles three digits at a time
        def thous_group(group, multiplier):
            out = ''
            
            # Handle Hundreds
            if group[0] != 0:
                out = ones[group[0]] + ' Hundred'
            
            # Handle teen numbers
            if group[1] == 1:
                out += yuck[group[2]]
            
            # Handle the tens and ones (if not teens)
            else:
                out += tens[group[1]] +  ones[group[2]]
            
            # Handle multiplier (thousand, million, ...)
            if out: out += mult[multiplier]
                
            return out
        
        # Turn the input number into a list of integer digits
        num = list(str(num))
        num = [int(x) for x in num]
        
        # Loop through 3 digit groups
        i = len(num)
        multiplier = 0
        while i > 0:
            # If there are fewer than 3 digits left, add buffer 0s to it
            if i - 3 < 0: 
                num = abs(i-3)*[0] + num
                i += abs(i-3)
            
            # Use the helper function to return the string for this group
            output = thous_group(num[i-3:i], multiplier) + output
            i -= 3
            multiplier += 1
            
        return output.strip()
    
#Method-4   
#Recursive Sol


class Solution:
    def numberToWords(self, num: int) -> str:
        zero_to_nineteen = 'Zero One Two Three Four Five Six Seven Eight Nine Ten Eleven Twelve Thirteen Fourteen Fifteen Sixteen Seventeen Eighteen Nineteen'.split()
        tens = 'None None Twenty Thirty Forty Fifty Sixty Seventy Eighty Ninety'.split()
        
        if num == 0: return 'Zero'
        
        def stringMaker(pre, place):
            string = []
            if len(pre) > 2:
                if pre[0] != '0':
                    string.append(zero_to_nineteen[int(pre[0])])
                    string.append('Hundred')
                pre = pre[1:]
            if len(pre) and int(pre) > 19:
                string.append(tens[int(pre[0])])
                pre = pre[1:]
            if len(pre) and int(pre) > 0: string.append(zero_to_nineteen[int(pre)])
            if string and place: string.append(place)
            return string
        
        def convert(n):
            length = len(n)
            if (length) > 9:
                diff = length - 9
                pre = n[:diff]
                string = stringMaker(pre, 'Billion')
            elif (length) > 6:
                diff = length - 6
                pre = n[:diff]
                string = stringMaker(pre, 'Million')
            elif (length) > 3:
                diff = length - 3
                pre = n[:diff]
                string = stringMaker(pre, 'Thousand')
            else: return stringMaker(n, None)
            return string + convert(n[diff:])
        
        return ' '.join(convert(str(num)))
    
    
#Method-5    
#Binary-search 

class Solution:
    def numberToWords(self, num: int) -> str:
        if (num == 0):
            return "Zero"
        numEng100 = [
            [1, "One"], [2, "Two"], [3, "Three"], [4, "Four"], [5, "Five"],
            [6, "Six"], [7, "Seven"], [8, "Eight"], [9, "Nine"], [10, "Ten"],
            [11, "Eleven"], [12, "Twelve"], [13, "Thirteen"], [14, "Fourteen"], [15, "Fifteen"],
            [16, "Sixteen"], [17, "Seventeen"], [18, "Eighteen"], [19, "Nineteen"], [20, "Twenty"],
            [30, "Thirty"], [40, "Forty"], [50, "Fifty"], [60, "Sixty"], [70, "Seventy"],
            [80, "Eighty"], [90, "Ninety"]
        ]
        
        result = []
        R = len(numEng100) - 1
        while(num > 0):
            if (num >= 100):
                scale = self.findScale(num)
                cnt = num // scale[0]
                if (cnt > 9):
                    result.append(self.numberToWords(cnt))
                else:
                    result.append(numEng100[cnt - 1][1]) # cnt = 1..9
                result.append(scale[1])
                
                num = num % scale[0]
            else:
                L = 0
                while(L <= R):
                    mid = (L + R) >> 1
                    if (numEng100[mid][0] <= num):
                        L = mid + 1
                    else:
                        R = mid - 1
                
                result.append(numEng100[R][1])
                
                num = num - numEng100[R][0]
        return " ".join(result)
                
                
            
    
    def findScale(self, num: int) -> List[Union[int, str]]:
        
        scaleRange = [
           [100, "Hundred"], [1000, "Thousand"], [1000000, "Million"],  [1000000000, "Billion"]
        ]
        if (num >= scaleRange[-1][0]):
            return scaleRange[-1]
        
        L = 0
        R = len(scaleRange) - 1
        while(L < R):
            mid = (L + R) >> 1
            if (scaleRange[mid][0] <= num) and (num < scaleRange[mid + 1][0]):
                return scaleRange[mid]
            elif (scaleRange[mid][0] < num):
                L = mid + 1
            else:
                R = mid - 1
        return scaleRange[L]




#Q19 Minimum Window Substring
'''

Given two strings s and t of lengths m and n respectively, return the minimum window substring of s such that every character in t (including duplicates) is included in the window. If there is no such substring, return the empty string "".

The testcases will be generated such that the answer is unique.

A substring is a contiguous sequence of characters within the string.

 

Example 1:

Input: s = "ADOBECODEBANC", t = "ABC"
Output: "BANC"
Explanation: The minimum window substring "BANC" includes 'A', 'B', and 'C' from string t.
Example 2:

Input: s = "a", t = "a"
Output: "a"
Explanation: The entire string s is the minimum window.
Example 3:

Input: s = "a", t = "aa"
Output: ""
Explanation: Both 'a's from t must be included in the window.
Since the largest window of s only has one 'a', return empty string.
 

Constraints:

m == s.length
n == t.length
1 <= m, n <= 105
s and t consist of uppercase and lowercase English letters.
 

Follow up: Could you find an algorithm that runs in O(m + n) time?

'''


#Solution 

#Method-1

#O(m + n) || Using a counter class to simplify the code

# The key idea here is that each iteration of the for loop finds the shortest valid substring which ends at the right pointer. One of those substrings must be the shortest valid substring overall.

# The solution is O(m + n) because it takes:

# O(n) steps to create the LetterCounter
# O(m) steps to complete the for loop
# The for loop takes O(m) steps because each iteration moves the right pointer forward 1 place and doesn't move the left pointer backwards.

class Solution:
    def minWindow(self, s: str, t: str) -> str:
        min_range = (0, float("inf"))
        counter = LetterCounter(t)
        left = 0
        
        for right in range(len(s)):
            counter.add(s[right])
            
            if not counter.is_valid():
                continue
            
            while counter.is_valid():
                counter.remove(s[left])
                left += 1
            left -= 1
            counter.add(s[left])
            
            if right - left < min_range[1] - min_range[0]:
                min_range = (left, right)
        
        return "" if min_range == (0, float("inf")) else s[min_range[0]:min_range[1] + 1]
    
class LetterCounter:
    def __init__(self, letters):
        self.needed = dict()
        for l in letters:
            if l not in self.needed:
                self.needed[l] = 1
            else:
                self.needed[l] += 1
        self.num_invalid = len(self.needed)

    def add(self, letter):
        if letter in self.needed:
            self.needed[letter] -= 1
            if self.needed[letter] == 0:
                self.num_invalid -= 1

    def remove(self, letter):
        if letter in self.needed:
            self.needed[letter] += 1
            if self.needed[letter] == 1:
                self.num_invalid += 1

    def is_valid(self):
        return self.num_invalid == 0
    
#Method-2

#O(n+m) 

class Solution:
    def minWindow(self, s: str, t: str) -> str:
        if t=="": 
            return ""
        countT,window={},{}
        res,reslen=[-1,-1],float("inf")
        for c in t:
            countT[c]=1+countT.get(c,0)
            
        l=0
        have,need=0,len(countT)
        for r in range(len(s)):
            c=s[r]
            window[c]=1+window.get(c,0)
            
            if c in countT and window[c]==countT[c]:
                have+=1
                
            while have==need:
                if r-l+1<reslen:
                    res=[l,r]
                    reslen=r-l+1
                    
                window[s[l]]-=1
                if s[l] in countT and window[s[l]]<countT[s[l]]:
                    have-=1
                l+=1
                
        l,r=res
        return s[l:r+1] if reslen!=float("inf") else ""
    
    
#Method-3
#Sliding Window 

class Solution(object):
    def minWindow(self, s, t):
        
        if len(t) > len(s):
            return ''
        
        need = len(t)                     #Calculate the number of elements that needs to be matched
        hash_map = collections.Counter(t) #Create a hash map for elements in t
        subLength = len(s) + 1            #Initialize the length of substring
        left = right = 0                  #Intialize the index of sliding window
        start, end = 0, -1                #Start and end index of the substring
        
        while(right < len(s)):              #Right pointer of sliding window keep moving forward
            if s[right] in t:
                if hash_map[s[right]] > 0:  #If s[right] is in t, and we still need it
                    need -= 1               #Find one, need - 1
                hash_map[s[right]] -= 1     #Count for the element - 1. This number can be negative, 
				                            #meaning we have more s[right] in our substring than need.

            
            while(need == 0):                       #Find one target substring, left pointer moves forward
                if right - left + 1 < subLength:
                    subLength = right - left + 1    #Calculate the length of target substring
                    start, end = left, right        #Change the start and end index of the target substring
            
                if s[left] in t:                   
                    if hash_map[s[left]] >= 0:      #The element moved out is the element we need
                        need += 1
                    hash_map[s[left]] += 1
                left += 1
                
            right += 1
        
        return s[start:end + 1]                     #Return the target substring
    
    
    
#Method-4   
#Two pointers

class Solution:
    def minWindow(self, s: str, t: str) -> str:
        
        h = collections.Counter(t)
        cnt = len(h)
        n = len(s)
        mini = n+1
        start, end = 0, -1
        lo = 0
        
        for hi in range(n):
            if(s[hi] in h):
                h[s[hi]] -= 1
                cnt -= h[s[hi]] == 0
            while(not cnt):
                if(hi-lo+1 < mini):
                    mini = hi-lo+1
                    start, end = lo, hi
                if(s[lo] in h):
                    h[s[lo]] += 1
                    cnt += h[s[lo]] == 1
                lo += 1
                
        return s[start:end+1]
    
#Method-5    
#O(n) Object Oriented


# uses an object Requirement to keep track of states (e.g. seen characters, do we meet the requirement?)
# constant time lookup of is_okay()
# sliding window expands and shrinks by jumping ahead to required chars
# Solution

class Solution:
    def minWindow(self, s: str, t: str) -> str:
        if len(t) > len(s):
            # window is larger than s, impossible
            return ""
        
        # keep track of substring requirements
        req = Requirement()
        for c in t:
            req.addReq(c)

        res = ""
        
        # initialize with first char of s
        req.see(s[0])
        
        # while our window hasn't reached the end yet
        l, r = 0, 0
        while r < len(s):
            if req.is_okay():
                # no more required chars left
                if not res or len(res) > (r - l + 1):
                    # check if matched substring is smaller
                    res = s[l:r + 1]
                # shrink window by moving left pointer
                req.unsee(s[l])
                l += 1
                # keep shrinking window until we come across
                # a required char
                while l < r and s[l] not in req.freq:
                    l += 1
            else:
                if r == len(s) - 1:
                    # we have reached the end, break out
                    break
                # expand window by moving right pointer
                r += 1
                # keep expanding until we come across
                # a required char
                while r < len(s) - 1 and s[r] not in req.freq:
                    r += 1
                req.see(s[r])
                
        return res

    
class Requirement:
    def __init__(self) -> None:
        self.freq = {}
        self.formed = 0
        self.required = 0
        
        
    def is_okay(self):
        return self.formed == self.required
        
        
    def addReq(self, c: str) -> None:
        if c not in self.freq:
            self.freq[c] = 0
            self.required += 1
        self.freq[c] += 1

        
    def see(self, c: str) -> None:
        if c not in self.freq:
            # ignore unnecessary chars
            return

        self.freq[c] -= 1
        if self.freq[c] == 0:
            # dropped to zero so we have a newly
            # formed letter
            self.formed += 1
        
        
    def unsee(self, c: str) -> None:
        if c not in self.freq:
            # ignore unnecessary chars
            return

        self.freq[c] += 1
        if self.freq[c] == 1:
            # increased to 1 so we have no longer
            # have a formed letter
            self.formed -= 1
                    

                
#Another way O(N) with 2 pointers

class Solution:
    def minWindow(self, s, t):
        count = 0
        m = {}
        for c in t:
            if c not in m:
                count += 1
                m[c] = 0
            m[c] += 1
        start = 0
        size = len(s)
        ansLen = size + 1
        ans = ''
        for end in range(size):
            if s[end] not in m:
                continue
            m[s[end]] -= 1
            if m[s[end]] == 0:
                count -= 1
            
            while count == 0:
                if end - start + 1 < ansLen:
                    ansLen = end-start+1
                    ans = s[start:end+1]
                startC = s[start]
                start += 1
                if startC not in m:
                    continue
                m[startC] += 1
                if m[startC] == 1:
                    count += 1
                    break
                
        if ansLen == size + 1:
            return ''
        return ans


#Q20 Valid Number

'''
A valid number can be split up into these components (in order):

A decimal number or an integer.
(Optional) An 'e' or 'E', followed by an integer.
A decimal number can be split up into these components (in order):

(Optional) A sign character (either '+' or '-').
One of the following formats:
One or more digits, followed by a dot '.'.
One or more digits, followed by a dot '.', followed by one or more digits.
A dot '.', followed by one or more digits.
An integer can be split up into these components (in order):

(Optional) A sign character (either '+' or '-').
One or more digits.
For example, all the following are valid numbers: ["2", "0089", "-0.1", "+3.14", "4.", "-.9", "2e10", "-90E3", "3e+7", "+6e-1", "53.5e93", "-123.456e789"], while the following are not valid numbers: ["abc", "1a", "1e", "e3", "99e2.5", "--6", "-+3", "95a54e53"].

Given a string s, return true if s is a valid number.

 

Example 1:

Input: s = "0"
Output: true
Example 2:

Input: s = "e"
Output: false
Example 3:

Input: s = "."
Output: false
 

Constraints:

1 <= s.length <= 20
s consists of only English letters (both uppercase and lowercase), digits (0-9), plus '+', minus '-', or dot '.'.

'''
#Solution

#Method-1

# check for valid number patterns
# To avoid working out the more complicated logic, I decided to parse the string into a pattern and check if the resulting pattern is valid.

class Solution:
    def isNumber(self, s: str) -> bool:
        valid_patterns = {
            'I', 'sI',
            '.I', 's.I',
            'I.', 'sI.',
            'I.I', 'sI.I',
            'IeI', 'sIeI', 'IesI', 'sIesI',
            'I.IeI', 'sI.IeI', 'I.IesI', 'sI.IesI',
            'I.eI', 'sI.eI', 'I.esI', 'sI.esI',
            '.IeI', 's.IeI', '.IesI', 's.IesI'            
        }
        
        test_pattern = []
        parsing_int = False
        for c in s:
            if parsing_int:
                if c.isnumeric():
                    continue
                else:
                    parsing_int = False
                    test_pattern.append('I')
            if c.isnumeric():
                parsing_int = True
            elif c in '+-':
                test_pattern.append('s')
            elif c in 'eE':
                test_pattern.append('e')
            elif c == '.':
                test_pattern.append('.')
            else:
                return False
            # Shortcut to limit space used because the longest valid pattern is 7 characters
            if len(test_pattern) > 7:
                return False
        if parsing_int:
            test_pattern.append('I')
            
        return ''.join(test_pattern) in valid_patterns
                
    # Time: O(N)
    # Space: O(1)
    
#Method-2
#DFA Solution


class Solution:
    def isNumber(self, s: str) -> bool:
        number = '0123456789'
        sign = '+-'
        state = 0
        dot_digits = False
        
        # DFA (deterministic finite automata) map
        transitions = {
            (0, 'sign'): 1,
            (0, 'digits'): 2,
            (0, 'dot'): 3,
            (1, 'digits'): 2,
            (1, 'dot'): 3,
            (2, 'digits'): 2,
            (2, 'dot'): 3,
            (2, 'exponent'): 5,
            (3, 'digits'): 4,
            (3, 'exponent'): 5,
            (4, 'digits'): 4,
            (4, 'exponent'): 5,
            (5, 'sign'): 6,
            (5, 'digits'): 7,
            (6, 'digits'): 7,
            (7, 'digits'): 7
        }
        
        def get_transition(l):
            if l in number:
                return 'digits'
            if l in sign:
                return 'sign'
            if l == '.':
                return 'dot'
            if l in 'eE':
                return 'exponent'
            return None
        
        # iterate over input and consume DFA map
        for n in s:
            trans = get_transition(n)
            if (state, trans) in transitions:
                state = transitions[(state, trans)]
            else:           # IF no correct state/transition found exit
                return False
            
            # Must get valid integer/decimal before exponent
            if trans == 'exponent' and not dot_digits:
                return False
                
            if state in {2, 4}:
                dot_digits = True
                
        # Valid Number
        # if DFA has been consumed + last character is digit or dot (with preceding digits)
        return (trans == 'dot' and dot_digits) or (trans == 'digits')

 

#Method-3    
#IF-ELSE using set() and separating into components

class Solution:
    def isNumber(self, s: str) -> bool:
        i = 0
        valid_symbols = {'0', '1', '2', '3', '4', '5', '6', '7', '8', '9', '+', '-', 'e', 'E', '.'}
        one_point = False
        first_sign = False
        second_sign = False
        has_e = False
        
        first_component = ''
        first_component_is_valid = False
        second_component = ''
        second_component_is_valid = False
        
        while i < len(s):
            if s[i] not in valid_symbols:
                return False
            elif s[i] == '.':
                if one_point:
                    return False
                else:
                    one_point = True
                if has_e:
                    return False
                else:
                    first_component = f'{first_component}.'
            elif s[i] == '+' or s[i] == '-':
                if has_e and not second_component and not second_sign:
                    second_sign = True
                    second_component = s[i]
                elif has_e:
                    return False
                elif not first_component and not first_sign:
                    first_sign = True
                    first_component = s[i]
                else:
                    return False
            elif s[i] == 'e' or s[i] == 'E':
                if has_e:
                    return False
                elif not first_component or first_component == '.' or first_component == '+' or first_component == '-':
                    return False
                else:
                    has_e = True
            else:
                if has_e:
                    second_component = f'{second_component}{s[i]}'
                    second_component_is_valid = True
                else:
                    first_component = f'{first_component}{s[i]}'
                    first_component_is_valid = True
            i += 1
        if second_component and second_component_is_valid:
            return True
        elif second_component:
            return False
        elif has_e and not second_component:
            return False
        elif first_component and first_component_is_valid:
            return True
        else:
            return False
        
#Method-4

class Solution:
    def isNumber(self, s: str) -> bool:
        
        #if the string is inf, replace it
        if s == '-inf' or s == 'inf' or s == '+inf' or s == '-Infinity' or s == 'Infinity' or s == '+Infinity':
            return(False)

        #Check if it's an int
        try:
            return(type(int(float(s))) == int)
        except:
            ValueError('Error Int Check')

        #check if inf
        try:
            return(str(float(s)) == 'inf' or str(float(s)) == '-inf')
        except:
            ValueError("Error inf")

        return(False)
    
#Method-5

#Regex, explained, one line

# Assuming regex is not considered as cheating.

# [+-]? if there is a sign component
# (\d+\\.\d*) Decimal [at least one digit followed by a . followed by 0 or more digits]
# (\\.\d+) Decimal [a . must be followed by at least one digit]
# | or operator to choose between either of the two decimal groups
# (\d+) Integer [must be at least one digit]
# | Or operator again to choose either an integer group or one of the decimal group
# Exponential grouping
# [eE] either character e or E
# [+-]? signed component of exponent if exists
# (\d+) followed by integer
# Its important to mark this entire group inside ^ and $ for starts with and ends with.

import re
class Solution:
    def isNumber(self, s: str) -> bool:
        if(re.compile('^([+-]?(((\d+\.\d*)|(\.\d+))|(\d+))([eE][+-]?\d+)?)$').match(s) == None):
            return False
        return True



 #Q21  Distinct Subsequences

 '''

Given two strings s and t, return the number of distinct subsequences of s which equals t.

A string's subsequence is a new string formed from the original string by deleting some (can be none) of the characters without disturbing the remaining characters' relative positions. (i.e., "ACE" is a subsequence of "ABCDE" while "AEC" is not).

The test cases are generated so that the answer fits on a 32-bit signed integer.

 

Example 1:

Input: s = "rabbbit", t = "rabbit"
Output: 3
Explanation:
As shown below, there are 3 ways you can generate "rabbit" from S.
rabbbit
rabbbit
rabbbit
Example 2:

Input: s = "babgbag", t = "bag"
Output: 5
Explanation:
As shown below, there are 5 ways you can generate "bag" from S.
babgbag
babgbag
babgbag
babgbag
babgbag
 

Constraints:

1 <= s.length, t.length <= 1000
s and t consist of English letters.

 '''

 #Solution 

 #Method-1
#Index match

class Solution:
    def numDistinct(self, s: str, t: str) -> int:
        
        @lru_cache(None)
        def match(i, j):
            if i == len(s) or j == len(t):
                if i == len(s) and j == len(t):
                    return 1
                elif i == len(s):
                    return 0
                else:
                    return 1
            if s[i] == t[j]:
                return match(i+1, j+1) + match(i+1, j)
            else:
                return match(i+1, j)
        return match(0, 0)
    
#Method-2
#DP

class Solution:
    def f(self,i,j,s,t,dp):
        if j==0:
            return 1
        if i==0:
            return 0
        if dp[i][j]!=-1:
            return dp[i][j]
        if s[i-1]==t[j-1]:
            dp[i][j]= self.f(i-1,j-1,s,t,dp)+self.f(i-1,j,s,t,dp)
        else:
            dp[i][j]= self.f(i-1,j,s,t,dp)
        return dp[i][j]
    
    def numDistinct(self, s: str, t: str) -> int:
        m=len(s)
        n=len(t)
        # dp=[[-1 for i in range(n+1)]for j in range(m+1)]
        # return self.f(m,n,s,t,dp)
        dp=[[ 0 for i in range(n+1)]for j in range(m+1)]
        for i in range(m+1):
            dp[i][0]=1
        for j in range(1,n+1):
            dp[0][j]=0
        for i in range(1,m+1):
            for j in range(1,n+1):
                if s[i-1]==t[j-1]:
                    dp[i][j]= dp[i-1][j-1]+dp[i-1][j]
                else:
                    dp[i][j]= dp[i-1][j]
        return dp[m][n]
    
    
#Method-3
#DFS
class Solution:
    def numDistinct(self, s: str, t: str) -> int:
        n, m = len(s), len(t)
        
        @lru_cache(None)
        def dfs (i, j):
            if j == m: return 1
            if i == n: return 0
            if s[i]==t[j]: return dfs(i+1, j+1) + dfs(i+1, j)
            else: return dfs(i+1, j)
        
        return dfs(0,0)
    
#Method-4

class Solution(object):
    def numDistinct(self, s, t):
        """
        :type s: str
        :type t: str
        :rtype: int
       """
        countList = []
        len_t = len(t)
    
        for i in range(len_t+1):
            countList.append(0)
    
            countList[0] = 1
    
        for char in s:
            for j in range(len_t-1, -1, -1):
                 if countList[j] != 0 and t[j] == char:
                        countList[j+1] += countList[j]
    
        return countList[len_t]
    
#Method-5 
#DP
class Solution:
	def numDistinct(self, s: str, t: str) -> int:


		"""
						  r a b b b i t

						r 1 0 0 0 0 0 0
						a 0 1 0 0 0 0 0
						b 0 0 1 1 1 0 0 
						b 0 0 0 1 2 0 0 
						i 0 0 0 0 0 3 0
						t 0 0 0 0 0 0 3

		"""

		matrix = [[0 for i in range(len(s))] for j in range(len(t))]

		for j in range(len(s)):
			if s[j] == t[0]:
				matrix[0][j] = 1

		for j in range(1, len(t)):
			running_sum = 0
			for i in range(len(s)):
				if s[i] == t[j]:
					matrix[j][i] = running_sum
				running_sum += matrix[j - 1][i]

		return sum(matrix[-1]) 


#Q22 Smallest Range Covering Elements from K Lists
'''
You have k lists of sorted integers in non-decreasing order. Find the smallest range that includes at least one number from each of the k lists.

We define the range [a, b] is smaller than range [c, d] if b - a < d - c or a < c if b - a == d - c.

 

Example 1:

Input: nums = [[4,10,15,24,26],[0,9,12,20],[5,18,22,30]]
Output: [20,24]
Explanation: 
List 1: [4, 10, 15, 24,26], 24 is in range [20,24].
List 2: [0, 9, 12, 20], 20 is in range [20,24].
List 3: [5, 18, 22, 30], 22 is in range [20,24].
Example 2:

Input: nums = [[1,2,3],[1,2,3],[1,2,3]]
Output: [1,1]
 

Constraints:

nums.length == k
1 <= k <= 3500
1 <= nums[i].length <= 50
-105 <= nums[i][j] <= 105
nums[i] is sorted in non-decreasing order.

'''

#Solution

#Method-1
#Heap

class Solution:
    def smallestRange(self, nums: List[List[int]]) -> List[int]:    
        heap = []
        largest = 0
        for idx, num in enumerate(nums):
            largest = max(largest, num[0])
            heappush(heap, (num[0], idx, 0))

        x, y = heap[0][0], max(map(max, nums))
        while len(heap):
            val, array_idx, idx = heappop(heap)
            if largest - val < y - x:
                x, y = val, largest

            array = nums[array_idx]
            if idx + 1 == len(array):
                break
            largest = max(largest, array[idx + 1])
            heappush(heap, (array[idx + 1], array_idx, idx + 1))
        
        return [x, y]
    
#Method-2

#heap-priority-queue

class Solution:
    def smallestRange(self, nums: List[List[int]]) -> List[int]:
        minx,miny,diff_range=float('inf'),0,float('inf')
        queue=[]
        heapq.heapify(queue)
        curr_max=-float('inf')
        for i in range(len(nums)):
            heapq.heappush(queue,(nums[i][0],i,0))
            curr_max=max(curr_max,nums[i][0])
        curr_min=-float('inf')
        while queue:
            curr_min,arr,pos=heapq.heappop(queue)
            if curr_max-curr_min<diff_range:
                minx,miny,diff_range=curr_min,curr_max,curr_max-curr_min
            # print(curr_min)
            # print(curr_max)
            if pos+1<len(nums[arr]):
                heapq.heappush(queue,(nums[arr][pos+1],arr,pos+1))
                curr_max=max(curr_max,nums[arr][pos+1])
            else:
                break
        return [minx,miny]
    
    
    
    
    
#Method-3


#Sliding Window, Set, HashMap O(kNLog(kN))


#Flatten and sort

# Lets look at the example [[4,10,15,24,26],[0,9,12,20],[5,18,22,30]]
# We want to flatten this to a 1-d array while keeping information of which original array the number belongs to
# After flattening, we can efficiently lookup to the array we included in our windows in O(1) time
# Flatten it and sort it (sorting here is O(kNlog(kN)):



class Solution:
    def smallestRange(self, nums: List[List[int]]) -> List[int]:
        # flatten and sort by value
        flatten_nums = [(i,x) for i,X in enumerate(nums) for x in X]
        flatten_nums.sort(key=lambda x: x[1])
        
        res = None
        
        # sliding window
        i = 0
        remaining = {i: 1 for i in range(len(nums))}
        remaining_set = {*range(len(nums))}
        for j in range(len(flatten_nums)):
            nums_idx_j, v_j = flatten_nums[j]
            nums_idx_i, v_i = flatten_nums[i]
            remaining[nums_idx_j] -= 1
            if remaining[nums_idx_j] == 0:
                remaining_set.remove(nums_idx_j)
            while not remaining_set:
                nums_idx_i, v_i = flatten_nums[i]
                if res is None or v_j-v_i < res[1]-res[0]:
                    res = [v_i,v_j]
                remaining[nums_idx_i] += 1
                if remaining[nums_idx_i] > 0:
                    remaining_set.add(nums_idx_i)
                i += 1
                    
        return res

#Method-4    
#minheap

class Solution:
	# one element from each row in the heap
	# pop the top(minimum)
	# push the next
	# check the distance from minimun to the max
    def smallestRange(self, nums: List[List[int]]) -> List[int]:
        k = len(nums)
        ans = []
        heap = [(row[0],i,0) for i,row in enumerate(nums)]
        heapq.heapify(heap)
        right = max(row[0] for row in nums)
        while heap:
            # the smallest on the top
            left,i,j = heapq.heappop(heap)
            if not ans or right-left < ans[1]-ans[0]:
                ans = [left,right]
            if j + 1 == len(nums[i]):
                return ans
            right = max(right,nums[i][j+1])
            heapq.heappush(heap,(nums[i][j+1],i,j+1))
        return ans
    
#Method-5   
#bisect insort

class Solution:
    def smallestRange(self, nums: List[List[int]]) -> List[int]:
        base = []
        for idx,num in enumerate(nums):
            base += [[nums[idx].pop(0),idx]]
        base.sort()
        #print(base)
        cur_min = base[0][0]
        cur_max = base[-1][0]
        out = [cur_min,cur_max]
        while(True):
            b = base.pop(0)
            #idx = 0
            #while(idx<len(base) and base[idx][0]==base[0][0]):
            #    idx+=1
            # 
            #canidate = [[nums[base[i][1]],i] for i in range(idx)]
            #canidate.sort()
            #b = base.pop(canidate[0][1])
            if(not nums[b[1]]):
                return out
            t = [nums[b[1]].pop(0),b[1]]
            insort(base,t)
            new_min = base[0][0]
            new_max = base[-1][0]
            if(new_max-new_min<out[1]-out[0]):
                out=[new_min,new_max]
            #print(base,new_min,new_max)



#Q23 Substring with Concatenation of All Words


'''

You are given a string s and an array of strings words. All the strings of words are of the same length.

A concatenated substring in s is a substring that contains all the strings of any permutation of words concatenated.

For example, if words = ["ab","cd","ef"], then "abcdef", "abefcd", "cdabef", "cdefab", "efabcd", and "efcdab" are all concatenated strings. "acdbef" is not a concatenated substring because it is not the concatenation of any permutation of words.
Return the starting indices of all the concatenated substrings in s. You can return the answer in any order.

 

Example 1:

Input: s = "barfoothefoobarman", words = ["foo","bar"]
Output: [0,9]
Explanation: Since words.length == 2 and words[i].length == 3, the concatenated substring has to be of length 6.
The substring starting at 0 is "barfoo". It is the concatenation of ["bar","foo"] which is a permutation of words.
The substring starting at 9 is "foobar". It is the concatenation of ["foo","bar"] which is a permutation of words.
The output order does not matter. Returning [9,0] is fine too.
Example 2:

Input: s = "wordgoodgoodgoodbestword", words = ["word","good","best","word"]
Output: []
Explanation: Since words.length == 4 and words[i].length == 4, the concatenated substring has to be of length 16.
There is no substring of length 16 is s that is equal to the concatenation of any permutation of words.
We return an empty array.
Example 3:

Input: s = "barfoofoobarthefoobarman", words = ["bar","foo","the"]
Output: [6,9,12]
Explanation: Since words.length == 3 and words[i].length == 3, the concatenated substring has to be of length 9.
The substring starting at 6 is "foobarthe". It is the concatenation of ["foo","bar","the"] which is a permutation of words.
The substring starting at 9 is "barthefoo". It is the concatenation of ["bar","the","foo"] which is a permutation of words.
The substring starting at 12 is "thefoobar". It is the concatenation of ["the","foo","bar"] which is a permutation of words.
 

Constraints:

1 <= s.length <= 104
1 <= words.length <= 5000
1 <= words[i].length <= 30
s and words[i] consist of lowercase English letters.

'''

#Solution 

# Method-1
#Sliding Window || Two Pointer || Hash Table || Hashing | O (n * a * 26)

class Solution:

    def splitInNEqualParts(self, string: str, ws: int):
        output = []
        for i in range(len(string)):
            if (i + 1) % ws == 0:
                output.append(string[i + 1 - ws:i + 1])
        return output

    def findSubstring(self, s: str, words: List[str]) -> Set[int]:
        js = "".join(words)
        anagram = Counter(js)
        anagram_2nd = Counter(words)
        print(anagram, anagram_2nd)
        totalWindowLength = len(js)
        ws = len(words[0])
        window = Counter()
        output = set()
        i = j = 0
        while i < len(s):
            window[s[i]] += 1
            if i - j + 1 == totalWindowLength:
                # print(window)
                if anagram == window:
                    parts = self.splitInNEqualParts(s[j:i + 1], ws)
                    print(parts)
                    ma = Counter(parts)
                    if ma == anagram_2nd:
                        output.add(j)
                window[s[j]] -= 1
                if window[s[j]] < 1:
                    del window[s[j]]
                j += 1
            i += 1
        return output
    
# Method-2
# Using hashmap

class Solution:
    def is_exist(self, s, subst_len, word_len, word2cnt, idx):
        word2cnt_copy = word2cnt.copy()
        
        for i in range(idx, idx + subst_len, word_len):
            word = s[i:i + word_len]
            if word2cnt_copy[word] == 0:
                return False
            else:
                word2cnt_copy[word] -= 1

        return True
    
    def findSubstring(self, s: str, words: List[str]) -> List[int]:
        str_len = len(s)
        
        words_cnt = len(words)
        word_len = len(words[0])
        
        word2cnt = collections.Counter(words)
        
        res = []
        
        # word_length * words_count - substr length
        for idx in range(str_len - word_len * words_cnt + 1):
            if self.is_exist(s, word_len * words_cnt, word_len, word2cnt, idx):
                res.append(idx)
        
        return res


    
    
# Method-3    

class Solution:
    def findSubstring(self, s: str, words: List[str]) -> List[int]:
        n = len(s)
        k = len(words)
        word_length = len(words[0])
        substring_size = word_length * k
        word_count = collections.Counter(words)
        
        def sliding_window(left):
            words_found = collections.defaultdict(int)
            words_used = 0
            excess_word = False
            
            # Do the same iteration pattern as the previous approach - iterate
            # word_length at a time, and at each iteration we focus on one word
            for right in range(left, n, word_length):
                if right + word_length > n:
                    break

                sub = s[right : right + word_length]
                if sub not in word_count:
                    # Mismatched word - reset the window
                    words_found = collections.defaultdict(int)
                    words_used = 0
                    excess_word = False
                    left = right + word_length # Retry at the next index
                else:
                    # If we reached max window size or have an excess word
                    while right - left == substring_size or excess_word:
                        # Move the left bound over continously
                        leftmost_word = s[left : left + word_length]
                        left += word_length
                        words_found[leftmost_word] -= 1

                        if words_found[leftmost_word] == word_count[leftmost_word]:
                            # This word was the excess word
                            excess_word = False
                        else:
                            # Otherwise we actually needed it
                            words_used -= 1
                    
                    # Keep track of how many times this word occurs in the window
                    words_found[sub] += 1
                    if words_found[sub] <= word_count[sub]:
                        words_used += 1
                    else:
                        # Found too many instances already
                        excess_word = True
                    
                    if words_used == k and not excess_word:
                        # Found a valid substring
                        answer.append(left)
        
        answer = []
        for i in range(word_length):
            sliding_window(i)

        return answer
 


# Method-4   
class Solution:
     def findSubstring(self, s: str, words: List[str]) -> List[int]:
        word_l = len(words[0])
        word_c = Counter(words)
        b,e=0,word_l*len(words)
        indices=[]
        
        while e <= len(s):
            if Counter([s[x:x+word_l] for x in range(b,e,word_l)])==word_c:
                indices.append(b)

            b+=1
            e+=1

        return indices
    
    
# Method-5    
# Since we know all words have the same length, we could calculate the window size and extract substring from each position; we then divided the substring into words and check with the word list.

class Solution:
    def findSubstring(self, s: str, words: List[str]) -> List[int]:
        word_dict = defaultdict(int)
        for word in words:
            word_dict[word] += 1
        
        word_size = len(words[0])
        window_size = word_size * len(words)
        
        res = []
        
        def check(i):
            cur_dict = word_dict.copy()
            sample_word_list = [s[j:j+word_size] for j in range(i, i + window_size, word_size)]
            for word in sample_word_list:
                if word in cur_dict:
                    cur_dict[word] -= 1
                    if cur_dict[word] == 0:
                        del cur_dict[word]
                else:
                    return
            if not cur_dict: #check if all entries have been deleted
                res.append(i)
                
        for i in range(len(s) - window_size + 1):
            check(i)
        return res


        

