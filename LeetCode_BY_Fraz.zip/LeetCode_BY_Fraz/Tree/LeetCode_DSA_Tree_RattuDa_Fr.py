#Tree

#Q1. Diameter of Binary Tree

'''

Given the root of a binary tree, return the length of the diameter of the tree.

The diameter of a binary tree is the length of the longest path between any two nodes in a tree. This path may or may not pass through the root.

The length of a path between two nodes is represented by the number of edges between them.

 

Example 1:


Input: root = [1,2,3,4,5]
Output: 3
Explanation: 3 is the length of the path [4,2,1,3] or [5,2,1,3].
Example 2:

Input: root = [1,2]
Output: 1
 

Constraints:

The number of nodes in the tree is in the range [1, 104].
-100 <= Node.val <= 100

'''
#Solution:

# Definition for a binary tree node.
# class TreeNode:
#     def __init__(self, val=0, left=None, right=None):
#         self.val = val
#         self.left = left
#         self.right = right


# Method-1
# Recursive 

class Solution:
    dia = 0
    def diameterOfBinaryTree(self, root: Optional[TreeNode]) -> int:
        if root == None: return True
        self.height(root)
        return self.dia

    def height(self, root):
        if (root == None): return 0
        l = self.height(root.left)
        r = self.height(root.right)
        if l+r > self.dia:
            self.dia = l+r
        return max(l, r)+1
    
#Method-2

class Solution:

    def __init__(self):
        self.max_diameter = -1
    
    def getDiameter(self,node):
        
        if node is None:
            return 0
        
        left_path = self.getDiameter(node.left)
        right_path = self.getDiameter(node.right)
        
        # diameter seen at current node
        self.max_diameter = max(self.max_diameter,left_path+right_path)
        
        # diameter extension that can be experienced by parents
        return 1+max(left_path,right_path)
    
    def diameterOfBinaryTree(self, root: Optional[TreeNode]) -> int:
        self.getDiameter(root)
        return self.max_diameter
    
#Method-3
# dfs
# recursion
# easy-understanding


class Solution:
    def diameterOfBinaryTree(self, root: Optional[TreeNode]) -> int:

        mypath=[]

        def dfs(node): 
            nonlocal mypath
            if not node:
                return 0,0,[]

            left,a,lpath=dfs(node.left)
            right,b,rpath=dfs(node.right)

            if left+right>a and left+right>b:
                mypath=max(mypath,lpath+[node]+rpath[::-1],key=len)

            ret=max(a,b,left+right)
            return 1+max(left,right),ret,max(lpath+[node],rpath+[node],key=len)

        ans=dfs(root)        
        print([node.val for node in mypath])
        # prints the path in correct order from one end to the other 

        return ans[1]

#Method-4

# recursive solution
# Definition for a binary tree node.
# class TreeNode:
#     def __init__(self, val=0, left=None, right=None):
#         self.val = val
#         self.left = left
#         self.right = right



class Solution:
    '''
        For every node, find the righ and left subtree depth and then the maximum of them will be the result.
        This is O(N^2) solution. However, the algorithm is fairly simple.
    '''
    def __init__(self) :
        #Resetting the class variable res everytime a new tree is checked for diameter. 
        Solution.res=0
        
    def height(self,node) :
        if node is None :
            return 0
        return 1 + max(self.height(node.left),self.height(node.right))
        
    def diameterOfBinaryTree(self, root: Optional[TreeNode]) -> int:
        print(Solution.res)
        if root is None :
            return
        lheight = self.height(root.left)
        rheight = self.height(root.right)
        Solution.res = max(rheight+lheight,Solution.res)
        self.diameterOfBinaryTree(root.left)
        self.diameterOfBinaryTree(root.right)
        return Solution.res
    
#Method-5

class Solution(object):
    def __init__(self):
        self.dia = 0
    def sub(self, root):
        if not root:
            return 0
        left = self.sub(root.left)
        right = self.sub(root.right)
        t = left+right
        self.dia = max(t, self.dia)
        return 1+max(left, right)
        
    def diameterOfBinaryTree(self, root):
        """
        :type root: TreeNode
        :rtype: int
        """
        self.sub(root)
        return self.dia


#Q2.   Invert Binary Tree

'''
Given the root of a binary tree, invert the tree, and return its root.

 

Example 1:


Input: root = [4,2,7,1,3,6,9]
Output: [4,7,2,9,6,3,1]
Example 2:


Input: root = [2,1,3]
Output: [2,3,1]
Example 3:

Input: root = []
Output: []
 

Constraints:

The number of nodes in the tree is in the range [0, 100].
-100 <= Node.val <= 100

'''
#Solution

# Definition for a binary tree node.
# class TreeNode:
#     def __init__(self, val=0, left=None, right=None):
#         self.val = val
#         self.left = left
#         self.right = right


#Method-1

# levelorder
class Solution(object):
    def invertTree(self, root):
        def helper(node, level):
            if not node:
                return
            else:
                sol[level-1].append(node.val)
                node.left, node.right = node.right, node.left
                if len(sol) == level:  
                    sol.append([])
                helper(node.left, level+1)
                helper(node.right, level+1)
        sol = [[]]
        helper(root, 1)
        return root
    
class Solution(object):
    def invertTree(self, root):
        if root is None: return
        curr, queue = root, [root]
        while queue:
            curr = queue.pop(0) 
            curr.left, curr.right = curr.right, curr.left
            if curr.left: 
                queue.append(curr.left)
            if curr.right:
                queue.append(curr.right)
        return root
    
#Method-2

# Use recursion to solve this question

class Solution:
    def invertTree(self, root: Optional[TreeNode]) -> Optional[TreeNode]:
        if root == None:
            return root
        else:
            temp = root.right
            root.right = root.left
            root.left = temp
            self.invertTree(root.left)
            self.invertTree(root.right)
        return root
    
#Method-3

# DFS w/ Recursion
# dfs
# dfs with recursion

class Solution:
    def invertTree(self, root: Optional[TreeNode]) -> Optional[TreeNode]:
        def dfs(node):
            # No node? Tree is empty or we must have reached a leaf. If leaf, begin unwinding implicit stack created in memory so we can check rest of other nodes.
            if not node:
                return
            
            # swap nodes to complete inversion
            node.left, node.right = dfs(node.right), dfs(node.left)
            
            # return root
            return node
        
        return dfs(root)

#Method-4

# recursive


class Solution:
    # @param {TreeNode} root
    # @return {TreeNode}
    def invertTree(self, root):
        if root != None:
            temp=root.left
            root.left=self.invertTree(root.right)
            root.right=self.invertTree(temp)
        return root

#Method-5

class Solution:
    def invertTree(self, root):
        if not root:
            return
        root.left, root.right = self.invertTree(root.right), self.invertTree(root.left)
        return root



#Q3. Subtree of Another Tree

'''


Given the roots of two binary trees root and subRoot, return true if there is a subtree of root with the same structure and node values of subRoot and false otherwise.

A subtree of a binary tree tree is a tree that consists of a node in tree and all of this node's descendants. The tree tree could also be considered as a subtree of itself.

 

Example 1:


Input: root = [3,4,5,1,2], subRoot = [4,1,2]
Output: true
Example 2:


Input: root = [3,4,5,1,2,null,null,null,null,0], subRoot = [4,1,2]
Output: false
 

Constraints:

The number of nodes in the root tree is in the range [1, 2000].
The number of nodes in the subRoot tree is in the range [1, 1000].
-104 <= root.val <= 104
-104 <= subRoot.val <= 104

'''
#Solution


# Definition for a binary tree node.
# class TreeNode:
#     def __init__(self, val=0, left=None, right=None):
#         self.val = val
#         self.left = left
#         self.right = right

#Method-1

class Solution:
    def isSubtree(self, root: Optional[TreeNode], subRoot: Optional[TreeNode]) -> bool:
        if not root and not subRoot:
            return True
        # to create a result array of tree
        def bfs(root,arr):
            q=deque([root])
            while q:
                for i in range(len(q)):
                    x=q.popleft()
                    if x!=None:
                        arr.append(x.val)
                        if x.left:
                            q.append(x.left)
                        else:
                            q.append(None)
                        if x.right:
                            q.append(x.right)
                        else:
                            q.append(None)
                    else:
                        arr.append(None)
            return arr
        # create array for subRoot tree
        subRoottree=bfs(subRoot,[])
        # bfs for main tree 
        # intiate a queue to hold nodes
        q=deque([root])
        # while loop to continue iteration till last node
        while q:
            # for loop to iterate every level
            for i in range(len(q)):
                x=q.popleft()
                # check if nodes value matches subroot tree root value
                if x.val==subRoot.val:
                    # if matches make result array from that node
                    subtree=bfs(x,[])
                    if subtree==subRoottree:
                        return True
                if x.left:
                    q.append(x.left)
                if x.right:
                    q.append(x.right)
                    
        return False
    
#Method-2

# Recursive

class Solution:
    def isSame(self, root1, root2) -> bool:
        if not root1 or not root2:
            return root1 == root2
        else:
            return root1.val == root2.val and self.isSame(root1.left, root2.left) and self.isSame(root1.right, root2.right)
			
    def isSubtree(self, root: Optional[TreeNode], subRoot: Optional[TreeNode]) -> bool:
        if root:
            if self.isSame(root, subRoot):
                return True
            else:
                return self.isSubtree(root.left, subRoot) or self.isSubtree(root.right, subRoot)
        else:
            return False
        

#Method-3
# Definition for a binary tree node.
# class TreeNode:
#     def __init__(self, val=0, left=None, right=None):
#         self.val = val
#         self.left = left
#         self.right = right
class Solution:
    def isSubtree(self,s: TreeNode,t: TreeNode) -> bool:
        if not t: return True
        if not s: return False
        
 # If both of the trees are same return true       
        if self.sameTree(s,t):
            return True
        
# Checking if t is the left subtree of s OR t is the right subtree of s        
        return(self.isSubtree(s.left,t)or
              self.isSubtree(s.right, t))
    
# Helper func sameTree 
    def sameTree(self, s,t):
        
#If both empty return True
        if not s and not t:
            return True
        
##If both of them are not empty
        if s and t and s.val== t.val:
            return (self.sameTree(s.left, t.left)and
                    self.sameTree(s.right, t.right))
# If neither of this condition works that means one of the tree is empty hence return False
        return False


#Method-4

# binary tree

# Recursive + Iterative || Time: O(NM) Space: O(M)

# Definition for a binary tree node.
# class TreeNode:
#     def __init__(self, val=0, left=None, right=None):
#         self.val = val
#         self.left = left
#         self.right = right

class Solution:
    def isSubtree(self, root: Optional[TreeNode], subRoot: Optional[TreeNode]) -> bool:
        def isSameTree(t1, t2):
            # if both t1 and t2 are null, it's a match
            if not t1 and not t2:
                return True
            # if only 1 of t1 and t2 is null, they are not the same
            if not t1 or not t2:
                return False
            # if value is not equal, they are not the same
            if t1.val != t2.val:
                return False
            # if t1 and t2 has the same value, check if their children's matches too
            else:
                return isSameTree(t1.left, t2.left) and isSameTree(t1.right, t2.right)
        
        # if both subRoot and root is null, all the node is matched already
        if not subRoot and not root:
            return True
        # if only 1 of subRoot or root is null, does not match
        if not subRoot or not root:
            return False
        # if value of current node match, we check if the sub childrens are exactly the same
        if root.val == subRoot.val:
            if (isSameTree(root.left, subRoot.left) and isSameTree(root.right, subRoot.right)):
                return True
        # if subRoot is not the current node, try to march subRoot in left or right children
        return self.isSubtree(root.left, subRoot) or self.isSubtree(root.right, subRoot)
        

#Method-4  

# Iterative Solution with similar logics:

# m = height of first tree, n = height of the second tree
# Time complexity is O(mn), becuae in the worst case for every child if the root tree, we are going to compare all node in subRoot to that node.
# Space complexity is O(m), because maximum size of the queue (for iterative solution) and maximum height of the recursive stack (for recursive solution) is equal to the height of root tree.


# Definition for a binary tree node.
# class TreeNode:
#     def __init__(self, val=0, left=None, right=None):
#         self.val = val
#         self.left = left
#         self.right = right

class Solution:
    def isSubtree(self, root: Optional[TreeNode], subRoot: Optional[TreeNode]) -> bool:
        
        def isSameTree(t1, t2):
            q = []
            q.append((t1, t2))
            
            while q:
                currT1, currT2 = q.pop()
                if not currT1 and not currT2:
                    continue
                if not currT1 or not currT2:
                    return False
                if currT1.val != currT2.val:
                    return False
                q.append((currT1.left, currT2.left))
                q.append((currT1.right, currT2.right))
            
            return True
        
        
        
        q = []
        q.append((root, subRoot))
        
        while q:
            currRoot, currSubRoot = q.pop()
            
            if not currRoot and not currSubRoot:
                return True
            elif not currRoot or not currSubRoot:
                continue
            elif currRoot.val == currSubRoot.val:
                if isSameTree(currRoot.left, currSubRoot.left) and isSameTree(currRoot.right, currSubRoot.right):
                    return True
            
            q.append((currRoot.left, currSubRoot))
            q.append((currRoot.right, currSubRoot))
        
        return False
    
#Q4. Range Sum of BST

'''
Given the root node of a binary search tree and two integers low and high, return the sum of values of all nodes with a value in the inclusive range [low, high].

 

Example 1:


Input: root = [10,5,15,3,7,null,18], low = 7, high = 15
Output: 32
Explanation: Nodes 7, 10, and 15 are in the range [7, 15]. 7 + 10 + 15 = 32.
Example 2:


Input: root = [10,5,15,3,7,13,18,1,null,6], low = 6, high = 10
Output: 23
Explanation: Nodes 6, 7, and 10 are in the range [6, 10]. 6 + 7 + 10 = 23.
 

Constraints:

The number of nodes in the tree is in the range [1, 2 * 104].
1 <= Node.val <= 105
1 <= low <= high <= 105
All Node.val are unique.

'''
#Solution

# Definition for a binary tree node.
# class TreeNode:
#     def __init__(self, val=0, left=None, right=None):
#         self.val = val
#         self.left = left
#         self.right = right

# binary-tree
#Method-1


class Solution:
	ans = 0
	def rangeSumBST(self, root: Optional[TreeNode], low: int, high: int) -> int:

		if root.val >= low and root.val <= high:
			self.ans += root.val

		if root.left:
			root.left = self.rangeSumBST(root.left, low, high)
		if root.right:
			root.right = self.rangeSumBST(root.right, low, high) 

		return self.ans
    
#Method-2
#DFS
# Time Complexity: O(N), where NN is the number of nodes in the tree.
# Space Complexity: O(N)

class Solution:
    def rangeSumBST(self, root: Optional[TreeNode], low: int, high: int) -> int:
        ans = 0
        stack = [root]
        while stack:
            node = stack.pop()
            if node:
                if low <= node.val <= high:
                    ans += node.val
                if low < node.val:
                    stack.append(node.left)
                if node.val < high:
                    stack.append(node.right)
        return ans
    
#Method-3

# bottom up recursive solution:

class Solution:
    def rangeSumBST(self, root, L, R):
        if not root:
            return 0;

        if R < root.val:
            return self.rangeSumBST(root.left, L, R)
        elif L > root.val:
            return self.rangeSumBST(root.right, L, R)
        else:
            return self.rangeSumBST(root.left, L, R) + root.val + self.rangeSumBST(root.right, L, R)
        
#Method-4
# Tree Traversal

class Solution:
    def rangeSumBST(self, root, L, R):
        """
        :type root: TreeNode
        :type L: int
        :type R: int
        :rtype: int
         """
        if root is None:
            return 
        q=[root]
        s=[]
        while len(q)>0:
            for node in q:
                if node.val>=min(L,R) and node.val<=max(L,R):
                    s.append(node.val)
            next_q =[]
            for node in q:
                if node.left is not None:
                    next_q.append(node.left)
                if node.right is not None:
                    next_q.append(node.right)
            q= next_q
        return sum(s)

#Method-5
# DFS any order

class Solution:
    def rangeSumBST(self, root, L, R):
        res = []
        self.inorder(root, res, L, R)
        return sum(res)

    def inorder(self, root, res, L, R):
        cur = root
        if not cur:
            return None
        self.inorder(cur.left, res, L, R)
        if L <= cur.val <= R:
            res.append(cur.val)
        self.inorder(cur.right, res, L, R)  


 #Q5.. Symmetric Tree

'''
Given the root of a binary tree, check whether it is a mirror of itself (i.e., symmetric around its center).

 

Example 1:


Input: root = [1,2,2,3,4,4,3]
Output: true
Example 2:


Input: root = [1,2,2,null,3,null,3]
Output: false
 

Constraints:

The number of nodes in the tree is in the range [1, 1000].
-100 <= Node.val <= 100  
'''
#Solution

# Definition for a binary tree node.
# class TreeNode:
#     def __init__(self, val=0, left=None, right=None):
#         self.val = val
#         self.left = left
#         self.right = right

# class Solution:
#     def isSymmetric(self, root: Optional[TreeNode]) -> bool:
        
    
# Method-1
# bfs
# A simple BFS solution using deque. A 101 (out of constaint set) is used as a marker to present null.

class Solution:
    def isSymmetric(self, root: Optional[TreeNode]) -> bool:
        
        q = collections.deque()
        q.append(root)
        while q:
            levelNode = []
            for i in range(len(q)):
                node = q.popleft()
                if node:
                    levelNode.append(node.val)
                    q.append(node.left)
                    q.append(node.right)
                else:
                    levelNode.append(101)
            if levelNode:
                if levelNode != levelNode[::-1]:
                    return False
        return True


# Method-2

# Iterative approach
# iteration
# deque
# default-dict

# Definition for a binary tree node.
# class TreeNode:
#     def __init__(self, val=0, left=None, right=None):
#         self.val = val
#         self.left = left
#         self.right = right

from collections import deque, defaultdict
class Solution:
    def isSymmetric(self, root: Optional[TreeNode]) -> bool:
        left = defaultdict(deque)
        right = defaultdict(deque)
        queue = deque([(root, 0, False)])
        while queue:
            nt = queue.popleft()
            if nt[2]:
                right[nt[1]].appendleft(nt[0].val if nt[0] else None)
            else:
                left[nt[1]].append(nt[0].val if nt[0] else None)
            if nt[0] is not None:
                queue.append((nt[0].left, nt[1] + 1, nt[2]))
                queue.append((nt[0].right, nt[1] + 1, nt[2] if nt[1] > 0 else True))
        for level in left:
            if level != 0:
                if left[level] != right[level]:
                    return False
        return True

# Method-3

# Definition for a binary tree node.
# class TreeNode:
#     def __init__(self, val=0, left=None, right=None):
#         self.val = val
#         self.left = left
#         self.right = right

class Solution:
    def isSymmetric(self, root: Optional[TreeNode]) -> bool:
        
        def _isSymmetric(root1, root2):
            
            if not root1 and not root2:
                return True
            if not root1:
                return False
            if not root2:
                return False
            if root1 and root2:
                if root1.val != root2.val:
                    return False
                return _isSymmetric(root1.left, root2.right) and _isSymmetric(root1.right, root2.left)
        
        if root:
            return _isSymmetric(root.left, root.right)
        return False
    
    
# Method-4

# Recursive Approach 

# recursive

# We can recurse over the left and right side and check if the values are not matching or one of them is None to get a False

class Solution:
    def isSymmetric(self, root: Optional[TreeNode]) -> bool:
        def helper(p, q):
            if not p and not q:
                return True
            if None in [p, q]:
                return False
            if p.val != q.val:
                return False
            return helper(p.left, q.right) and helper(p.right, q.left)
        return helper(root, root)

    
#Method-5

# BSF solution 

# Definition for a binary tree node.
# class TreeNode:
#     def __init__(self, val=0, left=None, right=None):
#         self.val = val
#         self.left = left
#         self.right = right

import collections
class Solution:
    def isSymmetric(self, root: Optional[TreeNode]) -> bool:
        queue = collections.deque()
        queue.append([root, 0, 0])
        idx_dict = collections.defaultdict(list)
        if root is None:
            return True
        while queue:
            node, row_index, col_index = queue.popleft()
            if node is None:
                continue
            idx_dict[row_index].append([col_index, node.val])
            queue.append([node.left, row_index+1, col_index-1])
            queue.append([node.right, row_index+1, col_index+1])
        for row in idx_dict:
            if row != 0 and len(idx_dict[row]) % 2 == 1:
                return False
            left = 0
            right = len(idx_dict[row]) - 1
            while left < right:
                left_item = idx_dict[row][left]
                right_item = idx_dict[row][right]
                if left_item[0] + right_item[0] == 0 and left_item[1] == right_item[1]:
                    pass
                else:
                    return False
                left += 1
                right -= 1
        return True
        
#Q6. Convert Sorted Array to Binary Search Tree

'''

Given an integer array nums where the elements are sorted in ascending order, convert it to a height-balanced binary search tree.

A height-balanced binary tree is a binary tree in which the depth of the two subtrees of every node never differs by more than one.

 

Example 1:


Input: nums = [-10,-3,0,5,9]
Output: [0,-3,9,-10,null,5]
Explanation: [0,-10,5,null,-3,null,9] is also accepted:

Example 2:


Input: nums = [1,3]
Output: [3,1]
Explanation: [1,null,3] and [3,1] are both height-balanced BSTs.
 

Constraints:

1 <= nums.length <= 104
-104 <= nums[i] <= 104
nums is sorted in a strictly increasing order.

'''
#Solution

# Definition for a binary tree node.
# class TreeNode:
#     def __init__(self, val=0, left=None, right=None):
#         self.val = val
#         self.left = left
#         self.right = right


# class Solution:
#     def sortedArrayToBST(self, nums: List[int]) -> Optional[TreeNode]:



#Method-1

# Recursion
# Time Complexity: O(n log n)
# Space Complexity: O(n)

# Since nums is a sorted list, the middle element nums[len(nums)//2] must be the root node of nums.
# Thus, after setting the middle element be the root, finding the middle element in the left subarry nums[:len(nums)//2] and right subarry nums[len(nums)//2 + 1 : ]

# For example, nums = [0, 1, 2, 3, 4, 5, 6, 7]



class Solution:
    def sortedArrayToBST(self, nums: List[int]) -> Optional[TreeNode]:
        total_nums = len(nums)
        if not total_nums:
            return None

        mid_node = total_nums // 2
        return TreeNode(
            nums[mid_node], 
            self.sortedArrayToBST(nums[:mid_node]), self.sortedArrayToBST(nums[mid_node + 1 :]))

#Method-2

# recursion
# Definition for a binary tree node.
# class TreeNode:
#     def __init__(self, val=0, left=None, right=None):
#         self.val = val
#         self.left = left
#         self.right = right

class Solution:
    def sortedArrayToBST(self, nums: List[int]) -> Optional[TreeNode]:
        
        def helper(l,r):
            if l>r:
                return None
            mid = (l+r)//2
            root = TreeNode(nums[mid])

            root.left = helper(l,mid-1)
            root.right = helper(mid+1,r)

            return root
        return helper(0, len(nums)-1)

#Method-3
# recursive 
class Solution(object):
    def sortedArrayToBST(self, nums):
        """
        :type nums: List[int]
        :rtype: TreeNode
        """
        n=len(nums)
        if not nums:
            return None
        mid=n//2
        root=TreeNode(nums[mid])
        root.left=self.sortedArrayToBST(nums[:mid])
        root.right=self.sortedArrayToBST(nums[mid+1:])
        return root

#Method-4

class Solution(object):
    def sortedArrayToBST(self, nums):
        """
        :type nums: List[int]
        :rtype: TreeNode
        """
        if not nums:
            return None
        root = self.dfs(nums, 0, len(nums) - 1)
        return root

    def dfs(self, nums, start, end):
        if start > end:
            return None
        if start == end:
            return TreeNode(nums[start])
        mid = start + (end - start) // 2
        root = TreeNode(nums[mid])
        root.left = self.dfs(nums, start, mid - 1)
        root.right = self.dfs(nums, mid + 1, end)
        return root
    
#Method-5

# Basic idea is to use divide and conquer approch .
# Middle element of the list will be the root and left side of the middle will be left sub tree and right side will the right sub tree
# recursion
# divid and conquer

class Solution:
    def sortedArrayToBST(self, nums: List[int]) -> Optional[TreeNode]:
        
        # Helper function to perform divide and conquer approch
        def divideAndConquer(left,right):
            
            # if the left poistion is gerater than the right just return None
            if left > right : return None
            
            # if left is equal to right the only one element is left so just convert into a node and return
            if left == right: return TreeNode(nums[left])
            
            # find the mid of the list 
            mid = (left + right) // 2
            
            # call the funtion recursivle on left to mid - 1 element and mid + 1 to right element of the list
            left = divideAndConquer(left,mid - 1)
            right = divideAndConquer(mid + 1,right)
            
            # middle not will be the root and left list will be left and right list will be right
            return TreeNode(nums[mid],left,right)
        
        # call the recursive funtion
        return divideAndConquer(0,len(nums) - 1)


#Q7.  Merge Two Binary Trees

'''
You are given two binary trees root1 and root2.

Imagine that when you put one of them to cover the other, some nodes of the two trees are overlapped while the others are not. You need to merge the two trees into a new binary tree. The merge rule is that if two nodes overlap, then sum node values up as the new value of the merged node. Otherwise, the NOT null node will be used as the node of the new tree.

Return the merged tree.

Note: The merging process must start from the root nodes of both trees.

 

Example 1:


Input: root1 = [1,3,2,5], root2 = [2,1,3,null,4,null,7]
Output: [3,4,5,5,4,null,7]
Example 2:

Input: root1 = [1], root2 = [1,2]
Output: [2,2]
 

Constraints:

The number of nodes in both trees is in the range [0, 2000].
-104 <= Node.val <= 104

'''
#Solution

# Definition for a binary tree node.
# class TreeNode:
#     def __init__(self, val=0, left=None, right=None):
#         self.val = val
#         self.left = left
#         self.right = right

# class Solution:
#     def mergeTrees(self, root1: Optional[TreeNode], root2: Optional[TreeNode]) -> Optional[TreeNode]:
        
#Methgod-1

# Definition for a binary tree node.
# class TreeNode:
#     def __init__(self, val=0, left=None, right=None):
#         self.val = val
#         self.left = left
#         self.right = right

class Solution:
    def mergeTrees(self, root1: Optional[TreeNode], root2: Optional[TreeNode]) -> Optional[TreeNode]:
        
        if root1 == None:
            return root2
        if root2 == None:
            return root1
        root1.val += root2.val
        root1.left = self.mergeTrees(root1.left, root2.left)
        root1.right = self.mergeTrees(root1.right, root2.right)
        return root1
    
#Methgod-2
# Definition for a binary tree node.
# class TreeNode(object):
#     def __init__(self, x):
#         self.val = x
#         self.left = None
#         self.right = None

class Solution(object):
    def mergeTrees(self, t1, t2):
        """
        :type t1: TreeNode
        :type t2: TreeNode
        :rtype: TreeNode
        """
        # initial filter for inputs to make sure they're Tree Nodes with values 
        if not t1: 
            return t2
        if not t2: 
            return t1 

        # initializing a tree node to store the merged tree 
        t = TreeNode(0)
        t.left = TreeNode(1)
        t.right = TreeNode(1)
        
        # initializing a stack 
        dfs= []
        dfs.append(t1)
        dfs.append(t2)
        dfs.append(t)  
       
        # will merge while the stack has items to merge 
        while dfs: 
            
            t_node = dfs.pop()
            t2_node = dfs.pop()
            t1_node = dfs.pop()
          
            # need to make sure the items appended are valid; otherwise 
            if t1_node and t2_node and t_node: 

                sumup = t1_node.val + t2_node.val
                t_node.val = sumup 

                if not t1_node.left: 
                    t_node.left = t2_node.left
                elif not t2_node.left and t1_node.left: 
                    t_node.left = t1_node.left
                else: 
                    dfs.append(t1_node.left)
                    dfs.append(t2_node.left)
                    if not t_node.left: 
                        t_node.left = TreeNode(0)
                    dfs.append(t_node.left)
                    
                    
                if not t1_node.right: 
                    t_node.right = t2_node.right 
                elif not t2_node.right and t1_node.right: 
                    t_node.right = t1_node.right
                else: 
                    dfs.append(t1_node.right)
                    dfs.append(t2_node.right)

                    # not super confident about this... I feel like this isn't a good method
                    if not t_node.right: 
                        t_node.right = TreeNode(0)
                    dfs.append(t_node.right)
        
        return t 
    
#Methgod-3

# Definition for a binary tree node.
# class TreeNode(object):
#     def __init__(self, x):
#         self.val = x
#         self.left = None
#         self.right = None

class Solution(object):
    def mergeTrees(self, t1, t2):
        """
        :type t1: TreeNode
        :type t2: TreeNode
        :rtype: TreeNode
        """
        
        # 100 pass -95% runtime and 100% space
        # Recursive function to traverse the trees
        def traverse(node1, node2):
            
            # When both the nodes are present, change value to their sum
            if node1 and node2:
                node1.val = node1.val+node2.val
            
            # If both left are present recurse, else if node2 only present then replace node1 as node2
            if node1.left and node2.left:
                traverse(node1.left, node2.left)
            elif node2.left:
                node1.left = node2.left
            
            # If both right are present recurse, else if node2 only present then replace node1 as node2
            if node1.right and node2.right:
                traverse(node1.right, node2.right)
            elif node2.right:
                node1.right = node2.right
        
        # Null check for root node of both tree
        if not t1:
            return t2
        if not t2:
            return t1
        
        # Recursive call
        traverse(t1, t2)
        
        # Return the root of the first tree
        return t1
    
#Methgod-4
# recursive solution.

class Solution(object):
    def mergeTrees(self, t1, t2):
        if t1 and t2:
            root = TreeNode(t1.val + t2.val)
            root.left = self.mergeTrees(t1.left, t2.left)
            root.right = self.mergeTrees(t1.right, t2.right)
            return root
        elif t1:
            return t1
        else:
            return t2

#Methgod-5
# not in place

class Solution(object):
    def mergeTrees(self, root1, root2):
        """
        :type root1: TreeNode
        :type root2: TreeNode
        :rtype: TreeNode
        """
        
        if root1 and root2:
            return TreeNode(root1.val + root2.val, self.mergeTrees(root1.left, root2.left), self.mergeTrees(root1.right, root2.right))
        elif root1:
            return TreeNode(root1.val, self.mergeTrees(root1.left, None), self.mergeTrees(root1.right, None))
        elif root2:
            return TreeNode(root2.val, self.mergeTrees(None, root2.left), self.mergeTrees(None, root2.right))
        else:
            return None



#Q8.Maximum Depth of Binary Tree


'''

Given the root of a binary tree, return its maximum depth.

A binary tree's maximum depth is the number of nodes along the longest path from the root node down to the farthest leaf node.

 

Example 1:


Input: root = [3,9,20,null,null,15,7]
Output: 3
Example 2:

Input: root = [1,null,2]
Output: 2
 

Constraints:

The number of nodes in the tree is in the range [0, 104].
-100 <= Node.val <= 100

'''
#Solution

# Definition for a binary tree node.
# class TreeNode:
#     def __init__(self, val=0, left=None, right=None):
#         self.val = val
#         self.left = left
#         self.right = right

# class Solution:
#     def maxDepth(self, root: Optional[TreeNode]) -> int:
        
        
        
        
# RECURSIVE DFS 



# To calculate the maximum depth we can use the Depth-First Search. We call a helper function recursively and return the maximum depth between left and right branches.

# Time: O(N) - for DFS
# Space: O(N) - for the recursive stack

# Runtime: 40 ms, faster than 89.54% of Python3 online submissions for Maximum Depth of Binary Tree.
# Memory Usage: 16.3 MB, less than 18.15% of Python3 online submissions for Maximum Depth of Binary Tree.


#Method-1
# dfs

class Solution:
    def maxDepth(self, root: Optional[TreeNode]) -> int:
        def dfs(root, depth):
            if not root: return depth
            return max(dfs(root.left, depth + 1), dfs(root.right, depth + 1))
                       
        return dfs(root, 0)



#Method-2

class Solution:
    def maxDepth(self, root: TreeNode) -> int:
        if not root: return 0
        queue = [(root, 1)]
        self.res = 0
    
        while queue:
            root, nums = queue.pop(0)
            if not root.left and not root.right:
                self.res = max(self.res, nums)
            
            if root.left:
                queue.append((root.left, nums + 1))
            
            if root.right:
                queue.append((root.right, nums + 1))
            
        return self.res
     
#Method-3

class Solution:
    def maxDepth(self, root: Optional[TreeNode]) -> int:
        if not root:
            return 0
        return max(self.maxDepth(root.left), self.maxDepth(root.right)) + 1
    
    
#Method-4

# iterative solution using stack
# The idea is to store node and its level in a pair and put the pair to stack

# Definition for a binary tree node.
# class TreeNode:
#     def __init__(self, x):
#         self.val = x
#         self.left = None
#         self.right = None

class Solution:
    # @param {TreeNode} root
    # @return {integer}
    def maxDepth(self, root):
        maxDepth, stack = 0, [(root, 1)]
        while stack:
            node, level = stack.pop()
            if node:
                # update maxDepth
                maxDepth = max(maxDepth, level)
                # push left and right child onto stack
                stack.append((node.left, level+1))
                stack.append((node.right, level+1))
        return maxDepth
    
    
#Method-5    
class Solution(object):
    def maxDepth(self, root):
        stack = [[root,1]]
        max_dep = 0
        while stack:
            node, dep = stack.pop() 
            if node:
                max_dep = max(max_dep, dep)
                stack.append([node.left,dep+1])
                stack.append([node.right, dep+1])
        return max_dep


#Q9. Binary Tree Paths

'''
Given the root of a binary tree, return all root-to-leaf paths in any order.

A leaf is a node with no children.

 

Example 1:


Input: root = [1,2,3,null,5]
Output: ["1->2->5","1->3"]
Example 2:

Input: root = [1]
Output: ["1"]
 

Constraints:

The number of nodes in the tree is in the range [1, 100].
-100 <= Node.val <= 100
'''
#Solution

# Definition for a binary tree node.
# class TreeNode:
#     def __init__(self, val=0, left=None, right=None):
#         self.val = val
#         self.left = left
#         self.right = right

# class Solution:
#     def binaryTreePaths(self, root: Optional[TreeNode]) -> List[str]:
        
    
# Method-1

class Solution:
    res = []
    def make_paths(self, root , ans):
        if root == None:
            return
        if root.left == None and root.right == None:
            ans += str(root.val)
            #print(ans)
            self.res.append(ans)
        ans += str(root.val)
        ans += "->"
        self.make_paths(root.left , ans)
        self.make_paths(root.right , ans)
        
    def binaryTreePaths(self, root: Optional[TreeNode]) -> List[str]:
        self.res.clear()
        self.make_paths(root , "")
        #print(self.res)
        #self.res.clear()
        return self.res
    
# Method-2

class Solution:
    def binaryTreePaths(self, root: Optional[TreeNode]) -> List[str]:
        if not root: return []
        if root.left is None and root.right is None:
            return [ str(root.val) ]
        lpaths = [ 
            str(root.val) + "->" + path for path in self.binaryTreePaths(root.left) ]
        rpaths = [ 
            str(root.val) + "->" + path for path in self.binaryTreePaths(root.right) ] 
    
        return lpaths + rpaths

# Method-3

# PreOrder traversal O(n)  solution


# Definition for a binary tree node.
# class TreeNode:
#     def __init__(self, x):
#         self.val = x
#         self.left = None
#         self.right = None

class Solution:
    def binaryTreePaths(self, root):
        """
        :type root: TreeNode
        :rtype: List[str]
        """
        l =list() 
        def preorder(root, path, list_):
            if not root:
                return
            if not path:
                path = "{}".format(root.val)
            else:
                path += ("->{}".format(root.val))
            if not root.left and not root.right:
                list_.append(path)
            preorder(root.left, path, list_)
            preorder(root.right,path, list_)
        preorder(root, "", l)
        return l
    
# Method-4

# Definition for a binary tree node.
# class TreeNode(object):
#     def __init__(self, x):
#         self.val = x
#         self.left = None
#         self.right = None

class Solution(object):
    def binaryTreePaths(self, root):
        """
        :type root: TreeNode
        :rtype: List[str]
        """
        paths=[]
        def dfs(current_node,path):
            
            if not current_node:
                return []
            if not current_node.left and not current_node.right:
                path=path+[current_node.val]
                paths.append("->".join(map(str,path)))
                return
            
            path=path+[current_node.val]
            dfs(current_node.left,path)
            dfs(current_node.right, path)

        dfs(root,paths)
        return paths

    
#Method-5

# DFS & BackTracking | 
# dfs approach
# back tracking

# Definition for a binary tree node.
# class TreeNode:
#     def __init__(self, val=0, left=None, right=None):
#         self.val = val
#         self.left = left
#         self.right = right

class Solution:
    def binaryTreePaths(self, root: Optional[TreeNode]) -> List[str]:
        
        ans = []
        
        def bt(cur=root, path=[]):
            if not cur.left and not cur.right:
                path.append(str(cur.val))
                ans.append('->'.join(path.copy()))
                return
            
            path.append(str(cur.val))

            if cur.left:
                bt(cur.left, path)
                path.pop()
            
            if cur.right:
                bt(cur.right, path)
                path.pop()
                
        def dfs(cur=root, path=[]):
            if not cur.left and not cur.right:
                path.append(str(cur.val))
                ans.append('->'.join(path.copy()))
                return

            if cur.left:
                bt(cur.left, path+[str(cur.val)])
            
            if cur.right:
                bt(cur.right, path+[str(cur.val)])
        bt()
        return ans

 #Q10.Same Tree

'''
Given the roots of two binary trees p and q, write a function to check if they are the same or not.

Two binary trees are considered the same if they are structurally identical, and the nodes have the same value.

 

Example 1:


Input: p = [1,2,3], q = [1,2,3]
Output: true
Example 2:


Input: p = [1,2], q = [1,null,2]
Output: false
Example 3:


Input: p = [1,2,1], q = [1,1,2]
Output: false
 

Constraints:

The number of nodes in both trees is in the range [0, 100].
-104 <= Node.val <= 104

'''

#Solution

# Definition for a binary tree node.
# class TreeNode:
#     def __init__(self, val=0, left=None, right=None):
#         self.val = val
#         self.left = left
#         self.right = right

# class Solution:
#     def isSameTree(self, p: Optional[TreeNode], q: Optional[TreeNode]) -> bool:
        
        
# Method-1       
# Recursion

# The simplest strategy here is to use recursion. Check if p and q nodes are not None, and their values are equal. If all checks are OK, do the same for the child nodes recursively.


# Time complexity : O(N)O(N), where N is a number of nodes in the tree, since one visits each node exactly once.

# Space complexity : O(N)O(N) in the worst case of completely unbalanced tree, to keep a recursion stack.

class Solution:
    def isSameTree(self, p, q):
        """
        :type p: TreeNode
        :type q: TreeNode
        :rtype: bool
        """    
        # p and q are both None
        if not p and not q:
            return True
        # one of p and q is None
        if not q or not p:
            return False
        if p.val != q.val:
            return False
        return self.isSameTree(p.right, q.right) and \
               self.isSameTree(p.left, q.left)
    
# Method-2

# Iteration


# Start from the root and then at each iteration pop the current node out of the deque. Then do the same checks as in the approach 1 :

# p and p are not None,

# p.val is equal to q.val,

# and if checks are OK, push the child nodes.

# Time complexity : O(N)O(N) since each node is visited exactly once.

# Space complexity : O(N)O(N) in the worst case, where the tree is a perfect fully balanced binary tree, since BFS will have to store at least an entire level of the tree in the queue, and the last level has O(N)O(N) nodes.


from collections import deque
class Solution:
    def isSameTree(self, p, q):
        """
        :type p: TreeNode
        :type q: TreeNode
        :rtype: bool
        """    
        def check(p, q):
            # if both are None
            if not p and not q:
                return True
            # one of p and q is None
            if not q or not p:
                return False
            if p.val != q.val:
                return False
            return True
        
        deq = deque([(p, q),])
        while deq:
            p, q = deq.popleft()
            if not check(p, q):
                return False
            
            if p:
                deq.append((p.left, q.left))
                deq.append((p.right, q.right))
                    
        return True
    
# Method-3

# use a queue in the iterative implementation. In fact the two solutions are the same except that we use the call stack in one and make our own stack in the other.

class Solution:

    def isSameTree(self, p, q):
        stack = [(p, q)]
        while stack:
            (p, q) = stack.pop()
            if p and q and p.val == q.val:
                stack.extend([
                    (p.left,  q.left),
                    (p.right, q.right)
                ])
            elif p or q:
                return False
        return True
    
# Method-4

class Solution:
    def isSameTree(self, p: TreeNode, q: TreeNode) -> bool:
        queue = deque()
        queue.append((p, q))
        
        while queue:
            p, q = queue.popleft()
            
            if not p and not q:
                continue
            if not p or not q or p.val != q.val:
                return False
            
            queue.append((p.left, q.left))
            queue.append((p.right, q.right))
        
        return True
    
# Method-5

# Traverse both together, Return True if Reach both ends with Equal Values at Each Iteration


# Definition for a binary tree node.
# class TreeNode:
#     def __init__(self, val=0, left=None, right=None):
#         self.val = val
#         self.left = left
#         self.right = right

class Solution:
    def isSameTree(self, p: Optional[TreeNode], q: Optional[TreeNode]) -> bool:
        # If both reach the end equally, they are equal
        if p == q == None:
            return True
        # If one reaches the end before the other, they are not equal
        if p == None or q == None:
            return False
        # They are equal as long as the current values are equal 
        # and the traversal of its left+rights in tandem are also equal
        if p.val == q.val and self.isSameTree(p.left, q.left) and self.isSameTree(p.right, q.right):
            return True


#Q11.  Lowest Common Ancestor of a Binary Search Tree

'''
Given a binary search tree (BST), find the lowest common ancestor (LCA) node of two given nodes in the BST.

According to the definition of LCA on Wikipedia: “The lowest common ancestor is defined between two nodes p and q as the lowest node in T that has both p and q as descendants (where we allow a node to be a descendant of itself).”

 

Example 1:


Input: root = [6,2,8,0,4,7,9,null,null,3,5], p = 2, q = 8
Output: 6
Explanation: The LCA of nodes 2 and 8 is 6.
Example 2:


Input: root = [6,2,8,0,4,7,9,null,null,3,5], p = 2, q = 4
Output: 2
Explanation: The LCA of nodes 2 and 4 is 2, since a node can be a descendant of itself according to the LCA definition.
Example 3:

Input: root = [2,1], p = 2, q = 1
Output: 2
 

Constraints:

The number of nodes in the tree is in the range [2, 105].
-109 <= Node.val <= 109
All Node.val are unique.
p != q
p and q will exist in the BST.

'''
#Solution

# Definition for a binary tree node.
# class TreeNode:
#     def __init__(self, x):
#         self.val = x
#         self.left = None
#         self.right = None

# class Solution:
#     def lowestCommonAncestor(self, root: 'TreeNode', p: 'TreeNode', q: 'TreeNode') -> 'TreeNode':
        
    
# Method-1
# Recusrion


class Solution:
    def lowestCommonAncestor(self, root: 'TreeNode', p: 'TreeNode', q: 'TreeNode') -> 'TreeNode':
        if max(p.val, q.val) < root.val:
            return self.lowestCommonAncestor(root.left, p, q)
        elif min(p.val, q.val) > root.val:
            return self.lowestCommonAncestor(root.right, p, q)
        return root
    
# Method-2

# recursion

class Solution:
    def lowestCommonAncestor(self, root: 'TreeNode', p: 'TreeNode', q: 'TreeNode') -> 'TreeNode':
            temp1 = max(p.val,q.val)
            temp2 = min(p.val,q.val)
            if ((temp2<=root.val) and (temp1>=root.val)):
                return root
            elif(temp1 < root.val):
                return self.lowestCommonAncestor(root.left,p,q)
            else:
                return self.lowestCommonAncestor(root.right,p,q)

# Method-3

# binary-tree

# dfs

# Definition for a binary tree node.
# class TreeNode:
#     def __init__(self, x):
#         self.val = x
#         self.left = None
#         self.right = None

class Solution:
    def lowestCommonAncestor(self, root: 'TreeNode', p: 'TreeNode', q: 'TreeNode') -> 'TreeNode':
        min_val, max_val = min(p.val,q.val), max(p.val,q.val)
        
        while True:
            if min_val<= root.val <= max_val:
                return root
            elif max_val<root.val:
                root = root.left
            else:
                root = root.right
                
        
        
# Method-4

# Time: O(n)
# recursion

# The current node is the answer:

# if p lie in left subtree and q lie in right subtree
# or if p lie in right subtree and q lie in left subtree
# I also check "equal to" in case either of p or q is equal to current node value (since a node can be a descendant of itself)

# If both p and q lie in left subtree, we recursively check if left node is the solution
# If both p and q lie in right subtree, we recursively check if right node is the solution



class Solution:
    def lowestCommonAncestor(
        self, root: "TreeNode", p: "TreeNode", q: "TreeNode") -> "TreeNode":

        if (root.val >= p.val and root.val <= q.val) or (
            root.val <= p.val and root.val >= q.val
        ):
            return root

        # if both p, q lie in left subtree
        if root.val > p.val and root.val > q.val:
            return self.lowestCommonAncestor(root.left, p, q)

        # if both p, q lie in right subtree
        if root.val < p.val and root.val < q.val:
            return self.lowestCommonAncestor(root.right, p, q)

        
# Method-5

# This solution only works when p and q are in the tree, and for this problem, it seems that's the case.

class Solution(object):
    def lowestCommonAncestor(self, root, p, q):
        """
        :type root: TreeNode
        :type p: TreeNode
        :type q: TreeNode
        :rtype: TreeNode
        """
        if not root:
            return None
        if p==root or q==root:
            return root
        if p.val>q.val:
            p,q=q,p
        if p.val<root.val and q.val>root.val:
            return root
        if p.val>root.val:
            return self.lowestCommonAncestor(root.right, p, q)
        return self.lowestCommonAncestor(root.left, p, q)


#Q12.Path Sum

'''

Given the root of a binary tree and an integer targetSum, return true if the tree has a root-to-leaf path such that adding up all the values along the path equals targetSum.

A leaf is a node with no children.

 

Example 1:


Input: root = [5,4,8,11,null,13,4,7,2,null,null,null,1], targetSum = 22
Output: true
Explanation: The root-to-leaf path with the target sum is shown.
Example 2:


Input: root = [1,2,3], targetSum = 5
Output: false
Explanation: There two root-to-leaf paths in the tree:
(1 --> 2): The sum is 3.
(1 --> 3): The sum is 4.
There is no root-to-leaf path with sum = 5.
Example 3:

Input: root = [], targetSum = 0
Output: false
Explanation: Since the tree is empty, there are no root-to-leaf paths.
 

Constraints:

The number of nodes in the tree is in the range [0, 5000].
-1000 <= Node.val <= 1000
-1000 <= targetSum <= 1000

'''
#Solution

# Definition for a binary tree node.
# class TreeNode:
#     def __init__(self, val=0, left=None, right=None):
#         self.val = val
#         self.left = left
#         self.right = right

# class Solution:
#     def hasPathSum(self, root: Optional[TreeNode], targetSum: int) -> bool:
        
        
        
#Method-1

# Definition for a binary tree node.
# class TreeNode:
#     def __init__(self, val=0, left=None, right=None):
#         self.val = val
#         self.left = left
#         self.right = right

class Solution:
    def hasPathSum(self, root: Optional[TreeNode], targetSum: int) -> bool:
        
        if root:
            targetSum -= root.val
            if targetSum == 0 and root.left is None and root.right is None:
                return True
            return self.hasPathSum(root.left, targetSum) or self.hasPathSum(root.right, targetSum)
        
        
#Method-2

# Definition for a  binary tree node
# class TreeNode:
#     def __init__(self, x):
#         self.val = x
#         self.left = None
#         self.right = None

class Solution:
    # @param root, a tree node
    # @param sum, an integer
    # @return a boolean
    def hasPathSum(self, root, sum):
        if root==None:
            return False
        if root.left==None and root.right==None and root.val==sum:
            return True
        if root.left!=None:
            if self.hasPathSum(root.left,sum-root.val)==True:
                return True
        if root.right!=None:
            if self.hasPathSum(root.right,sum-root.val)==True:
                return True
        return False

    
#Method-3

# preorder traversal

# The idea is to do preorder traversal and maintain the sum value from root to current node, if at any time the sum is zero and the current node is a leaf node, we have found a path where the node values sum to given sum.

class Solution(object):

    __slots__ = 'res'
    
    def __init__(self):
        self.res = False
        
    def hasPathSum(self, r, s):
        """
        :type root: TreeNode
        :type sum: int
        :rtype: bool
        """
        def preOrder(root, sum):
            if root:
                root.val = sum-root.val
                sum = root.val
                # print(root.val, sum)
                if sum == 0 and root.left is None and root.right is None:
                    # print('FOUND PATH WITH SUM:', s)
                    self.res = True
                preOrder(root.left, sum)
                preOrder(root.right, sum)
        preOrder(r, s)
        return self.res

    
#Method-4

# Using DFS


class Solution:
    def hasPathSum(self, root: Optional[TreeNode], targetSum: int) -> bool:
        def sumUtil(node: Optional[TreeNode], sum_: int) -> bool:
            if not node:
                return False
            elif not node.left and not node.right and node.val + sum_ == targetSum:
                return True
            else:
                res = False
                if node.left:
                    res = res or sumUtil(node.left, sum_ + node.val)
                if node.right:
                    res = res or sumUtil(node.right, sum_ + node.val)
                return res
            
        return sumUtil(root, 0)

    
#Method-5


# recursion

# Definition for a binary tree node.
# class TreeNode:
#     def __init__(self, val=0, left=None, right=None):
#         self.val = val
#         self.left = left
#         self.right = right

class Solution:
    def hasPathSum(self, root: Optional[TreeNode], targetSum: int) -> bool:
	
        #We perform a preorder traversal and subtract root.val from TargetSum
        def preorder(root,  current):
            if root == None:
                return
            current = current - root.val
            
            if root.left == None and root.right == None:
                return current == 0
                
            return preorder(root.left, current) or preorder(root.right, current)
             
        return preorder(root, targetSum)


#Q13. Minimum Absolute Difference in BST

''''

Given the root of a Binary Search Tree (BST), return the minimum absolute difference between the values of any two different nodes in the tree.

 

Example 1:


Input: root = [4,2,6,1,3]
Output: 1
Example 2:


Input: root = [1,0,48,null,null,12,49]
Output: 1
 

Constraints:

The number of nodes in the tree is in the range [2, 104].
0 <= Node.val <= 105

'''
#Solution

# Definition for a binary tree node.
# class TreeNode:
#     def __init__(self, val=0, left=None, right=None):
#         self.val = val
#         self.left = left
#         self.right = right

# class Solution:
#     def sumOfLeftLeaves(self, root: Optional[TreeNode]) -> int:
        
    
#Method-1
# level order traveral

class Solution:
    def sumOfLeftLeaves(self, root: Optional[TreeNode]) -> int:
        st = [root]
        ans = 0
        while st:
            a = st.pop(0)
            if a.left:
                b = a.left
                st.append(a.left)
                if b.left==None and b.right==None:
                    print(a.left.val)
                    ans+=a.left.val
            if a.right:
                st.append(a.right)
        return ans

    
#Method-2

# DFS recursive one liner and iterative solution
# DFS with Recursion


class Solution:
    def sumOfLeftLeaves(self, root: Optional[TreeNode], isl=False) -> int:
            
        return 0 if not root else (root.val if not root.left and not root.right and isl else self.sumOfLeftLeaves(root.left, True) + self.sumOfLeftLeaves(root.right, False))
    

    
    
    
#Method-3

# iterative
# dfs
# recursion
# recursive
# dfs-using-stack
# dfs with recursion

# DFS with iteration using stack

class Solution:
    def sumOfLeftLeaves(self, root: Optional[TreeNode]) -> int:
        if not root: return 0
        
        summ=0
        
        q = [(root, False)]
        
        while q:
            
            node, is_left = q.pop()
            
            if is_left and not node.left and not node.right:
                summ = summ + node.val
            
            q.append((node.left, True)) if node.left else None
            q.append((node.right,False)) if node.right else None
            
        return summ
    
#Method-4

# dfs iterative solution 

# Definition for a binary tree node.
# class TreeNode(object):
#     def __init__(self, x):
#         self.val = x
#         self.left = None
#         self.right = None

class Solution(object):
    def sumOfLeftLeaves(self, root):
        """
        :type root: TreeNode
        :rtype: int
        """
        if not root:
            return 0
        stack ,res = [root] , 0
        while stack:
            node = stack.pop()
            if node.left and not node.left.left and not node.left.right:
                res += (node.left.val)
            if node.left:
                stack += [node.left]
            if node.right:
                stack += [node.right]
        return res

#Method-5

# Definition for a binary tree node.
# class TreeNode:
#     def __init__(self, val=0, left=None, right=None):
#         self.val = val
#         self.left = left
#         self.right = right
class Solution:
    def sumOfLeftLeaves(self, root: Optional[TreeNode]) -> int:
        
        def traversal(root):
            temp = 0
            if root == None:
                return temp
            
            if root.left and root.left.left == None and root.left.right == None:
                temp += root.left.val
            return temp + traversal(root.left) + traversal(root.right)
            
        Sum = traversal(root)
        return Sum


#Q14.  Balanced Binary Tree

'''

Given a binary tree, determine if it is height-balanced.

For this problem, a height-balanced binary tree is defined as:

a binary tree in which the left and right subtrees of every node differ in height by no more than 1.

 

Example 1:


Input: root = [3,9,20,null,null,15,7]
Output: true
Example 2:


Input: root = [1,2,2,3,3,null,null,4,4]
Output: false
Example 3:

Input: root = []
Output: true
 

Constraints:

The number of nodes in the tree is in the range [0, 5000].
-104 <= Node.val <= 104

'''
#Solution

# Definition for a binary tree node.
# class TreeNode:
#     def __init__(self, val=0, left=None, right=None):
#         self.val = val
#         self.left = left
#         self.right = right


# class Solution:
#     def isBalanced(self, root: Optional[TreeNode]) -> bool:



        
# Method-1        
# Recursion | Solution


class Solution:
    def isBalanced(self, root: Optional[TreeNode]) -> bool:
        
        def dfs(root):
            if not root:
                return [True, 0]
            
            left,right = dfs(root.left), dfs(root.right)
            
            balanced = (left[0] and right[0] and
                        abs(left[1] - right[1]) <= 1)
            
            return [balanced, 1+max(left[1], right[1])]
        
        return dfs(root)[0]
    
# Method-2

# DFS Iterative Solution


class Solution:
    def isBalanced(self, root: Optional[TreeNode]) -> bool:          
        if root is None:
            return True
        
        stack = [root]
        d_node = {None:0}
        
        while stack:
            tmp_node = stack[-1]
            if tmp_node.left and tmp_node.left not in d_node:
                stack.append(tmp_node.left)
            elif tmp_node.right and tmp_node.right not in d_node:
                stack.append(tmp_node.right)
            else:
                node = stack.pop(-1)
                h_left = d_node[node.left]
                h_right = d_node[node.right]
                d_node[node] = max(h_left, h_right) + 1
                
                if abs(h_left - h_right) > 1:
                    return False
        return True
    
    
# Method-3

# non-recursive, using post-order tree traversal
# non-recursive
# post-order-traversal
# cal the depth from the leaf to a tree node, judge if it is balanced and store it in each node.

class Solution:
    # @param {TreeNode} root
    # @return {boolean}
    def isBalanced(self, root):
        if root == None: return True
        stack = []
        p = root
        while p != None or len(stack) > 0:
            while p != None:
                    stack.append((0,p))
                    p = p.left
            lr, p = stack.pop()
            if p.right != None:
                if lr == 0:
                    stack.append((1,p))
                    p = p.right
                    continue
                r = p.right.val
            else:
                r = 0
            if p.left == None:
                l = 0
            else:
                l = p.left.val
                
            if (r-l) in range(-1,2):
                p.val = max(r,l)+1
                p = None
            else:
                return False
                
        return True

# Method-4

# Recursive || DFS || O(N)->TC || O(N)->SC because of recursion stack space


class Solution:
	def isBalanced(self, root: Optional[TreeNode]) -> bool:

		def dfs(root):
			if not root:
				return [True, 0]

			var1 = dfs(root.left)
			var2 = dfs(root.right)

			new = (var1[0] and var2[0]) and (abs(var1[1] - var2[1]) < 2)

			return [new, 1 + max(var1[1], var2[1])]

		return dfs(root)[0]
    
    
# Method-5

# Definition for a binary tree node.
# class TreeNode:
#     def __init__(self, val=0, left=None, right=None):
#         self.val = val
#         self.left = left
#         self.right = right
class Solution:
    def isBalanced(self, root: Optional[TreeNode]) -> bool:
        ans = True
        
        def rec(node, height):
            nonlocal ans
            if node is None or not ans:
                return height
            left_height = rec(node.left, height + 1)
            right_height = rec(node.right, height + 1)
            if abs(left_height - right_height) > 1:
                ans = False
            return max(left_height, right_height)
        
        rec(root, 0)
        return ans    
  

#Q15. Binary Tree Inorder Traversal

'''

Given the root of a binary tree, return the inorder traversal of its nodes' values.

 

Example 1:


Input: root = [1,null,2,3]
Output: [1,3,2]
Example 2:

Input: root = []
Output: []
Example 3:

Input: root = [1]
Output: [1]
 

Constraints:

The number of nodes in the tree is in the range [0, 100].
-100 <= Node.val <= 100
 

Follow up: Recursive solution is trivial, could you do it iteratively?

'''
#Solution

# Definition for a binary tree node.
# class TreeNode:
#     def __init__(self, val=0, left=None, right=None):
#         self.val = val
#         self.left = left
#         self.right = right

#Method-1

# Binary Tree Inorder Traversal || Binary Tree || Recursion

class Solution:
    def inorderTraversal(self, root: Optional[TreeNode]) -> List[int]:
        
        if root is None:
            return []
        return self.inorderTraversal(root.left)+ [root.val]+ self.inorderTraversal(root.right)

        
        
#Method-2

class Solution:
    def inorderTraversal(self, root: Optional[TreeNode]) -> List[int]:
        traverse = []
        
        def traverse_tree(root):
            if(root == None):
                return
            
            traverse_tree(root.left)
            traverse.append(root.val)
            traverse_tree(root.right)
            return
        
        traverse_tree(root)
        return traverse
    
    
#Method-3

class Solution:
    """
    Explanation Inorder Traversal
        1. Traverse the left subtree ==> Inorder(left-subtree)
        2. Visit the root. for this problem we store root val in the result list 
        3. Traverse the right subtree ==> Inorder(right-subtree)
        4. return the result list
    """
    def helper(self, root, result):
        
        if root:
            self.helper(root.left, result)
            result.append(root.val)
            self.helper(root.right, result)
        
        return result
    
    def inorderTraversal(self, root: Optional[TreeNode]) -> List[int]:
        return self.helper(root, result=[])
    
#Method-4

class Solution:
    def inorderTraversal(self, root: Optional[TreeNode]) -> List[int]:
        list_of_nodes = []
        def inorder(root, list_of_nodes):
            if root:
                # Left -> Root -> Right
                list_of_nodes = inorder(root.left, list_of_nodes)
                list_of_nodes.append(root.val)
                list_of_nodes = inorder(root.right, list_of_nodes)
            return list_of_nodes
        result = inorder(root, list_of_nodes)
        return result
    
#Method-5

class Solution(object):
    def inorderTraversal(self, root):
        stack = []
        result = []
    
        while stack or root:
            if root:
                stack.append(root)
                root = root.left
            else:
                top = stack.pop()
                result.append(top.val)
                root = top.right
        
        return result


#Q16. Count Good Nodes in Binary Tree

'''

Given a binary tree root, a node X in the tree is named good if in the path from root to X there are no nodes with a value greater than X.

Return the number of good nodes in the binary tree.

 

Example 1:



Input: root = [3,1,4,3,null,1,5]
Output: 4
Explanation: Nodes in blue are good.
Root Node (3) is always a good node.
Node 4 -> (3,4) is the maximum value in the path starting from the root.
Node 5 -> (3,4,5) is the maximum value in the path
Node 3 -> (3,1,3) is the maximum value in the path.
Example 2:



Input: root = [3,3,null,4,2]
Output: 3
Explanation: Node 2 -> (3, 3, 2) is not good, because "3" is higher than it.
Example 3:

Input: root = [1]
Output: 1
Explanation: Root is considered as good.
 

Constraints:

The number of nodes in the binary tree is in the range [1, 10^5].
Each node's value is between [-10^4, 10^4].


'''
#Solution

# Definition for a binary tree node.
# class TreeNode:
#     def __init__(self, val=0, left=None, right=None):
#         self.val = val
#         self.left = left
#         self.right = right


# class Solution:
#     def goodNodes(self, root: TreeNode) -> int:
        
#Method-1 

class Solution:
    def goodNodes(self, root: TreeNode) -> int:
        
        def traverse(node, val):
            if node is None: return 0
            ans = 0
            if val is None or node.val >= val:
                ans += 1
                val = node.val
            
            return ans + traverse(node.left, val) + traverse(node.right, val)
        
        return traverse(root, None)
    
#Method-2

# The idea is simple, in the recursive function at each call we check if the new root.val is the bigges in the route from the original root.
# Then we call to Rec again with root.left and root.right if they exsist with the new(or not) max_val.

# Definition for a binary tree node.
# class TreeNode:
#     def __init__(self, val=0, left=None, right=None):
#         self.val = val
#         self.left = left
#         self.right = right


class Solution:
    def goodNodes(self, root: TreeNode) -> int:
        max_val = root.val
        ans = 1
        ans += self.Rec(root.left, max_val)
        ans += self.Rec(root.right, max_val)
        return ans
    
    def Rec(self, root: TreeNode, max_val: int) -> int:
        if not root:
            return 0
        ans = 1 if root.val >= max_val else 0
        max_val = max(max_val, root.val)
		
        if root.left:
            ans += self.Rec(root.left, max_val)
            
        if root.right:
            ans += self.Rec(root.right, max_val)
        
        return ans
    
#Method-3

# DFS, Clean O(N) 

class Solution:
    def goodNodes(self, root: TreeNode) -> int:
        def dfs(node, maxpval):
            if not node:
                return 0
            #If we encounter a new highest value, then we must have a 'good' path, so we update our new highest value and recur. Else, we keep the current highest value and traverse
            if node.val >= maxpval: 
                maxpval = node.val 
                return dfs(node.left, maxpval) + dfs(node.right, maxpval) + 1
            else:
                return dfs(node.left, maxpval) + dfs(node.right, maxpval) + 0
            

        return dfs(root, root.val)
    
#Method-4

# Traverse all binary tree using DFS, and we care the maximum value of the path
# When we find value is same or greater than maximum value, increase count and update maximum value
# After DFS, return count value

# Definition for a binary tree node.
# class TreeNode(object):
#     def __init__(self, val=0, left=None, right=None):
#         self.val = val
#         self.left = left
#         self.right = right

class Solution(object):
    def goodNodes(self, root):
        """
        :type root: TreeNode
        :rtype: int
        """
        self.count = 0
        
        def dfs(node, maximum):
            if not node:
                return
            if node.val >= maximum:
                self.count += 1
                maximum = max(node.val, maximum)
            dfs(node.left, maximum)
            dfs(node.right, maximum)
        
        dfs(root, root.val)
        return self.count
    
    
#Method-5

class Solution:
    def goodNodes(self, root: TreeNode) -> int:
        self.result = 0
        
        def DFS(node, curr_max):
            if node:
                if node.val >= curr_max:
                    self.result += 1
                
                curr_max = max(curr_max, node.val)
                
                DFS(node.left, curr_max)
                DFS(node.right, curr_max)
        
        DFS(root, root.val)
        
        return self.result

#Q17. Lowest Common Ancestor of a Binary Tree

'''
Given a binary tree, find the lowest common ancestor (LCA) of two given nodes in the tree.

According to the definition of LCA on Wikipedia: “The lowest common ancestor is defined between two nodes p and q as the lowest node in T that has both p and q as descendants (where we allow a node to be a descendant of itself).”

 

Example 1:


Input: root = [3,5,1,6,2,0,8,null,null,7,4], p = 5, q = 1
Output: 3
Explanation: The LCA of nodes 5 and 1 is 3.
Example 2:


Input: root = [3,5,1,6,2,0,8,null,null,7,4], p = 5, q = 4
Output: 5
Explanation: The LCA of nodes 5 and 4 is 5, since a node can be a descendant of itself according to the LCA definition.
Example 3:

Input: root = [1,2], p = 1, q = 2
Output: 1
 

Constraints:

The number of nodes in the tree is in the range [2, 105].
-109 <= Node.val <= 109
All Node.val are unique.
p != q
p and q will exist in the tree.
'''
#Solution

# Definition for a binary tree node.
# class TreeNode:
#     def __init__(self, x):
#         self.val = x
#         self.left = None
#         self.right = None

# class Solution:
#     def lowestCommonAncestor(self, root: 'TreeNode', p: 'TreeNode', q: 'TreeNode') -> 'TreeNode':
        
# Method-1        
# Recursive Approach
# 1 --> 2 --> 4 --> 8
# BACKTRACK 8 --> 4
# 4 --> 9 (ONE NODE FOUND, return True)
# BACKTRACK 9 --> 4 --> 2
# 2 --> 5 --> 10
# BACKTRACK 10 --> 5
# 5 --> 11 (ANOTHER NODE FOUND, return True)
# BACKTRACK 11 --> 5 --> 2

# 2 is the node where we have left = True and right = True and hence it is the lowest common ancestor.

class Solution:

    def __init__(self):
        # Variable to store LCA node.
        self.ans = None

    def lowestCommonAncestor(self, root, p, q):
        """
        :type root: TreeNode
        :type p: TreeNode
        :type q: TreeNode
        :rtype: TreeNode
        """
        def recurse_tree(current_node):

            # If reached the end of a branch, return False.
            if not current_node:
                return False

            # Left Recursion
            left = recurse_tree(current_node.left)

            # Right Recursion
            right = recurse_tree(current_node.right)

            # If the current node is one of p or q
            mid = current_node == p or current_node == q

            # If any two of the three flags left, right or mid become True.
            if mid + left + right >= 2:
                self.ans = current_node

            # Return True if either of the three bool values is True.
            return mid or left or right

        # Traverse the tree
        recurse_tree(root)
        return self.ans
    
# Method-2 

# Iterative using parent pointers


# If we have parent pointers for each node we can traverse back from p and q to get their ancestors. The first common node we get during this traversal would be the LCA node. We can save the parent pointers in a dictionary as we traverse the tree.

# Algorithm

# Start from the root node and traverse the tree.
# Until we find p and q both, keep storing the parent pointers in a dictionary.
# Once we have found both p and q, we get all the ancestors for p using the parent dictionary and add to a set called ancestors.
# Similarly, we traverse through ancestors for node q. If the ancestor is present in the ancestors set for p, this means this is the first ancestor common between p and q (while traversing upwards) and hence this is the LCA node

class Solution:

    def lowestCommonAncestor(self, root, p, q):
        """
        :type root: TreeNode
        :type p: TreeNode
        :type q: TreeNode
        :rtype: TreeNode
        """

        # Stack for tree traversal
        stack = [root]

        # Dictionary for parent pointers
        parent = {root: None}

        # Iterate until we find both the nodes p and q
        while p not in parent or q not in parent:

            node = stack.pop()

            # While traversing the tree, keep saving the parent pointers.
            if node.left:
                parent[node.left] = node
                stack.append(node.left)
            if node.right:
                parent[node.right] = node
                stack.append(node.right)

        # Ancestors set() for node p.
        ancestors = set()

        # Process all ancestors for node p using parent pointers.
        while p:
            ancestors.add(p)
            p = parent[p]

        # The first ancestor of q which appears in
        # p's ancestor set() is their lowest common ancestor.
        while q not in ancestors:
            q = parent[q]
        return q
    
#Method-3
class Solution(object):
    def lowestCommonAncestor(self, root, p, q):
        if root is None:
            return None
        
        left_res = self.lowestCommonAncestor(root.left, p, q)
        right_res = self.lowestCommonAncestor(root.right, p, q)
        
        if (left_res and right_res) or (root in [p, q]):
            return root
        else:
            return left_res or right_res

#Method-4
# Backtracking


class Solution:
    def lowestCommonAncestor(self, root: 'TreeNode', p: 'TreeNode', q: 'TreeNode') -> 'TreeNode':
        p_ances = self.get_ances(root, p, [])
        q_ances = self.get_ances(root, q, [])
        n = min(len(p_ances), len(q_ances))
        lca = None
        for i in range(n):
            if p_ances[i] == q_ances[i]:
                lca = p_ances[i]
            else:
                break
        return lca
        
    def get_ances(self, root, node, ances):
        if root == node:
            ances.append(node)
            return ances
        
        for child in [root.left, root.right]:
            if child:
                ances.append(root)
                result = self.get_ances(child, node, ances)
                if result:
                    return result
                ances.remove(root)
                
                
#Method-5                
class Solution:
    def lowestCommonAncestor(self, root: 'TreeNode', p: 'TreeNode', q: 'TreeNode') -> 'TreeNode':
        self.res = 0
		
        def dfs(cur) :
            if not cur :
                return False            
            left = dfs(cur.left)
            right = dfs(cur.right)            
            if cur == p or cur == q :
                r =  True
            else :
                r = False                
            if (left and right) or (r and left) or (r and right):
                self.res = cur
                return         
            return left or right or r        
        dfs(root)
        
        return self.res


#Q18.Binary Tree Right Side View

'''

Given the root of a binary tree, imagine yourself standing on the right side of it, return the values of the nodes you can see ordered from top to bottom.

 

Example 1:


Input: root = [1,2,3,null,5,null,4]
Output: [1,3,4]
Example 2:

Input: root = [1,null,3]
Output: [1,3]
Example 3:

Input: root = []
Output: []
 

Constraints:

The number of nodes in the tree is in the range [0, 100].
-100 <= Node.val <= 100

'''
#Solution

# Definition for a binary tree node.
# class TreeNode:
#     def __init__(self, val=0, left=None, right=None):
#         self.val = val
#         self.left = left
#         self.right = right

# class Solution:
#     def rightSideView(self, root: Optional[TreeNode]) -> List[int]:
 
# Method-1

# binary-tree

# level order    
    
class Solution:
    def rightSideView(self, root: Optional[TreeNode]) -> List[int]:
        if root is None:
            return []

        resultant = []

        storageQueue = deque()

        storageQueue.append(root)

        while len(storageQueue) > 0:
            size = len(storageQueue)

            for index in range(size):
                node = storageQueue.popleft()
				
				# Take the last element of the level for right view
				# The first element of every level will be considered as left view
                if index == size - 1:
                    resultant.append(node.val)

                if node.left:
                    storageQueue.append(node.left)
                if node.right:
                    storageQueue.append(node.right)

        return resultant
    
    
# Method-2

# Deque


class Solution(object):
    def rightSideView(self, root):
        res = []
        if not root:
            return None
        
        que = collections.deque([root])
        
        while que:
            size = len(que)
            for i in range(size):
                cur = que.popleft()
                if i == size - 1:
                    res.append(cur.val)
                if cur.left:
                    que.append(cur.left)
                if cur.right:
                    que.append(cur.right)

        return res
    
# Method-3

# HASHMAP || BFS
# hashmap
# python
# bfs
# dfs

class Solution:
    def rightSideView(self, root: Optional[TreeNode]) -> List[int]:
        
        res = []
        hmap = defaultdict(list)
        
        def dfs(node, level):
            
            if not node:
                return
            
            hmap[level].append(node.val)
            
            for ch in (node.left, node.right):
                dfs(ch, level+1)
        
        dfs(root, 0)
        
        for lvl, lst in sorted(hmap.items()):
            res.append(lst[-1])
        
        return res



#Q19.All Nodes Distance K in Binary Tree
'''

Given the root of a binary tree, the value of a target node target, and an integer k, return an array of the values of all nodes that have a distance k from the target node.

You can return the answer in any order.

 

Example 1:


Input: root = [3,5,1,6,2,0,8,null,null,7,4], target = 5, k = 2
Output: [7,4,1]
Explanation: The nodes that are a distance 2 from the target node (with value 5) have values 7, 4, and 1.
Example 2:

Input: root = [1], target = 1, k = 3
Output: []
 

Constraints:

The number of nodes in the tree is in the range [1, 500].
0 <= Node.val <= 500
All the values Node.val are unique.
target is the value of one of the nodes in the tree.
0 <= k <= 1000

'''
#Solution

# Definition for a binary tree node.
# class TreeNode:
#     def __init__(self, x):
#         self.val = x
#         self.left = None
#         self.right = None

# class Solution:
#     def distanceK(self, root: TreeNode, target: TreeNode, k: int) -> List[int]:

# Method-1
# Annotate Parent


# If we know the parent of every node x, we know all nodes that are distance 1 from x. We can then perform a breadth first search from the target node to find the answer.

# Algorithm

# We first do a depth first search where we annotate every node with information about it's parent.

# After, we do a breadth first search to find all nodes a distance K from the target.

# Time Complexity: O(N)O(N), where NN is the number of nodes in the given tree.

# Space Complexity: O(N)O(N).

class Solution(object):
    def distanceK(self, root, target, K):
        def dfs(node, par = None):
            if node:
                node.par = par
                dfs(node.left, node)
                dfs(node.right, node)

        dfs(root)

        queue = collections.deque([(target, 0)])
        seen = {target}
        while queue:
            if queue[0][1] == K:
                return [node.val for node, d in queue]
            node, d = queue.popleft()
            for nei in (node.left, node.right, node.par):
                if nei and nei not in seen:
                    seen.add(nei)
                    queue.append((nei, d+1))

        return []
    
    
# Method-2

#  Percolate Distance

# From root, say the target node is at depth 3 in the left branch. It means that any nodes that are distance K - 3 in the right branch should be added to the answer.

# Algorithm

# Traverse every node with a depth first search dfs. We'll add all nodes x to the answer such that node is the node on the path from x to target that is closest to the root.

# To help us, dfs(node) will return the distance from node to the target. Then, there are 4 cases:

# If node == target, then we should add nodes that are distance K in the subtree rooted at target.

# If target is in the left branch of node, say at distance L+1, then we should look for nodes that are distance K - L - 1 in the right branch.

# If target is in the right branch of node, the algorithm proceeds similarly.

# If target isn't in either branch of node, then we stop.

# In the above algorithm, we make use of the auxillary function subtree_add(node, dist) which adds the nodes in the subtree rooted at node that are distance K - dist from the given node.

# Time Complexity: O(N)O(N), where NN is the number of nodes in the given tree.

# Space Complexity: O(N)O(N).


class Solution(object):
    def distanceK(self, root, target, K):
        ans = []

        # Return distance from node to target if exists, else -1
        # Vertex distance: the # of vertices on the path from node to target
        def dfs(node):
            if not node:
                return -1
            elif node is target:
                subtree_add(node, 0)
                return 1
            else:
                L, R = dfs(node.left), dfs(node.right)
                if L != -1:
                    if L == K: ans.append(node.val)
                    subtree_add(node.right, L + 1)
                    return L + 1
                elif R != -1:
                    if R == K: ans.append(node.val)
                    subtree_add(node.left, R + 1)
                    return R + 1
                else:
                    return -1

        # Add all nodes 'K - dist' from the node to answer.
        def subtree_add(node, dist):
            if not node:
                return
            elif dist == K:
                ans.append(node.val)
            else:
                subtree_add(node.left, dist + 1)
                subtree_add(node.right, dist + 1)

        dfs(root)
        return ans


    
# Method-3

from collections import deque

class Solution(object):
    def distanceK(self, root, target, K):
        """
        :type root: TreeNode
        :type target: TreeNode
        :type K: int
        :rtype: List[int]
        """
        parents = {}
        def dfs(this, parent):
            parents[this] = parent
            if this.left:
                dfs(this.left, this)
            if this.right:
                dfs(this.right, this)
        dfs(root, None)
        
        q = deque([(target, 0)])
        seen = {target}
        while q:
            this, dist = q.popleft()
            if dist == K:
                return [this.val] + [node.val for node, d in q]
            for node in (this.left, this.right, parents[this]):
                if node and node not in seen:
                    seen.add(node)
                    q.append((node, dist+1))
        return []
    
    
# Method-4
#DFS

# Definition for a binary tree node.
# class TreeNode:
#     def __init__(self, x):
#         self.val = x
#         self.left = None
#         self.right = None

class Solution:
    def distanceK(self, root: TreeNode, target: TreeNode, k: int) -> List[int]:
        # bfs 
        graph = defaultdict(set)
        stack = [root]
        while stack:
            node = stack.pop()
            if node.right:
                graph[node].add(node.right)
                graph[node.right].add(node)
                stack.append(node.right)
            if node.left:
                graph[node].add(node.left)
                graph[node.left].add(node)
                stack.append(node.left)
                
        queue = deque([(target, None)])
        while queue:
            if k == 0:
                return [n[0].val for n in queue]
            lens = len(queue)
            i = 0
            while i < lens:
                node, parent = queue.pop()
                for nei in graph[node]:
                    if nei != parent:
                        queue.appendleft((nei, node))
                i += 1
            k -= 1
                                
        return []
    

# Method-5    
# DFS + BFS Solution


class Solution:
    def distanceK(self, root: TreeNode, target: TreeNode, k: int) -> List[int]:
        
        # DFS to make the adj List
        adjList = defaultdict(list)
        def dfs(node):
            if not node:
                return
            
            if node.left:
                adjList[node].append(node.left)
                adjList[node.left].append(node)
            
            if node.right:
                adjList[node].append(node.right)
                adjList[node.right].append(node)
            dfs(node.left)
            dfs(node.right)
        
        dfs(root)
        
        # bfs to find the nodes with k distance
        
        q = deque([(target, 0)])
        visit = set()
        visit.add(target)
        res = []
        while q:
            for i in range(len(q)):
                node, dist = q.popleft()

                if dist == k:
                    res.append(node.val)
                
                if dist > k:
                    break
                for nei in adjList[node]:
                    if nei not in visit:
                        visit.add(nei)
                        q.append((nei, dist + 1))
        return res
   

#Q20.Validate Binary Search Tree

'''

Given the root of a binary tree, determine if it is a valid binary search tree (BST).

A valid BST is defined as follows:

The left subtree of a node contains only nodes with keys less than the node's key.
The right subtree of a node contains only nodes with keys greater than the node's key.
Both the left and right subtrees must also be binary search trees.
 

Example 1:


Input: root = [2,1,3]
Output: true
Example 2:


Input: root = [5,1,4,null,null,3,6]
Output: false
Explanation: The root node's value is 5 but its right child's value is 4.
 

Constraints:

The number of nodes in the tree is in the range [1, 104].
-231 <= Node.val <= 231 - 1
'''
#Solution

# Definition for a binary tree node.
# class TreeNode:
#     def __init__(self, val=0, left=None, right=None):
#         self.val = val
#         self.left = left
#         self.right = right


# class Solution:
#     def isValidBST(self, root: Optional[TreeNode]) -> bool:
        
# Method-1

class Solution:
    def isValidBST(self, root: TreeNode) -> bool:
        def valid(node, left, right):
            if not node:
                return True
            if not (node.val < right and node.val > left):
                return False

            return valid(node.left, left, node.val) and valid(
                node.right, node.val, right
            )

        return valid(root, float("-inf"), float("inf"))    
    
# Method-2

class Solution:
    def isValidBST(self, root: Optional[TreeNode]) -> bool:
        
        def valid(node, l=float("-inf"), r=float("inf")):
            if node is None: return True
            if l < node.val < r:
                return valid(node.left, l, node.val) and valid(node.right, node.val, r)
            return False
        
        return valid(root)
    
# Method-3

# Iterative with queue and borders


class Solution:
    def isValidBST(self, root: Optional[TreeNode]) -> bool:
        queue = [[root, [-10**31-1,10**31+1]]]
        while queue:
            node, borders = queue.pop()
            if not borders[0] < node.val < borders[1]:
                return False
            if node.left:
                queue.append([node.left,[borders[0], node.val] ])
            if node.right:
                queue.append([node.right,[node.val, borders[1]] ])
        return True

# Method-4

class Solution:
    def isValidBST(self, root: Optional[TreeNode]) -> bool:
        
        def dsf(root,minx,maxx):
            if(root==None):
                return True
            if(root.val<=minx or root.val>=maxx):
                return False
            return dsf(root.left,minx,root.val) and dsf(root.right,root.val,maxx)
            
        return dsf(root,-2**31-1,2**31)
    
    
# Method-5
# inorder traversal


# Definition for a  binary tree node
# class TreeNode:
#     def __init__(self, x):
#         self.val = x
#         self.left = None
#         self.right = None

class Solution:
    # @param root, a tree node
    # @return a boolean
    # 7:38
    def isValidBST(self, root):
        output = []
        self.inOrder(root, output)
        
        for i in range(1, len(output)):
            if output[i-1] >= output[i]:
                return False

        return True

    def inOrder(self, root, output):
        if root is None:
            return
        
        self.inOrder(root.left, output)
        output.append(root.val)
        self.inOrder(root.right, output)
        
        

# tree
# inorder
# traversal

# Here's a similar solution but with O(1) space, where you only check if the current element is greater than the previous element, and you break out of checking the rest if this is False.


class Solution(object):
    def isValidBST(self, root):
        """
        :type root: TreeNode
        :rtype: bool
        """
        return self.isBSTHelper(root, [])
        
    def isBSTHelper(self, root, prev=[]):
        if not root:
            return True
        if not self.isBSTHelper(root.left, prev):
            return False
        if not prev:
            prev.append(root.val)
        elif root.val <= prev[0]:
            return False
        prev[0] = root.val
        if not self.isBSTHelper(root.right, prev):
            return False
        return True


        
# inorder traversal

class Solution(object):
    def isValidBST(self, root):
        if not root:return True
        stack=[]
        res=[]
        while root or stack:
            if root:
                stack.append(root)
                root=root.left
            else:
                root=stack.pop()
                res.append(root.val)
                root=root.right
        if res==sorted(res) and len(res)==len(set(res)):
            return True
        else:return False

# @lee215 correct my mistake. below version stops traversal and only stores the previous node value not the whole tree

class Solution(object):
    def isValidBST(self, root):
        self.correct = True
        self.prev = float('-inf')
        self.inorder(root)
        return self.correct

    def inorder(self, node):
        if not node or not self.correct:    # return if already found out of order
            return

        self.inorder(node.left)
        if node.val <= self.prev:
            self.correct = False
            return          # halt exploration
        self.prev = node.val
        self.inorder(node.right)

# Solution based on Inorder traversal, no extra array

class Solution:
    def isValidBST(self, root: TreeNode) -> bool:
        
        self.lastelement = float("-inf")
        self.result = True
        def helper(node):
            if not node:
                return
            helper(node.left)
            if node.val <= self.lastelement:
                self.result = False
                return
            else:
                self.lastelement = node.val
            helper(node.right)
         
        helper(root)
        return self.result

# Similar but cleaner in my mind

class Solution(object):
    def isValidBST(self, root):
        """
        :type root: TreeNode
        :rtype: bool
        """
        rst = []
        stack = [(root,False)]
        
        while stack:
            cur = stack.pop()
            if not cur[0]:
                continue
            
            if cur[1]:
                if rst and cur[0].val <= rst[-1]:
                    return False
                rst.append(cur[0].val)
            else:
                stack.append((cur[0].right, False))
                stack.append((cur[0], True))
                stack.append((cur[0].left, False))
                
        return True

# I did almost the same as yours. But my concern is that this solution is quite slow.. Yes, O(n) guaranteed, but do we have chance to "short circuit" as soon as we find the incorrect ordering while doing the inOrder()? I'm just curious why other people getting much better running time than this.


# A bit improved version, return a list from inOrder function:

class Solution:
    def isValidBST(self, root):
        output = self.inOrder(root)
        
        for i in range(1, len(output)):
            if output[i-1] >= output[i]:
                return False

        return True

    def inOrder(self, root):
        if root is None:
            return []
        
        return self.inOrder(root.left) + [root.val] + self.inOrder(root.right)


#Q21. Binary Tree Zigzag Level Order Traversal

'''

Given the root of a binary tree, return the zigzag level order traversal of its nodes' values. (i.e., from left to right, then right to left for the next level and alternate between).

 

Example 1:


Input: root = [3,9,20,null,null,15,7]
Output: [[3],[20,9],[15,7]]
Example 2:

Input: root = [1]
Output: [[1]]
Example 3:

Input: root = []
Output: []
 

Constraints:

The number of nodes in the tree is in the range [0, 2000].
-100 <= Node.val <= 100

'''
#Solution

# Definition for a binary tree node.
# class TreeNode:
#     def __init__(self, val=0, left=None, right=None):
#         self.val = val
#         self.left = left
#         self.right = right

# class Solution:
#     def zigzagLevelOrder(self, root: Optional[TreeNode]) -> List[List[int]]:
        
#Method-1

# Definition for a binary tree node.
# class TreeNode:
#     def __init__(self, val=0, left=None, right=None):
#         self.val = val
#         self.left = left
#         self.right = right
class Solution:
    def zigzagLevelOrder(self, root: Optional[TreeNode]) -> List[List[int]]:
        if not root:
            return
        queue = []
        res = []
        queue.append(root)
        while len(queue) != 0:
            val = []
            for i in queue:
                val.append(i.val)
            res.append(val)
            
            roots = []
            while queue:
                roots.append(queue.pop(0))
                
            for i in roots:
                if i.left:
                    queue.append(i.left)
                if i.right:
                    queue.append(i.right)
        for i in range(len(res)):
            if i % 2 != 0:
                res[i] = res[i][::-1]
        return res
    
#Method-2
# DFS

class Solution:
    def zigzagLevelOrder(self, root: Optional[TreeNode]) -> List[List[int]]:
        result = []

        def dfs(node, level):
            if not node:
                return 
            
            if len(result) == level:
                 result.append([])
            
            if level%2 == 0:
                result[level].append(node.val)
            else:
                result[level].insert(0,node.val)
        
            dfs(node.left, level+1)
            dfs(node.right, level+1) 
        
        dfs(root, 0)
        return result
    
#Method-3

# BFS, using deque to handle the zigzag
# Using append() and appendleft() to handle the zigzag.

from collections import deque
class Solution(object):
    def zigzagLevelOrder(self, root):
        """
        :type root: TreeNode
        :rtype: List[List[int]]
        """
        if not root: return []
        left, level, res = True, 0, []
        queue = deque([(root, level)])
        while queue:
            node, newlevel = queue.popleft()
            if newlevel != level or newlevel == 0:
                res.append(deque([]))
                left = not left
            if left:
                res[newlevel].appendleft(node.val)
            else:
                res[newlevel].append(node.val)
            if node.left: queue.append((node.left, newlevel + 1))
            if node.right: queue.append((node.right, newlevel + 1))
            level = newlevel
        return [list(i) for i in res]


#Method-4
class Solution(object):
    def zigzagLevelOrder(self, root):
        """
        :type root: TreeNode
        :rtype: List[List[int]]
        """
        if not root: return []
        
        ans = []
        
        node = root 
        
        q = collections.deque([node])
        
        order = -1 
        
        while q:
            order = -order
            level = []
            for _ in range(len(q)):
                node = q.popleft()
                
                level.append(node.val)
                
                if node.left:
                    q.append(node.left)
                if node.right:
                    q.append(node.right)
                    
            ans.append(level[::order])
                
        return ans

#Method-5

# level order traversal technique
# bfs

# Definition for a binary tree node.
# class TreeNode:
#     def __init__(self, val=0, left=None, right=None):
#         self.val = val
#         self.left = left
#         self.right = right

class Node:
    def __init__(self,val):
        self.val=val
        self.next=None

class Queue:
    def __init__(self):
        self.head=None
        self.tail=None
        self.size=0
        
    def push(self,val):
        tempNode=Node(val)
        if self.head is None:
            self.head=tempNode
            self.tail=tempNode
            self.size+=1
            return
        self.tail.next=tempNode
        self.tail=tempNode
        self.size+=1
    
    def pop(self):
        if self.head is not None:
            temp=self.head
            self.head=temp.next
            temp.next=None
            self.size-=1
            return temp
        
class Solution:
    def zigzagLevelOrder(self, root: Optional[TreeNode]) -> List[List[int]]:
        #if root is null
        if root is None:
            return root
        
        #using custom Queue Class
        q=Queue()
        q.push(root)
        res=[]
        leftToRight=True #for zig zag traversal
        
        while q.size!=0:
            queueSize=q.size
            row=[None for i in range(queueSize)]
            
            for i in range(queueSize):
                node=q.pop().val
                
                #setting up index 
                if leftToRight:
                    index=i
                else:
                    index=queueSize-1-i
                    
                row[index]=node.val
                
                if node.left:
                    q.push(node.left)
                if node.right:
                    q.push(node.right)
            
            #changing the direction of storing values
            if leftToRight:
                leftToRight=False
            else:
                leftToRight=True
            
            res.append(row)
            
        return res
        
#Q22. Binary Search Tree Iterator

'''
Implement the BSTIterator class that represents an iterator over the in-order traversal of a binary search tree (BST):

BSTIterator(TreeNode root) Initializes an object of the BSTIterator class. The root of the BST is given as part of the constructor. The pointer should be initialized to a non-existent number smaller than any element in the BST.
boolean hasNext() Returns true if there exists a number in the traversal to the right of the pointer, otherwise returns false.
int next() Moves the pointer to the right, then returns the number at the pointer.
Notice that by initializing the pointer to a non-existent smallest number, the first call to next() will return the smallest element in the BST.

You may assume that next() calls will always be valid. That is, there will be at least a next number in the in-order traversal when next() is called.

 

Example 1:


Input
["BSTIterator", "next", "next", "hasNext", "next", "hasNext", "next", "hasNext", "next", "hasNext"]
[[[7, 3, 15, null, null, 9, 20]], [], [], [], [], [], [], [], [], []]
Output
[null, 3, 7, true, 9, true, 15, true, 20, false]

Explanation
BSTIterator bSTIterator = new BSTIterator([7, 3, 15, null, null, 9, 20]);
bSTIterator.next();    // return 3
bSTIterator.next();    // return 7
bSTIterator.hasNext(); // return True
bSTIterator.next();    // return 9
bSTIterator.hasNext(); // return True
bSTIterator.next();    // return 15
bSTIterator.hasNext(); // return True
bSTIterator.next();    // return 20
bSTIterator.hasNext(); // return False
 

Constraints:

The number of nodes in the tree is in the range [1, 105].
0 <= Node.val <= 106
At most 105 calls will be made to hasNext, and next.
 

Follow up:

Could you implement next() and hasNext() to run in average O(1) time and use O(h) memory, where h is the height of the tree?

'''
#Solution


# Definition for a binary tree node.
# class TreeNode:
#     def __init__(self, val=0, left=None, right=None):
#         self.val = val
#         self.left = left
#         self.right = right
# class BSTIterator:

#     def __init__(self, root: Optional[TreeNode]):
        

#     def next(self) -> int:
        

#     def hasNext(self) -> bool:
        


# Your BSTIterator object will be instantiated and called as such:
# obj = BSTIterator(root)
# param_1 = obj.next()
# param_2 = obj.hasNext()


# binary search tree
# recursion
# pointer
# traverse
# inorder-traveral


#Method-1

# Definition for a binary tree node.
# class TreeNode:
#     def __init__(self, val=0, left=None, right=None):
#         self.val = val
#         self.left = left
#         self.right = right
class BSTIterator:

	def __init__(self, root: Optional[TreeNode]):
		self.root = root
		self.store = []
		self.inOrderTraversal(root, self.store)

		self.pointer =0

	def inOrderTraversal(self, root, store):
		if not root:
			return

		self.inOrderTraversal(root.left, store)
		store.append(root.val)
		self.inOrderTraversal(root.right, store)

	def next(self) -> int:
		val = self.store[self.pointer]
		self.pointer +=1
		return val

	def hasNext(self) -> bool:
		if self.pointer < len(self.store):
			return True

		return False

#Method-2

# O(1) time, O(h) space Python sol. Time & Space Complexity 

class BSTIterator:

    def __init__(self, root: Optional[TreeNode]):
        # Space Complexity primarily comes from keeping the stack
        # Since stack only keeps track of the left nodes, the space
        # complexity is O(h) where h is the height of the tree
        self.stack = []
        
        if root:
            self.stack.append(root)

            # Push all the left nodes until hitting a leaf
            while root.left:
                self.stack.append(root.left)
                root = root.left

    # assuming all the call to next() is valid
    # If next does not have right, time is O(1)
    # If next has right, it takes O(h) in the worst case where h is the heigh of the tree.
    def next(self) -> int:
        
        # Popping from stack is O(1) because the API know the size of the stack,
        # so the API can directly index into the last element of the stack (List).
        next = self.stack.pop()
        
        if next.right:
            top = next.right
            self.stack.append(top)
            
            while top.left:
                self.stack.append(top.left)
                top = top.left
        
        return next.val
        
    # Time complexity is O(1) because len(List) in Python is O(1) time.
    def hasNext(self) -> bool:
        return len(self.stack) != 0
    
        

# Your BSTIterator object will be instantiated and called as such:
# obj = BSTIterator(root)
# param_1 = obj.next()
# param_2 = obj.hasNext()


#Method-3

class BSTIterator:

    def __init__(self, root: Optional[TreeNode]):
        self.root=root
        self.stack=[root]
        curr=root.left
        while curr:
            self.stack.append(curr)
            curr=curr.left
    def next(self) -> int:
        temp=self.stack.pop()
        curr=temp.right
        while curr:
            self.stack.append(curr)
            curr=curr.left
        return temp.val
        

    def hasNext(self) -> bool:
        return self.stack
        

#Method-4

# The idea is get the sorted tree nodes, and then the problem turns to check the next smallest int number & check if there are any remaining numbers



class BSTIterator(object):

    def __init__(self, root):
        # get the in order tree node values
        def inorder(root):
            if not root:    return []
            return inorder(root.left) + [root.val] + inorder(root.right)
        
        self.treenodes = inorder(root)
        
        
    def next(self):
        # pop out the current smallest int
        return self.treenodes.pop(0)
        

    def hasNext(self):
        # check if there are remaining int
        return len(self.treenodes) != 0
    
    
#Method-5

# Algorithm

# Use a stack and initialize the stack with a walk along the left-most border.
# next will pop the top of the stack. If the top has a right child, it will push all nodes along the left border of the subtree rooted at the right child.


class BSTIterator(object):
    def __init__(self, root):
        """
        :type root: TreeNode
        """
        self.st = []
        while root:
            self.st.append(root)
            root = root.left
        return
        

    def hasNext(self):
        """
        :rtype: bool
        """
        return len(self.st) > 0
        

    def next(self):
        """
        :rtype: int
        """
        x = self.st.pop()
        y = x.right
        while y:
            self.st.append(y)
            y = y.left
        return x.val
    
#Q23. Binary Tree Level Order Traversal

'''

Given the root of a binary tree, return the level order traversal of its nodes' values. (i.e., from left to right, level by level).

 

Example 1:


Input: root = [3,9,20,null,null,15,7]
Output: [[3],[9,20],[15,7]]
Example 2:

Input: root = [1]
Output: [[1]]
Example 3:

Input: root = []
Output: []
 

Constraints:

The number of nodes in the tree is in the range [0, 2000].
-1000 <= Node.val <= 1000

'''
#Solution 

# Definition for a binary tree node.
# class TreeNode:
#     def __init__(self, val=0, left=None, right=None):
#         self.val = val
#         self.left = left
#         self.right = right

# class Solution:
#     def levelOrder(self, root: Optional[TreeNode]) -> List[List[int]]:
 
    
#Method-1

class Solution:
    def levelOrder(self, root: Optional[TreeNode]) -> List[List[int]]:
        result = []
        que = collections.deque([root])
        if not root:
            return []
        while que:
            level = []
            for i in range(0,len(que)):
                curr = que.popleft()
                level.append(curr.val)
                if curr.left:
                    que.append(curr.left)
                if curr.right:
                    que.append(curr.right)
            result.append(level)
        return result

#Method-2

# Recursive generator | Dfs

# Definition for a binary tree node.
# class TreeNode:
#     def __init__(self, val=0, left=None, right=None):
#         self.val = val
#         self.left = left
#         self.right = right


from collections import defaultdict
class Solution:
    def levelOrder(self, root: Optional[TreeNode]) -> List[List[int]]:
        ans = defaultdict(list)
        
        def rec(node, level):
            if node is None:
                return
            yield node.val, level
            yield from rec(node.left, level + 1)
            yield from rec(node.right, level + 1)
            
        for val, level in rec(root, 0):
            ans[level].append(val)
        return [val for _, val in sorted(ans.items(), key=lambda x: x[0])]
 

#Method-3
class Solution:
    def levelOrder(self, root: Optional[TreeNode]) -> List[List[int]]:
        d=defaultdict(list)
        def solve(root,lev):
            if not root:
                return
            d[lev].append(root.val)
            solve(root.left,lev+1)
            solve(root.right,lev+1)
        solve(root,0)
        ans=[]
        for i in d:
            ans.append(d[i])
        return ans 
    
#Method-4

# BFS Solution:
# Time complexity: O(n) where n is the number of nodes in the tree


class Solution:
    def levelOrder(self, root: Optional[TreeNode]) -> List[List[int]]:

        ans = []
        cur_level, cur_level_nodes = 0, []

		# initialise and add root in queue with level as 0
        q = deque()
        q.append((root, 0))

        while q:
			# get first element from the queue and its resp. level
            node, level = q.popleft()
            if node is None:
                continue

			# if level is same, append nodes value
			# else change level and append nodes value
            if level == cur_level:
                cur_level_nodes.append(node.val)
            else:
                ans.append(cur_level_nodes)
                cur_level = level
                cur_level_nodes = [node.val]

			# add left and right children in queue with level as parent's level + 1
            q.append((node.left, level+1))
            q.append((node.right, level+1))

        if len(cur_level_nodes):
            ans.append(cur_level_nodes)

        return ans

 #Q24. Path Sum III

'''
Given the root of a binary tree and an integer targetSum, return the number of paths where the sum of the values along the path equals targetSum.

The path does not need to start or end at the root or a leaf, but it must go downwards (i.e., traveling only from parent nodes to child nodes).

 

Example 1:


Input: root = [10,5,-3,3,2,null,11,3,-2,null,1], targetSum = 8
Output: 3
Explanation: The paths that sum to 8 are shown.
Example 2:

Input: root = [5,4,8,11,null,13,4,7,2,null,null,5,1], targetSum = 22
Output: 3
 

Constraints:

The number of nodes in the tree is in the range [0, 1000].
-109 <= Node.val <= 109
-1000 <= targetSum <= 1000
'''
#Solution

# Definition for a binary tree node.
# class TreeNode:
#     def __init__(self, val=0, left=None, right=None):
#         self.val = val
#         self.left = left
#         self.right = right


# class Solution:
#     def pathSum(self, root: Optional[TreeNode], targetSum: int) -> int:
        
    
#Method-1 

# backtracking solution with prefix sum
# Definition for a binary tree node.
# class TreeNode:
#     def __init__(self, val=0, left=None, right=None):
#         self.val = val
#         self.left = left
#         self.right = right
class Solution:
    def pathSum(self, root: Optional[TreeNode], targetSum: int) -> int:
        """
        dfs, prefix sum.
        q102, q103.
        """
        self.targetSum = targetSum
        self.d = defaultdict(int)
        self.d[0] = 1
        self.res = 0
        self.dfs(root, 0)
        return self.res

    def dfs(self, node, psum):
        if not node:
            return
        psum += node.val
        header = psum - self.targetSum
        self.res += self.d[header]
        self.d[psum] += 1
        self.dfs(node.left, psum)
        self.dfs(node.right, psum)
        self.d[psum] -= 1  # backtracking.
        
    
#Method-2

# DFS & prefix sum solution


class Solution:
    def pathSum(self, root: Optional[TreeNode], targetSum: int) -> int:
        
        def dfs(node,prevSum,targetSum):
            # when at node, the total sum of previous node.val on the path = prevSum
            count = 0
            if not node:
                return 0
            prevSum += node.val # the value of the current node has also been added
            residual = prevSum - targetSum # residual is the amount to reach targetSum
            count += prefixCount.get(residual,0)
            # update prefixCount
            prefixCount[prevSum] = 1 + prefixCount.get(prevSum,0)
            # left subtree
            count += dfs(node.left,prevSum,targetSum)
            # right subtree
            count += dfs(node.right,prevSum,targetSum)
            # return to the previous node, so the most recent added value will not be in our path
            prefixCount[prevSum] -= 1
            return count
        
        prefixCount = {0:1}
        return dfs(root,0,targetSum)
	
#Method-3

# Self-explanatory Python iterative solution DFS - post-order


class Solution(object):
    def pathSum(self, root, sum):

        prefix_sum_map = {0:1}
        
        node = root
        stack = []
        current_sum = 0
        count = 0
        lastvisited = None
        
        while node or stack:
            if node:
                stack.append(node)
                
                current_sum += node.val
                complement = current_sum - sum
                
                if complement in prefix_sum_map:
                    count += prefix_sum_map[complement]
                    
                if current_sum in prefix_sum_map:
                    prefix_sum_map[current_sum] += 1
                else:
                    prefix_sum_map[current_sum] = 1
                    
                node = node.left
            else:
                peek = stack[-1]
                
                if peek.right and peek.right != lastvisited:
                    node = peek.right
                else:
                    lastvisited = stack.pop()
                    prefix_sum_map[current_sum] -= 1
                    current_sum -= lastvisited.val
                    
        return count
	
#Method-4
# recursive


class Solution:
    def pathSum(self, root: Optional[TreeNode], targetSum: int) -> int:
        def util(node: TreeNode, sum_array) -> int:
            t = [e - node.val for e in sum_array]
            zeroes = t.count(0)
            if node.left is None and node.right is None:
                return zeroes
            ansl, ansr = 0, 0
            if node.left:
                ansl = util(node.left, t + [targetSum])
            if node.right:
                ansr = util(node.right, t + [targetSum])
            return ansl + ansr + zeroes

        return util(root, [targetSum]) if root is not None else 0


#Q25.Construct Binary Tree from Preorder and Postorder Traversal
'''

Given two integer arrays, preorder and postorder where preorder is the preorder traversal of a binary tree of distinct values and postorder is the postorder traversal of the same tree, reconstruct and return the binary tree.

If there exist multiple answers, you can return any of them.

 

Example 1:


Input: preorder = [1,2,4,5,3,6,7], postorder = [4,5,2,6,7,3,1]
Output: [1,2,3,4,5,6,7]
Example 2:

Input: preorder = [1], postorder = [1]
Output: [1]
 

Constraints:

1 <= preorder.length <= 30
1 <= preorder[i] <= preorder.length
All the values of preorder are unique.
postorder.length == preorder.length
1 <= postorder[i] <= postorder.length
All the values of postorder are unique.
It is guaranteed that preorder and postorder are the preorder traversal and postorder traversal of the same binary tree.
'''
#Solution

# Definition for a binary tree node.
# class TreeNode:
#     def __init__(self, val=0, left=None, right=None):
#         self.val = val
#         self.left = left
#         self.right = right

# class Solution:
#     def constructFromPrePost(self, preorder: List[int], postorder: List[int]) -> Optional[TreeNode]:
        
    
# Definition for a binary tree node.
# class TreeNode:
#     def __init__(self, val=0, left=None, right=None):
#         self.val = val
#         self.left = left
#         self.right = right
#Baraa


#Method-1

class Solution:
    def constructFromPrePost(self, preorder: List[int], postorder: List[int]) -> Optional[TreeNode]:
        preorder_index = 0
        postorder_index = {}
        def dfs():
            nonlocal preorder_index
            root_val = preorder[preorder_index]
            root_post_idx = postorder_index[root_val]
            root = TreeNode(root_val)
            #if next value occurs in postorder traversal before current value it means this is a left child
            if preorder_index + 1 < len(preorder) and postorder_index[preorder[preorder_index + 1]] < root_post_idx:
                preorder_index += 1
                root.left = dfs()
                #if next value occurs in postorder traversal before current value it means this is a right child
                if preorder_index + 1 < len(preorder) and postorder_index[preorder[preorder_index + 1]] < root_post_idx:
                    preorder_index += 1
                    root.right = dfs()
            return root
        for idx, c in enumerate(postorder):
            postorder_index[c] = idx
        
        return dfs()
    
    
#Method-2

class Solution:
    def constructFromPrePost(self, preorder: List[int], postorder: List[int]) -> Optional[TreeNode]:
        def findPrePost(preorder, postorder):
            if preorder[1] == postorder[-2]:
                return preorder[1:],postorder[:-1],[],[]
            else:
                for idx in range(len(postorder)-1):
                    if postorder[idx] == preorder[1]:
                        leftPost = postorder[:idx+1]
                        rightPost = postorder[idx+1:-1]        
                for idx in range(1,len(preorder)):
                    if preorder[idx] == postorder[-2]:
                        rightPre = preorder[idx:]
                        leftPre = preorder[1:idx]
                return leftPre,leftPost, rightPre, rightPost
        def helper(node,preorder, postorder,goLeft):
            if len(preorder) == 0:
                return
            if goLeft:
                node.left = TreeNode(preorder[0])
                node = node.left
            else:
                node.right = TreeNode(preorder[0])
                node = node.right
            if len(preorder) == 1:
                return
                
            leftPre,leftPost, rightPre, rightPost = findPrePost(preorder, postorder)
            helper(node,leftPre,leftPost,True)
            helper(node,rightPre, rightPost,False)
                
        root = TreeNode(preorder[-1])
        helper(root,preorder, postorder,True)
        return root.left

#Method-3

class Solution:
    def constructFromPrePost(self, preorder: List[int], postorder: List[int]) -> Optional[TreeNode]:
        def build(preLeft, preRight):
            if preLeft > preRight:
                return None
            
            # food for thought: why do we need this base case?
            if preLeft == preRight:
                root = TreeNode(postorder[self.postIdx])
                self.postIdx -= 1
                return root
            
            rootVal = postorder[self.postIdx]
            root = TreeNode(rootVal)
            self.postIdx -= 1
            
            cutIdx = mp[postorder[self.postIdx]]
            root.right = build(cutIdx, preRight)
            root.left = build(preLeft + 1, cutIdx - 1)
            return root
            
        
        self.postIdx = len(postorder) - 1
        mp = {val : idx for idx, val in enumerate(preorder)}
        return build(0, len(preorder) - 1)
    
#Method-4

# recursive algorithm
# make use of list slicing

class Solution:
    def constructFromPrePost(self, pre: 'List[int]', post: 'List[int]') -> 'TreeNode':
        if pre == []:
            return
        root_val = post.pop()
        pre.pop(0)
        root = TreeNode(root_val)

        if pre == []:
            return root
        
        left_val = pre[0]

        for left_size in range(len(post) - 1, -1, -1):
            if post[left_size] == left_val:
                break

        left = self.constructFromPrePost(pre[:left_size + 1], post[:left_size + 1])
        right = self.constructFromPrePost(pre[left_size + 1:], post[left_size + 1:])

        root.left = left
        root.right = right
        return root
    
#Method-5    
# Operate on pre and post directly.

class Solution:
    def constructFromPrePost(self, pre: 'List[int]', post: 'List[int]') -> 'TreeNode':
        def construct(pre_left, pre_right, post_left, post_right):
            if pre_right < pre_left:
                return
            root_val = pre[pre_left]
            root = TreeNode(root_val)

            left_pre_left = pre_left + 1
            right_post_right = post_right - 1
            if left_pre_left > pre_right:
                return root

            left_val = pre[left_pre_left]
            for idx in range(post_right - 1, post_left - 1, -1):
                if post[idx] == left_val:
                    break
            left_size = idx - post_left
            left = construct(left_pre_left, left_pre_left + left_size, post_left, idx)
            right = construct(left_pre_left + left_size + 1, pre_right, post_left + left_size + 1, right_post_right)
            root.left = left
            root.right = right
            return root

        pre_left = post_left = 0
        pre_right = post_right = len(pre) - 1
        res = construct(pre_left, pre_right, post_left, post_right)

        return res


#Q26.  Unique Binary Search Trees

'''

Given an integer n, return the number of structurally unique BST's (binary search trees) which has exactly n nodes of unique values from 1 to n.

 

Example 1:


Input: n = 3
Output: 5
Example 2:

Input: n = 1
Output: 1
 

Constraints:

1 <= n <= 19
'''
#Solution 

#Method-1

# Math + Memo/Rec

# Choose a node i to be the root. On the left side, all nodes will have value smaller than i. On the right, they will be bigger.

import math
class Solution:
    def numTrees(self, n: int) -> int:
        return comb(2 * n, n) // (n + 1)

    
    
# O(1), O(1)
#Method-2

class Solution:
    @cache
    def numTrees(self, n: int) -> int:
        if n <= 1:
            return 1
        return sum(self.numTrees(k) * self.numTrees(n - 1 - k) for k in range(n))    
# O(n), O(n)

#Method-3

# using the Catalan Formula
# Catalan Formula = 2n!/(n+1!*n!)

class Solution(object):
    def numTrees(self, n):
        facn=1
        for i in range(1,n+1):
            facn *= i
        fac2n=facn
        facnp=facn*(n+1)
        for i in range(n+1,2*n+1):
            fac2n *= i
        ans = fac2n/(facn*facnp)
        
#Method-4

class Solution(object):
    def numTrees(self, n):
        if n == 0 or n == 1:
            return 1
        # Create 'sol' array of length n+1...
        sol = [0] * (n+1)
        # The value of the first index will be 1.
        sol[0] = 1
        # Run a loop from 1 to n+1...
        for i in range(1, n+1):
            # Within the above loop, run a nested loop from 0 to i...
            for j in range(i):
                # Update the i-th position of the array by adding the multiplication of the respective index...
                sol[i] += sol[j] * sol[i-j-1]
        # Return the value of the nth index of the array to get the solution...
        return sol[n]
    
#Method-5

from math import factorial as ft
class Solution:
    def numTrees(self, n: int) -> int:
        return ft(2*n)//(ft(n)*ft(n + 1))
    
    
#Method-6
# Using DP

# Apparently, any BST in size of n will have n partitions, for example [0,...i ], i+1, [i+2,...n]. where i+1 represent the root.


class Solution:
    def numTrees(self, n):
        """
        :type n: int
        :rtype: int
        """
        if n == 0: return 0
        dp = [0 if _ > 1 else 1 for _ in range(n+1)]
        for i in range(2, n+1):
            for j in range(0, i):
                dp[i] += dp[j] * dp[i-1-j]
        return dp[-1]

#Q27.Recover Binary Search Tree

'''

You are given the root of a binary search tree (BST), where the values of exactly two nodes of the tree were swapped by mistake. Recover the tree without changing its structure.

 

Example 1:


Input: root = [1,3,null,null,2]
Output: [3,1,null,null,2]
Explanation: 3 cannot be a left child of 1 because 3 > 1. Swapping 1 and 3 makes the BST valid.
Example 2:


Input: root = [3,1,4,null,null,2]
Output: [2,1,4,null,null,3]
Explanation: 2 cannot be in the right subtree of 3 because 2 < 3. Swapping 2 and 3 makes the BST valid.
 

Constraints:

The number of nodes in the tree is in the range [2, 1000].
-231 <= Node.val <= 231 - 1
 

Follow up: A solution using O(n) space is pretty straight-forward. Could you devise a constant O(1) space solution?

'''

#Solution

# Definition for a binary tree node.
# class TreeNode:
#     def __init__(self, val=0, left=None, right=None):
#         self.val = val
#         self.left = left
#         self.right = right


# Method-1
# O(1) space O(n) time solution

class Solution(object):
    def recoverTree(self, root):
        """
        :type root: TreeNode
        :rtype: void Do not return anything, modify root in-place instead.
        """
        self.pre_node,self.n1,self.n2 = None,None,None
        self.solve(root)
        self.n1.val,self.n2.val=self.n2.val,self.n1.val
        
    def solve(self,root):
        if not root:return
        self.solve(root.left)
        if not self.pre_node:self.pre_node = root
        if root.val<self.pre_node.val:
            if not self.n1:
                self.n1 = self.pre_node
                self.n2 = root
            else:self.n2 = root
        self.pre_node = root
        self.solve(root.right)
    
# Method-2

# inorder Traversal | 85% faster

class Solution:
    """
    approach: 
    we can create an inorder traversal and identify the first inversion
    ie. node with value greater than the next value and we have to replace that node
    with the smallest value on the right of it.
    """
    
    def recoverTree(self, root: Optional[TreeNode]) -> None:
        self.inorder = []
        def inorder(root):
            if root is None:
                return
            
            inorder(root.left)
            self.inorder.append(root)
            inorder(root.right)
            
        inorder(root)
        for i in range(len(self.inorder)-1):
            if self.inorder[i].val > self.inorder[i+1].val:
                first_pos = i
                break
        
        min_so_far = float('inf')
        min_index = -1
        for j in range(i+1, len(self.inorder)):
            if self.inorder[j].val < min_so_far:
                min_so_far = self.inorder[j].val
                min_index = j
        self.inorder[min_index].val = self.inorder[i].val
        self.inorder[i].val = min_so_far

# Method-3
# Definition for a binary tree node.
# class TreeNode:
#     def __init__(self, val=0, left=None, right=None):
#         self.val = val
#         self.left = left
#         self.right = right
class Solution:
    def inOrderTraversal(self, root: Optional[TreeNode]) -> None:
        if root is None:
            return []
        return self.inOrderTraversal(root.left) + [root] + self.inOrderTraversal(root.right) 
           
    def recoverTree(self, root: Optional[TreeNode]) -> None:
        """
        Do not return anything, modify root in-place instead.
        """
        # Get inorder traversal
        inOrder = self.inOrderTraversal(root)
        
        # Find first inversion
        for i in range(len(inOrder)-1):
            if inOrder[i].val > inOrder[i+1].val:
                # find smallest node to the right of node i and swap this node with smallest
                minNode = min(inOrder[i+1:], key=lambda node: node.val)
                inOrder[i].val, minNode.val = minNode.val, inOrder[i].val
 

# Method-4   
# using recurrsion(not efficient)

class Solution(object):
    def recoverTree(self, root):
        Solution.swap(root,root,None,None)
    @staticmethod
    def swap(root,cur_root,last_left,last_right):
        if cur_root is None or root is None:
            return
        if last_left is not None and cur_root.val>last_left.val:
            Solution.swap_vals(cur_root,last_left)
            Solution.swap(root,root,None,None)
            return
        if last_right is not None and cur_root.val<last_right.val:
            Solution.swap_vals(cur_root,last_right)
            Solution.swap(root,root,None,None)
            return
        Solution.swap(root,cur_root.left,cur_root,last_right)
        Solution.swap(root,cur_root.right,last_left,cur_root)
    
    @staticmethod
    def swap_vals(node1,node2):
        temp=node1.val
        node1.val=node2.val
        node2.val=temp

        
        
# Method-5

# iterative and recursive solution space O(N)


class Solution_iterative:
    def recoverTree(self, root):
        first = second = pre = None
        stack, node = [], root
        while stack or node:
            while node:
                stack.append(node)
                node = node.left
            node = stack.pop()
            if pre and pre.val > node.val:
                if first is None:
                    first = pre
                second = node
            pre = node
            node = node.right
        first.val, second.val = second.val, first.val

# Method-6

class Solution_recursive:
    def recoverTree(self, root):
        """
        :type root: TreeNode
        :rtype: void Do not return anything, modify root in-place instead.
        """
        self.first, self.second, self.pre = None, None, None

        def inorder(root):
            if root:
                inorder(root.left)
                if self.pre and self.pre.val > root.val:
                    if self.first is None:
                        self.first = self.pre
                    self.second = root
                self.pre = root
                inorder(root.right)
        inorder(root)
        self.first.val, self.second.val = self.second.val, self.first.val



#Q28. Populating Next Right Pointers in Each Node

'''
You are given a perfect binary tree where all leaves are on the same level, and every parent has two children. The binary tree has the following definition:

struct Node {
  int val;
  Node *left;
  Node *right;
  Node *next;
}
Populate each next pointer to point to its next right node. If there is no next right node, the next pointer should be set to NULL.

Initially, all next pointers are set to NULL.

 

Example 1:


Input: root = [1,2,3,4,5,6,7]
Output: [1,#,2,3,#,4,5,6,7,#]
Explanation: Given the above perfect binary tree (Figure A), your function should populate each next pointer to point to its next right node, just like in Figure B. The serialized output is in level order as connected by the next pointers, with '#' signifying the end of each level.
Example 2:

Input: root = []
Output: []
 

Constraints:

The number of nodes in the tree is in the range [0, 212 - 1].
-1000 <= Node.val <= 1000
 

Follow-up:

You may only use constant extra space.
The recursive approach is fine. You may assume implicit stack space does not count as extra space for this problem.

'''
#Solution

"""
# Definition for a Node.
class Node:
    def __init__(self, val: int = 0, left: 'Node' = None, right: 'Node' = None, next: 'Node' = None):
        self.val = val
        self.left = left
        self.right = right
        self.next = next
"""
# Method-1
# BFS solution

class Solution:
    def connect(self, root: 'Optional[Node]') -> 'Optional[Node]':
        if not root:
            return None
        level = [root]    
        while level:
            curlevel = []
            for i, node in enumerate(level):
                if i > 0:
                    level[i-1].next = node 
                if node.left:
                    curlevel.append(node.left)
                if node.right:
                    curlevel.append(node.right)
            level = curlevel
        return root
    
# Method-2
# depth first search

from collections import deque
class Solution:
    def connect(self, root: 'Optional[Node]') -> 'Optional[Node]':
        queue = deque()
        if root:
            queue.append([root,0])
        else:
            return root
        dicti = {}
        while(queue):
            curr = queue.pop()
            if curr[1] not in dicti:
                dicti[curr[1]] = []
            dicti[curr[1]].append(curr[0])
            if curr[0].left:
                queue.appendleft([curr[0].left,curr[1]+1])
            if curr[0].right:
                queue.appendleft([curr[0].right,curr[1]+1])
        for i in dicti:
            temp = dicti[i]
            for j in range (0 ,len(temp)-1):
                temp[j].next = temp[j+1]
        return root

    
# Method-3
# BFS

import collections
class Solution:
    def connect(self, root: 'Optional[Node]') -> 'Optional[Node]':
        if not root:
            return root
        q = collections.deque([root])
        while q:
            size = len(q)
            for i in range(size):
                node = q.popleft()
                if i < size - 1:
                    node.next = q[0]
                if node.left:
                    q.append(node.left)
                if node.right:
                    q.append(node.right)
        return root

# Method-4   
"""
# Definition for a Node.
class Node:
    def __init__(self, val: int = 0, left: 'Node' = None, right: 'Node' = None, next: 'Node' = None):
        self.val = val
        self.left = left
        self.right = right
        self.next = next
"""

class Solution:
    def connect(self, root: 'Optional[Node]') -> 'Optional[Node]':
        #basecase
        if root==None:
            return root
        #preorder position
        #what should we do to the root
        #rootleft->rootright if root.left  In the Example: 2->3
        #rootright->root.next.left if root.next  In the Example: 5->6
        if root.next and root.right:
            root.right.next=root.next.left
        if root.left:
            root.left.next=root.right
        #traverse to left and right node
        self.connect(root.left)
        self.connect(root.right)
        return root

#Q29.. Flatten Binary Tree to Linked List
'''

Given the root of a binary tree, flatten the tree into a "linked list":

The "linked list" should use the same TreeNode class where the right child pointer points to the next node in the list and the left child pointer is always null.
The "linked list" should be in the same order as a pre-order traversal of the binary tree.
 

Example 1:


Input: root = [1,2,5,3,4,null,6]
Output: [1,null,2,null,3,null,4,null,5,null,6]
Example 2:

Input: root = []
Output: []
Example 3:

Input: root = [0]
Output: [0]
 

Constraints:

The number of nodes in the tree is in the range [0, 2000].
-100 <= Node.val <= 100
 

Follow up: Can you flatten the tree in-place (with O(1) extra space)?

'''
#Solution

# Definition for a binary tree node.
# class TreeNode:
#     def __init__(self, val=0, left=None, right=None):
#         self.val = val
#         self.left = left
#         self.right = right

#Method-1

class Solution:
    def flatten(self, root: Optional[TreeNode], append=None) -> None:
        """
       if(root==null) return;
        flatten(root.right, append);
        if (root.right == null) root.right = append;
        flatten(root.left, root.right);
        if (root.left != null) root.right = root.left;
        root.left = null;
        """
        if not root:
            return root
        
        self.flatten(root.right, append)
        
        if not root.right:
            root.right = append
        
        self.flatten(root.left, root.right)
        
        if root.left:
            root.right = root.left
        
        root.left = None
        
        return root
    
# Method-2

class Solution:
    def __init__(self):
        self.prev=None
    def flatten(self, root: Optional[TreeNode]) -> None:
        if not root:
            return None
        self.flatten(root.right)
        self.flatten(root.left)
        root.right=self.prev
        root.left=None
        self.prev=root
        
# Method-3

# Python generators 

# I split the problem into two parts:

# A generator that create a sequence of nodes from a pre-order traversal.
# The flatten method uses the generator to fix the tree, just link prev.right with curr.

# Complessity: O(n)

class Solution:

    # @param root, a tree node
    # @return nothing, do it in place
    def flatten(self, root):
        
        if not root: return
        
        prev = None
        for node in self.preOrder(root):
            
            node.left = None
            if prev: prev.right = node
            prev = node
    
    
    def preOrder(self, node):
        
        left = node.left
        right = node.right
        
        yield node
        if left:
            for node in self.preOrder(left):
                yield node
        
        if right:
            for node in self.preOrder(right):
                yield node
                
# Method-4

class Solution:
    def flatten(self, root: Optional[TreeNode]) -> None:

        # check if root exists
        if root:
            
            temp = root.right # store the right part of root
            
            root.right = root.left  # move the left part to the right
            root.left = None        # clear left part
            
            curr = root
            while curr.right:       # use while loop to find the bottom right side
                curr = curr.right
            curr.right = temp       # attach temp back
            
            #recursion
            self.flatten(root.right)

# Method-5

# Definition for a binary tree node.
# class TreeNode:
#     def __init__(self, val=0, left=None, right=None):
#         self.val = val
#         self.left = left
#         self.right = right
class Solution:
    
    def dfs(self, root):
        if root is None:
            return root
        
        left_tail = self.dfs(root.left)
        right_tail = self.dfs(root.right)
        
        if left_tail:
            left_tail.right = root.right
            root.right = root.left
            root.left = None
        
        last = right_tail or left_tail or root
        return last
        

    def flatten(self, root: Optional[TreeNode]) -> None:
        """
        Do not return anything, modify root in-place instead.
        """
        self.dfs(root)

# Q30.Maximum Width of Binary Tree

'''

Given the root of a binary tree, return the maximum width of the given tree.

The maximum width of a tree is the maximum width among all levels.

The width of one level is defined as the length between the end-nodes (the leftmost and rightmost non-null nodes), where the null nodes between the end-nodes that would be present in a complete binary tree extending down to that level are also counted into the length calculation.

It is guaranteed that the answer will in the range of a 32-bit signed integer.

 

Example 1:


Input: root = [1,3,2,5,3,null,9]
Output: 4
Explanation: The maximum width exists in the third level with length 4 (5,3,null,9).
Example 2:


Input: root = [1,3,2,5,null,null,9,6,null,7]
Output: 7
Explanation: The maximum width exists in the fourth level with length 7 (6,null,null,null,null,null,7).
Example 3:


Input: root = [1,3,2,5]
Output: 2
Explanation: The maximum width exists in the second level with length 2 (3,2).
 

Constraints:

The number of nodes in the tree is in the range [1, 3000].
-100 <= Node.val <= 100


'''
#Solution

# Definition for a binary tree node.
# class TreeNode:
#     def __init__(self, val=0, left=None, right=None):
#         self.val = val
#         self.left = left
#         self.right = right

# Method-1
class Solution:
    def widthOfBinaryTree(self, root: Optional[TreeNode]) -> int:
        if root==None:
            return 0
        res = 0
        q = deque([(root, 0)])
        while(q):
            size = len(q)
            mmin = q[0][1]
            first, last = 0, 0
            for i in range(0, size):
                cur_id = q[0][1] - mmin
                node = q[0][0]
                q.popleft()
                if i == 0:
                    first = cur_id
                if i==size-1:
                    last = cur_id
                if node.left:
                    q.append((node.left, cur_id*2+1))
                if node.right:
                    q.append((node.right, cur_id*2+2))
            res = max(res, last-first+1)
        return res
        
# Method-2

class Solution:
    def widthOfBinaryTree(self, root: Optional[TreeNode]) -> int:
        if not root:
            return 
        q = collections.deque([(root,1)])
        result = []
        while q:  
            lenq = len(q) 
            first = None
            last = None

            for _ in range(lenq):  
                (node,id) = q.popleft() 
                if node.left:
                    q.append((node.left, 2*id))
                if node.right:
                    q.append((node.right,2*id+1))
                last = id
                if first is None:
                    first = id
                result.append(last-first+1)
        return max(result)
    
# Method-3

# Use index to record each level.

# Definition for a binary tree node.
# class TreeNode(object):
#     def __init__(self, x):
#         self.val = x
#         self.left = None
#         self.right = None

class Solution(object):
    def widthOfBinaryTree(self, root):
        """
        :type root: TreeNode
        :rtype: int
        """
        self.res = 1
        self.go([root],[0])
        return self.res
        
    def go(self, level, coor):
        
        # get length of current level and go to next level
        # print level
        # print coor
        
        if not level:
            return 0
        
        length = max(coor)-min(coor)+1
        self.res = max(self.res, length)
        
        new_level = []
        new_coor = []
        for i, element in enumerate(level):
            if element.left:
                new_level.append(element.left)
                new_coor.append(coor[i]*2+0)
            if element.right:
                new_level.append(element.right)
                new_coor.append(coor[i]*2+1)
        self.go(new_level, new_coor)
        
# Method-4
# Maximum Width of Binary Tree

# level order

# Here we need to maintain a dict with a index of a node. for 0 based indexing left child will be 2pos+1
# and for right 2pos+2. Here pos is the index of parent root. We will index the node with level order traversal and the the maximum width of a Binary Tree will be (index of last node - index of first node +1) of last level.

class Solution:
    def widthOfBinaryTree(self, root: Optional[TreeNode]) -> int:
        maxWidth=1
        nxt_level=[]
        cur_level=[(root,1)]
        while cur_level:
            for node,pos in cur_level:
                if node.left:
                    nxt_level.append((node.left,(2*pos)+1))
                if node.right:
                    nxt_level.append((node.right,(2*pos)+2))
                                 
            if nxt_level:
                maxWidth=max(maxWidth,nxt_level[-1][1]-nxt_level[0][1]+1)
            cur_level=nxt_level
            nxt_level=[]
                                 
        return maxWidth

# Method-5
# in-order
class Solution(object):
    def widthOfBinaryTree(self, root):
        def inOrder(dep, rank, r):
            if not r:
                return
            inOrder(dep + 1, 2 * (rank - 1) + 1, r.left)
            dic[dep] = dic.get(dep, [rank + 2, rank - 1])
            dic[dep][0], dic[dep][1] = min(rank, dic[dep][0]), max(rank, dic[dep][1])
            inOrder(dep + 1, 2 * (rank - 1) + 2, r.right)
        dic = {}
        inOrder(0, 1, root)
        ans = 0
        for key in dic:
            ans = max(ans, dic[key][1] - dic[key][0] + 1)
        return ans


#Q31. Serialize and Deserialize Binary Tree

'''


Serialization is the process of converting a data structure or object into a sequence of bits so that it can be stored in a file or memory buffer, or transmitted across a network connection link to be reconstructed later in the same or another computer environment.

Design an algorithm to serialize and deserialize a binary tree. There is no restriction on how your serialization/deserialization algorithm should work. You just need to ensure that a binary tree can be serialized to a string and this string can be deserialized to the original tree structure.

Clarification: The input/output format is the same as how LeetCode serializes a binary tree. You do not necessarily need to follow this format, so please be creative and come up with different approaches yourself.

 

Example 1:


Input: root = [1,2,3,null,null,4,5]
Output: [1,2,3,null,null,4,5]
Example 2:

Input: root = []
Output: []
 

Constraints:

The number of nodes in the tree is in the range [0, 104].
-1000 <= Node.val <= 1000

'''
#Solution

# Method-1
# Preorder 

# Definition for a binary tree node.
# class TreeNode(object):
#     def __init__(self, x):
#         self.val = x
#         self.left = None
#         self.right = None

class Codec:
    def buildString(self, node, nodes):
        if node is None:
            nodes.append('X')
        else:
            nodes.append(str(node.val))
            self.buildString(node.left, nodes)
            self.buildString(node.right, nodes)
        
    def buildTree(self):
        nodeVal = self.nodes[self.idx]
        self.idx += 1
        if (nodeVal == "X"):
            return None
        curr = TreeNode(int(nodeVal))
        curr.left = self.buildTree()
        curr.right = self.buildTree()
        return curr
    
    def serialize(self, root):
        """Encodes a tree to a single string.
        
        :type root: TreeNode
        :rtype: str
        """
        nodes = []
        self.buildString(root, nodes)
        return ",".join(nodes)
        

    def deserialize(self, data):
        """Decodes your encoded data to tree.
        
        :type data: str
        :rtype: TreeNode
        """
        self.nodes = data.split(",")
        self.idx = 0
        return self.buildTree()
        
        

# Your Codec object will be instantiated and called as such:
# ser = Codec()
# deser = Codec()
# ans = deser.deserialize(ser.serialize(root))

# Method-2
# dfs
# Definition for a binary tree node.
# class TreeNode(object):
#     def __init__(self, x):
#         self.val = x
#         self.left = None
#         self.right = None

class Codec:

    def serialize(self, root):
        """Encodes a tree to a single string.
        
        :type root: TreeNode
        :rtype: str        
        """
        #[1,2,3] -> 1(2(,),3(,))
        #[1,2,3,null,null,4,5] -> 1(2(,), 3(4(,),5(,)))
        if not root: return ''
        
        ser_left = self.serialize(root.left)
        ser_right = self.serialize(root.right)
        
        return f'{root.val}({ser_left},{ser_right})'
        

    def deserialize(self, data):
        """Decodes your encoded data to tree.
        
        :type data: str
        :rtype: TreeNode
        """       
        if not data: return None
        
        s_idx = 0
        
        def read_str():
            nonlocal s_idx
            curr_node = None
            
            # read num
            start_idx = s_idx
            
            while data[s_idx] == '-' or data[s_idx].isdigit(): s_idx += 1
            
            # when we finished reading the number, could be one of two cases:
            # 1. ',' -> child node is none, nothing to create. in that start_idx == s_idx
            # 2. '(' -> in that case start_idx < s_idx
            if start_idx < s_idx:
                # skip open bracket
                s_idx += 1
                
                # init node
                curr_node = TreeNode(val=int(data[start_idx: s_idx-1]))
                curr_node.left = read_str()
                curr_node.right = read_str()                
                            
            # skip comma or closing bracket
            s_idx += 1
            return curr_node
                        
        return read_str()
    
    
# Method-3

from collections import deque
class Codec:

    def serialize(self, root):
        """Encodes a tree to a single string.
        
        :type root: TreeNode
        :rtype: str
        """
        result = []
        curr_q = deque()
        curr_q.append(root)
        new_q = deque()
        
        while curr_q:
            if any(curr_q): result.extend([str(n.val) if n else "#" for n in list(curr_q)])
            else: break
                
            while curr_q:
                node = curr_q.popleft()
                
                if node and node.left: new_q.append(node.left)
                elif node: new_q.append(None)
                    
                if node and node.right: new_q.append(node.right)
                elif node: new_q.append(None)
            
            curr_q = new_q
            new_q = deque()
                
        return ','.join(result)     

    def deserialize(self, data):
        """Decodes your encoded data to tree.
        
        :type data: str
        :rtype: TreeNode
        """
        if not data: return None
        
        n_lst = data.split(",")
        root = TreeNode(int(n_lst[0]))
        curr_q = deque()
        curr_q.append(root)
        i=1

        while i < len(n_lst) and curr_q:
            
            node = curr_q.popleft()
            if n_lst[i] != '#':
                left_node = TreeNode(int(n_lst[i]))
                node.left = left_node
                curr_q.append(left_node)
            i+=1
            if n_lst[i] != '#':
                right_node = TreeNode(int(n_lst[i]))
                node.right = right_node
                curr_q.append(right_node)
            i+=1
        
        return root

# Method-4

# Postorder Traversal Using DFS


# Definition for a binary tree node.
# class TreeNode(object):
#     def __init__(self, x):
#         self.val = x
#         self.left = None
#         self.right = None

class Codec:

    def serialize(self, root):
        """Encodes a tree to a single string.
        
        :type root: TreeNode
        :rtype: str
        """
        if not root:
            return "None,"
        
        res = []
        def dfs(currRoot):
            nonlocal res
            if not currRoot:
                res.append("None,")
            else:
                res = dfs(currRoot.left)
                res = dfs(currRoot.right)
                res.append(str(currRoot.val) + ",")
            
            return res
        
        dfs(root)
        return "".join(res)
        
    def deserialize(self, data):
        """Decodes your encoded data to tree.
        
        :type data: str
        :rtype: TreeNode
        """
        def helper(s):
            if s[-1] == "None":
                s.pop()
                return None
            
            root = TreeNode(int(s[-1]))
            s.pop()
            root.right = helper(s)
            root.left = helper(s)
            
            return root
        
        dl = data.split(",")
        
        return helper(dl[:-1])
        
# Method-5

# Uses Hashmap to Easily Rebuild


# Definition for a binary tree node.
# class TreeNode(object):
#     def __init__(self, x):
#         self.val = x
#         self.left = None
#         self.right = None

class Codec:

    def serialize(self, root):
        """Encodes a tree to a single string.
        
        :type root: TreeNode
        :rtype: str
        """
        result = ""
        def buildMap(node, string):
            nonlocal result
            if node != None:
                result += string + "." + str(node.val) + ","
                buildMap(node.left, string + "l")
                buildMap(node.right, string + "r")
            return
            
            
        buildMap(root, "r")
        return result
        

    def deserialize(self, data):
        """Decodes your encoded data to tree.
        
        :type data: str
        :rtype: TreeNode
        """
        def rebuild(string):
            if string in mappings:
                node = TreeNode(int(mappings[string]))
                node.left = rebuild(string + "l")
                node.right = rebuild(string + "r")
                return node
            else:
                return None
            
        pairs = data.split(",")
        pairs.pop()
        mappings = {}
        for p in pairs:
            temp = p.split(".")
            mappings[temp[0]] = temp[1]
            
        return rebuild("r")

#Q32.  Binary Tree Maximum Path Sum

'''

A path in a binary tree is a sequence of nodes where each pair of adjacent nodes in the sequence has an edge connecting them. A node can only appear in the sequence at most once. Note that the path does not need to pass through the root.

The path sum of a path is the sum of the node's values in the path.

Given the root of a binary tree, return the maximum path sum of any non-empty path.

 

Example 1:


Input: root = [1,2,3]
Output: 6
Explanation: The optimal path is 2 -> 1 -> 3 with a path sum of 2 + 1 + 3 = 6.
Example 2:


Input: root = [-10,9,20,null,null,15,7]
Output: 42
Explanation: The optimal path is 15 -> 20 -> 7 with a path sum of 15 + 20 + 7 = 42.
 

Constraints:

The number of nodes in the tree is in the range [1, 3 * 104].
-1000 <= Node.val <= 1000

'''

#Solution 

# Method-1
# DFS| Recursive |Without DP | Less space than DP


class Solution:
    def maxPathSum(self, root: Optional[TreeNode]) -> int:
        
        self.dm=float('-inf')
        
        def dfs(node):
            if not node:
                return 0
            
            leftval=dfs(node.left)
            rightval=dfs(node.right)
            
            self.dm=max(self.dm,leftval+node.val,rightval+node.val,leftval+rightval+node.val,node.val)
            
            return max(leftval+node.val,rightval+node.val,node.val)
        
        dfs(root)
        return self.dm
    
# Method-2

class Solution(object):
    current_max = float('-inf')
    def maxPathSum(self, root):
        self.maxPathSumHelper(root)
        return self.current_max

    def maxPathSumHelper(self, root):
        """Helper method"""
        if root is None:
            return root
        left = self.maxPathSumHelper(root.left)
        right = self.maxPathSumHelper(root.right)
        left = 0 if left is None else (left if left > 0 else 0)
        right = 0 if right is None else (right if right > 0 else 0)
        self.current_max = max(left+right+root.val, self.current_max)
        return max(left, right) + root.val
    
# Method-3

# Definition for a binary tree node.
# class TreeNode:
#     def __init__(self, val=0, left=None, right=None):
#         self.val = val
#         self.left = left
#         self.right = right
class Solution:
    def maxPathSum(self, root: Optional[TreeNode]) -> int:
        
        self.max = -inf
        
        def max_path(node):
            if not node:
                return -inf
            if node.left or node.right:
                left = max_path(node.left)
                right = max_path(node.right)
                if node.left and node.right:
                    self.max = max(self.max, node.val, left + node.val, right + node.val, node.val + right + left)  
                    return max(node.val, left + node.val, right + node.val)
                elif node.left:
                    self.max = max(self.max, node.val, node.val + left, left)  
                    return max(node.val, left + node.val)
                else:
                    self.max = max(self.max, node.val, node.val + right, right)  
                    return max(node.val, right + node.val)
            else:
                self.max = max(self.max, node.val)
                return node.val
        max_path(root)
        return self.max
    
# Method-4

# Recursive solution with explanation O(n) Post-order traversal.


# The maximum path sum can either be in the left subtree or the right subtree so using the post-order traversal is good.

# because the maximum will not always go through root, at each node you always check if the sum of the left and right and current node val and store the maximum

# at each node, you always return the current node value + the max of left subtree or right subtree
# or the node value itself if it's bigger then the left or right subtree.

class Solution(object):
    max_val = -10000

    def max_path(self,root):
        if root:
            left = self.max_path(root.left)
            right = self.max_path(root.right)

            self.max_val = max(self.max_val, max(left,right)+root.val,left+right+root.val,root.val)
            #print "at node ", root.val , "left is " , left , "right is " , right, "returning: ", max(max(left,right)+root.val,root.val)
            #print "max: ", self.max_val
            return max(max(left,right)+root.val,root.val)
        else:
            return 0
                
    def maxPathSum(self, root):
        """
        :type root: TreeNode
        :rtype: int
        """
        self.max_path(root)
        return self.max_val

# Method-5

# DFS Solution Dynamic Programing

# Definition for a binary tree node.
# class TreeNode:
#     def __init__(self, val=0, left=None, right=None):
#         self.val = val
#         self.left = left
#         self.right = right
class Solution:
    def maxPathSum(self, root: Optional[TreeNode]) -> int:
        
        """
        hypothesis:
        ip root | return max(sum(path)), not guaranty that it would be also the longest path. 
        
        base case:
        1. if not root
        
        induction:
        1. root.left
        2. root.right
        3. addition of the curent val with max(leftPathSum, rightPathSum)
        
        """
        def maxPath(root):
            
            # bc
            if not root:
                return 0
            
            left = maxPath(root.left)
            right = maxPath(root.right)
            # induction | addition of the curent val with max(leftPathSum, rightPathSum)
            self.maxSum = max(self.maxSum, left+right+root.val)
            #    if leftTreePathSum < 0, rightPathSUm < 0, then it returns 0,
            # which is assumption as if current node is leaf, and start calculating the path starting from it 
            return max(left+root.val, right+root.val, 0)
            
        # Gvar
        # maxSum = int_min
        self.maxSum = -1001
        maxPath(root)
        return self.maxSum
    
"""
TC : O(n)
Sc : O(n)
"""

#Q33. Vertical Order Traversal of a Binary Tree

'''

Given the root of a binary tree, calculate the vertical order traversal of the binary tree.

For each node at position (row, col), its left and right children will be at positions (row + 1, col - 1) and (row + 1, col + 1) respectively. The root of the tree is at (0, 0).

The vertical order traversal of a binary tree is a list of top-to-bottom orderings for each column index starting from the leftmost column and ending on the rightmost column. There may be multiple nodes in the same row and same column. In such a case, sort these nodes by their values.

Return the vertical order traversal of the binary tree.

 

Example 1:


Input: root = [3,9,20,null,null,15,7]
Output: [[9],[3,15],[20],[7]]
Explanation:
Column -1: Only node 9 is in this column.
Column 0: Nodes 3 and 15 are in this column in that order from top to bottom.
Column 1: Only node 20 is in this column.
Column 2: Only node 7 is in this column.
Example 2:


Input: root = [1,2,3,4,5,6,7]
Output: [[4],[2],[1,5,6],[3],[7]]
Explanation:
Column -2: Only node 4 is in this column.
Column -1: Only node 2 is in this column.
Column 0: Nodes 1, 5, and 6 are in this column.
          1 is at the top, so it comes first.
          5 and 6 are at the same position (2, 0), so we order them by their value, 5 before 6.
Column 1: Only node 3 is in this column.
Column 2: Only node 7 is in this column.
Example 3:


Input: root = [1,2,3,4,6,5,7]
Output: [[4],[2],[1,5,6],[3],[7]]
Explanation:
This case is the exact same as example 2, but with nodes 5 and 6 swapped.
Note that the solution remains the same since 5 and 6 are in the same location and should be ordered by their values.
 

Constraints:

The number of nodes in the tree is in the range [1, 1000].
0 <= Node.val <= 1000

'''

#Solution

# Definition for a binary tree node.
# class TreeNode:
#     def __init__(self, val=0, left=None, right=None):
#         self.val = val
#         self.left = left
#         self.right = right

#Method-1
# dfs
# recursion


class Solution:
    
    def verticalTraversal(self, root: Optional[TreeNode]) -> List[List[int]]:
        
        def dfs(root, row, col):
            if not root:
                return
            vertical_order[(row,col)].append(root.val)
            dfs(root.left, row+1, col-1)
            dfs(root.right, row+1, col+1)
            
        vertical_order = collections.defaultdict(list)
        output = collections.defaultdict(list)

        dfs(root,0,0)
        
        for i,j in sorted(vertical_order, key=lambda k:(k[1],k[0])):
            output[j].extend(sorted(vertical_order[(i,j)]))
            
        return list(output.values())

#Method-2

# using Heap
# dfs
# tree
# heap

class Solution(object):
    def traverse(self, node, x_cord, y_cord, heap):
        if not node:
            return
        heap.append((y_cord, (x_cord, node.val)))
        self.traverse(node.left, x_cord+1, y_cord-1, heap)
        self.traverse(node.right, x_cord+1, y_cord+1, heap)
    
    def verticalTraversal(self, root):
        """
        :type root: TreeNode
        :rtype: List[List[int]]
        """
        heap = []
        self.traverse(root, 0, 0, heap)
        
        heapq.heapify(heap)
        ans, level_heap = [], []
        prev, node_val = heapq.heappop(heap)
        level_heap.append(node_val[1])
        
        while heap:
            y_cord, node_val = heapq.heappop(heap)
            if y_cord!=prev:
                ans.append(level_heap)
                level_heap = []
                prev = y_cord
            level_heap.append(node_val[1])
        
        ans.append(level_heap)
        return ans

#Method-3

# DFS and Sort


# Use dfs to traverse the binary tree. For each node, add its row and value into a dict based on its col. We need both row and value because we have to sort all nodes by their rows and values. As you traverse the tree, keep track of the lowest and highest column.

# Lastly, iterate from the lowest to the highest column and add values of sorted nodes of each column into the result.

# Complexity:
# Time: O(nlogn)
# Space: O(n)


from collections import defaultdict
from math import inf


class TreeNode:
    def __init__(self, val=0, left=None, right=None):
        self.val = val
        self.left = left
        self.right = right


class Solution:
    def verticalTraversal(self, root: TreeNode) -> list[list[int]]:

        # Two variables to keep track of the lowest and the highest column
        lowest, highest = inf, -inf

        # A dict to store all nodes belong to each column
        cols = defaultdict(list)

        # Traverse the tree using dfs
        def dfs(node, row, col):
            nonlocal lowest, highest

            # Update the lowest and highest columns
            lowest, highest = min(lowest, col), max(highest, col)

            # Add the current node's row and value into the dict
            cols[col].append((row, node.val))

            # If there is a left child, go to it
            if node.left:
                dfs(node.left, row + 1, col - 1)

            # If there is a right child, go to it
            if node.right:
                dfs(node.right, row + 1, col + 1)

        # Call dfs on the binary tree
        dfs(root, 0, 0)

        # Initialize the result
        res = []

        # Iterate through all columns
        for i in range(lowest, highest + 1):

            # For each column, add values of sorted nodes into the result
            res.append([val for _, val in sorted(cols[i])])

        return res
    
#Method-4

# Algorithm
# 1. Take data structure: defaultdict with list
# 2. Start from root with row r = 0 and column c = 0
# 3. Append the tuple (r, root.val) into list at key = c
# 4. Repeat for left child with r+1, c-1 and right child with r+1, c+1
# 5. Stop when root becomes null
# 6. Minimum and Maximum of all keys (c) will be full range of (min, max)
# 7. For each key in range, extract the list from default key, sort it and append 2nd val of tuple to result

class Solution:
    # Time O(n log n) Space O(n) where n is the number of nodes in the tree
    def verticalTraversal(self, root: Optional[TreeNode]) -> List[List[int]]:
        dct = defaultdict(list)                         # data structure

        def dfs(root, r, c):
            if root:                                    # if root is not None
                dct[c].append((r,root.val))             # append value with row index into data structure
                dfs(root.left, r+1, c-1)                # repeat for left child with next row r+1, left col c-1
                dfs(root.right, r+1, c+1)               # repeat for right child with next row r+1, right col c-1

        dfs(root, 0, 0)                                 # start from root with r = 0, c = 0
        mn, mx = min(dct), max(dct)                     # range of keys/columns is mim and max

        res = []                                        # result container
        for k in range(mn, mx+1):                       # for each key/col
            res.append([v for k,v in sorted(dct[k])])   # create list from 2nd value from sorted tuples
        return res                                      # return the result
    
    
#Method-5

# [Deque] BFS Traversal with Explaination


# Idea - To insert tuple of (col, childNode) in deque during DFS, which will be col-1 and col+1 for left and right. So, when element is popped we will get index of col.

class Solution:
    def verticalTraversal(self, root: Optional[TreeNode]) -> List[List[int]]:
        dq=deque([(0,root)])
        data={}
        mini=inf
        while dq:
            temp=[]
            for _ in range(len(dq)):    #standard BFS by deque
                val,popped=dq.popleft()
                if not popped: continue
                mini=min(mini,val)      #maitaining minimum col to get data from dictionary later, sequentially
                temp.append((val,popped.val))
                dq.append((val-1,popped.left))
                dq.append((val+1,popped.right))
            temp.sort()
            for idx,node in temp:     #col wise appending in data
                if idx in data: data[idx].append(node)
                else: data[idx]=[node]
        fina=[]
        while mini in data:     #done to sequentialy access the data
            fina.append(data[mini])
            mini+=1
        return fina


#Q34.Binary Tree Cameras
'''

You are given the root of a binary tree. We install cameras on the tree nodes where each camera at a node can monitor its parent, itself, and its immediate children.

Return the minimum number of cameras needed to monitor all nodes of the tree.

 

Example 1:


Input: root = [0,0,null,0,0]
Output: 1
Explanation: One camera is enough to monitor all nodes if placed as shown.
Example 2:


Input: root = [0,0,null,0,null,0,null,null,0]
Output: 2
Explanation: At least two cameras are needed to monitor all nodes of the tree. The above image shows one of the valid configurations of camera placement.
 

Constraints:

The number of nodes in the tree is in the range [1, 1000].



'''

#Solution 

# Definition for a binary tree node.
# class TreeNode:
#     def __init__(self, val=0, left=None, right=None):
#         self.val = val
#         self.left = left
#         self.right = right


# class Solution:
#     def minCameraCover(self, root: Optional[TreeNode]) -> int:
        
#Method-1

# Dynamic Programming

class Solution(object):
    def minCameraCover(self, root):
        def solve(node):
            # 0: Strict ST; All nodes below this are covered, but not this one
            # 1: Normal ST; All nodes below and incl this are covered - no camera
            # 2: Placed camera; All nodes below this are covered, plus camera here

            if not node: return 0, 0, float('inf')
            L = solve(node.left)
            R = solve(node.right)

            dp0 = L[1] + R[1]
            dp1 = min(L[2] + min(R[1:]), R[2] + min(L[1:]))
            dp2 = 1 + min(L) + min(R)

            return dp0, dp1, dp2

        return min(solve(root)[1:])
    
#Method-2
# Greedy

class Solution(object):
    def minCameraCover(self, root):
        self.ans = 0
        covered = {None}

        def dfs(node, par = None):
            if node:
                dfs(node.left, node)
                dfs(node.right, node)

                if (par is None and node not in covered or
                        node.left not in covered or node.right not in covered):
                    self.ans += 1
                    covered.update({node, par, node.left, node.right})

        dfs(root)
        return self.ans
 
#Method-3

# Node value map:-
# 0: Node is not monitored
# 1: Node is monitored
# 2: Node has a camera

# greedy
# dfs
# iterative-dfs


class Solution:
    def minCameraCover(self, root: Optional[TreeNode]) -> int:
        n_cams = 0
        
        stack = []
        crr = root
        while True:
            while crr:
                stack.append(crr)
                stack.append(crr)
                crr = crr.left

            if not stack:
                break

            crr = stack.pop()

            if stack and stack[-1] == crr:
                crr = crr.right
            else:
                state = min(crr.left.val if crr.left else float('inf'), crr.right.val if crr.right else float('inf'))
                if state == 0:
                    crr.val = 1
                    n_cams += 1
                elif state == 1:
                    crr.val = 2
                crr = None
        
        return n_cams + (root.val == 0)

#Method-4

# Postorder traversal. State machine.


# For this problem we have a few states:

# A node is NOT_COVERED
# A node got NEW_CAMERA_INSTALLED (and is covered by itself)
# A node is COVERED
# We need to cover as many nodes as possible with min cameras. The most coverage you will get with min cameras is when a parent covers its children and a parent of the parent (1 camera - 4 nodes: parent + 2 children + parent of the parent).

# image

# Thus we go from bottom to top and exclude leaves. This introduces post-order BT traversal (visit left, right, and then visit node and decide what's next). Parents always decide what to do next ;)

# There are 2 interesting for us cases: when the root returns COVERED (left) state and when it returns NOT_COVERED (right).



# State transition:

# A leaf node returns NOT_COVERED because it expects to be covered by the parent node (except the root node, which is a special case #2)
# When a parent node detects that one of children needs a coverage (gets I am NOT_COVERED response) the parent node knows that it needs to COVER a child node and thus returns NEW_CAMERA_INSTALLED state (and increases needed cams count).
# When a parent node sees that children are covered (got COVERED or NEW_CAMERA_INSTALLED state, which is a sub-state of COVERED) the parent node reports that it is COVERED too since the parent covers itself too.
# This is the left case on the diagram above.

# When a parent node sees that children are covered (got COVERED or COVERED state), but they were covered by next level nodes, the parent node reports that it needs to be covered too. Thus returns NOT_COVERED state from the postorder() method.
# This is the right case in the diagram above.
# This case covers the single node tree.



class Solution:
    def minCameraCover(self, root: Optional[TreeNode]) -> int:
        NOT_COVERED = 0
        NEW_CAMERA_INSTALLED = 1
        COVERED = 2
        
        def postorder(node):
            nonlocal cams

			# leaf nodes should be covered by the parent -> NOT_COVERED
            if not node.left and not node.right:
                return NOT_COVERED
            
            left_state = postorder(node.left) if node.left else None
            right_state = postorder(node.right) if node.right else None

			# a child reported that it is not covered -> need to cover myself and a NEW_CAMERA_INSTALLED
            if left_state == NOT_COVERED or right_state == NOT_COVERED:
                cams += 1
                return NEW_CAMERA_INSTALLED
            
			# a parent NEW_CAMERA_INSTALLED and the parent is covered too 
            elif left_state == NEW_CAMERA_INSTALLED or right_state == NEW_CAMERA_INSTALLED:
                return COVERED
            
			# children reported that they are COVERED, but the node is NOT_COVERED (case #2 or single root)
            else:
                return NOT_COVERED

        cams = 0
		# single root or root node is NOT_COVERED by any child node
        return cams + 1 if postorder(root) == NOT_COVERED else cams
    
    
# Method-5

# from the leaves to the root
# one node empty, one node camera, one node empty, one node camera
# if the grand children of the root is camera,which means the children are covered but the root is not.
# we need to add one camera to the root

class Solution:
	# time on
	# space on
    def minCameraCover(self, root: TreeNode) -> int:
        if not root: return 0
        self.res = 0
        covered = {None}
        def dfs(node,parent=None):
            if node:
                dfs(node.left,node)
                dfs(node.right,node)
                if node not in covered and not parent:
                    self.res += 1
                elif node.left not in covered or node.right not in covered:
                    self.res += 1
                    covered.update({node.left,node.right,node,parent})
        dfs(root)
        return self.res


#Q35.  Sum of Distances in Tree

'''

There is an undirected connected tree with n nodes labeled from 0 to n - 1 and n - 1 edges.

You are given the integer n and the array edges where edges[i] = [ai, bi] indicates that there is an edge between nodes ai and bi in the tree.

Return an array answer of length n where answer[i] is the sum of the distances between the ith node in the tree and all other nodes.

 

Example 1:


Input: n = 6, edges = [[0,1],[0,2],[2,3],[2,4],[2,5]]
Output: [8,12,6,10,10,10]
Explanation: The tree is shown above.
We can see that dist(0,1) + dist(0,2) + dist(0,3) + dist(0,4) + dist(0,5)
equals 1 + 1 + 2 + 2 + 2 = 8.
Hence, answer[0] = 8, and so on.
Example 2:


Input: n = 1, edges = []
Output: [0]
Example 3:


Input: n = 2, edges = [[1,0]]
Output: [1,1]
 

Constraints:

1 <= n <= 3 * 104
edges.length == n - 1
edges[i].length == 2
0 <= ai, bi < n
ai != bi
The given input represents a valid tree.

'''
#Solution

#Method-1

# Subtree Sum and Count

class Solution(object):
    def sumOfDistancesInTree(self, N, edges):
        graph = collections.defaultdict(set)
        for u, v in edges:
            graph[u].add(v)
            graph[v].add(u)

        count = [1] * N
        ans = [0] * N
        def dfs(node = 0, parent = None):
            for child in graph[node]:
                if child != parent:
                    dfs(child, node)
                    count[node] += count[child]
                    ans[node] += ans[child] + count[child]

        def dfs2(node = 0, parent = None):
            for child in graph[node]:
                if child != parent:
                    ans[child] = ans[node] - count[child] + N - count[child]
                    dfs2(child, node)

        dfs()
        dfs2()
        return ans

#Method-2

# PreOrder && PostOrder

# Using postOrder to find count of nodes in subtree for each node and distance it will travel for subtree (not all nodes only subtree nodes).postOrder because we need to find children count of nodes and distance before calculating root.
# Using PreOrder to find distance of each node from all nodes by using this relation, if node is k then dist[k]+=dist[k_parent]-count[nodes_in_subtree_of_k]+(total_nodes-count[nodes_in_subtree_of_k]). Using Preorder because as in above relation to calculate value of node_k we need value of parent node.

class Solution:
    def sumOfDistancesInTree(self, n: int, edges: List[List[int]]) -> List[int]:
        count=[1]*n
        dist=[0]*n
        def createGraph():
            g=[[] for i in range(n)]
            for u,v in edges:
                g[u].append(v)
                g[v].append(u)
            return g
        g=createGraph()
        def postOrder(curr,parent):
            for it in g[curr]:
                if it!=parent:
                    postOrder(it,curr)
                    count[curr]+=count[it]
                    dist[curr]+=dist[it]+count[it]
            return
        def preOrder(curr,parent):
            for it in g[curr]:
                if it!=parent:
                    dist[it]=dist[curr]-count[it]+(n-count[it])
                    preOrder(it,curr)
            return
        postOrder(0,-1)
        preOrder(0,-1)
        return dist
    
#Method-3

# two pass O(N) solution


class Solution(object):
    def sumOfDistancesInTree(self, N, edges):
        """
        :type N: int
        :type edges: List[List[int]]
        :rtype: List[int]
        """

        # first step, generate a undirected graph
        self.g0 = [[] for _ in range(N)]
        for e in edges:
            a, b = tuple(e)
            self.g0[a].append(b)
            self.g0[b].append(a)

        # second step, generate a tree based on the graph
        # this won't change the result
        root = 0
        self.g = [[] for _ in range(N)]
        self.gen_tree(root, None)

        # third step, conduct pass1 to calculate the 
        # number of child nodes and the sum of distances
        self.fc = [None for _ in range(N)]
        self.pass1(root)

        # fourth step, conduct pass2 to calculate the
        # number of parent nodes and the sum of distances
        self.fp = [None for _ in range(N)]
        self.fp[root] = (0, 0)
        self.pass2(root)

        return [self.fc[i][1] + self.fp[i][1] for i in range(N)]

    def gen_tree(self, i, p):
        for c in self.g0[i]:
            if c != p:
                self.g[i].append(c)
                self.gen_tree(c, i)

    def pass1(self, i):
        n = s = 0
        for c in self.g[i]:
            nc, sc = self.pass1(c)
            n += nc
            s += sc
        self.fc[i] = (n, s)
        return n + 1, s + n + 1
    
    def pass2(self, i):
        np, sp = self.fp[i]
        nc, sc = self.fc[i]
        for c in self.g[i]:
            n, s = self.fc[c]
            nx = np + nc - n - 1
            sx = sp + sc - n - s - 1
            self.fp[c] = (
                nx + 1,
                sx + nx + 1
            )
            self.pass2(c)
            
            
    
#Method-4

# sum of distance from the i-th node to each of its children
# dis2child = [0] * N
# numbers of the i-th node and all of its children
# population = [1] * N
# sum of distance from the i-th node to all other nodes
# dis2all = [0] * N

#   0
#  / \
# 1  (2)
#    /|\
#   3 4 5
# population[node] = sum(population[child])
# node2child = sum(child2child + population[child])
# node2all = node2child + node2other
# = node2child + parent2other + node2parent * nums of other
# = node2child + (parent2all - node2child - populartion) + node2parent * (N - population)

# population[2] = population[3] + population[4] + population[5]
# node2child[2] = sum(node2child[3,4,5] + population[3,4,5])
# node2all[2] = node2child[2] + (node2all[0] - node2child[2] - population[2]) + (N - population[2])
# = node2all[0] + N - 2 * population[2]

# Time On
# Space On

class Solution(object):
    def sumOfDistancesInTree(self, N, edges):
        if N == 1: return [0]
        
        neighbors = collections.defaultdict(set)
        for n1,n2 in edges:
            neighbors[n1].add(n2)
            neighbors[n2].add(n1)
        # sum of distance from the i-th node to each of its children
        dis2child = [0] * N
        # numbers of the i-th node and all of its children
        population = [1] * N
        # sum of distance from the i-th node to all other nodes
        dis2all = [0] * N
         
        def dfs1(node = 0,parent = None):
            for child in neighbors[node]:
                if child != parent:
                    dfs1(child,node)
                    population[node] += population[child]
                    dis2child[node] += dis2child[child] + population[child]
            return
        dis2all = dis2child
        def dfs2(node = 0,parent = None):
            for child in neighbors[node]:
                if child != parent:
                    dis2all[child] = dis2all[node] + N - 2*population[child]
                    dfs2(child,node)
                    
        dfs1()
        dfs2()
        return dis2all

    
#Method-5

# fw and dfs sol for ref
# floydwarshall algorithm
# Floyd walsh 

class Solution:
    def sumOfDistancesInTree(self, n: int, edges: List[List[int]]) -> List[int]:
        dp = [[float('inf') for _ in range(n)] for _ in range(n)]
        
        for s,e in edges:
            dp[s][e] = 1
            dp[e][s] = 1
            
        for i in range(n):
            dp[i][i] = 0
        
        for k in range(n):
            for j in range(n):
                for i in range(n):
                    dp[i][j] = min(dp[i][j], dp[i][k] + dp[k][j])    
                        
    
        ans = []
        
        for i in range(n):
            s = 0 
            for j in range(n):
                s += dp[i][j] if dp[i][j] != float('inf') else 0
                
            ans.append(s)
            
        return ans
    
#Method-6
# DFS twice - first to collect the count of all subtree nodes and sum of all distances to 0. Second to use the value(s) from first step, as reference and calc the sums of other nodes.

class Solution:
    def sumOfDistancesInTree(self, n: int, edges: List[List[int]]) -> List[int]:
        count = [1]*n
        res = [0]*n
                
        g = defaultdict(list)
        
        for s,e in edges:
            g[s].append(e)
            g[e].append(s)
            
        visited = set()
        
        def dfs_count_up_to_0(node):
            visited.add(node)
            
            for c in g[node]:
                if c not in visited:
                    count[node] += dfs_count_up_to_0(c)
                    res[node] += res[c] + count[c]
            return count[node]
        
        
        def dfs_fill_up_rest(node):
            visited.add(node)
            for c in g[node]:
                if c not in visited:
                    res[c] =  res[node] - count[c] + n - count[c]
                    dfs_fill_up_rest(c)
            
        dfs_count_up_to_0(0)
        
        visited.clear()
        
        dfs_fill_up_rest(0)
        
        return res

#Q34. Number Of Ways To Reconstruct A Tree

'''

You are given an array pairs, where pairs[i] = [xi, yi], and:

There are no duplicates.
xi < yi
Let ways be the number of rooted trees that satisfy the following conditions:

The tree consists of nodes whose values appeared in pairs.
A pair [xi, yi] exists in pairs if and only if xi is an ancestor of yi or yi is an ancestor of xi.
Note: the tree does not have to be a binary tree.
Two ways are considered to be different if there is at least one node that has different parents in both ways.

Return:

0 if ways == 0
1 if ways == 1
2 if ways > 1
A rooted tree is a tree that has a single root node, and all edges are oriented to be outgoing from the root.

An ancestor of a node is any node on the path from the root to that node (excluding the node itself). The root has no ancestors.

 

Example 1:


Input: pairs = [[1,2],[2,3]]
Output: 1
Explanation: There is exactly one valid rooted tree, which is shown in the above figure.
Example 2:


Input: pairs = [[1,2],[2,3],[1,3]]
Output: 2
Explanation: There are multiple valid rooted trees. Three of them are shown in the above figures.
Example 3:

Input: pairs = [[1,2],[2,3],[2,4],[1,5]]
Output: 0
Explanation: There are no valid rooted trees.
 

Constraints:

1 <= pairs.length <= 105
1 <= xi < yi <= 500
The elements in pairs are unique.
'''

#Solution


#Method-1
# greedy

class Solution:
    def checkWays(self, pairs: List[List[int]]) -> int:
        graph = {}
        for x, y in pairs: 
            graph.setdefault(x, set()).add(y)
            graph.setdefault(y, set()).add(x)
        
        ans = 1 
        ancestors = set()
        for n in sorted(graph, key=lambda x: len(graph[x]), reverse=True): 
            p = min(ancestors & graph[n], key=lambda x: len(graph[x]), default=None) # immediate ancestor 
            ancestors.add(n)
            if p: 
                if graph[n] - (graph[p] | {p}): return 0 # impossible to have more than ancestor
                if len(graph[n]) == len(graph[p]): ans = 2
            elif len(graph[n]) != len(graph)-1: return 0
        return ans 
    
    
#Method-2

class Solution:
    def checkWays(self, pairs: List[List[int]]) -> int:
        nodes = set()
        graph = {}
        degree = {}
        for x, y in pairs: 
            nodes |= {x, y}
            graph.setdefault(x, set()).add(y)
            graph.setdefault(y, set()).add(x)
            degree[x] = 1 + degree.get(x, 0)
            degree[y] = 1 + degree.get(y, 0)
        
        if max(degree.values()) < len(nodes) - 1: return 0 # no root
        for n in nodes: 
            if degree[n] < len(nodes)-1: 
                nei = set()
                for nn in graph[n]: 
                    if degree[n] >= degree[nn]: nei |= graph[nn] # brothers & childrens
                if nei - {n} - graph[n]: return 0 # impossible
        
        for n in nodes: 
            if any(degree[n] == degree[nn] for nn in graph[n]): return 2 # brothers 
        return 1 
    
#Method-3

# recursion + bfs to find connected components.


class Solution:
    def checkWays(self, pairs: List[List[int]]) -> int:
        neighbor = defaultdict(set)
        for x,y in pairs:
            neighbor[x].add(y)
            neighbor[y].add(x)
        
        # find out all connected components among nodes
        def split(nodes, pres):
            rst = []
            seen = set()
            for n in nodes:
                if n not in seen and n not in pres:
                    tmp = set()
                    que = deque([n])
                    seen.add(n)
                    while que:
                        q = que.popleft()
                        tmp.add(q)
                        for nextnode in neighbor[q]:
                            if nextnode not in seen and nextnode not in pres:
                                que.append(nextnode)
                                seen.add(nextnode)
                    rst.append(tmp)
            return rst
            
        
        # how many ways, given node set as nodes.
        def check(nodes, pres):
            if len(nodes) == 1: return 1
            if len(nodes) == 2: return 2
            root = set()
            for n in nodes:
                if len(neighbor[n]) == len(nodes) - 1 + len(pres):
                    root.add(n)
            if not root: return 0
            elif len(root) == len(nodes): return len(root)
            pres = pres | root
            comps = split(nodes, pres)
            rst = 1
            for c in comps: rst *= check(c, pres)
                
            return rst*len(root)
        
        t =  check(neighbor.keys(), set())
        if t > 1: return 2
        return t
    
    
#Method-4

class Solution(object):
    def checkWays(self, pairs):
        def get_connected_components(nodes, graph):
            """
            nodes: A set of nodes on which connected components need to be found
            graph: A dictionary for adjacency list
            Returns: A dictionary of node sets in one component with key as component id starting from 0
            """
            idx, ret, visited = 0, dict(), set()
            def dfs(root, c_idx):
                ret.setdefault(c_idx, set()).add(root)
                visited.add(root)
                for n in graph[root]:
                    if n not in visited: dfs(n, c_idx)
            for node in nodes:
                if node not in visited:
                    dfs(node, idx)
                    idx += 1
            return ret
        ####################################################################
        graph = dict()
        for pair in pairs:
            graph.setdefault(pair[0], set()).add(pair[1])
            graph.setdefault(pair[1], set()).add(pair[0])
        def graph_validity(nodes):
            # Find root node: Node that has degree equal to len(nodes)-1
            degree_node_map = dict()
            for node in nodes:
                degree_node_map.setdefault(len(graph[node]), []).append(node)
            if len(nodes)-1 not in degree_node_map: return 0
            # Below condition only holds when we have checked that all subgraphs can be constructed.
            #if len(degree_node_map[len(nodes)-1]) >= 2: return 2
            root_node = degree_node_map[len(nodes)-1][0]
            # prune the graph, remove connections involving root node
            childrens = graph[root_node]
            for children in childrens:
                graph[children].remove(root_node)
            del graph[root_node]
            components = get_connected_components(childrens, graph)
            # For each components, check the validity
            validity = [graph_validity(components[i]) for i in components]
            if 0 in validity: return 0
            if 2 in validity: return 2
            if len(degree_node_map[len(nodes)-1]) >= 2: return 2
            return 1

        return graph_validity(set([k for k in graph]))
    
    
#Method-5

# dfs solution

# First idea we need to understand, is that A pair [xi, yi] exists in pairs if and only if xi is an ancestor of yi or yi is an ancestor of xi. Let us illustrate this on example of tree:

# 5
# | \
# 4 3
# | \
# 1 2

# We will have pairs [1, 4], [1, 5], [2,4], [2,5], [3,5], [4,5], that is all pairs with two nodes, on which is ancestor of another. What we can notice, if it is possible to create such a tree, that one node will be ancestor of all other nodes, that is in case, there will be pairs [1, 5], [2, 5], [3, 5], [4, 5].

# Now, let us go to the algorithm:

# First, create graph from our pairs array.
# Function helper(nodes) have input set of nodes and try to solve subproblem with this set.
# We discussed, that we need to find node which is connected with all other nodes, that is its degree should be equal to m = len(nodes) - 1.
# If we did not found such a node, we can immedietly return 0: it is not possible to recunstruct a tree.
# If there is such a node, let us denote it root. Actually, it can happen that there is more than one node with this property and in this case any of them can be root and if we have say U possible solution with first of them being root, that there will be exactly U possible solutions if another will be root - we can just replace one of them with another.
# Now, we clean our graph g: we remove all connections between root and all its neighbours (actually it is enough to cut only one way connections)
# Next step is to perform dfs to find connected components.
# Finally, we run our helper function on each of found components: if it happens that for some subproblem we have answer 0, it means that for original problem we also need to return 0. If 0 not here and we met 2 in our cands, than we return 2: it means, that we found 2 or more solutions for some subproblems and 1 for others, like cands = [1, 2, 1, 1, 2]. In this case, we can be sure, that we have more than 2 solutions (in fact we have 1*2*1*1*2). Finally, important point: if we have len(d[m]) >= 2, we also return 2 - see step 5.
# Complexity: this is the most interesting part. Imagine, that we have n nodes in our graph. Then on each step we split our data into several parts and run helper function recursively on each part, such that sum of sizes is equal to n-1 on the first step and so on. So, each element in helper(nodes) can be used no more than n times, and we can estimate it as O(n^2). Also, we need to consider for node in g[root]: g[node].remove(root) line, which for each run of helper can be estimated as O(E), where E is total number of edges in g. Finally, there is part, where we look for connected components, which can be estimated as O(E*n), because we will have no more than n levels of recursion and on each level we use each edge no more than 1 time. So, final time complexity is O(E*n). I think, this estimate can be improved to O(n^2), but I do not know at the moment, how to do it. Space complexity is O(n^2) to keep all stack of recursion.

class Solution:
    def checkWays(self, P):
        g = defaultdict(set)
        for u, v in P:
            g[u].add(v)
            g[v].add(u)

        def helper(nodes):
            d, m = defaultdict(list), len(nodes) - 1
            for node in nodes:
                d[len(g[node])].append(node)

            if len(d[m]) == 0: return 0
            root = d[m][0]
            
            for node in g[root]: g[node].remove(root)
            
            comps, seen, i = defaultdict(set), set(), 0
            def dfs(node, i):
                comps[i].add(node)
                seen.add(node)
                for neib in g[node]:
                    if neib not in seen: dfs(neib, i)
                        
            for node in nodes:
                if node != root and node not in seen:
                    dfs(node, i)
                    i += 1
                    
            cands = [helper(comps[i]) for i in comps]
            if 0 in cands: return 0
            if 2 in cands: return 2
            if len(d[m]) >= 2: return 2
            return 1
            
        return helper(set(g.keys()))

# Method-6
# O(ElogE) in Average | Generalized Counting

from collections import defaultdict

class Solution:
    def checkWays(self, pairs: List[List[int]]) -> int:
        G = defaultdict(set)
        for v, w in pairs:
            G[v].add(w)
            G[w].add(v)
        def solve(V):
            dt = defaultdict(set)
            n = len(V)-1
            for v in V:
                dt[len(G[v])].add(v)
            if n not in dt:
                return 0
            #set of vertices with highest degree
            W = dt[n].copy()
            for v in W:
                for w in W:
                    if v == w:
                        continue
                    if w not in G[v]:
                        return 0
                    G[v].remove(w)
            #set of adjacent vertices with a vertex that has highest degree
            X = G[next(iter(W))].copy()
            for w in W:
                if G[w] != X:
                    return 0
            for w in W:
                for v in G[w]:
                    G[v].remove(w)
            components, visited, i = defaultdict(set), set(), 0
            def dfs(v, i):
                components[i].add(v)
                visited.add(v)
                for w in G[v]:
                    if w not in visited:
                        dfs(w, i)
            for x in X:
                if x not in visited:
                    dfs(x, i)
                    i += 1
            sol = [solve(components[i]) for i in components]
            if 0 in sol:
                return 0
            if 2 in sol or len(dt[n]) > 1:
                return 2
            return 1
        return solve(set(G.keys()))
 
# Method-7
# The follwing code(solve method) solves the more general problem that counts the number of all the possible trees

from collections import defaultdict
import math

class Solution:
    def checkWays(self, pairs: List[List[int]]) -> int:
        G = defaultdict(set)
        for v, w in pairs:
            G[v].add(w)
            G[w].add(v)
        def solve(V):
            dt = defaultdict(set)
            n = len(V)-1
            for v in V:
                dt[len(G[v])].add(v)
            if n not in dt:
                return 0
            #set of vertices with highest degree
            W = dt[n].copy()
            for v in W:
                for w in W:
                    if v == w:
                        continue
                    if w not in G[v]:
                        return 0
                    G[v].remove(w)
            #set of adjacent vertices with a vertex that has highest degree
            X = G[next(iter(W))].copy()
            for w in W:
                if G[w] != X:
                    return 0
            for w in W:
                for v in G[w]:
                    G[v].remove(w)
            components, visited, i = defaultdict(set), set(), 0
            def dfs(v, i):
                components[i].add(v)
                visited.add(v)
                for w in G[v]:
                    if w not in visited:
                        dfs(w, i)
            for x in X:
                if x not in visited:
                    dfs(x, i)
                    i += 1
            res = 1
            for i in components:
                res *= solve(components[i])
            return res*math.factorial(len(dt[n]))
        sol = solve(set(G.keys()))
        return 2 if sol > 1 else sol


# Q35. Redundant Connection II
'''

In this problem, a rooted tree is a directed graph such that, there is exactly one node (the root) for which all other nodes are descendants of this node, plus every node has exactly one parent, except for the root node which has no parents.

The given input is a directed graph that started as a rooted tree with n nodes (with distinct values from 1 to n), with one additional directed edge added. The added edge has two different vertices chosen from 1 to n, and was not an edge that already existed.

The resulting graph is given as a 2D-array of edges. Each element of edges is a pair [ui, vi] that represents a directed edge connecting nodes ui and vi, where ui is a parent of child vi.

Return an edge that can be removed so that the resulting graph is a rooted tree of n nodes. If there are multiple answers, return the answer that occurs last in the given 2D-array.

 

Example 1:


Input: edges = [[1,2],[1,3],[2,3]]
Output: [2,3]
Example 2:


Input: edges = [[1,2],[2,3],[3,4],[4,1],[1,5]]
Output: [4,1]
 

Constraints:

n == edges.length
3 <= n <= 1000
edges[i].length == 2
1 <= ui, vi <= n
ui != vi
'''
#Solution 

# Method-1

# Bruteforce 

# The Union-Find solution is an implementation of a solution provided here.

# Solution:
# To solve this problem, we need to be able to determine if by removing a edge, remaining edges will create a valid tree. There are two approaches to solve this problem.

# Bruteforce:
# Start by skip each edge one at at time starting from the last edge. For each skip, check if the remanining edges make a tree by building adjacency list and make sure all nodes have no more than 1 parent. Then, run dfs on the adjacency list to check if we can visit all nodes. Since there is only one extra edge added to the tree, there will always be a node without an incoming edge when we remove an edge.

# Union-find:
# Usually union-find won't be able to find a cycle in a directed graph because if two parent nodes point to a child node, union-find will indicate a cricle if we try to union the two parent nodes.

# However, since we are working with a tree (all nodes have at most 1 parent), union-find will be able to find any cycle as long as there is no nodes with two incoming edges. Since, we are adding a single edge to the tree, there will either be a node with 2 incoming edges or all nodes have a single incoming edge.

# For the first case, we remove one incoming edge and check if the tree has a cycle. If yes, return another edge.

# For the second case, we add all edges to the union-find and return the last edge that cause a cycle.

# Complexity:
# Time: O(VE**2) for bruteforce and O(VE) for union-find
# Space: O(V + E)

# Bruteforce

from collections import defaultdict

class Solution:
    def findRedundantDirectedConnection(self, edges: list[list[int]]) -> list[int]:

        # Find numbers of vertices and edges
        V, E = max(max(edge) for edge in edges), len(edges)

        # Check if remaining edges can make a tree
        def isTree(skip):

            # Initialize the adjacency list
            adj = defaultdict(list)

            # Initialize a set to keep track of nodes that have no parent
            noParent = set(range(1, V + 1))

            # Iterate through all edges
            for i in range(E):

                # Skip an edge
                if i == skip:
                    continue

                # Find the src and dst vertices
                src, dst = edges[i]

                # If there are more than 1 incoming edges to a vertex, return False
                if dst not in noParent:
                    return False

                # Add edge to the adjacency list
                adj[src].append(dst)

                # Mark the current dst vertex as has parent
                noParent.remove(dst)

            # Use dfs to check if there is a cycle
            # Initlaize the stack and visited set
            stack = list(noParent)
            visited = set(stack)

            # Iterate until stack is empty
            while stack:

                # Pop a vertex
                vertex = stack.pop()

                # Iterate through neighboring vertices
                for nextVertex in adj[vertex]:

                    # If we visited a neighboring vertex already, there is a cycle
                    if nextVertex in visited:
                        return False

                    # Add the neighboring vertex to the stack
                    visited.add(nextVertex)

                    # Mark such vertex as visited
                    stack.append(nextVertex)

            # Check if we were able to visit all vertices
            return len(visited) == V

        # Skip all edges one a time and check if we can make a tree with reamining edges
        for i in range(E - 1, -1, -1):
            if isTree(i):
                return edges[i]
            
# Method-2      
# Union-Find

from collections import defaultdict

class Solution:
    def findRedundantDirectedConnection(self, edges: list[list[int]]) -> list[int]:

        # Implementation of union-find
        class UnionFind:
            def __init__(self):

                # A dict to keep track of roots of each node
                self.roots = {}

            # Recursively find the root node of a node
            def find(self, x):
                if self.roots.get(x, x) == x:
                    return x

                return self.find(self.roots[x])

            # Union two nodes
            def union(self, x, y):

                # Find roots of both nodes
                rootX, rootY = self.find(x), self.find(y)

                # If roots are different, union them
                if rootX != rootY:
                    self.roots[y] = rootX
                    return True

                # Else, return False
                return False

        # Find vertice that have two in-edges
        # Get the number of edges
        E = len(edges)

        # Initialize a dict to keep track of incoming edges to each vertex
        inEdges = defaultdict(list)

        # Initialize to keep track of a vertex that has two incoming edges
        twoIncomingEdges = None

        # Iterate through all edges
        for i in range(E):

            _, dst = edges[i]

            # Add the index of an edge to the dict based on the destination vertex
            inEdges[dst].append(i)

            # If a vertex has more than 1 incoming edges, save it and end the search
            if len(inEdges[dst]) == 2:
                twoIncomingEdges = inEdges[dst]
                break

        # Use union find to detect a cycle
        # Initialize the union-find
        uf = UnionFind()

        # Iterate through all edges
        for i in range(E):

            # Get the source and desitnation vertices
            src, dst = edges[i]

            # If there is a vertex with two incoming edges and the current edge is the second incoming edge of such vertex, skip it
            if twoIncomingEdges and i == twoIncomingEdges[1]:
                continue

            # Union the two vertices
            if not uf.union(src, dst):

                # If there was a vertex with two incoming edges, return the first incoming edge as skipping the second incoming edge does not remove the cycle.
                # Else, return the current edge that cause the cycle 
                return edges[i] if not twoIncomingEdges else edges[twoIncomingEdges[0]]

        # If there is no cycle, return the second incoming edge
        return edges[twoIncomingEdges[1]]
    
    
# Method-3

# Disjoint set


class GraphNode:
    def __init__(self):
        self.indegree = 0
        self.out_nodes = []

class Solution:
    def findRedundantDirectedConnection(self, edges: List[List[int]]) -> List[int]:
        # two possible additional edge position
        # 1. when the additional_edge_to_node is having two parents
        # 2. when the additional_edge_to_node is having one parent
        graph = defaultdict(GraphNode)
        additional_edge_to_node = 0
        
        for from_node, to_node in edges:
            graph[from_node].out_nodes.append(to_node)
            graph[to_node].indegree += 1
            if graph[to_node].indegree == 2:
                additional_edge_to_node = to_node
        
        nodes_len = len(graph.keys())
        # scenario 1: when additional_edge_to_node having 2 parents
        if additional_edge_to_node != 0:
            possible_additional_edges = []
            for from_node, to_node in edges:
                if additional_edge_to_node == to_node:
                    possible_additional_edges.append([from_node, additional_edge_to_node])
                        
            for possible_additional_edge in possible_additional_edges:
                dsu = DisjointSetUnion(nodes_len)
                connected_components = nodes_len
                for edge in edges:
                    # we check by ignoring each possible edge each time, 
                    # if the graph is still in one piece
                    # and a valid one, if so that is the additional edge
                    if possible_additional_edge != edge:
                        if not dsu.union(*edge):
                            connected_components -= 1
                            # we exit from current loop since it is ignoring one node
                            break
                if connected_components == nodes_len:
                    additional_edge = possible_additional_edge
            return additional_edge

        # scenario 2: when additional_edge_to_node having 2 parents
        dsu = DisjointSetUnion(nodes_len)
        for edge in edges:
            # if not able to union then it is a cycle
            if not dsu.union(*edge):
                # return the edge that creates the cycle
                return edge
            
            
# Method-4
# disjoint set union
        
class DisjointSetUnion:
    def __init__(self, n):
        self.parent = list(range(n + 1))
        self.rank = [0] * (n + 1)
        
    def find(self, node):
        if self.parent[node] != node:
            self.parent[node] = self.find(self.parent[node])
        return self.parent[node]

    def union(self, node1, node2):
        node1_abs_parent, node2_abs_parent = self.find(node1), self.find(node2)
        
        if node1_abs_parent == node2_abs_parent:
            return False
        elif self.rank[node1_abs_parent] > self.rank[node2_abs_parent]:
            self.parent[node2_abs_parent] = node1_abs_parent
        elif self.rank[node1_abs_parent] < self.rank[node2_abs_parent]:
            self.parent[node1_abs_parent] = node2_abs_parent
        else:
            self.parent[node2_abs_parent] = node1_abs_parent
            self.rank[node1_abs_parent] += 1
        return True

# Method-5

# O(N) 

class Solution:
    def findRedundantDirectedConnection(self, edges: List[List[int]]) -> List[int]:
        
        # In order to form a valid tree, we need to ensure that each of the node has only one parent and there are no cycle
        
        mem = dict()
        # find if any node has two parents
        A,B = [],[]
        for x,y in edges:
            if y in mem:
                # y has two parent
                A,B = [mem[y],y],[x,y] # List of edges
                break
            mem[y] = x
        
        
        parent = list(range(len(edges)+1))
        
        def find(x):
            if x!=parent[x]:
                parent[x] = find(parent[x])
            return parent[x]
        
        def union(x,y):
            px = find(x)
            py = find(y)
            parent[px] = py
            
        
        for x,y in edges:
            if [x,y] == B: # Ingnpre the edge B
                continue
            
            px = find(x)
            py = find(y)
            if px!=py:
                union(x,y)
                
            else:
                if A: # if A exits remove A
                    return A
                else:
                    return [x,y] # if A doesn't exits remove (x,y)
        
        return B # If no cycle detected, means B is the faulty edge


        