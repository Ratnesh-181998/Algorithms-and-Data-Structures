

#MATH Problems


# Q1 Reverse Integer

'''

Given a signed 32-bit integer x, return x with its digits reversed. If reversing x causes the value to go outside the signed 32-bit integer range [-231, 231 - 1], then return 0.

Assume the environment does not allow you to store 64-bit integers (signed or unsigned).

 

Example 1:

Input: x = 123
Output: 321
Example 2:

Input: x = -123
Output: -321
Example 3:

Input: x = 120
Output: 21
 

Constraints:

-231 <= x <= 231 - 1

'''
#Solution 

#Method-1

class Solution:
    def reverse(self, x: int) -> int:
        if x >= 2**31-1 or x <= -2**31: return 0
        else:
            strg = str(x)
            if x >= 0 :
                revst = strg[::-1]
            else:
                temp = strg[1:] 
                temp2 = temp[::-1] 
                revst = "-" + temp2
            if int(revst) >= 2**31-1 or int(revst) <= -2**31: return 0
            else: return int(revst)
        
#Method-2

class Solution:
    def reverse(self, x):
        """
        :type x: int
        :rtype: int
        """
        
        s = str(abs(x))
            
        reversed = int(s[::-1])
        
        if reversed > 2147483647:
            return 0

        return reversed if x > 0 else (reversed * -1)
    
#Method-3
"""
:type x: int
:rtype: int
"""

class Solution:
    def reverse(self, x):
        b = 2 ** 31
        neg_b = -1 * b 
    
        rev = 0 
        if x > 0:
            while x != 0:
                digit = x % 10 
                x //= 10 
                rev = rev * 10 + digit 
        else:
            x = abs(x)
            while x != 0:
                digit = x % 10 
                x //= 10 
                rev = rev * 10 + digit
            rev *= -1
        if rev > b or rev < neg_b:
            return 0 
        return rev 


#Method-4

class Solution:
    def reverse(self, x: int) -> int:
        negative = False
        if x<0:
            negative = True
        reversedInt = int(''.join(reversed([i for i in str(abs(x))])))
        if reversedInt < (-2**31) or reversedInt > (2**31):
            return 0
        return (-reversedInt) if negative else reversedInt 
 
#Method-5
# @return an integer  
class Solution:
    def reverse(self, x: int) -> int:
        a=1
        if(x<0):
            x=x*(-1)
            a=-1   
        rem=0
        while(x>0):
            rem=rem*10+(x%10)
            x=x//10
        if rem<((-2)**31) or rem>((2**31)-1):
            return 0    
        return rem*a


#Q2 Add Binary

'''
Given two binary strings a and b, return their sum as a binary string.

Example 1:

Input: a = "11", b = "1"
Output: "100"
Example 2:

Input: a = "1010", b = "1011"
Output: "10101"
 

Constraints:

1 <= a.length, b.length <= 104
a and b consist only of '0' or '1' characters.
Each string does not contain leading zeros except for the zero itself.

'''
#Solution 


#Method-1

class Solution:
    def addBinary(self, a: str, b: str) -> str:
        m,n = 0,0
        for i,c in enumerate(a):
            m += int(c) * (2**(len(a)-(i+1)))
        for i,c in enumerate(b):
            n += int(c)* (2**(len(b)-(i+1)) )
        if m==0 and n == 0:
            return "0"
        else:       
            return str(bin(m+n)).lstrip("0b")
        
#Method-2

#using bin() || bit manipulation
#Approach 1:

class Solution:
    def addBinary(self, a: str, b: str) -> str:           
        return bin(int(a,2)+int(b,2))[2:]
		
#Approach 2:

class Solution:
    def addBinary(self, a: str, b: str) -> str:
        carry=0
        ans=[]
        i=0
        while(i<len(a) or i<len(b) or carry!=0):
            x=0  #if string a is exhausted then we can take x=0 for addition 
            y=0   #if string b is exhausted then we can take y=0 for addition
			
            '''
			for eg:
			if a= 110
			   b= 10
			'''
			   
            if(i<len(a) and a[len(a)-1-i]=='1'):
                x=1
                
            if(i<len(b) and b[len(b)-1-i]=='1'):
                y=1
                
            sum1 = (x+y+carry)%2
            carry = (x+y+carry)//2
            ans.insert(0,str(sum1))
            i=i+1
            
        return "".join(ans)
 

#Method-3    
#Type-Casting

class Solution:
    def addBinary(self, a: str, b: str) -> str:
        if len(a) > len(b):
            for i in range(len(a)-len(b)):
                b = "0" + b
        if len(a) < len(b):
            for i in range(len(b)-len(a)):
                a = "0" + a
        lis1 = list(a)
        lis2 = list(b)
        s = ""
        c = 0
        print(lis1, lis2)
        for i in range(len(lis1)-1, -1, -1):
            print(c, s)
            if c == 1:
                if int(lis1[i]) == 1 and int(lis2[i]) == 1:
                    s = '1' + s
                    c = 1
                elif int(lis1[i]) == 1 or int(lis2[i]) == 1:
                    s = '0' + s
                    c = 1
                else:
                    s = '1' + s
                    c = 0
            else:
                if int(lis1[i]) == 1 and int(lis2[i]) == 1:
                    s = '0' + s
                    c = 1
                elif (int(lis1[i]) == 1 and int(lis2[i]) == 0) or (int(lis2[i]) == 1 and int(lis1[i]) == 0):
                    s = '1' + s
                    c = 0
                else:
                    s = '0' + s
                    c = 0
        res = ""
        if c:
            res = str(c)+s
        else:
            res = s
        return (res)
    
#Method-4
#Two pointer

class Solution:
    def addBinary(self, a: str, b: str) -> str:
        i = len(a) - 1
        j = len(b) - 1
        flag = 0
        res = []
        while i >= 0 and j >= 0:
            _sum = int(a[i]) + int(b[j]) + flag
            if _sum >= 2:
                _sum = _sum % 2
                flag = 1
            else:
                flag = 0
            res.append(str(_sum))
            i -= 1
            j -= 1
            
        while i >= 0:
            _sum = int(a[i]) + flag
            if _sum >= 2:
                _sum = _sum % 2
                flag = 1
            else:
                flag = 0
            res.append(str(_sum)) 
            i -= 1
                
        while j >= 0:
            _sum = int(b[j]) + flag
            if _sum >= 2:
                _sum = _sum % 2
                flag = 1
            else:
                flag = 0
            res.append(str(_sum)) 
            j -= 1
        if flag:
            res.append("1")
        return "".join(res[::-1])
    
#Method-5

#Using zero-padding and XOR operator

class Solution:
    def addBinary(self, a: str, b: str) -> str:
        delta = len(a) - len(b)
        # Make a and b have the same length by zero-padding 
        if delta > 0:
            b = delta*'0' + b
        elif delta < 0:
            a = -delta*'0' + a
        
        out = ''
        current_sum = remember = 0
        # Sum every digit from the right to the left
        for i in range(-1, -len(a)-1, -1):
            # XOR operator
            current_sum = int(a[i]) ^ int(b[i]) ^ remember
            # remember has only 2 values: 0 or 1
            remember = int((int(a[i]) + int(b[i]) + remember) >= 2)

            out = str(current_sum) + out

        if remember:
            out = '1' + out
        return out
    
    
class Solution:
    def addBinary(self, a: str, b: str) -> str:
        a = a[::-1]         #reverse both the strings
        b = b[::-1]
        i,j = 0,0
        l = []
        carry = 0
        sum1 = 0
        while (i<len(a) or j<len(b) or carry == 1):
            #checking if one of the following conditions are true
            sum1 = carry                      #always adding carry to sum as it can be 0 or 1 (if 1 then its important)
            if i<len(a):                           #if ath condition is true then add that to sum
                sum1 +=int(a[i])
            if j<len(b):                          #if bth condition is true then add that to sum
                sum1 += int(b[j])
            if sum1 >=2:                        # IF SUM IS GREATER THEN 2 THEN CARRY MUST BE 1 ELSE 0
                carry = 1
            else:
                carry = 0
            if sum1 % 2 == 0:                #IF SUM IS AN EVEN NUMBER THEN THE ANSWER MUST BE 0 ELSE 1
                l.append(0)
            else:
                l.append(1)
            i += 1
            j += 1
        temp = ''
        for i in l[::-1]:                           #REVERSING THE STRING AND THEN APPENDING TO A TEMP RETURNING IT
            temp +=str(i)
        return temp


#Q3 Palindrome Number

'''
Given an integer x, return true if x is palindrome integer.

An integer is a palindrome when it reads the same backward as forward.

For example, 121 is a palindrome while 123 is not.
 

Example 1:

Input: x = 121
Output: true
Explanation: 121 reads as 121 from left to right and from right to left.
Example 2:

Input: x = -121
Output: false
Explanation: From left to right, it reads -121. From right to left, it becomes 121-. Therefore it is not a palindrom

'''

#Solution

#Method-1

class Solution:
    def isPalindrome(self, x: int) -> bool:
        return False if x < 0 else x == int(str(x)[::-1])
    
#Method-2

class Solution:
    def isPalindrome(self, x: int) -> bool:
        a = str(x)
        if a == a[::-1]:
            return True
        return False

#Method-3
#Without converting to string (but using list)

class Solution:
    def isPalindrome(self, x: int) -> bool:
        if x < 0:
            return False
        else:
            tenth_numbers = [ ]
            while x != 0:
                tenth_numbers.append(x % 10)
                x = x // 10
        return tenth_numbers == tenth_numbers[::-1]

    
#Method-4

class Solution:
    # @return a boolean
    def isPalindrome(self, x):
        
        #negative numbers are not palindromes, return 0
        if x<0:
            return 0
        x=str(x)
        #making sure the length is greater than 1, otherwise it's always a palindrome
        while len(x)>1:
            #check the first and last digits to see if they are equal
            while x[0]==x[len(str(x))-1]:
                #if yes, take out those digits, repeat the process until there's only 1 digit left
                x=x[1:len(x)-1]
                #if there's only one or no digit left after repeatedly taking out digits, it's a palindrome
                if len(x)==1 | len(x)==0:
                    return 1
            #if the first and last digits do not equal to each other, return 0 as it's not a palindrome
            else:
                return 0
        else:
            return 1



#Q4
'''
Minimum Moves to Equal Array Elements

Given an integer array nums of size n, return the minimum number of moves required to make all array elements equal.

In one move, you can increment n - 1 elements of the array by 1.

 

Example 1:

Input: nums = [1,2,3]
Output: 3
Explanation: Only three moves are needed (remember each move increments two elements):
[1,2,3]  =>  [2,3,3]  =>  [3,4,3]  =>  [4,4,4]
Example 2:

Input: nums = [1,1,1]
Output: 0
 

Constraints:

n == nums.length
1 <= nums.length <= 105
-109 <= nums[i] <= 109
The answer is guaranteed to fit in a 32-bit integer.

'''
#Solution 

#Method-1

class Solution:
    def minMoves(self, nums: List[int]) -> int:
        return sum(nums) - len(nums) * min(nums)
        
        
#Method-2

class Solution:
    def minMoves(self, nums: List[int]) -> int:
	
        # Approach:
        # we want to make all the elements equal ; question does not 
        # say "to which element" they should be made equal so that means
        # we can "choose" to what element they all should finally reach
        
        # Choose the minimum element of the array as a starting point
        # because the statement says - 
        # we can increment all elements except one element 
        # which can be interpreted as "decreasing that one element" in each
        # move to make all the elements equal
        
        # for eg: 
        # [1,2,3] -> [1,1,3] -> [1,1,2] -> [1,1,1]
        # at each step, we decrement one element towards the smallest
        _min = min(nums)
        ans = 0
        
        # if all elements are already equal; ans = 0
        if all(ele == nums[0] for ele in nums):
            return 0
        else:
            for ele in nums:
                ans = ans + (ele - _min)
                # ele - _min because it takes ele - _min steps to make ele 
                # equal to the minimum element
            return ans
        
# TC = O(N); because we iterate through the array once
# SC = O(1); we are not using any extra space

#Method-3
class Solution:
    def minMoves(self, nums: List[int]) -> int:
        m=sum(nums)-min(nums)*len(nums)
        return(m)                           
                                  #sum+m*(n-1)=x*n
                                  #x=min+m
#Method-4

class Solution:
    def minMoves(self, nums: List[int]) -> int:
        # finding min element in array takes O(n)
        Min = min(nums)
        moves = 0
        # now we need to find the difference between each elements with the min ele and add all diff
        # will we the required result
        for n in nums:
            moves += abs(Min - n)
        return moves
    
#Method-5

# Within the first n (n = length of the array) times of adding (say it is 'times'), you will get a sum of the array such that sum % n == 0. Though 'times' may not be the answer, it is m * n (m is some integer you need to find) away from the answer.
# After step 1, the smallest number in the array is added by 'times' (you can think about why), and if it is still smaller than sum // n, it means 'times' is not the answer and you will keep adding m * n times. For how many times of n? (Or what is m?) Say after step 1, the smallest number becomes min + 'times', then m = sum_after_step1 // n - (min + 'times'). (You can think about why).

class Solution:
    def minMoves(self, nums: List[int]) -> int:
        times, n, m, s = 0, len(nums), min(nums), sum(nums)
        for times in range(n):
            if not (s + times * (n - 1)) % n:
                break;
        if (s + times * (n - 1)) // n - m > times:
            times += ((s + times * (n - 1)) // n - (m + times)) * n
        return times




#Q5 Happy Number
'''

Write an algorithm to determine if a number n is happy.

A happy number is a number defined by the following process:

Starting with any positive integer, replace the number by the sum of the squares of its digits.
Repeat the process until the number equals 1 (where it will stay), or it loops endlessly in a cycle which does not include 1.
Those numbers for which this process ends in 1 are happy.
Return true if n is a happy number, and false if not.

 

Example 1:

Input: n = 19
Output: true
Explanation:
12 + 92 = 82
82 + 22 = 68
62 + 82 = 100
12 + 02 + 02 = 1
Example 2:

Input: n = 2
Output: false

'''

#Solution 

#Method-1

class Solution:
    def isHappy(self, n: int) -> bool:
        if n == 1:
            return True
        s = set ()
        while n not in s :
            s.add(n)
            n = sum([int(i) **2 for i in str(n)])
        
        return n == 1

    
#Method-2
#Using Hashmap :

class Solution:
    def isHappy(self, n: int) -> bool:
        if n == 1:
            return True
        d = dict()
        while n != 1 :
            if n in d :
                return False
            else :
                d[n] = True
            n = sum ([int(i) **2 for i in str(n)])
        return True
    
#Method-3

class Solution:
    def isHappy(self, n: int) -> bool:
        seen = set() # to store all the sum of square if digits
        while n != 1:
            sums = sum([int(digit)**2 for digit in str(n)]) # sum of square of digits
            if sums in seen: # if the sums in present in seen then it will be a endless loop
                return False
            n = sums
            seen.add(n)
        
        return True
    
    
#Method-4    
#Recursive solution

class Solution:
    def __init__(self):
        self.memo = set()
        
    def isHappy(self, n: int) -> bool:
        if n in self.memo:
            return False
        
        if n == 1:
            return True
        
        self.memo.add(n)
        
        digits = list(str(n))
        sum_of_squared_digits = 0
            
        for num in digits:
            sum_of_squared_digits += pow(int(num), 2)
        
        return self.isHappy(sum_of_squared_digits)
    
 
#Method-5

class Solution(object):
    
    Happy = set([1])
    NotHappy = set()
    Temp = set()
    
    def isHappy(self, n):
        """
        :type n: int
        :rtype: bool
        """
        if n in self.Happy:
            self.Temp.clear()
            return True
        elif n in self.NotHappy:
            self.Temp.clear()
            return False
        else:
            self.Temp.add(n)
            result = 0
            div, mod = divmod(n, 10)
            result += mod*mod
            while div >= 10:
                div, mod = divmod(div, 10)
                result += mod*mod
            result += div*div
            if result == 1:
                self.Happy.update(self.Temp)
                self.Temp.clear()
                return True
            elif result in self.Temp:
                self.NotHappy.update(self.Temp)
                self.Temp.clear()
                return False
            else:
                return self.isHappy(result)

#Method-6

class Solution:
    def isHappy(self, n: int) -> bool:
        
        seen = set()
        
        while n != 1 and n not in seen:
            seen.add(n)
            
            t = 0
            while n > 0:
                t += (n%10)** 2
                n //= 10
            n = t
            
        return n == 1
    

#Q6 Excel Sheet Column Title
'''
Given an integer columnNumber, return its corresponding column title as it appears in an Excel sheet.

For example:

A -> 1
B -> 2
C -> 3
...
Z -> 26
AA -> 27
AB -> 28 
...
 

Example 1:

Input: columnNumber = 1
Output: "A"
Example 2:

Input: columnNumber = 28
Output: "AB"
Example 3:

Input: columnNumber = 701
Output: "ZY"
 

Constraints:

1 <= columnNumber <= 231 - 1

'''
#Solution 

#Method-1

class Solution:
    def convertToTitle(self, n: int) -> str:
        ans = ""
        
        while n:
            ans = chr(ord('A') + (n-1)%26 ) + ans
            n = (n-1)//26
        
        return ans     
    
#Method-2

class Solution:
    def convertToTitle(self, columnNumber: int) -> str:
        result = []
        while columnNumber != 0:
            d = columnNumber % 26
            if d == 0:
                d = 26
                columnNumber -= 26
            result.append(self.toString(d))
            columnNumber //= 26
        return ''.join(reversed(result))
    
    def toString(self, d):
        return chr(ord('A') + d - 1)
    
#Method-3

class Solution(object):
	def convertToTitle(self, columnNumber):
		answer =""
		while columnNumber != 0:
			index = columnNumber%26
			if index ==0:
				index = 26
			answer = chr(64+int(index)) + answer
			columnNumber -= index
			columnNumber = columnNumber/26
		return answer
    
#Method-4

#string


class Solution:
    def convertToTitle(self, columnNumber: int) -> str:
        string = "" # consider an empty string
        while columnNumber>0: 
            columnNumber-=1
            string = chr(columnNumber%26 + 65) + string  #considering the ascii values of the alphabets 
            columnNumber//=26

        return string
    
#Method-5    
#Recursion instead of loop

# At first I thought this would be as simple as converting to base 26, but figuring out where to add and subtract one was quite tricky.

class Solution(object):
    def convertToTitle(self, columnNumber):
        if columnNumber <= 26:
            return chr(ord('A') + columnNumber - 1)
        else:
            return self.convertToTitle((columnNumber-1)//26) + self.convertToTitle((columnNumber-1)%26+1)





#Q7 Missing Number
'''

Given an array nums containing n distinct numbers in the range [0, n], return the only number in the range that is missing from the array.

 

Example 1:

Input: nums = [3,0,1]
Output: 2
Explanation: n = 3 since there are 3 numbers, so all numbers are in the range [0,3]. 2 is the missing number in the range since it does not appear in nums.
Example 2:

Input: nums = [0,1]
Output: 2
Explanation: n = 2 since there are 2 numbers, so all numbers are in the range [0,2]. 2 is the missing number in the range since it does not appear in nums.
Example 3:

Input: nums = [9,6,4,2,3,5,7,0,1]
Output: 8
Explanation: n = 9 since there are 9 numbers, so all numbers are in the range [0,9]. 8 is the missing number in the range since it does not appear in nums.
 

Constraints:

n == nums.length
1 <= n <= 104
0 <= nums[i] <= n
All the numbers of nums are unique.
 

Follow up: Could you implement a solution using only O(1) extra space complexity and O(n) runtime complexity?

'''

#Solution 

#Method-1

class Solution:
    def missingNumber(self, nums: List[int]) -> int:
        # create a set which is equal to hashmap in python
        s=set(nums)
        # iterate till len nums
        for i in range (len(s)+1):
            if i not in s:
                return i
            
#Method-2

class Solution:
    def missingNumber(self, nums: List[int]) -> int: # nums = [9,6,4,2,3,5,7,0,1]
        maxx = max(nums) # 9
        full_range = set([i for i in range(maxx+1)]) # {0, 1, 2, 3, 4, 5, 6, 7, 8, 9}
        nums_set = set(nums) # {0, 1, 2, 3, 4, 5, 6, 7, 9}
        diff = full_range - nums_set # {8}
        if diff:
            return diff.pop() # 8
        return maxx+1
    
#Method-3

class Solution:
    def missingNumber(self, nums: List[int]) -> int:
        return sum(range(len(nums)+1)) - sum(nums)
    
    
#Method-4   
#Using math formula
# Final Best or Average Time Complexity:
# O(n)

# Space Complexity:
# O(1)

class Solution:
    def missingNumber(self, nums: List[int]) -> int:
        n = len(nums)
        expected = int(n * (n + 1)/2)     # O(n)
        actual = sum(nums)                # O(n)
        return expected - actual

#Method-5

class Solution(object):
    def missingNumber(self, nums):
        res = len(nums)
        
        for i in range (len(nums)):
            res += (i - nums[i])
        return res
        



#Q8. Maximum Product of Three Numbers

'''
Given an integer array nums, find three numbers whose product is maximum and return the maximum product.

Example 1:

Input: nums = [1,2,3]
Output: 6
Example 2:

Input: nums = [1,2,3,4]
Output: 24
Example 3:

Input: nums = [-1,-2,-3]
Output: -6
 

Constraints:

3 <= nums.length <= 104
-1000 <= nums[i] <= 1000

'''
#Solution

#Method-1

class Solution:
    def maximumProduct(self, nums):
        n = len(nums)
        nums.sort()
        return max(nums[0] * nums[1] * nums[n - 1], nums[n-3] * nums[n - 2] * nums[n-1])
        
#Method-2

class Solution:
    def maximumProduct(self, nums: List[int]) -> int:
        
        nums.sort(reverse=True) 
        
        tmp1 = nums[0]*nums[1]*nums[2]
        tmp2 = nums[0] * nums[-1] * nums[-2]
        
        return max(tmp1,tmp2)
 
        
#Method-3

class Solution:
    def maximumProduct(self, nums: List[int]) -> int:
        # TC = O(NlogN) because sorting the array 
        # SC = O(1); no extra space needed; sorting was done in place.
        
        # sorting the array in descending order
        nums.sort(reverse = True)
        
        # maximum product can only occur for:
        # 1. positive no * positive no * positive no
        # 2. negative no * negative no * positive no
        
        # one negative and two positives and all negatives wont give max product
        # case where all numbers in the array are negative 
        # eg : [-4,-3,-2,-1] is covered in all positives 
        
        return max(nums[0]*nums[1]*nums[2],nums[-1]*nums[-2]*nums[0])
  
#Method-4
#Heap
import heapq
class Solution:
    def maximumProduct(self, array):
        largest = heapq.nlargest(3, array)
        smallest = heapq.nsmallest(2,array)

        return max(largest[0] * largest[1] * largest[2], largest[0] * smallest[0] * smallest[1] )
    
    
#Method-5

import bisect

class Solution:
    def maximumProduct(self, nums: List[int]) -> int:
        total, negative = [], [] # Space O(3)      
        for num in nums:
            bisect.insort(total, num) # O(3)
            if len(total) > 3:
                total.pop(0)
            if num < 0:
                bisect.insort(negative, abs(num)) # O(2)
                if len(negative) > 2:
                    negative.pop(0)                
        # Candidate by multiplying max 3 nums
        res = total[-3] * total[-2] * total[-1]
        if len(negative) < 2:
            return res
        else:
            return max(res, total[-1] * negative[-2] * negative[-1])


#Q9. Power of Two
'''

Given an integer n, return true if it is a power of two. Otherwise, return false.

An integer n is a power of two, if there exists an integer x such that n == 2x.

 

Example 1:

Input: n = 1
Output: true
Explanation: 20 = 1
Example 2:

Input: n = 16
Output: true
Explanation: 24 = 16
Example 3:

Input: n = 3
Output: false
 

Constraints:

-231 <= n <= 231 - 1
 

Follow up: Could you solve it without loops/recursion?

'''

#Solution 

#Method-1

import math
class Solution:
    def isPowerOfTwo(self, n: int) -> bool:
        if n <= 0:
            return False
        a = math.log10(n)/math.log10(2)
        if a == int(a):
            return True
        return False
    
#Method-2    
class Solution:
	def isPowerOfTwo(self, n: int) -> bool:

		mx = 2**30  # 30 is the largest power of 2 inside the constraint of 2**31-1 

		return n>0 and mx%n==0
    
#Method-3
    
class Solution:
    def isPowerOfTwo(self, n: int) -> bool:
        return log(n, 2) == int(log(n, 2)) if n > 0 and n != 536870912 else True if n == 536870912 else False
    
    
#Method-4    
class Solution:
	def isPowerOfTwo(self, n: int) -> bool:
		if n<=0:
			return False
		power_of_two_set = set()
		power_of_two_set.add(1)
		x = 2
		while x <= 2**31 - 1:
			power_of_two_set.add(x)
			x *= 2
		if n in power_of_two_set: 
			return True
		return False    
    
    
#Method-5
#Bit manipulation] + Explanation

class Solution:
    def isPowerOfTwo(self, n: int) -> bool:
        if n == 0:
            return False
        return (n & -n) == n




#Q10 Encode and Decode TinyURL
'''
Note: This is a companion problem to the System Design problem: Design TinyURL.
TinyURL is a URL shortening service where you enter a URL such as https://leetcode.com/problems/design-tinyurl and it returns a short URL such as http://tinyurl.com/4e9iAk. Design a class to encode a URL and decode a tiny URL.

There is no restriction on how your encode/decode algorithm should work. You just need to ensure that a URL can be encoded to a tiny URL and the tiny URL can be decoded to the original URL.

Implement the Solution class:

Solution() Initializes the object of the system.
String encode(String longUrl) Returns a tiny URL for the given longUrl.
String decode(String shortUrl) Returns the original long URL for the given shortUrl. It is guaranteed that the given shortUrl was encoded by the same object.
 

Example 1:

Input: url = "https://leetcode.com/problems/design-tinyurl"
Output: "https://leetcode.com/problems/design-tinyurl"

Explanation:
Solution obj = new Solution();
string tiny = obj.encode(url); // returns the encoded tiny url.
string ans = obj.decode(tiny); // returns the original url after deconding it.
 

Constraints:

1 <= url.length <= 104
url is guranteed to be a valid URL.

'''
#Solution 

#Method-1

class Codec:
    
    def __init__(self):
        self.db = {}
        self.valid_chars = "abcdefghijklmnopqrstuvwxyzABCEFGHIJKLMNOPQRSTUVWXYZ0123456789"
        self.last_key = None

    def find_next_key(self, url:str) -> str:
        if not self.last_key:
            return self.valid_chars[0]
        else:
            if self.last_key[-1] != self.valid_chars[-1]:
                return self.last_key[:-1] + self.valid_chars[self.valid_chars.index(self.last_key[-1]) + 1]
            else:
                return self.last_key + self.valid_chars[0]
        
    def encode(self, longUrl: str) -> str:
        """Encodes a URL to a shortened URL.
        """
        tiny_url = self.find_next_key(longUrl) 
        self.db[tiny_url] = longUrl
        return tiny_url
            
            
    def decode(self, shortUrl: str) -> str:
        """Decodes a shortened URL to its original URL.
        """
        return self.db[shortUrl]

    
#Method-2    
class Codec:
    dict_url={}
    n=0
    def encode(self, longUrl):
        """Encodes a URL to a shortened URL.
        
        :type longUrl: str
        :rtype: str
        """
        return longUrl
        

    def decode(self, shortUrl):
        """Decodes a shortened URL to its original URL.
        
        :type shortUrl: str
        :rtype: str
        """
        return shortUrl
    
    
#Method-3
#With Sync hashmap


class Codec:
    enc_map = {}
    dec_map = {}
    
    def encode(self, longUrl: str) -> str:
        """ Encodes a URL to a shortened URL. """
        if longUrl in Codec.enc_map:
            return Codec.enc_map[longUrl]
        
        url = f'http://tinyurl.com/{len(Codec.enc_map)}'
        Codec.enc_map[longUrl] = url
        Codec.dec_map[url] = longUrl
        return url

    def decode(self, shortUrl: str) -> str:
        """ Decodes a shortened URL to its original URL. """
        return Codec.dec_map[shortUrl]
    
    
    
    
#Method-4

class Codec:
    def __init__(self):
        self.dict = {}
        self.key = 1
    def encode(self, longUrl: str) -> str:
        self.dict[self.key] = longUrl
        self.key += 1
        return self.key-1

    def decode(self, shortUrl: str) -> str:
        return self.dict[shortUrl]
    
 
#Method-5

class Codec:
    # A HashMap which will store all links maped to an integer value
    def __init__(self):
        self.dict = dict()  # hashmap
        self.key = 1      # integer encoding for a url
        
    # enocde URL : map an interger to a link and return it
    def encode(self, longUrl: str) -> str:
        self.dict[self.key] = longUrl
        self.key = self.key+1
        return self.key-1
    
    # since key of map acts as encoded URL, we will just return it's value
    def decode(self, shortUrl: str) -> str:
        return self.dict[shortUrl]
    
    
#Method-6

# https://github.com/jsgoller1/programming-problems/blob/master/leetcode/general/535-encode-and-decode-tinyurl.py
# -----------------------
# Understand / Plan

# encoding:
# - we need a (mostly) collisionless way to encode a url to a tinyurl string
#   - the actual encoding is just the URL path; we need to append or trim the "tinyurl" part.
#   - the encoding should be a hash function of some kind, ideally not too long.
# - decoding can be the path mapped to the target url in a dictionary

# encode:
#   - take md5 of string
#   - use as path for url
#   - install in dictionary
#   - return to user

# decode:
#   - get path
#   - lookup in dict
#   - return target to user




import hashlib
class Codec:
    def __init__(self):
        self.urlmap = {}

    def encode(self, longUrl):
        """Encodes a URL to a shortened URL.

        :type longUrl: str
        :rtype: str
        """
        md5 = hashlib.md5()
        md5.update(longUrl.encode())
        slug = md5.hexdigest()
        self.urlmap[slug] = longUrl
        return "http://tinyurl.com/" + slug

    def decode(self, shortUrl):
        """Decodes a shortened URL to its original URL.

        :type shortUrl: str
        :rtype: str
        """

        if shortUrl[:19] != "http://tinyurl.com/":
            return ""

        slug = shortUrl[19:]
        try:
            return self.urlmap[slug]
        except KeyError:
            return ""
        
        
        
        

# Your Codec object will be instantiated and called as such:
# codec = Codec()
# codec.decode(codec.encode(url))




#Q11 String to Integer (atoi)
'''


Implement the myAtoi(string s) function, which converts a string to a 32-bit signed integer (similar to C/C++'s atoi function).

The algorithm for myAtoi(string s) is as follows:

Read in and ignore any leading whitespace.
Check if the next character (if not already at the end of the string) is '-' or '+'. Read this character in if it is either. This determines if the final result is negative or positive respectively. Assume the result is positive if neither is present.
Read in next the characters until the next non-digit character or the end of the input is reached. The rest of the string is ignored.
Convert these digits into an integer (i.e. "123" -> 123, "0032" -> 32). If no digits were read, then the integer is 0. Change the sign as necessary (from step 2).
If the integer is out of the 32-bit signed integer range [-231, 231 - 1], then clamp the integer so that it remains in the range. Specifically, integers less than -231 should be clamped to -231, and integers greater than 231 - 1 should be clamped to 231 - 1.
Return the integer as the final result.
Note:

Only the space character ' ' is considered a whitespace character.
Do not ignore any characters other than the leading whitespace or the rest of the string after the digits.
 

Example 1:

Input: s = "42"
Output: 42
Explanation: The underlined characters are what is read in, the caret is the current reader position.
Step 1: "42" (no characters read because there is no leading whitespace)
         ^
Step 2: "42" (no characters read because there is neither a '-' nor '+')
         ^
Step 3: "42" ("42" is read in)
           ^
The parsed integer is 42.
Since 42 is in the range [-231, 231 - 1], the final result is 42.
Example 2:

Input: s = "   -42"
Output: -42
Explanation:
Step 1: "   -42" (leading whitespace is read and ignored)
            ^
Step 2: "   -42" ('-' is read, so the result should be negative)
             ^
Step 3: "   -42" ("42" is read in)
               ^
The parsed integer is -42.
Since -42 is in the range [-231, 231 - 1], the final result is -42.
Example 3:

Input: s = "4193 with words"
Output: 4193
Explanation:
Step 1: "4193 with words" (no characters read because there is no leading whitespace)
         ^
Step 2: "4193 with words" (no characters read because there is neither a '-' nor '+')
         ^
Step 3: "4193 with words" ("4193" is read in; reading stops because the next character is a non-digit)
             ^
The parsed integer is 4193.
Since 4193 is in the range [-231, 231 - 1], the final result is 4193.
 

Constraints:

0 <= s.length <= 200
s consists of English letters (lower-case and upper-case), digits (0-9), ' ', '+', '-',

'''
#Solution 

#Method-1
#Using regular expression

class Solution:
    def myAtoi(self, s: str) -> int:
        s = s.strip()
        asn = re.findall('(^[\+\-0-9][0-9]*)', s)
        try:
            result = int(''.join(asn))
            MAX_INT = 2147483647
            MIN_INT = -2147483648
            if result > MAX_INT > 0:
                return MAX_INT
            elif result < MIN_INT < 0:
                return MIN_INT
            else:
                return result
        except ValueError:
            return 0
        
#Method-2        
#solution||time & space complexity - O(n)

class Solution:
    def myAtoi(self, s: str) -> int:
        Min_int=-2**31
        Max_int=2**31-1
        ans=0
        i=0
        isnegative=1
        
        #white space
        while i<len(s) and s[i]==' ':
            i +=1
            
        #-/+ cheak
        if i<len(s) and (s[i]=='-'or s[i]=='+'):
            if s[i]=='-':
                isnegative=-1
            i+=1
          
        #cheak 0-9
        cheak=set("1234567890")
        while i<len(s) and s[i] in cheak:
            ans = (ans*10) + int(s[i])
            i+=1
        #cheak Min/Max int
        ans=isnegative*ans
        if ans<0:
            return max(Min_int,ans)
        return min(Max_int,ans)
    
    
#Method-3
# Regex ^(?: *)[+,-]?\d+ explained:

# ^ only match at the beginning
# (?: *) looks for 0 or more spaces, but doesn't include them in the found match
# [+,-]? looks for 0 or 1 sign and includes it if found
# \d+ looks for 1 or more digits (0-9) and includes them if found

import re

class Solution:
    def myAtoi(self, s: str) -> int:
        min = -2**31
        max = 2**31-1
        extract = re.compile(r'^(?: *)[+,-]?\d+')
		
		# if no matches are found search.group(0) will raise an attribute error
        try: string = extract.search(s).group(0)
        except AttributeError: string = '0'
		
        result = int(string)
        if result < min: result = min
        elif result > max: result = max
        return result
    
#Method-4

class Solution:
    def myAtoi(self, s: str) -> int:
        
        # STRIP SPACES OF THE FRONT
        s=s.lstrip()
        
        # IF STRING IS EMPTY 
        # NO REASON TO DO WORK
        if len(s) == 0:
            return 0
        
        # COUNT THE SIGN PREFIXES
        signs = 0
        for idx in [0, min(1, len(s) - 1)]:
            if s[idx] in "+-":
                signs += 1
        
        # IF MULTISIGN
        # NO REASON TO DO WORK
        if signs > 1:
            return 0
        
        # LOOP UNTIL NOT A NUMBER
        # GET THE NUMBER OF DIGITS THAT EXIST AFTER THE SIGN BEFORE A NON-INT IS FOUND
        last_index = 0
        digits = 0
        for idx in range(0 + signs, len(s)):

            if s[idx] not in '0123456789':
                break
                
            digits += 1
            last_index = idx
        
        # IF NO DIGIT FOUND IN THE ZERO POSITION
        if last_index == 0 and digits == 0:
            return 0
                
        # RETURN THE NUMBER INBETWEEN THE CONTRAINTS
        return max( -2**31, min(int(s[0:last_index + 1]), 2**31-1) )
    
    
#Method-4
class Solution:
    def myAtoi(self, s: str) -> int:
        
        i = 0
        
        tmp_s = s
        
        while i < len(s):
            if s[i] == ' ':
                tmp_s = tmp_s[1:]
            else:
                break
                
            i += 1
            
        s = tmp_s
            
        if len(s) == 1:
            if s.isdigit():
                ans = int(s)
                return ans
            else:
                ans = 0
                return ans
                
        if len(s) == 0:
            ans = 0
            return ans
        
        if ((s[0] == '-' or s[0] == '+') and s[1].isdigit()) or s[0].isdigit():
            d = re.findall(r'[+-]?\d+', s)
            
            hugou = '+'
            
            if d[0][0] == '-' or d[0][0] == '+':
                hugou = d[0][0]
                d_data = d[0][1:]
            else:
                d_data = d[0]
                
            i = 0
            
            data = 0
            
            while i < len(d_data):
                if d_data[i] != 0:
                    break
                i += 1
                
            while i < len(d_data):
                data += int(d_data[i])
                data *= 10
                i += 1
                
            data //= 10
            
            ans = int(hugou + str(data))
            
            if ans > 2**31 - 1:
                ans = 2**31 - 1
            if ans < -2**31:
                ans = -2**31
                
            return ans
        
        ans = 0
        return ans
    
#Method-5

class Solution:
    def myAtoi(self, s: str) -> int:
        sign = 1
        y = ''
        s = s.lstrip()
        n = len(s)

        for i in range(n):
            if (s[i].isdigit() == False):
                if (i == 0):
                    if (s[i] == '-'):
                        sign = -1
                        continue
                    if (s[i] == '+'):
                        continue
                break
            else:
                y += s[i]
        
        if (y == ''):
            return 0
        
        y = int(y)*sign
        y = max(y, -2**31)
        y = min(y, 2**31-1)
        return y
    
    
#Method-6
import re
class Solution(object):
    def myAtoi(self, str):
        r = re.match("[+-]?[0-9]+", str.strip())
        if not r:
            return 0
        y = int(r.group())
        if y < -2147483648:
            y = -2147483648 
        if y > 2147483647:
            y = 2147483647
        return y


#Q12 Multiply Strings
'''
Given two non-negative integers num1 and num2 represented as strings, return the product of num1 and num2, also represented as a string.

Note: You must not use any built-in BigInteger library or convert the inputs to integer directly.

 

Example 1:

Input: num1 = "2", num2 = "3"
Output: "6"
Example 2:

Input: num1 = "123", num2 = "456"
Output: "56088"
 

Constraints:

1 <= num1.length, num2.length <= 200
num1 and num2 consist of digits only.
Both num1 and num2 do not contain any leading zero, except the number 0 itself.

'''

#Solution

#Method-1

class Solution:
    def multiply(self, num1: str, num2: str) -> str:
        expression = f"{num1}*{num2}"
        res = eval(expression)
        return str(res)
 
#Method-2

class Solution:
    def multiply(self, num1: str, num2: str) -> str:
        # Reverse digits to start from end
        rnum1 = num1[::-1]
        rnum2 = num2[::-1]
        totalSum = 0
        for i in range(len(num1)):
            partialSum = 0
            # This is to get the correct trailing 0s
            partialNum = int(rnum1[i]) * pow(10, i)
            for j in range(len(num2)):
                subNum = int(rnum2[j]) * pow(10, j)
                partialSum += partialNum * subNum
            totalSum += partialSum
        return str(totalSum)

#Method-3
class Solution:
    def multiply(self, num1: str, num2: str) -> str:
        return f"{int(num1)*int(num2)}"
    
#Method-4
#O(MN) Solution

    
class Solution:
    def multiply(self, num1: str, num2: str) -> str:
		# special case: either num1 or num2 is '0', just return '0'
        if num1 == '0' or num2 == '0':
            return '0'
        
        num1 = num1[::-1]
        num2 = num2[::-1]
        result = [0] * (len(num1)+len(num2))
        carry = 0
        
        for i in range(len(num1)):
            for j in range(len(num2)):
                prod = int(num1[i]) * int(num2[j])
                newSum = result[i+j] + prod + carry
                result[i+j] = newSum % 10 
                carry = newSum // 10
            if carry != 0:
                result[i+j+1] = carry
                carry = 0
        
        result.reverse()
        return ''.join([str(n) for n in result]).lstrip('0')
    
#Method-5
class Solution:
    def multiply(self, num1: str, num2: str) -> str:
        num1_i=0
        num2_i=0
        
        int_num={'1':1,'2':2,'3':3,'4':4,'5':5,'6':6,'7':7,'8':8,'9':9,'0':0}
        
        for i in num1:
            num1_i=num1_i*10+int_num[i]          #converting num1 to int
        
        for i in num2:
            num2_i=num2_i*10+int_num[i]          #converting num2 to int
        
        num_mul=num1_i*num2_i
        out_s=str(num_mul)
        return(out_s)

#Method-6
#elementary math

class Solution:
    def multiply(self, num1: str, num2: str) -> str:
        """
		:type num1: string
		:type num2: string
		:rtype: string
		"""
        def to_int(s):
            res = 0
            mag = 1
            while s:
                c = s[-1]
                s = s[:-1]
                res += int(c)*mag
                mag *= 10
            return res
          
        res = 0
        n1 = to_int(num1)
        n2 = to_int(num2)
        l1 = reversed(num1)
        l2 = reversed(num2)
        m1 = 1
        m2 = 1
        for j, b in enumerate(l2):
            res += (int(b)*m2)*n1
            m2 *= 10
        return str(res)

#Q13. Angle Between Hands of a Clock
'''

Given two numbers, hour and minutes, return the smaller angle (in degrees) formed between the hour and the minute hand.

Answers within 10-5 of the actual value will be accepted as correct.

 

Example 1:


Input: hour = 12, minutes = 30
Output: 165
Example 2:


Input: hour = 3, minutes = 30
Output: 75
Example 3:


Input: hour = 3, minutes = 15
Output: 7.5
 

Constraints:

1 <= hour <= 12
0 <= minutes <= 59

'''
#Solution 

#Method-1
class Solution:
    def angleClock(self, hour: int, minutes: int) -> float:
        
        #Angle traversal by hourhand
        hAngle = 30*(hour%12)
        
        #Angle traversal by minuteshand
        mAngle = 6*(minutes%60)
        
        #Extra traversal by hourhand based on minutes hand
        extraAngle = (minutes/60)*30
        
        hAngle+=extraAngle
        
        #Angle difference
        diff = abs(hAngle-mAngle)
        
        #Always prefer acute angle
        return min(diff,360-diff)
    
#Method-2

#math sol 0(1)


class Solution:
    def angleClock(self, h: int, m: int) -> float:
        angleH=(((360/12)*h)+((30/60)*m))%360
        angleM=((360/60)*m)%360
        return min(abs(angleH-angleM),abs(abs(angleH-angleM)-360))
    
#Method-3
class Solution:
    def angleClock(self, hour: int, minutes: int) -> float:
        ah = ((hour % 12) * 60 + minutes) / 2
        am = minutes * 6
        res = abs(ah - am)
        return res if res <= 180 else 360 - res
    
#Method-4  
class Solution(object):
    def angleClock(self, hour, minutes):
        """
        :type hour: int
        :type minutes: int
        :rtype: float
        """
        minute_angle = minutes*6
        hour_angle = (hour%12 + minutes/60.0)*30
        
        angle = abs(hour_angle- minute_angle)
        return min(angle, 360-angle)
    
#Method-5

class Solution:
    def angleClock(self, hour: int, minutes: int) -> float:
        hours = [0,30,60,90,120,150,180,210,240,270,300,330,0]
    
        hours = hours[hour] + (minutes/2)
        minutes = (minutes / 60) * 360
    
    
        angle =  hours - minutes
        return ((min(abs(angle),abs(360-abs(angle)))))
 
#Method-6

class Solution:
    def angleClock(self, hour: int, minutes: int) -> float:
        m_stick = 6 * minutes
        h_stick = 30 * (hour % 12) + minutes / 2
        diff = abs(m_stick - h_stick)
        return diff if diff <= 180 else 360 - diff



 #Q14 Integer Break
'''

Given an integer n, break it into the sum of k positive integers, where k >= 2, and maximize the product of those integers.

Return the maximum product you can get.

 

Example 1:

Input: n = 2
Output: 1
Explanation: 2 = 1 + 1, 1 × 1 = 1.
Example 2:

Input: n = 10
Output: 36
Explanation: 10 = 3 + 3 + 4, 3 × 3 × 4 = 36.
 

Constraints:

2 <= n <= 58

'''
#Solution

#Method-1
#O(n) solution without dp
class Solution:
    def integerBreak(self, n: int) -> int:
        if n == 2:
            return 1
        
        if n == 3:
            return 2
        
        p = 1
        while n > 4:
            n -= 3
            p *= 3
        return p * n 
    
    
#Method-2
class Solution:
    def integerBreak(self, n: int) -> int:
        # for i >= 2, best_split[i] is the greatest product achievable 
        # by splitting i into at least 2 addends.
        best_split = [0, 0]
        
        for i in range(2, n + 1):
            best_split.append(0)
            for addend_1 in range(1, i//2 + 1):
                addend_2 = i - addend_1
                addend_1_value = max(addend_1, best_split[addend_1])
                addend_2_value = max(addend_2, best_split[addend_2])
                best_split[i] = max(best_split[i], addend_1_value * addend_2_value)
        
        return best_split[n]
 


#Method-3
#Solved using Bottom-Up DP + Tabulation


class Solution:
    #Time-Complexity: O(n^2)
    #Space-Complexity: O(n)
    def integerBreak(self, n: int) -> int:
        #we know we can reduce n as 
        # n
    #   /  \
    #  1   n-1
    #     /  \
    #    1   n-2
    #     ...
    
        #Basically, we can keep reducing n like this in this tree structure above!
        #This is the pattern I recognized! I recognized for given n, there are 
        #potential sums of (1, n-1), (2, n-2), (3, n-3), ..., (n//2, n//2)!
        #For each pair, I can compare the direct number with the max product decomposition
        #and take the max of two!
        
        
        #Reason for comparison: for each of the sum factor of given n, either leave it
        #undecomposed or decompose it into further sum factors if the product of sum
        #factors produce ultimately a number that exceeds the orignal sum factor! This way
        #I am maximing product contribution for each and every sum factor!
        
        #For example, for 5, we decompose it into 2 and 3, since 2*3 > 5, so it will
        #maximize our product further!
        
        #However, for 3, we don't decompose since we can maximally decompose to
        #1 and 2 but 1*2 < 3!
        
        #Do that for both numbers of each pair and take the product!
        #Whatever is largest across the pairs will be answer for given input n!
    
        dp = [-1] * (n+1)
        #add dp-base!
        dp[1] = 1
    
        #this problem has only one state parameter: the given number to start decomposing           #from!
        #iterate through each subproblem or state!
        #Bottom-Up
        for i in range(2, n+1, 1):
            upper_bound = (i // 2) + 1
            #iterate through all possible pairs!
            for j in range(1, upper_bound, 1):
                #current pair (j, i-j), which we probably already solved its subproblems!
                first = max(j, dp[j])
                second = max(i-j, dp[i-j])
                #get product for current pair!
                sub_ans = first * second
                #compare current pair's product against built up answer maximum!
                dp[i] = max(dp[i], sub_ans)
    
        #then, once we are done, we can return dp[n]!
        return dp[n]
    
    
##Method-4

# The constraint 2<=n<=58 indicates that we can use dynamic programming to solve this problem. I use an array named dp to store the results, where dp[i] is the maximum number that integer i can achieve by breaking and multiplying. Note that dp[i] may be smaller than i (which means no breaking. E.g. 3> dp[3]= 1*2 = 2), we need to add this check in the rule.
# Here is the rule:
# dp[i] = max(dp[i], max((i-j)\*j, dp[i-j]\* j )), for all j < i


class Solution:
    def integerBreak(self, n: int) -> int:
        dp = [0] * (n + 1)
        dp[1] = 1
        for i in range(2, n + 1):
            for j in range(1, i):
                dp[i] = max(dp[i], max(j * dp[i - j], j * (i - j)))
        return dp[n]
    
    
 
#Method-5

class Solution:
    def integerBreak(self, n: int) -> int:
        dp = [1] * (n + 1)
        # for n = 1 and n = 2, result is 1, so we start from n = 3
        for i in range(3, n+1):
			# j*(i-j) are same as (i-j)*j 
			# we only iterate through the first half part
            for j in range(1, i//2 + 1): 
                dj = max(dp[j], j)
                diminusj = max(dp[i-j], i-j)
                dp[i] = max(dp[i], dj * diminusj)
        return dp[-1]
    
 

#Method-6 (Output Limit Exceeded)
# Dynamic Programming| Recursion
# Dynamic Programming

class Solution:
    def integerBreak(self, n: int) -> int:
        
        if n == 2:
            return 1
        
        dptable = [1]*(n+1)
        dptable[2] = 2
        
        for i in range(3,n+1):
            if i == n:
                max_in = n-1
            else:
                max_in = i
            for j in range(1,i):
                max_in = max(dptable[i-j]*dptable[j], max_in)
                
            dptable[i] = max_in
            
        return dptable[-1]
    
    
# Recursion

class Solution:
    def integerBreak(self, n: int) -> int:

        res = [0]
        def helper(pos, sum1):
            if pos >n :
                return 
            
            if pos == n:
                res[0] = max(res[0], sum1)
                return 
            
            for i in range(1, n):
                print(i)
                helper(pos+i, sum1*i)

        helper(0, 1)
        return res[0]

#Q15 Valid Square

'''
Given the coordinates of four points in 2D space p1, p2, p3 and p4, return true if the four points construct a square.

The coordinate of a point pi is represented as [xi, yi]. The input is not given in any order.

A valid square has four equal sides with positive length and four equal angles (90-degree angles).

 

Example 1:

Input: p1 = [0,0], p2 = [1,1], p3 = [1,0], p4 = [0,1]
Output: true
Example 2:

Input: p1 = [0,0], p2 = [1,1], p3 = [1,0], p4 = [0,12]
Output: false
Example 3:

Input: p1 = [1,0], p2 = [-1,0], p3 = [0,1], p4 = [0,-1]
Output: true
 

Constraints:

p1.length == p2.length == p3.length == p4.length == 2
-104 <= xi, yi <= 104
'''

#Solution

#Method-1
#Using a dictionary

class Solution:
    def validSquare(self, p1: List[int], p2: List[int], p3: List[int], p4: List[int]) -> bool:
        points = (p1, p2, p3, p4)
        
        # compute distance between all points
        distance_count = defaultdict(int)
        for i in range(4):
            for j in range(i + 1, 4):
                distance = sqrt((points[i][0] - points[j][0])**2 + (points[i][1] - points[j][1])**2)
                # only increase count if the points are not the same
                if distance > 0:
                    distance_count[distance] += 1
                
        # a square has 4 sides and 2 diagonals that are of the same size
        if 4 in distance_count.values() and 2 in distance_count.values():
            return True
        
        return False
    
#Method-2

class Solution:
    def validSquare(self, p1: List[int], p2: List[int], p3: List[int], p4: List[int]) -> bool:
        def dist(x,y):
            return ((x[0]-y[0])**2+(x[1]-y[1])**2)
		# edge case: make sure no identical points
        if p1==p2 or p2==p3 or p3==p4 or p4==p1:
            return False
        pts = [p1,p2,p3,p4]
        pts.sort()
        # after sorting, p1p2, p2p4, p3p4, p1p3 must be edges, p1p4, p2p3 must be diagonals
        edge1 = dist(pts[0],pts[1])
        edge2 = dist(pts[1],pts[3])
        edge3 = dist(pts[3],pts[2])
        edge4 = dist(pts[2],pts[0])
        diag1 = dist(pts[0],pts[3])
        diag2 = dist(pts[1],pts[2])
        if edge1==edge2 and edge2==edge3 and edge3==edge4 and edge4==edge1:
            if diag1==diag2:
                return True
        return False
    
    
#Solution that not universally correct:

class Solution:
    def validSquare(self, p1: List[int], p2: List[int], p3: List[int], p4: List[int]) -> bool:
        def dist(x,y):
            return ((x[0]-y[0])**2+(x[1]-y[1])**2)
        if p1==p2 or p2==p3 or p3==p4 or p4==p1:
            return False
        pts = [p1,p2,p3,p4]
        s = []
        # calculate all combinations of length
        # for a valid square, it should have four equal length edges and two equal-length diagonals
        for i in range(len(pts)):
            for j in range(i, len(pts)):
                if i!=j:
                    s.append(dist(pts[i],pts[j]))
        s.sort()
        if s[0]==s[1] and s[1]==s[2] and s[2]==s[3] and s[3]==s[0]:
            if s[4]==s[5]:
                return True
  
        return False

# The above solution only works when the input is integer.
# If we have double numbers for points : [-1,0], [1,0], [0, sqrt(3)], [0, 2+sqrt(3)]
# it is not a square, though the above will return True.


#Method-3
#3 points make up a Isosceles Right Triangle

class Solution(object):
    def validSquare(self, p1, p2, p3, p4):
        """
        :type p1: List[int]
        :type p2: List[int]
        :type p3: List[int]
        :type p4: List[int]
        :rtype: bool
        """
        def distance(p1, p2):
            return (p1[0] - p2[0]) ** 2 + (p1[1] - p2[1]) ** 2
        def foo(p1, p2, p3):
            arr = [distance(p1, p2), distance(p2, p3), distance(p3, p1)]
            if 0 in arr:
                return False
            if arr[0] == arr[1] and 2 * arr[0] == arr[2]:
                return True
            if arr[1] == arr[2] and 2 * arr[1] == arr[0]:
                return True
            if arr[2] == arr[0] and 2 * arr[2] == arr[1]:
                return True
            return False
        return foo(p1, p2, p3) and foo(p1, p2, p4) and foo(p1, p3, p4) and foo(p2, p3, p4)
 

#Method-4
#using Dictionary


from collections import Counter
class Solution:
    def validSquare(self, p1: List[int], p2: List[int], p3: List[int], p4: List[int]) -> bool:
        if p1== p2 or p1 ==p3 or p1 == p4 or p2 ==p3 or p2==p4 or p3 ==p4:
            return False
        
        d1 = (p1[0]-p2[0])**2 + (p1[1]-p2[1])**2
        d2 = (p1[0]-p3[0])**2 + (p1[1]-p3[1])**2
        d3 = (p1[0]-p4[0])**2 + (p1[1]-p4[1])**2
        d4 = (p2[0]-p3[0])**2 + (p2[1]-p3[1])**2
        d5 = (p2[0]-p4[0])**2 + (p2[1]-p4[1])**2
        d6 = (p3[0]-p4[0])**2 + (p3[1]-p4[1])**2
        
        lengths = [d1, d2, d3, d4, d5, d6]
        
        LenDict = Counter(lengths)
        
        if len(LenDict) == 2:    # Only edges or diagornals so two possible lengths only
            return True
        else:
            return False
 

#Method-5
class Solution:
    def validSquare(self, p1: List[int], p2: List[int], p3: List[int], p4: List[int]) -> bool:
        def square_distance(x, y):
            return (x[0]-y[0]) ** 2 + (x[1]-y[1])**2
        check = set()
        check.add((p1[0], p1[1]))
        check.add((p2[0], p2[1]))
        check.add((p3[0], p3[1]))
        check.add((p4[0], p4[1]))
        if len(check) != 4:
            return False
        
        dist = set()
        
        for p in [p2, p3, p4]:
            dist.add(square_distance(p1, p))
        for p in [p1, p3, p4]:
            dist.add(square_distance(p2, p))
        for p in [p1, p2, p4]:
            dist.add(square_distance(p3, p))
        for p in [p1, p2, p3]:
            dist.add(square_distance(p4, p))
            
        print(dist)
        return len(dist) == 2
    
    
    
#Method-6    
# 4 eq-len edges + 2 eq-len diagonals 

class Solution:
    def validSquare(self, p1, p2, p3, p4):
        def dSquareSum(a, b):
                return (a[0] - b[0])**2 + (a[1] - b[1])**2 # doing sqrt is unnecessary
        sq_sums = {}
        for (a, b) in [(p1, p2), (p1, p3), (p1, p4), (p2, p3), (p2, p4), (p3, p4)]:
            dss = dSquareSum(a, b)
            if dss in sq_sums: sq_sums[dss] += 1
            else: sq_sums[dss] = 1
                
        sqlen_edge, sqlen_diag = min(sq_sums.keys()), max(sq_sums.keys())
        return sq_sums[sqlen_edge] == 4 and sq_sums[sqlen_diag] == 2
	
	# check if right angle
	# return sq_sums[sqlen_edge] == 4 and sqlen_edge*2 == sqlen_diag 


#Q16 The kth Factor of n
'''
You are given two positive integers n and k. A factor of an integer n is defined as an integer i where n % i == 0.

Consider a list of all factors of n sorted in ascending order, return the kth factor in this list or return -1 if n has less than k factors.

 

Example 1:

Input: n = 12, k = 3
Output: 3
Explanation: Factors list is [1, 2, 3, 4, 6, 12], the 3rd factor is 3.
Example 2:

Input: n = 7, k = 2
Output: 7
Explanation: Factors list is [1, 7], the 2nd factor is 7.
Example 3:

Input: n = 4, k = 4
Output: -1
Explanation: Factors list is [1, 2, 4], there is only 3 factors. We should return -1.
 

Constraints:

1 <= k <= n <= 1000
 

Follow up:

Could you solve this problem in less than O(n) complexity?
'''
#Solution 


#Method-1
#Quick Select || O(N^(1/2))

class Solution:
    def kthFactor(self, n: int, k: int) -> int:
        
        factors = []

        
        for i in range(1, int(n**0.5)+1):
            
            if n % i == 0:
                
                q = n // i
                
                if i == q:
                    factors.append(i)
                else:
                    factors.append(i)
                    factors.append(q)

                
        if k > len(factors):
            return -1
        
        self.quick_select(0, len(factors)-1, factors, k-1)
        
        return factors[k-1]
    
    def quick_select(self, l, r, factors, k):
        
        pivot = factors[r]
        p = l
        
        for i in range(l, r):
            
            if factors[i] <= pivot:
                factors[i], factors[p] = factors[p], factors[i]
                p += 1
        
        factors[p], factors[r] = factors[r], factors[p]
        
        if p < k:
            
            self.quick_select(p+1, r, factors, k)
            
        elif p > k:
            
            self.quick_select(l, p-1, factors, k)
            
        else:
            
            return k
        
#Method-2

class Solution:
    def kthFactor(self, n: int, k: int) -> int:
        left, right, i = [], [], 1
        while i ** 2 < n:
            if not n % i:
                left.append(i)
                right.append(n // i)
            i += 1    
        res = left + [i] * bool(i ** 2 == n) + right[::-1]
        return res[k - 1] if k <= len(res) else -1
 

#Method-3

class Solution:
    def kthFactor(self, n: int, k: int) -> int:
        count=0
        for i in range(1,n+1):
            if n%i==0:
                count+=1
                if count==k:
                    return i
        return -1 
    
#Method-4    
class Solution:
    def kthFactor(self, n: int, k: int) -> int:
        factor=[x for x in range(1,n+1) if (n%x==0)] 
        try:
            return(factor[k-1])
        except:
            return(-1)
        
        
#Method-5           
class Solution:
    def kthFactor(self, n: int, k: int) -> int:
        
        factors = []
        for whole_number in range(1, n + 1):
            if n % whole_number == 0:
                factors.append(whole_number)
        return factors[k-1] if k-1<=len(factors)-1 else -1
 

#Method-6      
class Solution(object):
    def kthFactor(self, n, k):
        l = []; i=1
        while len(l) <= k and i <= n:
            if n%i == 0:
                l.append(i)
            i+=1
        return l[k-1] if len(l)>= k else -1

        """
        :type n: int
        :type k: int
        :rtype: int
        """

 #Q17 Basic Calculator
 '''

 Given a string s representing a valid expression, implement a basic calculator to evaluate it, and return the result of the evaluation.

Note: You are not allowed to use any built-in function which evaluates strings as mathematical expressions, such as eval().

 

Example 1:

Input: s = "1 + 1"
Output: 2
Example 2:

Input: s = " 2-1 + 2 "
Output: 3
Example 3:

Input: s = "(1+(4+5+2)-3)+(6+8)"
Output: 23
 

Constraints:

1 <= s.length <= 3 * 105
s consists of digits, '+', '-', '(', ')', and ' '.
s represents a valid expression.
'+' is not used as a unary operation (i.e., "+1" and "+(2 + 3)" is invalid).
'-' could be used as a unary operation (i.e., "-1" and "-(2 + 3)" is valid).
There will be no two consecutive operators in the input.
Every number and running calculation will fit in a signed 32-bit integer.

 '''

#Solution

#Method-1

# dfs without stack solution with explanation

# dfs only without using stack to store temp number
# calculate((5+(1+2+40)-6)+20) = calculate(5+(1+2+40)-6) + 20
# =  (5 + calculate(1+2+40) - 6) + 20 = (5 + 43 -6) + 20 = 62
# becuase there only have substraction and addition, is no precedence between calculation operators, so we maybe not to use stack to store temp number.

# the idea is
# if we meet (, find the number of expression first using dfs, and return number and where the expression (expression) end (return the location of )).

# if meet calculation operators, use a variable to control doing addition or substraction with next number.

# if meet number, just calculate how big a consecutive number is, and add to/substact from ans

# tc is O(N), every sc of dfs is O(1), dfs probably is called N times, total sc probably is O(N)


class Solution:
    def calculate(self, s: str) -> int:
        def dfs(i):
            ans, sign = 0, 0
            while i < len(s):
                if s[i] == '(':
                    end, sub = dfs(i+1)
                    ans = ans + sub if sign == 0 else ans - sub
                    i = end
                elif s[i] == ')':
                    return i, ans
                elif s[i] == '+':
                    sign = 0
                elif s[i] == '-':
                    sign = 1
                elif ord('0') <= ord(s[i]) <= ord('9'):
                    num = 0
                    while i+1 < len(s) and ord('0') <= ord(s[i+1]) <= ord('9'):
                        num = num * 10 + int(s[i])
                        i += 1
                    num = num * 10 + int(s[i])
                    ans = ans + num if sign == 0 else ans - num
                i += 1
            return i, ans
        _, ans = dfs(0)
        return ans
    
    
#Method-2
# optimized, no recursive

# python solution learnt from others, modified for easy understand, optimized stack only store statuses

# stack store the current big status that should be applied to each operation inside the '( xxxx )'
# when store in stack, consider the current level status, and the operator before ( .
# when calculate, consider the current level status, and current operator to be executed
# similar to a xor ⊕ logic
# for example, s = ( a - ( b- ( c-d))), after we apply a total status: +( a - ( b- ( c-d)))
# total basic is ['+']
# everything in level a should be with +, this time stack['+', '+'], top is '+'
# everything in level b should be with -, this time stack['+', '+', '-'], top is '-'
# everything in level c-d should be with -, this time stack['+', '+', '-', '+'], top is '+', this is flipped from '-' because we meet a new'-'
# optimized

class Solution:
    def calculate(self, s: str) -> int:

        res = 0
        num = 0
        operator = '+'
        stack = ['+'] # deal with the end, only store the status before (
        
        def execute_operator(stack, operator, num):
            current_status = stack[-1]
            if operator == current_status:   # before( and current ope ++ or --
                temp = num
            else:# +- or -+
                temp = -num
            return temp
        
        def calculate_current_substring_status(stack, operator):
            current_status = stack[-1]
            if operator == current_status:   # before( and current ope ++ or --
                temp = '+'
            else:# +- or -+
                temp = '-'
            return temp
        
        for char in s+"+":
            # print(res, num, operator, stack)
            if char == ' ':
                continue
            elif char.isdigit():
                num = 10*num + int(char)
            elif char in "+-":
                res += execute_operator(stack, operator, num)
                operator = char
                num = 0
            elif char == "(":
                stack.append(calculate_current_substring_status(stack,operator))
                operator = '+'
            elif char == ")":
                res += execute_operator(stack, operator, num)
                # print(stack, operator, num)
                num = 0
                stack.pop()
        return res
    
    
#Method-3
#O(n) | Recursive 

class Solution:
    def calculate(self, expression: str) -> int:
        #recurse when brackets encountered
        def helper(s,index):
            result = 0
            sign = 1
            currnum = 0
            i = index
            while i<len(s):
                c = s[i]
                if c.isdigit():
                    currnum = currnum*10+int(c)
                elif c in '-+': #update the sign
                    result += sign*currnum
                    sign = 1 if c=='+' else -1
                    currnum = 0
                elif c == '(': #pause and call helper for the next section
                    res, i = helper(s, i+1)
                    result += sign*res
                elif c == ')': #return results, index to resume to caller
                    result += sign*currnum
                    break
                i+=1
            #return result and current index
            return result, i
                
        if not expression:
            return 0
        #enclose input with brackets and call helper
        return helper('('+expression+')', 0)[0]
    
    
    
#Method-4
#Using stack ||O(n) Time Complexity

class Solution:
    def calculate(self, s: str) -> int:
        curr,output,sign,stack = 0,0,1,[]
        
        for ch in s:
            if ch.isdigit():
                curr = curr * 10 + int(ch)
            
            elif ch == '+':                
                output += sign * curr              
                sign = 1 
                curr = 0
                
            elif ch == '-':
                output += sign * curr
                sign = -1
                curr  = 0
            
            elif ch == '(':
                #push the result and then the sign
                stack.append(output)
                stack.append(sign)
                sign = 1
                output = 0
            
            elif ch == ')':
                output += sign * curr
                output *= stack.pop()
                output += stack.pop()
                curr = 0
        return output + sign*curr
    
    
#Method-5
#with stack
class Solution(object):
    def calculate(self, s):
        nums = []
        sign = 1
        num = 0
        rst = 0
    
        for c in s:
            if c.isdigit():
                num = num*10 + int(c)
                continue
            rst += sign*num
            num = 0
        
            if c == "-": sign = -1
            elif c == "+": sign = 1
            elif c == "(":
                nums.append(rst)
                nums.append(sign)
                sign = 1
                rst = 0
            elif c == ")":
                rst *= nums.pop()
                rst += nums.pop()

        return rst + sign * num
    
#Method-6    Time Limit Exceeded 
# Using stack with no fancy sign stuff, which should also works fir * /

# Idea is base on the way to write a Interpreter
# the first thing we need to do it clean up the data:

# 1+1   => 1 + 1
# (1+1) => ( 1 + 1 )
# ((1) + (2))   => ( ( 1 ) + ( 2) )

# s = s.replace("+",' + ').replace("-",' - ').replace("(",' ( ').replace(")",' ) ').split(" ")
# the rule is

# if the one i get is number
# => check to see if the prev one a op( + -)
# => True : then the stack should look like [num1, +/- , current num] , then we can add/sub num1 on current_num
# => False : it is "(" as "(4 +..", this means current number is num1, we need wait for num2

# if the one I get is "("
# => continue, nothing can be eval over here

# if the one I get is ")"
# => stack should look like [..... , "(" , num1 , ")"] , then we can just remove "(" and ")", keep num1

# if the one I get is op(+ -):
# => that means the prev I got is num1, then continue wait for num2

# then think about some sample case:

# 1         => [1]  => return 1
# (1+(4+5+2))-3 =>
# ['(']
# ['(', '1']
# ['(', '1', '+']
# ['(', '1', '+', '(']
# ['(', '1', '+', '(', '4']
# ['(', '1', '+', '(', '4', '+']
# ['(', '1', '+', '(', '4', '+', '5']
# ['(', '1', '+', '(', '9', '+']
# ['(', '1', '+',  '(', '9', '+', '2']
# ['(', '1', '+',  '(', '11' ]
# ['(', '1', '+', '(', '11', ')']
# ['(', '1', '+', '11']
# ['(', '12']
# ['(', '12', '-']
# ['(', '12', '-', '3']
# ['(', '9', ')']
# ['9']


class Solution:
    def eval(self,stack):
        if len(stack) < 3:
            return
        if stack[-1] == "(":
            return
        if stack[-1] == ")":
            stack.pop()
            num = stack.pop()
            stack.pop()
            stack.append(num)
            self.eval(stack)
            return
        if stack[-1] in "+-":
            return
        else:
            if stack[-2] == "+":
                num1 = int(stack.pop())
                stack.pop()
                num2 = int(stack.pop())
                stack.append(str(num1+num2))
            elif stack[-2] == "-":
                num1 = int(stack.pop())
                stack.pop()
                num2 = int(stack.pop())
                stack.append(str(num2-num1))

    def calculate(self, s):
        """
        :type s: str
        :rtype: int
        """
        stack = []
        # clean the data
        s = s.replace("+",' + ').replace("-",' - ').replace("(",' ( ').replace(")",' ) ').split(" ")
        for i in s:
            if not i:
                continue
            stack.append(i)
            print(stack)
            self.eval(stack)
        # I do not think it is necessary.. but , just in case 
        while len(stack) != 1:
            self.eval(stack)
        return stack[0]


#Q18 Max Points on a Line
'''
Given an array of points where points[i] = [xi, yi] represents a point on the X-Y plane, return the maximum number of points that lie on the same straight line.

Example 1:


Input: points = [[1,1],[2,2],[3,3]]
Output: 3
Example 2:


Input: points = [[1,1],[3,2],[5,3],[4,1],[2,3],[1,4]]
Output: 4
 

Constraints:

1 <= points.length <= 300
points[i].length == 2
-104 <= xi, yi <= 104
All the points are unique.

'''
#Solution
#Method-1
#Using dictionary
class Solution:
    def maxPoints(self, points: List[List[int]]) -> int:
        map1 = {tuple(i):{} for i in points}
        for i in points:
            for j in points:
                if(i!=j):
                    slope = None
                    if(i[0]!=j[0]):
                        slope = (j[1]-i[1])/(j[0]-i[0])
                    map1[tuple(i)][slope]=map1[tuple(i)].get(slope,[])+[j]
        res = 0
        for i in map1.values():
            for j in i.values():
                res = max(res,len(j))
        return res+1

    
#Method-2
#using hash table 

class Solution:
    def maxPoints(self, points: List[List[int]]) -> int:
        dc = dict() # dictionary to store lines
        res = 0
        for i in range(len(points)):
            for j in range(i):
                # for each pair of points:
                
                key = None
                
                if points[i][0] == points[j][0]: # if c coordinates are equal, then use the x value as a key,
                # because a will be equal to infinity in this case
                    key = (points[i][0],)
                else:
                    # else we difine a line with 2 numbers: a and b from the line's equation: ax+b=y
                    
                    # the formula of a: a=(y1-y2)/(x1-x2)
                    a = (points[i][1]-points[j][1])*10000//(points[i][0]-points[j][0])
                    # a should be float (not integer) from the formula,
                    # but using a float as dictionatry key is not safe, as float is not absolutely presize.
                    # we could just use integer (floor) divition, however in this case the a will not be accurate.
                    # So we multiply it by 10000 first, pulling 4 digits after the dot.
                    
                    # the formula for b is b=y-ax
                    # however, remember that a we found is not accurate, so just paste the formula for a:
                    # b = y1 - (y1-y2)/(x1-x2) * x1
                    # always multiply before dividing, because division will give not accurate number, 
                    # and it will be also multiplied, meaning that error will be multiplied.
                    # Similarly, always do +/- operations before division, for that
                    # we need to use common divisor.
                    # And similarly to a, multiply by 10000.
                    b = (points[i][1]*(points[i][0]-points[j][0]) - (points[i][1]-points[j][1])*points[i][0])*10000//(points[i][0]-points[j][0])
                    
                    # use a and b as a key
                    key = (a, b)
                if key not in dc:
                    dc[key] = 1
                else:
                    dc[key] += 1
                res = max(res, dc[key])
        
        # res here will contain repetions:
        # For example, if we have 4 points, there are 6 pairs. So the res will be 6, because we count each pair.
        # The number of all possible pairs from n points: c = n!/(2!*(n-2)!) = n * (n-1) / 2
        # we need to find n:
        # 2c = n^2 - n
        # n^2 - n - 2c = 0
        # Applying discriminant rule:
        # n = (1 +/- sqrt(1+8c)) / 2
        # We use only + sign, because - will result in negative result
        return (1 + int(sqrt(1+8*res))) // 2
    
    
#Method-3   
#Counting Lines in dict
# Count number of lines by slope a and y-axis intersection b. If there are n "lines" in a group, then there are ans points on the line, where n = ans*(ans-1)//2

class Solution:
    def maxPoints(self, points: List[List[int]]) -> int:
        """
            #math
        """
        def gcd(a,b):
            while a:
                a,b = b%a,a
            return b

        def slope(p1,p2):
            x1,y1 = p1
            x2,y2 = p2
            if x1 == x2:
                return (x1,None)
            else:
                g = gcd(y2-y1,x2-x1)
                return ((y2-y1)//g,(x2-x1)//g)

        n = len(points)
        slopeDict = {}
        ans = 0
        for i in range(n-1):
            for j in range(i+1,n):
                a = slope(points[i],points[j])
                if a not in slopeDict:
                    slopeDict[a] = defaultdict(int)
                if not a[1]:
                    b = None
                else:
                    b = points[i][1] - points[i][0]*a[0]/a[1]
                slopeDict[a][b]+=1
                ans = max(ans,slopeDict[a][b])

        return math.isqrt(2*ans)+1
                
        
        
#Method-4        
#Solution using HashMap

class Solution:
    def maxPoints(self, points: List[List[int]]) -> int:
        d = {}
        Max = 0
        for i in range(len(points)-Max-1):
            i_max = 0
            x1,y1 = points[i]
            for j in range(i+1,len(points)):
                x2,y2 = points[j]
                if x2 == x1:
                    slope = 100000001
                else:
                    slope = (y2 - y1) / (x2 - x1)
                if slope in d:
                    d[slope] += 1
                else:
                    d[slope] = 1
                i_max = i_max if i_max > d[slope] else d[slope]
            d.clear()
            Max = Max if Max > i_max else i_max
        return Max + 1
 
#Method-5
class Solution:
    def maxPoints(self, points: List[List[int]]) -> int:
        if len(points) == 1:
            return 1
        lines = {}
        for i in range(len(points)-1):
            for j in range(i+1, len(points)):
                if points[j][0] == points[i][0]:
                    m = '*'
                    b = points[j][0]
                else:
                    m = (points[j][1] - points[i][1]) / (points[j][0] - points[i][0])
                    b = points[i][1] - m * points[i][0]
                if (m,b) not in lines:
                    lines[(m,b)] = set()
                lines[(m,b)].add((points[i][0], points[i][1]))
                lines[(m,b)].add((points[j][0], points[j][1]))
                
        max_yet = 0
        for key, val in lines.items():
            max_yet = max(max_yet, len(val))
        return max_yet


#Q19 Permutation Sequence
'''
The set [1, 2, 3, ..., n] contains a total of n! unique permutations.

By listing and labeling all of the permutations in order, we get the following sequence for n = 3:

"123"
"132"
"213"
"231"
"312"
"321"
Given n and k, return the kth permutation sequence.

 

Example 1:

Input: n = 3, k = 3
Output: "213"
Example 2:

Input: n = 4, k = 9
Output: "2314"
Example 3:

Input: n = 3, k = 1
Output: "123"
 

Constraints:

1 <= n <= 9
1 <= k <= n!

'''
#Solution

#Method-1

class Solution:
    def getPermutation(self, n: int, k: int) -> str:
        ans = ''
        fact=1
        num = []
        for i in range(1,n):
            num.append(i)
            fact = fact*i
        num.append(n)
        k = k-1
        while True:
            ans += str(num[int(k/fact)])
            num.pop(int(k/fact))

            if len(num)==0:
                break

            k = k%fact
            fact = fact/len(num)

        return ans
    
#Method-2

# O(n*k) next permutation k times


class Solution:
    def getPermutation(self, n: int, k: int) -> str:
        
        def nextPermutation(nums):
            i=len(nums)-1
            while i>0 and nums[i-1]>=nums[i]:
                i-=1
            if i==0: return []
            k=i-1
            j=len(nums)-1
            while nums[k]>=nums[j]:
                j-=1
            nums[k],nums[j]=nums[j],nums[k]
            l,r=k+1,len(nums)-1
            while l<r:
                nums[l],nums[r]=nums[r],nums[l]
                l+=1
                r-=1
            return nums
        
        cur=[i for i in range(1,n+1)]
        for _ in range(k-1):
            cur=nextPermutation(cur)
        return ''.join(str(el) for el in cur)
    
    
    
#Method-3

from itertools import permutations
class Solution:
    def getPermutation(self, n: int, k: int) -> str:
        l=list(permutations(range(1, n+1)))
        r=''
        for i in l[k-1]:
            r=r+str(i)
        return r

    
#Method-4        
#O(N^2) Time and O(N) Space

class Solution:
    def factorial(self,n):
        result = 1
        count = 1
        while count <= n:
            result *= count
            count += 1
        return result
    def getPermutation(self, n: int, k: int) -> str:
        #we get the ith digit of our answer by comparing (n-i-1)! value with k that is left
        result = []
        count = 0
        digits = 0
        digitTaken = [False for i in range(n)]
        while digits < n:
            val = self.factorial(n-digits-1)
            digitVal = ((k-count-1) // val)+1
            #we need to find the digitVal th value that is not taken
            taken = 0
            value = -1
            index = 0
            while taken < digitVal:
                if not digitTaken[index]:
                    taken += 1
                index += 1
            value = index
            digitTaken[value-1] = True
            result.append(str(value))
            count += (digitVal-1) * val
            digits += 1
        return ''.join(result)
    
#Method-5

class Solution:
    def getPermutation(self, n: int, k: int) -> str:
        
        def helper(nums, path, k):
 
            if k == 0:
                return path + nums
            
            fact = math.factorial(len(nums)-1)
            num_i = k//fact
            path += nums[num_i]
            k = k % fact
            return helper(nums[:num_i] + nums[num_i+1:], path, k)
          
            
        nums = ""
        for i in range(1, n+1):
            nums += str(i)
  
        return helper(nums, "", k-1)


#Q20 Number of Digit One
'''
Given an integer n, count the total number of digit 1 appearing in all non-negative integers less than or equal to n.

 

Example 1:

Input: n = 13
Output: 6
Example 2:

Input: n = 0
Output: 0
 

Constraints:

0 <= n <= 109

'''
# Solution

#Method-1
# Digit DP, O(log(n))

# just have to careful when the current digit equals the actual digit of the given number in the solution. 

class Solution:
    def countDigitOne(self, n: int) -> int:
        s = str(n)
        dp = [[[0,0] for i in range(10)] for i in range(len(s))]
        ans = 0
        extra_ones = 1

        flag = -1
        next_flag = -1
        for i in range(0,len(s)):
            for j in range(0,10):
                if(j==1):
                    dp[i][j][0] = extra_ones
                if(i==0):
                    dp[i][j][0] += dp[i][j-1][0]

                else:
                    dp[i][j][0] += dp[i-1][9][0] + dp[i][j-1][0]

                if(j == int(s[len(s)-i-1])):
                    dp[i][j][1] = dp[i][j-1][0] + dp[i-1][flag][1]
                    if(j==1):
                        if(i==0):
                            dp[i][j][1]+=1
                        else:
                            dp[i][j][1]+= int(s[len(s)-i:])+1
                    flag = j
            extra_ones*=10
        return dp[-1][flag][1]

    
    
#Anothwer Way
# Digit Dp  Solution

class Solution:
    def countDigitOne(self, n: int) -> int:
        v = [int(x) for x in str(n)]
        l = len(v)
        
        memo = {}
        def helper(pos,tight,countPrev):
            if(pos==l):
                return countPrev
            key = (pos,tight,countPrev)
            if(key in memo):
                return memo[key]
            limit = 9
            if(tight==0):
                limit=v[pos]
                
            res = 0
            for i in range(limit+1):
                newTight = tight or (i<limit)
                if(i==1):
                    countPrev+=1
                # print(pos,i,countPrev)
                res+=helper(pos+1,newTight,countPrev)
                if(i==1):
                    countPrev-=1
            memo[key] = res
            return res
            
        ans = helper(0,0,0)
        # print(memo)
        return ans
				
# You can use dp array instead of memo hashmap also (It will improve time by some extent):

class Solution:
    def countDigitOne(self, n: int) -> int:
        v = [int(x) for x in str(n)]
        l = len(v)
        dp = [[[-1 for i in range(10)] for i in range(2)] for i in range(10)]
        def helper(pos,tight,countPrev):
            if(pos==l):
                return countPrev
            
            if(dp[pos][tight][countPrev]!=-1):
                return dp[pos][tight][countPrev]
            
            limit = 9
            if(tight==0):
                limit=v[pos]
                
            res = 0
            for i in range(limit+1):
                newTight = tight or (i<limit)
                if(i==1):
                    countPrev+=1
                # print(pos,i,countPrev)
                res+=helper(pos+1,newTight,countPrev)
                if(i==1):
                    countPrev-=1
            dp[pos][tight][countPrev] = res
            return res
            
        ans = helper(0,0,0)
        # print(memo)
        return ans
    
    
    
#Method-2

# if digit(i) is '1', how many numbers it can form that is lower than n?
# let n = x + digit(i) + y (string's concatenation)
# k = len(y) + 1
# There are 3 different cases: digit(i) = 0, digit(i) = 1, digit(i) > 1


class Solution:
    def countDigitOne(self, n: int) -> int:
        s = str(n)
        ret = 0
        # for each digit i, x is the higher digits, y is the lower digits
        # discuss different cases
        for i in range(len(s)):
            x, y = int(s[:i] if s[:i] else '0'), int(s[i+1:] if s[i+1:] else '0')
            k = 10 ** (len(s) - 1 - i)
            if s[i] == '0':
                ret += x * k
            elif s[i] == '1':
                ret += x * k + y + 1
            else:
                ret += (x + 1) * k
        return ret
 

#Method-2   
#Straight Math Solution

class Solution:
    def countDigitOne(self, n: int) -> int:
        
        #O(logn) mathematical solution
        #intervals of new 1s: 0-9, 10-99, 100-999, 1000,9999... 
            #each interval yields 1,10,100,etc. new '1's respectively
		#first and foremost, we want to check how many of each interval repeats 
        #conditions for FULL yield when curr%upper bound+1: 1 <=, 19 <=, 199 <=...
        #conditions for PARTIAL yielf when curr%upper bound+1: None, 10 <= < 19,  100 <= < 199, 1000 <= < 1999 ... 
        
        ans = 0
        for i in range(len(str(n))):
            curr = 10**(i+1)
            hi,lo = int('1'+'9'*i), int('1'+'0'*i)
            ans += (n//curr) * 10**i
            if (pot:=n%curr) >= hi: ans += 10**i
            elif lo <= pot < hi: 
                ans += pot - lo + 1
        return ans
    
    
    
#Method-3    
# O(logn) Solution

class Solution:
    def countDigitOne(self, n: int) -> int:
        ans = remainder = 0
        s = str(n)
        sn = len(s)
        for i in range(sn,0,-1):
            if s[i-1] == "1":
                ans += (remainder + 1)
                ans += (n // 10) * (10 ** (sn - i))
            else:
                ans += (math.ceil(n/10)) * (10 ** (sn -i))
            remainder += (10**(sn-i))*(n%10)
            n //= 10
        return ans

    
#Method-4      
# Math based
import math
class Solution:
    def countDigitOne(self, n: int) -> int:
        if n<10:return int(n>=1)
        val=n
        ans=0
        ## Removing digits from start one at a time after adding ones in answer:
        ## Eg: 536>36; answer+= number of ones in 500 >6 ; answer+= number of ones in 30
        for power in range(9,-1,-1):
            no=math.pow(10,power)
            q=val//no
            r=val%no
            if q>1:ans+=no ## no of ones in 100,101,102...
            if q==1:ans+=r+1 ## no of ones in 100,101,102...
            if q>=1:ans+=(math.pow(10,power-1)*power)*(q) ## no of ones in each 100 of 500 at units and 10s position
            val=r
        return int(ans)

    
#Method-5
#Recursive solution with memoization | Top down DFS | DP

class Solution:
    
    def countDigitOne(self, n):
        
        n, dp = str(n), {}
        size = len(n)
        
        def dfs(i, restrict, onecount):
            if i==size:
                return onecount
            key = i, restrict, onecount
            if key in dp:
                return dp[key]
            dp[key], limit = 0, int(n[i]) if restrict else 9
            for digit in range(limit+1):
                dp[key] += dfs(i+1, False if digit < limit else restrict, onecount+1 if digit==1 else onecount)
            return dp[key]   
            
        return dfs(0, True, 0)



