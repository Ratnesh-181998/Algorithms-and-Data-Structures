
#Bit Manipulation

#Q1.  Sum of Two Integers
'''
Given two integers a and b, return the sum of the two integers without using the operators + and -.

 

Example 1:

Input: a = 1, b = 2
Output: 3
Example 2:

Input: a = 2, b = 3
Output: 5
 

Constraints:

-1000 <= a, b <= 1000

'''
#Solution 

#Approach-1

class Solution:
    def getSum(self, a: int, b: int) -> int:
        values = []
        values.append(a)
        values.append(b)
        return sum(values)
    
#Approach-2

class Solution:
	def getSum(self, a: int, b: int) -> int:
		def add(a,b):
			if not a or not b:
				return a or b
			return add(a^b, (a&b) << 1)

		if a * b < 0: # assume it's always a < 0, b > 0
			if a > 0:
				return getSum(b,a)
			# add(~a, 1) gives the negative value of a
			if add(~a, 1) == b: # -a == b
				return 0
			# using add of -a < b in python will make loop never stop
			if add(~a, 1) < b: # -a < b
				return add(~add(add(~a, 1), add(~b,1)), 1)
		return add(a,b)

    
#Approach-3

class Solution:
    def getSum(self, a: int, b: int) -> int:
        def myadd(c, d):
            while d != 0:
                c, d = c^d, (c&d)<<1
            return c
        if a < 0 and myadd(~a, 1) <= b or b < 0 and myadd(~b, 1) <= a:
            return ~myadd(myadd(~a, ~b), 1)
        return myadd(a, b)





#Q2.Maximum XOR After Operations

'''
You are given a 0-indexed integer array nums. In one operation, select any non-negative integer x and an index i, then update nums[i] to be equal to nums[i] AND (nums[i] XOR x).

Note that AND is the bitwise AND operation and XOR is the bitwise XOR operation.

Return the maximum possible bitwise XOR of all elements of nums after applying the operation any number of times.

 

Example 1:

Input: nums = [3,2,4,6]
Output: 7
Explanation: Apply the operation with x = 4 and i = 3, num[3] = 6 AND (6 XOR 4) = 6 AND 2 = 2.
Now, nums = [3, 2, 4, 2] and the bitwise XOR of all the elements = 3 XOR 2 XOR 4 XOR 2 = 7.
It can be shown that 7 is the maximum possible bitwise XOR.
Note that other operations may be used to achieve a bitwise XOR of 7.
Example 2:

Input: nums = [1,2,3,9,2]
Output: 11
Explanation: Apply the operation zero times.
The bitwise XOR of all the elements = 1 XOR 2 XOR 3 XOR 9 XOR 2 = 11.
It can be shown that 11 is the maximum possible bitwise XOR.
 

Constraints:

1 <= nums.length <= 105
0 <= nums[i] <= 108

'''

#Solution 

#Approach-1

class Solution:
    def maximumXOR(self, nums: List[int]) -> int:
        if max(nums)<= 0: return 0
        bitloc = ceil(log2(max(nums))) + 1
        
        ans = 0
        while bitloc>=0:
            count = 0
            for num in nums:
                if num&1<<bitloc:
                    count+=1
            if count and not count%2:
                ans|=1<<bitloc
            bitloc-=1
        for num in nums:
            ans^=num
        return ans
    
#Approach-2
# Greedy bit operation
# just iterate the array to collect if any 1 on the 32 digits.
# The operation effect is simply to reduce number of 1's on the binary digits

class Solution:
    def maximumXOR(self, nums: List[int]) -> int:
        res=0
        nums.sort(reverse=True)
        for i in range(31,-1,-1):
            for a in nums:
                pfix=(a>>i)&1
                if pfix:
                    res|=(1<<i)
                    break
        return res
    
#Approach-3 

# operator - O(n) time O(1) space
# Given new_num = nums[i] AND (nums[i] XOR x)
# What are the properties of new_num?

# new_num will be the same length as nums[i] because of AND
# 0's in nums[i] cannot become 1's due to AND, but the 1's in nums[i] can become 0's
# So how do we maximize a list of new_nums?
# We want to keep all our 1's, and we can do so because we can change 1's to 0's so the XOR result will retain all our 1's. Therefore the maximum is just the or operator of all nums.

class Solution:
    def maximumXOR(self, nums: List[int]) -> int:
        res = 0
        for num in nums:
            res |= num
        return res
