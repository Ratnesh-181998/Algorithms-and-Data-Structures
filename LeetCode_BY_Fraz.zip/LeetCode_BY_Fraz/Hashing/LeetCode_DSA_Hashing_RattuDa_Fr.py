
#Hashing

#Q1. Top K Frequent Elements

''' 
Given an integer array nums and an integer k, return the k most frequent elements. You may return the answer in any order.

 

Example 1:

Input: nums = [1,1,1,2,2,3], k = 2
Output: [1,2]
Example 2:

Input: nums = [1], k = 1
Output: [1]
 

Constraints:

1 <= nums.length <= 105
-104 <= nums[i] <= 104
k is in the range [1, the number of unique elements in the array].
It is guaranteed that the answer is unique.
 

Follow up: Your algorithm's time complexity must be better than O(n log n), where n is the array's size.


'''

#Solution 

#Method-1

# heap
# maxheap

class Solution:
    def topKFrequent(self, nums: List[int], k: int) -> List[int]:
        count = Counter(nums)                               #Count the each elements' appearance times
        temp = [-i for i in count.values()]                #get the value of the hashmap with negative number to create a MaxHeap
        heap = list(zip(temp,count.keys()))                #To form a heap with Pair (value,key)
        heapq.heapify(heap)                               #Transform the list to the heap
        return [heapq.heappop(heap)[1] for i in range(k)] # pop k times from the maxheap's key which is our answer
		


#Method-2

class Solution:
    def topKFrequent(self, nums: List[int], k: int) -> List[int]:
        Dict = {}
        for i in nums:
            if i not in Dict:
                Dict[i] = [1, i]
            else:
                Dict[i][0] +=1
            
        Srtd = sorted(Dict.values(), key=lambda x:x[0])[::-1]
                
        return [Srtd[k][1] for k in range(k)]
    
#Method-3

# O(n) using Counter.

from collections import Counter
class Solution:
    def topKFrequent(self, nums, k: int):
        counter = Counter(nums)
        return sorted(counter, key=counter.get)[-k:]
    
#Method-4

# max/min heap solution with explanation
# the basic idea is to build table mapping key to frequency,
# then use max heap to find top k frequency elements, tc is O(nlogn), sc is O(number of distinct element)
# max heap, nlogn

from heapq import heappush, heappop
class Solution:
    def topKFrequent(self, nums: List[int], k: int) -> List[int]:
        numberToFreq, Q = {}, []
        for i in nums:
            numberToFreq[i] = numberToFreq.get(i, 0) + 1
        for key, freq in numberToFreq.items():
            heappush(Q, [-freq, key])
        ans = []
        for i in range(k):
            ans.append(heappop(Q)[1])
        return ans
    
    
    
#Method-5    
    
# min heap, nlogk

# in the max heap solution, it is not necessary to keep all the element in the heap, we can eliminate the small frequency element during putting item into heap, so the size of heap is k, tc is O(nlogk)
# sc is O(number of distinct element)

from heapq import heappush, heappop
class Solution:
    def topKFrequent(self, nums: List[int], k: int) -> List[int]:
        numberToFreq, Q = {}, []
        for i in nums:
            numberToFreq[i] = numberToFreq.get(i, 0) + 1

        for key, freq in numberToFreq.items():
            heappush(Q, [freq, key])
            if len(Q) > k:
                heappop(Q)
        ans = []
        for _, key in Q:
            ans.append(key)
        return ans


#Q2. Design Twitter

'''
Design a simplified version of Twitter where users can post tweets, follow/unfollow another user, and is able to see the 10 most recent tweets in the user's news feed.

Implement the Twitter class:

Twitter() Initializes your twitter object.
void postTweet(int userId, int tweetId) Composes a new tweet with ID tweetId by the user userId. Each call to this function will be made with a unique tweetId.
List<Integer> getNewsFeed(int userId) Retrieves the 10 most recent tweet IDs in the user's news feed. Each item in the news feed must be posted by users who the user followed or by the user themself. Tweets must be ordered from most recent to least recent.
void follow(int followerId, int followeeId) The user with ID followerId started following the user with ID followeeId.
void unfollow(int followerId, int followeeId) The user with ID followerId started unfollowing the user with ID followeeId.
 

Example 1:

Input
["Twitter", "postTweet", "getNewsFeed", "follow", "postTweet", "getNewsFeed", "unfollow", "getNewsFeed"]
[[], [1, 5], [1], [1, 2], [2, 6], [1], [1, 2], [1]]
Output
[null, null, [5], null, null, [6, 5], null, [5]]

Explanation
Twitter twitter = new Twitter();
twitter.postTweet(1, 5); // User 1 posts a new tweet (id = 5).
twitter.getNewsFeed(1);  // User 1's news feed should return a list with 1 tweet id -> [5]. return [5]
twitter.follow(1, 2);    // User 1 follows user 2.
twitter.postTweet(2, 6); // User 2 posts a new tweet (id = 6).
twitter.getNewsFeed(1);  // User 1's news feed should return a list with 2 tweet ids -> [6, 5]. Tweet id 6 should precede tweet id 5 because it is posted after tweet id 5.
twitter.unfollow(1, 2);  // User 1 unfollows user 2.
twitter.getNewsFeed(1);  // User 1's news feed should return a list with 1 tweet id -> [5], since user 1 is no longer following user 2.
 

Constraints:

1 <= userId, followerId, followeeId <= 500
0 <= tweetId <= 104
All the tweets have unique IDs.
At most 3 * 104 calls will be made to postTweet, getNewsFeed, follow, and unfollow


'''


#Solution

# Approach-1

class Twitter:

    def __init__(self):
        self.users = defaultdict(set)
        self.tweets = []
        
    def postTweet(self, userId: int, tweetId: int) -> None:
        self.tweets.append((userId, tweetId))
    def getNewsFeed(self, userId: int) -> List[int]:
        res = []
        i=len(self.tweets)-1
        while i>=0 and len(res)<10:
            if self.tweets[i][0] in self.users[userId] or self.tweets[i][0]==userId:
                res.append(self.tweets[i][1])
            i-=1
        return res
    def follow(self, followerId: int, followeeId: int) -> None:
        self.users[followerId].add(followeeId)
        
    def unfollow(self, followerId: int, followeeId: int) -> None:
        if followeeId in self.users[followerId]: self.users[followerId].remove(followeeId)
            
            
# Approach-2

# Priority Queue (Max Heap) Solution | O(k) Time | O(n) Space

# * Priority Queue (Max Heap) Solution | O(k) Time | O(n) Space
# * n -> The number of users and tweets | k -> The number of followees

# hash-table
# priority-queue


class Twitter:
    def __init__(self):
        self.count = 0
        # * Stores a key-value pair where the key is a followerId and value is a followeeId.
        # * followerId -> followeeId
        self.follow_mappings = collections.defaultdict(set)
        # * Stores a key-value pair where the key is a userId and value is an array of count and tweetId.
        # * userId -> [(count, tweetId)]
        self.tweet_mappings = collections.defaultdict(list)

    def postTweet(self, userId: int, tweetId: int) -> None:
        self.tweet_mappings[userId].append((self.count, tweetId))
        self.count += 1

    def getNewsFeed(self, userId: int) -> List[int]:
        # * To get his own tweets in the news feed.
        self.follow(userId, userId)
        recent_tweets = []
        max_heap = []

        # * Push the last/recent tweet of all the followees into the heap.
        for followee_id in self.follow_mappings[userId]:
            if followee_id in self.tweet_mappings:
                recent_tweet_index = len(self.tweet_mappings[followee_id]) - 1
                count, tweet_id = self.tweet_mappings[followee_id][recent_tweet_index]
                heapq.heappush(
                    max_heap,
                    (-count, tweet_id, followee_id, recent_tweet_index - 1)
                )

        while max_heap and len(recent_tweets) < 10:
            count, tweet_id, followee_id, recent_tweet_index = heapq.heappop(
                max_heap
            )
            recent_tweets.append(tweet_id)
            # * If we still have tweets available for the same followee then push it into the heap.
            if recent_tweet_index >= 0:
                count, tweet_id = self.tweet_mappings[followee_id][recent_tweet_index]
                heapq.heappush(
                    max_heap,
                    (-count, tweet_id, followee_id, recent_tweet_index - 1)
                )

        return recent_tweets

    def follow(self, followerId: int, followeeId: int) -> None:
        if followeeId not in self.follow_mappings[followerId]:
            self.follow_mappings[followerId].add(followeeId)

    def unfollow(self, followerId: int, followeeId: int) -> None:
        if followeeId in self.follow_mappings[followerId]:
            self.follow_mappings[followerId].remove(followeeId)


# Your Twitter object will be instantiated and called as such:
# obj = Twitter()
# obj.postTweet(userId,tweetId)
# param_2 = obj.getNewsFeed(userId)
# obj.follow(followerId,followeeId)
# obj.unfollow(followerId,followeeId)


# Approach-3

# heap
# priority queue
# Heap PriorityQueue

# The idea is to write custom PriorityQueue class that will be based on heap and will have O(KlogN) time to retrieve topk elements that will allow to make getNewsFeed function fast.

import heapq
from collections import defaultdict


class PriorityQueue:
    """PriorityQueue based on heap.
	
	Note: since heapq implements min heap, but we want max heap 
        for PriorityQueue so we will store -priority as a key.
	"""

    def __init__(self):
        self.arr = []
        
    def __len__(self):
        return len(self.arr)
        
    def push(self, priority, val):
        heapq.heappush(self.arr, (-priority, val))
        
    def pop(self):
        priority, val = heapq.heappop(self.arr)
        return -priority, val

    def topk(self, k):
        # O(klogn)
        values = [self.pop() for _ in range(min(k, len(self)))]
        for p, v in values:
            self.push(p, v)

        return values
    
    def __repr__(self):
        return str([(-p, val) for p, val in self.arr])


class Twitter:

    def __init__(self):
        self.followees = defaultdict(set)  # List of followees
        self.posts = defaultdict(PriorityQueue)  # Queue of tweets with priority = timestamp
        self.timestamp = 0

    def postTweet(self, userId: int, tweetId: int) -> None:
        # O(logN)

        self.posts[userId].push(self.timestamp, tweetId)  # Add tweet
        self.timestamp += 1  # Increase timestamp

    def getNewsFeed(self, userId: int, k: int = 10) -> List[int]:
        # O(KKlogN)

        # Retrieve topk tweets from all followees and user
        feed = PriorityQueue()
        for followeeId in self.followees[userId] | {userId}:
            for timestamp, tweetId in self.posts[followeeId].topk(k=k):
                feed.push(timestamp, tweetId)
                
        # Return topk tweets from all
        return [tweetId for _, tweetId in feed.topk(k=k)]

    def follow(self, followerId: int, followeeId: int) -> None:
        # O(1)

        self.followees[followerId].add(followeeId)

    def unfollow(self, followerId: int, followeeId: int) -> None:
        # O(1)

        if followeeId in self.followees[followerId]:
            self.followees[followerId].remove(followeeId)

            
# Approach-4

# SQLite

# Slower and bigger than most solutions, but why not let the SQLite programmers take care of the sorting for us

import sqlite3

class Twitter:

    def __init__(self):
        self.db = sqlite3.connect(':memory:')
        cursor = self.db.cursor()
        cursor.execute('CREATE TABLE tweets (tweetId INTEGER, userId INTEGER)')
        cursor.execute('CREATE INDEX userIdIdx ON tweets(userId)')
        cursor.execute('CREATE TABLE followers (followerId INTEGER, followeeId INTEGER)')
        cursor.execute('CREATE UNIQUE INDEX followerIdx ON followers(followerId, followeeId)')
        self.db.commit()
        

    def postTweet(self, userId: int, tweetId: int) -> None:
        cursor = self.db.cursor()
        cursor.execute('INSERT INTO tweets VALUES (?, ?)', (tweetId, userId))
        cursor.execute('INSERT OR REPLACE INTO followers VALUES (?, ?)', (userId, userId))
        self.db.commit()
        

    def getNewsFeed(self, userId: int) -> List[int]:
        cursor = self.db.cursor()
        rows = cursor.execute(
            '''
            SELECT t.tweetId
              FROM tweets t
              INNER JOIN followers f
                ON f.followeeId=t.userId AND f.followerId=?
              ORDER BY t.rowid DESC
              LIMIT 10
            ''',
            (userId,)
        ).fetchall()
        return [row[0] for row in rows]
        

    def follow(self, followerId: int, followeeId: int) -> None:
        cursor = self.db.cursor()
        cursor.execute('INSERT OR REPLACE INTO followers VALUES (?, ?)', (followerId, followeeId))
        self.db.commit()
        

    def unfollow(self, followerId: int, followeeId: int) -> None:
        cursor = self.db.cursor()
        cursor.execute('DELETE FROM followers WHERE followerId=? AND followeeId=?', (followerId, followeeId))
        self.db.commit()
        
# Approach-5

# using map of set and max heap
# hashmap
# maxheap


# time starts from 0 when we initialize our application and with each post we increase it. Use this time value to store both userId and tweetId in our heap
# max heap with negative values for time
# GetNewsFeed: we pop 10 nodes, check if they match our user constraint - ie. user itself of some other user that our user follows.. Then we put all those back in the heap. Since we're always popping and then pushing 10 elements into our heap it is constant time - 10 log 10. This should mean constant complexity each time our method is called.
# However if the feedcount changes from 10 to k, then the complexity will get klogk each time our getnewsfeed method is called.

class Twitter:

    def __init__(self):
        self.time = 0
        self.maxheap = []
        heapq.heapify(self.maxheap)
        self.followmap = {}
        self.feedcount = 10
        

    def postTweet(self, userId: int, tweetId: int) -> None:
        self.time -= 1 # cos we need max heap so need to use negatives 
        heapq.heappush(self.maxheap, [self.time, userId, tweetId])
        

    def getNewsFeed(self, userId: int) -> List[int]:
        feedresult = []
        feedspopped = []
        currentfeedcount = 0
        
        while currentfeedcount < self.feedcount and self.maxheap:

            feed = heapq.heappop(self.maxheap)
            if feed[1] == userId or (userId in self.followmap and feed[1] in self.followmap[userId]):
                feedresult.append(feed[2])
                currentfeedcount += 1
            feedspopped.append(feed)
        
        for feed in feedspopped:
            heapq.heappush(self.maxheap, feed)
        return feedresult
        

    def follow(self, followerId: int, followeeId: int) -> None:
        if followerId not in self.followmap:
            self.followmap[followerId] = set()
        self.followmap[followerId].add(followeeId)
        

    def unfollow(self, followerId: int, followeeId: int) -> None:
        if followerId in self.followmap:
            self.followmap[followerId].remove(followeeId)
        


# Your Twitter object will be instantiated and called as such:
# obj = Twitter()
# obj.postTweet(userId,tweetId)
# param_2 = obj.getNewsFeed(userId)
# obj.follow(followerId,followeeId)
# obj.unfollow(followerId,followeeId)


#Q3.Verifying an Alien Dictionary

'''

In an alien language, surprisingly, they also use English lowercase letters, but possibly in a different order. The order of the alphabet is some permutation of lowercase letters.

Given a sequence of words written in the alien language, and the order of the alphabet, return true if and only if the given words are sorted lexicographically in this alien language.

 

Example 1:

Input: words = ["hello","leetcode"], order = "hlabcdefgijkmnopqrstuvwxyz"
Output: true
Explanation: As 'h' comes before 'l' in this language, then the sequence is sorted.
Example 2:

Input: words = ["word","world","row"], order = "worldabcefghijkmnpqstuvxyz"
Output: false
Explanation: As 'd' comes after 'l' in this language, then words[0] > words[1], hence the sequence is unsorted.
Example 3:

Input: words = ["apple","app"], order = "abcdefghijklmnopqrstuvwxyz"
Output: false
Explanation: The first three characters "app" match, and the second string is shorter (in size.) According to lexicographical rules "apple" > "app", because 'l' > '∅', where '∅' is defined as the blank character which is less than any other character (More info).
 

Constraints:

1 <= words.length <= 100
1 <= words[i].length <= 20
order.length == 26
All characters in words[i] and order are English lowercase letters.
'''
#Solution 

# Approach-1

# Compare adjacent words

# Algorithm

# Initialize a hashmap/array to record the relations between each letter and its ranking in order.
# Iterate over words and compare each pair of adjacent words.
# Iterate over each letter to find the first different letter between words[i] and words[i + 1].
# If words[i + 1] ends before words[i] and no different letters are found, then we need to return false because words[i + 1] should come before words[i] (for example, apple and app).
# If we find the first different letter and the two words are in the correct order, then we can exit from the current iteration and proceed to the next pair of words.
# If we find the first different letter and the two words are in the wrong order, then we can safely return false.
# If we reach this point, it means that we have examined all pairs of adjacent words and that they are all sorted. Therefore we can return true.



# Let NN be the length of order, and MM be the total number of characters in words.

# Time complexity : O(M)O(M).

# Storing the letter-order relation of each letter takes O(N)O(N) time. For the nested for-loops, we examine each pair of words in the outer-loop and for the inner loop, we check each letter in the current word. Therefore, we will iterate over all of letters in words.

# Taking both into consideration, the time complexity is O(M + N)O(M+N). However, we know that NN is fixed as 2626. Therefore, the time complexity is O(M)O(M).

# Space complexity : O(1)O(1). The only extra data structure we use is the hashmap/array that serves to store the letter-order relations for each word in order. Because the length of order is fixed as 2626, this approach achieves constant space complexity.




class Solution:
    def isAlienSorted(self, words: List[str], order: str) -> bool:
        order_map = {}
        for index, val in enumerate(order):
            order_map[val] = index

        for i in range(len(words) - 1):

            for j in range(len(words[i])):
                # If we do not find a mismatch letter between words[i] and words[i + 1],
                # we need to examine the case when words are like ("apple", "app").
                if j >= len(words[i + 1]): return False

                if words[i][j] != words[i + 1][j]:
                    if order_map[words[i][j]] > order_map[words[i + 1][j]]: return False
                    # if we find the first different character and they are sorted,
                    # then there's no need to check remaining letters
                    break

        return True
    
# Approach-2

class Solution:
    def isAlienSorted(self, words: List[str], order: str) -> bool:
        return words == sorted(words, key=lambda word: [order.index(char) for char in word])
    
    
# Approach-3

# literally compare two adjacent words
# Time Complexity: O(M)
 # Space Complexity: O(1)
    
class Solution(object):
    def isAlienSorted(self, words, order):
        """
        :type words: List[str]
        :type order: str
        :rtype: bool
        """
        def is_in_order(word_A, word_B):
            for i in range(min(len(word_A), len(word_B))):
                if hashmap[word_A[i]] < hashmap[word_B[i]]:
                    return True
                elif hashmap[word_A[i]] > hashmap[word_B[i]]:
                    return False
            if len(word_A) > len(word_B):
                return False
            return True
        hashmap = {}
        for i in range(len(order)):  # Time Complexity O(N=26), or O(1)
            hashmap[order[i]] = i 
        for i in range(len(words)-1):  # Time Complexity O(M), M = the total number of characters across all words
            if not is_in_order(words[i], words[i+1]):
                return False
        return True
 
# Approach-4

# a fancier version
 # Time Complexity: O(M)
 # Space Complexity: O(1)

class Solution(object):
    def isAlienSorted(self, words, order):
        """
        :type words: List[str]
        :type order: str
        :rtype: bool
        """
        dic = {}
        new_words = []
        for i, ch in enumerate(order): # Time Complexity O(N=26), or O(1)
            dic[ch] = i
        for w in words:  # Time Complexity O(M), M = the total number of characters across all words
            new = []
            for c in w:
                new.append(dic[c])
            new_words.append(new)
        for w1, w2 in zip(new_words, new_words[1:]):  # Time Complexity O(M), M = the total number of characters across all words
            if w1 > w2:
                return False
        return True
 
#Q3. Verifying an Alien Dictionary
'''

In an alien language, surprisingly, they also use English lowercase letters, but possibly in a different order. The order of the alphabet is some permutation of lowercase letters.

Given a sequence of words written in the alien language, and the order of the alphabet, return true if and only if the given words are sorted lexicographically in this alien language.

 

Example 1:

Input: words = ["hello","leetcode"], order = "hlabcdefgijkmnopqrstuvwxyz"
Output: true
Explanation: As 'h' comes before 'l' in this language, then the sequence is sorted.
Example 2:

Input: words = ["word","world","row"], order = "worldabcefghijkmnpqstuvxyz"
Output: false
Explanation: As 'd' comes after 'l' in this language, then words[0] > words[1], hence the sequence is unsorted.
Example 3:

Input: words = ["apple","app"], order = "abcdefghijklmnopqrstuvwxyz"
Output: false
Explanation: The first three characters "app" match, and the second string is shorter (in size.) According to lexicographical rules "apple" > "app", because 'l' > '∅', where '∅' is defined as the blank character which is less than any other character (More info).
 

Constraints:

1 <= words.length <= 100
1 <= words[i].length <= 20
order.length == 26
All characters in words[i] and order are English lowercase letters.  
'''
#Solution 

# Approach-1

# Compare adjacent words

# Algorithm

# Initialize a hashmap/array to record the relations between each letter and its ranking in order.
# Iterate over words and compare each pair of adjacent words.
# Iterate over each letter to find the first different letter between words[i] and words[i + 1].
# If words[i + 1] ends before words[i] and no different letters are found, then we need to return false because words[i + 1] should come before words[i] (for example, apple and app).
# If we find the first different letter and the two words are in the correct order, then we can exit from the current iteration and proceed to the next pair of words.
# If we find the first different letter and the two words are in the wrong order, then we can safely return false.
# If we reach this point, it means that we have examined all pairs of adjacent words and that they are all sorted. Therefore we can return true.



# Let NN be the length of order, and MM be the total number of characters in words.

# Time complexity : O(M)O(M).

# Storing the letter-order relation of each letter takes O(N)O(N) time. For the nested for-loops, we examine each pair of words in the outer-loop and for the inner loop, we check each letter in the current word. Therefore, we will iterate over all of letters in words.

# Taking both into consideration, the time complexity is O(M + N)O(M+N). However, we know that NN is fixed as 2626. Therefore, the time complexity is O(M)O(M).

# Space complexity : O(1)O(1). The only extra data structure we use is the hashmap/array that serves to store the letter-order relations for each word in order. Because the length of order is fixed as 2626, this approach achieves constant space complexity.




class Solution:
    def isAlienSorted(self, words: List[str], order: str) -> bool:
        order_map = {}
        for index, val in enumerate(order):
            order_map[val] = index

        for i in range(len(words) - 1):

            for j in range(len(words[i])):
                # If we do not find a mismatch letter between words[i] and words[i + 1],
                # we need to examine the case when words are like ("apple", "app").
                if j >= len(words[i + 1]): return False

                if words[i][j] != words[i + 1][j]:
                    if order_map[words[i][j]] > order_map[words[i + 1][j]]: return False
                    # if we find the first different character and they are sorted,
                    # then there's no need to check remaining letters
                    break

        return True
    
# Approach-2

class Solution:
    def isAlienSorted(self, words: List[str], order: str) -> bool:
        return words == sorted(words, key=lambda word: [order.index(char) for char in word])
    
    
# Approach-3

# literally compare two adjacent words
# Time Complexity: O(M)
 # Space Complexity: O(1)
    
class Solution(object):
    def isAlienSorted(self, words, order):
        """
        :type words: List[str]
        :type order: str
        :rtype: bool
        """
        def is_in_order(word_A, word_B):
            for i in range(min(len(word_A), len(word_B))):
                if hashmap[word_A[i]] < hashmap[word_B[i]]:
                    return True
                elif hashmap[word_A[i]] > hashmap[word_B[i]]:
                    return False
            if len(word_A) > len(word_B):
                return False
            return True
        hashmap = {}
        for i in range(len(order)):  # Time Complexity O(N=26), or O(1)
            hashmap[order[i]] = i 
        for i in range(len(words)-1):  # Time Complexity O(M), M = the total number of characters across all words
            if not is_in_order(words[i], words[i+1]):
                return False
        return True
 
# Approach-4

# a fancier version
 # Time Complexity: O(M)
 # Space Complexity: O(1)

class Solution(object):
    def isAlienSorted(self, words, order):
        """
        :type words: List[str]
        :type order: str
        :rtype: bool
        """
        dic = {}
        new_words = []
        for i, ch in enumerate(order): # Time Complexity O(N=26), or O(1)
            dic[ch] = i
        for w in words:  # Time Complexity O(M), M = the total number of characters across all words
            new = []
            for c in w:
                new.append(dic[c])
            new_words.append(new)
        for w1, w2 in zip(new_words, new_words[1:]):  # Time Complexity O(M), M = the total number of characters across all words
            if w1 > w2:
                return False
        return True
   

# Approach-5

# compare adjacent words


class Solution:
    def isAlienSorted(self, words, order):
        """
        :type words: List[str]
        :type order: str
        :rtype: bool
        """
        #Adjacent compare
        length = len(words)
        for i in range(length-1):
            a = words[i]
            b = words[i+1]
            minlen = min(len(a),len(b))
            for j in range(minlen):
                if order.index(a[j]) < order.index(b[j]):break
                elif order.index(a[j]) > order.index(b[j]):return False
                elif j == minlen - 1  and len(b) < len(a):return False
        return True
            
#Q4. Design HashMap
'''

Design a HashMap without using any built-in hash table libraries.

Implement the MyHashMap class:

MyHashMap() initializes the object with an empty map.
void put(int key, int value) inserts a (key, value) pair into the HashMap. If the key already exists in the map, update the corresponding value.
int get(int key) returns the value to which the specified key is mapped, or -1 if this map contains no mapping for the key.
void remove(key) removes the key and its corresponding value if the map contains the mapping for the key.
 

Example 1:

Input
["MyHashMap", "put", "put", "get", "get", "put", "get", "remove", "get"]
[[], [1, 1], [2, 2], [1], [3], [2, 1], [2], [2], [2]]
Output
[null, null, null, 1, -1, null, 1, null, -1]

Explanation
MyHashMap myHashMap = new MyHashMap();
myHashMap.put(1, 1); // The map is now [[1,1]]
myHashMap.put(2, 2); // The map is now [[1,1], [2,2]]
myHashMap.get(1);    // return 1, The map is now [[1,1], [2,2]]
myHashMap.get(3);    // return -1 (i.e., not found), The map is now [[1,1], [2,2]]
myHashMap.put(2, 1); // The map is now [[1,1], [2,1]] (i.e., update the existing value)
myHashMap.get(2);    // return 1, The map is now [[1,1], [2,1]]
myHashMap.remove(2); // remove the mapping for 2, The map is now [[1,1]]
myHashMap.get(2);    // return -1 (i.e., not found), The map is now [[1,1]]
 

Constraints:

0 <= key, value <= 106
At most 104 calls will be made to put, get, and remove.

'''
#Solution 

# Approach-1
# solution using two mapped arrays for keys and values
# hashmap
# easy-understanding

class MyHashMap:
    
    def __init__(self):
        # choose a prime number
        self.size = 211
        # create a bucket as list of lists to be able to store different keys with the same hash value
        self.bucket_keys = [[] for _ in range(self.size)]   
        # create a bucket as list of lists to be able to store values mapped to the keys     
        self.bucket_values = [[] for _ in range(self.size)]        


    # create a simple hash function using modulo operator
    def hash_func(self, key: int):
        return key % self.size        


    def put(self, key: int, value: int) -> None:
        # index will never be greater than the initial size of the bucket because of modulo operation within hash function
        # so we will never get an index error
        index = self.hash_func(key)
        if not key in self.bucket_keys[index]:
            self.bucket_keys[index].append(key)
            self.bucket_values[index].append(value)
        else:
            val_index = self.bucket_keys[index].index(key)     
            self.bucket_values[index][val_index] = value


    def get(self, key: int) -> int:
        index = self.hash_func(key)
        if key in self.bucket_keys[index]:
            val_index = self.bucket_keys[index].index(key)     
            return self.bucket_values[index][val_index]
        return -1


    def remove(self, key: int) -> None:
        index = self.hash_func(key)
        if key in self.bucket_keys[index]:
            val_index = self.bucket_keys[index].index(key)     
            self.bucket_keys[index].remove(key) 
            del self.bucket_values[index][val_index]


# Approach-2            
class Bucket:
    def __init__(self):
        self.Bucket=list()

    def get(self, key):
        for item in self.Bucket:
            if item[0]==key:
                return item[1]
        return -1

    def update(self, key, value):
        index=0
        for item in self.Bucket:
            if item[0]==key:
                self.Bucket[index]=(key,value)
                return 
            index+=1
        
        self.Bucket.append((key,value))

    def remove(self, key):
        point2=0
        point1=0
        while point1<len(self.Bucket):
            if self.Bucket[point1][0]!=key:
                self.Bucket[point2]=self.Bucket[point1]
                point2+=1
            point1+=1
        self.Bucket=self.Bucket[0:point2]


class MyHashMap:
    def __init__(self):
        self.key_space=2069
        self.hash_table=[Bucket() for i in range(self.key_space)]

    def put(self, key: int, value: int) -> None:
        indexKey=self._hash(key)
        self.hash_table[indexKey].update(key,value)
        
    def get(self, key: int) -> int:
        indexKey=self._hash(key)
        return self.hash_table[indexKey].get(key)
     
    def remove(self, key: int) -> None:
        indexKey=self._hash(key)
        self.hash_table[indexKey].remove(key)
        
    def _hash(self,key):
        return key%self.key_space 

            
# Approach-3

# Lists and Dictionaries


"""
HashMap utilizing a Python list and Python dictionaries for key/value storage.
Dictionaries are only instantiated when required. Try/except statements are used 
to handle cases where we don't have a dictionary setup yet.
"""

class MyHashMap:

    def __init__(self):
        """
        Initialize your data structure here.
        """
        self.num_elements = 1000
        self.hash_map = [-1] * self.num_elements

    def put(self, key, value):
        """
        value will always be non-negative.
        :type key: int
        :type value: int
        :rtype: void
        """
        index = key % self.num_elements
        
        if self.hash_map[index] == -1:
            self.hash_map[index] = {}
            
        self.hash_map[index][str(key)] = value

    def get(self, key):
        """
        Returns the value to which the specified key is mapped, or -1 if this map contains no mapping for the key
        :type key: int
        :rtype: int
        """
        index = key % self.num_elements
        
        try:
            return self.hash_map[index][str(key)]
        except:
            return -1

    def remove(self, key):
        """
        Removes the mapping of the specified value key if this map contains a mapping for the key
        :type key: int
        :rtype: void
        """
        index = key % self.num_elements
        
        try:
            del self.hash_map[index][str(key)]
        except:
            return
        
