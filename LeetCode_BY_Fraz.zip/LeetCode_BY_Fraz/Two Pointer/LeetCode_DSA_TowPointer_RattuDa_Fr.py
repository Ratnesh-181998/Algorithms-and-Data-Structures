#Two Pointer

#Q1. Partition Labels

'''

You are given a string s. We want to partition the string into as many parts as possible so that each letter appears in at most one part.

Note that the partition is done so that after concatenating all the parts in order, the resultant string should be s.

Return a list of integers representing the size of these parts.

 

Example 1:

Input: s = "ababcbacadefegdehijhklij"
Output: [9,7,8]
Explanation:
The partition is "ababcbaca", "defegde", "hijhklij".
This is a partition so that each letter appears in at most one part.
A partition like "ababcbacadefegde", "hijhklij" is incorrect, because it splits s into less parts.
Example 2:

Input: s = "eccbbbbdec"
Output: [10]
 

Constraints:

1 <= s.length <= 500
s consists of lowercase English letters.

'''

#Solution 

# Approach 1: Greedy


# Algorithm

# We need an array last[char] -> index of S where char occurs last. Then, let anchor and j be the start and end of the current partition. If we are at a label that occurs last at some index after j, we'll extend the partition j = last[c]. If we are at the end of the partition (i == j) then we'll append a partition size to our answer, and set the start of our new partition to i+1.


# Time Complexity: O(N)O(N), where NN is the length of SS.

# Space Complexity: O(1)O(1) to keep data structure last of not more than 26 characters.


class Solution(object):
    def partitionLabels(self, S):
        last = {c: i for i, c in enumerate(S)}
        j = anchor = 0
        ans = []
        for i, c in enumerate(S):
            j = max(j, last[c])
            if i == j:
                ans.append(i - anchor + 1)
                anchor = i + 1
            
        return ans
    
# Approach 2:

import string

class Solution:
    def partitionLabels(self, S):
        """
        :type S: str
        :rtype: List[int]
        """
        last_idx= { x: k  for k, x in enumerate(S)}
        out_list = []
        maxN = cumsum = 0
        for idx, char in enumerate(S):
            maxN = max(last_idx[char], maxN)
            if maxN == idx:
                di = idx + 1 - cumsum
                cumsum += di
                out_list.append(di)
        return out_list
    
# Approach 3:

# O(n) Time | O(1) Space

# Logic
# For each character i check rindex right in string and within that range [i,right] for each character update right with max between current right and rindex of current character. Same do for remaining character

# Algorithm

# initialize empty list asn
# initialize i with 0 and n with len of string
# loop until i less than n
# update right as rindex of s[i] at s
# initialize count with 0
# loop until i less than equal to right
# update right with max of right and rindex of s[i] in s
# increment i and count
# add count in ans
# return ans


class Solution:
    def partitionLabels(self, s: str) -> List[int]:
        ans = []
        n = len(s)
        i = 0
        
        while i<n:
            right = s.rindex(s[i])
            count = 0
            while i<n and i<=right:
                right = max(right, s.rindex(s[i]))
                i+=1
                count += 1
            ans.append(count)
        return ans

    
    
# Approach 4:
# defaultdict | Sorting


from collections import defaultdict


class Solution:
    def partitionLabels(self, s: str) -> List[int]:
        st = defaultdict(lambda: defaultdict(int))
        for ind, char in enumerate(s):
            if char in st:
                st[char]['right'] = ind
            else:
                st[char]['left'] = ind
                st[char]['right'] = ind
        arr = [(val['left'], val['right']) for val in st.values()]
        arr.sort(key = lambda x: (x[0], x[1]))
        left, right = arr[0][0], arr[0][1]
        ans = []
        for i in range(1, len(arr)):
            if left < arr[i][0] < right and right < arr[i][1]:
                right = arr[i][1]
            elif right < arr[i][0]:
                ans.append(right - left + 1)
                left = arr[i][0]
                right = arr[i][1]
        ans.append(right - left + 1)
        return ans

    
# Approach 5:
# Two Pass Solution
class Solution:
    def partitionLabels(self, s: str) -> List[int]:
        myDict, ret, last, maxPoint = {}, [], 0, -1
        for i in reversed(range(0, len(s))):
            if s[i] not in myDict:
                myDict[s[i]] = i
                
        for idx, char in enumerate(s):
            maxPoint = max(myDict[char], maxPoint)
            if(idx == maxPoint):
                ret.append((idx + 1) - last)
                last += ret[-1]
        return(ret)


#Q2. Sort Colors

''' 
Given an array nums with n objects colored red, white, or blue, sort them in-place so that objects of the same color are adjacent, with the colors in the order red, white, and blue.

We will use the integers 0, 1, and 2 to represent the color red, white, and blue, respectively.

You must solve this problem without using the library's sort function.

 

Example 1:

Input: nums = [2,0,2,1,1,0]
Output: [0,0,1,1,2,2]
Example 2:

Input: nums = [2,0,1]
Output: [0,1,2]
 

Constraints:

n == nums.length
1 <= n <= 300
nums[i] is either 0, 1, or 2.
 

Follow up: Could you come up with a one-pass algorithm using only constant extra space?

'''

#Solution

#Approach-1        

class Solution:
    def sortColors(self, nums: List[int]) -> None:
        """
        Do not return anything, modify nums in-place instead.
        """
        k = 0
        
        # Find all reds and swap them to the beginning.
        for i in range(len(nums)):
            if nums[i] == 0:
                nums[k], nums[i] = nums[i], nums[k]
                k += 1
                
        # Now place the whites. Note that we need not scan
        # the first section of the array containing zeros again.
        for i in range(k,len(nums)):
            if nums[i] == 1:
                nums[k], nums[i] = nums[i], nums[k]
                k += 1  
        # The remaining part of the array now contains the blues.
        

#Approach-2
# DutchNationalFlag Algo 


class Solution:
    def sortColors(self, nums: List[int]) -> None:
        """
        Do not return anything, modify nums in-place instead.
        """
        c1=c2=c3= 0
        for i in nums :
            if i == 0:
                c1+=1
            if i == 1:
                c2+=1
            if i == 2:
                c3+= 1
        
        ind = 0
        while c1>0:
            nums[ind] = 0
            ind += 1
            c1-= 1
        
        while c2>0:
            nums[ind] = 1
            ind += 1
            c2 -= 1
        while c3>0:
            nums[ind] = 2
            ind += 1
            c3-= 1
            
#Approach-3

# HashMap


from collections import Counter
class Solution:
    def sortColors(self, nums: List[int]) -> None:
        """
        Do not return anything, modify nums in-place instead.
        """
        
        dicta = Counter(nums)
    
        i=0
       
        while(dicta[0]>=1):
            nums[i]=0
            i+=1
            dicta[0]-=1
        while dicta[1]>=1:
            nums[i]=1
            i+=1
            dicta[1]-=1
        while dicta[2]>=1:
            nums[i]=2
            i+=1
            dicta[2]-=1
            
#Approach-4

# left, mid and right pointers


class Solution:
    def sortColors(self, nums: List[int]) -> None:
        """
        Do not return anything, modify nums in-place instead.
        """
        l, m, r = 0, 0, len(nums)-1 # left, mid and right pointers
        while m <= r:
            if nums[m] == 2: # if blue found exchange with right pointer
                nums[m], nums[r] = nums[r], nums[m]
                r -=1
            elif nums[m] == 0: # if red found exchange with left pointer
                nums[m], nums[l] = nums[l], nums[m]
                l +=1
                m +=1
            else:
                m +=1
                
#Approach-5

 # HashMap || O(N) 


class Solution:
    def sortColors(self, nums: List[int]) -> None:
        hashMap = collections.Counter(nums)
        arr = [0]*hashMap[0] + [1]*hashMap[1] + [2]*hashMap[2]
        for i in range(len(arr)):
            nums[i] = arr[i]




# Q3. Longest Repeating Character Replacement

'''
You are given a string s and an integer k. You can choose any character of the string and change it to any other uppercase English character. You can perform this operation at most k times.

Return the length of the longest substring containing the same letter you can get after performing the above operations.

 

Example 1:

Input: s = "ABAB", k = 2
Output: 4
Explanation: Replace the two 'A's with two 'B's or vice versa.
Example 2:

Input: s = "AABABBA", k = 1
Output: 4
Explanation: Replace the one 'A' in the middle with 'B' and form "AABBBBA".
The substring "BBBB" has the longest repeating letters, which is 4.
 

Constraints:

1 <= s.length <= 105
s consists of only uppercase English letters.
0 <= k <= s.length

'''

#Solution
#Approach-1

class Solution:
    def characterReplacement(self, s: str, k: int) -> int:
        count = {}
        res = 0
        l = 0
        maxf = 0
        for r in range(len(s)):
            count[s[r]] = 1 + count.get(s[r], 0)
            maxf = max(maxf, count[s[r]])
            if (r - l + 1) - maxf > k:
                count[s[l]] -= 1
                l += 1

            res = max(res, r - l + 1)
        return res
    
#Approach-2
# Sliding window, Hashmap | O(n) time O(1) space
# hashmap
# sliding window

class Solution:
    def characterReplacement(self, s: str, k: int) -> int:
        m=defaultdict(lambda:0)
        
        l,r=0,0
        mf=0  # max frequency
        ml=0
        
        while r<len(s):
            m[s[r]]+=1
            
            if m[s[r]]>mf:
                mf=m[s[r]]
            
            if (r-l+1)-mf <= k:
                if r-l+1>ml:
                    ml=r-l+1
            else:
                m[s[l]]-=1
                l+=1
                mf=0
            
            r+=1
        
        return ml
    
#Approach-3
# Using Sliding Window Easy to Understand 
# sliding window
# sliding pointers

from collections import defaultdict

class Solution(object):
    def characterReplacement(self, s, k):
        l, r = 0, 0
        dic = [0 for i in range(26)]
        
        while r < len(s):
            start, end = s[l:l+1], s[r:r+1]
            dic[ord(end) - ord('A')] += 1
            
            if max(dic) + k < r - l + 1:
                dic[ord(start) - ord('A')] -= 1
                l += 1
            
            r += 1
        
        return r - l

#Approach-4

# fast-solution
# sliding-window
# explanation
# Iterate over the length of the string, at each point you have a candidate window. The size of candidate windown is always the size of so far longest achievable substring. At each step, the size of the window (from start to i, the current index) will either remain the same or increases by 1. Anytime it increases by 1 it marks a new record.

# You always maintains the most common character in the window which I call curMax and also the counts of characters in the window. Given these you can decide whether the current candidate windown is viable in which case you don't increase the start variable or if it's not viable in which case you increase.

# The trick to a fast solution is to realize thatcurMax will either remain the same or flips to the most recently seen character.

class Solution:
    def characterReplacement(self, s: str, k: int) -> int:
        counts = {}
        curMax, start = s[0], 0
        for i, c in enumerate(s):
            counts[c] = counts.get(c, 0) + 1
            if counts[c] > counts[curMax] or (counts[c] == counts[curMax] and curMax == s[start]):
                curMax = c
            flips = i - start + 1 - counts[curMax]
            if flips > k:
                counts[s[start]] -= 1
                start += 1
        return len(s)- start

    
#Approach-5

# O(N) and O(1) with List and explanation


class Solution:
    def characterReplacement(self, s: str, k: int) -> int:
        if len(s) == 1:
            return 1
        
        l, r, max_length, max_num_of_repeating_char = 0, 0, 0, 0
        char_count_list = [0] * 26
        
        for char in s:
            # Find the char index and increment the count of this char in the list
            char_index = ord(char) - ord('A')
            char_count_list[char_index] += 1
            
            # Every time the count of a char is incremented, check to see if it's the leading repeated char
            max_num_of_repeating_char = max(max_num_of_repeating_char, char_count_list[char_index])
            
            # Find the number of character to replace by subtracting the count of the repeating char from the length of the current window
            #                    The length of the current window -> r - l + 1
            # If: the number of char needed to be replaced is <= the total number of replacement k, update the max_length
            # Else: move the left pointer 1 unit to the right but before that, decrement the count of the char l is currently looking at
            num_of_char_to_replace = (r - l + 1) - max_num_of_repeating_char
            if num_of_char_to_replace <= k:
                max_length = (r - l + 1)
            else:
                char_count_list[ord(s[l]) - ord('A')] -= 1
                l += 1
            
            r += 1
            
        return max_length


#Q4. Maximum Number of Visible Points

'''

You are given an array points, an integer angle, and your location, where location = [posx, posy] and points[i] = [xi, yi] both denote integral coordinates on the X-Y plane.

Initially, you are facing directly east from your position. You cannot move from your position, but you can rotate. In other words, posx and posy cannot be changed. Your field of view in degrees is represented by angle, determining how wide you can see from any given view direction. Let d be the amount in degrees that you rotate counterclockwise. Then, your field of view is the inclusive range of angles [d - angle/2, d + angle/2].


You can see some set of points if, for each point, the angle formed by the point, your position, and the immediate east direction from your position is in your field of view.

There can be multiple points at one coordinate. There may be points at your location, and you can always see these points regardless of your rotation. Points do not obstruct your vision to other points.

Return the maximum number of points you can see.

 

Example 1:


Input: points = [[2,1],[2,2],[3,3]], angle = 90, location = [1,1]
Output: 3
Explanation: The shaded region represents your field of view. All points can be made visible in your field of view, including [3,3] even though [2,2] is in front and in the same line of sight.
Example 2:

Input: points = [[2,1],[2,2],[3,4],[1,1]], angle = 90, location = [1,1]
Output: 4
Explanation: All points can be made visible in your field of view, including the one at your location.
Example 3:


Input: points = [[1,0],[2,1]], angle = 13, location = [1,1]
Output: 1
Explanation: You can only see one of the two points, as shown above.
 

Constraints:

1 <= points.length <= 105
points[i].length == 2
location.length == 2
0 <= angle < 360
0 <= posx, posy, xi, yi <= 100

'''

#Solution 

#Approach-1

# O(n*log(n)) by sorting and two pointers

# One has to deal with the points at location in a special way, because their angle is undefined. They are always in the cone.

import math
class Solution:
    def visiblePoints(self, points: List[List[int]], angle: int, location: List[int]) -> int:
        angle = angle * math.pi / 180  # convert to radians
        # convert points to angles
        centered_points = ([p[0] - location[0], p[1] - location[1]] for p in points if p != location)
        angles = [math.atan2(p[1], p[0]) for p in centered_points]
        zero_points = len(points) - len(angles)
        nonzero_points = len(angles)
        # Sort by angle
        angles.sort()
        # add copy of angles + 2*pi to the end so range is [-pi, 3*pi)
        angles = angles + [ang + 2 * math.pi for ang in angles]
        
        # for each point determine how many points are in cone, if that point is on the right side of the cone
        max_points = zero_points
        end_index = 0
        for i in range(nonzero_points):
            left_angle = angles[i] + angle
            # to determine the left point use binary search
            while angles[end_index] <= left_angle:
                end_index += 1
            max_points = max(end_index - i + zero_points, max_points)
            
        return max_points
    

#Approach-2
# Sliding Window in Polar Coordinates


class Solution(object):
    def visiblePoints(self, points, angle, location):
        # original location
        x0, y0 = location

        # transform points to polar co-ordinates
        angle *= pi / 180
        angles = sorted([atan2(x - x0, y - y0) for x, y in points if x != x0 or y != y0])
        n = len(angles)
        # add 360 degrees to each angle
        angles += [2 * pi + a for a in angles]

        # window sliding
        left = right = max_visible_points = 0
        while left < n:
            while right < 2 * n and angles[right] - angles[left] <= angle:
                right += 1
            max_visible_points = max(max_visible_points, right - left)
            while left < n and angles[right] - angles[left] > angle:
                left += 1
        return max_visible_points + len(points) - n
    
    
#Approach-3: circular 2-pointer handling

class Solution:
    def visiblePoints(self, points: List[List[int]], angle: int, location: List[int]) -> int:
        angles = [ ]
        always_visible = 0
        x1, y1 = location
        for x2, y2 in points:
            # we always need to include this point, irrespective of the angle
            if x1== x2 and y2 == y1:
                always_visible +=1
            else:
                ang_rad = math.atan2((y2-y1),(x2-x1))  
                angles.append(math.degrees(ang_rad))
        angles.sort()
        
        maxcount = 0
        l, r = 0, 0
        n = len(angles)
        
        while l < len(angles):
		   # use r != l + n to avoid travel past l
		   # use (angles[r % n] - angles[l]) % 360 to caculate angle diff
            while r != l + n and (angles[r % n] - angles[l]) % 360 <= angle:
                r += 1
            maxcount = max(maxcount, (r - l))
            l += 1
        return maxcount + always_visible

    
#Approach-4: Uses Atan2 and BinarySearch

# Uses field of vision from current points angle to get a rotating window approach.
# For angles close to 360, remaining angle greater than 0 degree found separately.

# (please let me know in comments if code is not explanatory, I will add more explanation)

class Solution:
    def visiblePoints(self, points: List[List[int]], angle: int, location: List[int]) -> int:
        
        def getAngle(x,y):
            d = math.degrees(math.atan2(y,x))
            if 0 <= d <= 180:
                return d
            else:
                return 360+d
        
        
        angle_counts = collections.Counter()
        own = 0
        
        for p in points:
            y = p[0]-location[0]
            x = p[1]-location[1]
            if x == 0 and y == 0:
                own += 1
            else:
                angle_counts[getAngle(x,y)] += 1
            

        angles = []
        counts = []
        for k in sorted(list(angle_counts.keys())):
            angles.append(k)
            counts.append(angle_counts[k])

            
        s = 0
        sums = []
        for c in counts:
            s += c
            sums.append(s)
        
        def query(i,j):
            if i == 0:
                return sums[j]
            else:
                return sums[j] - sums[i-1]
        
        mx = 0
        for i,a in enumerate(angles):
            if a + angle <= 360:
                idx = bisect.bisect_left(angles,a+angle)
                if idx == len(angles) or angles[idx] > (a+angle):
                    idx -= 1
                mx = max(mx,query(i,idx))
            else:
                rem = (a+angle)-360
                pts = query(i,len(angles)-1)
                idx = bisect.bisect_left(angles,rem)
                if idx == 0 and angles[idx] > rem:
                    pts += 0
                else:
                    if idx == len(angles) or angles[idx] > rem:
                        idx -= 1
                    pts += query(0,idx)
                mx = max(pts,mx)
        return mx+own


#Q5. Subarrays with K Different Integers

'''

Given an integer array nums and an integer k, return the number of good subarrays of nums.

A good array is an array where the number of different integers in that array is exactly k.

For example, [1,2,3,1,2] has 3 different integers: 1, 2, and 3.
A subarray is a contiguous part of an array.

 

Example 1:

Input: nums = [1,2,1,2,3], k = 2
Output: 7
Explanation: Subarrays formed with exactly 2 different integers: [1,2], [2,1], [1,2], [2,3], [1,2,1], [2,1,2], [1,2,1,2]
Example 2:

Input: nums = [1,2,1,3,4], k = 3
Output: 3
Explanation: Subarrays formed with exactly 3 different integers: [1,2,1,3], [2,1,3], [1,3,4].
 

Constraints:

1 <= nums.length <= 2 * 104
1 <= nums[i], k <= nums.length

'''

#Solution

# Approach 1: Sliding Window

# Time Complexity: O(N)O(N), where NN is the length of A.

# Space Complexity: O(N)O(N).

class Window:
    def __init__(self):
        self.count = collections.Counter()
        self.nonzero = 0

    def add(self, x):
        self.count[x] += 1
        if self.count[x] == 1:
            self.nonzero += 1

    def remove(self, x):
        self.count[x] -= 1
        if self.count[x] == 0:
            self.nonzero -= 1

class Solution(object):
    def subarraysWithKDistinct(self, A, K):
        window1 = Window()
        window2 = Window()
        ans = left1 = left2 = 0

        for right, x in enumerate(A):
            window1.add(x)
            window2.add(x)

            while window1.nonzero > K:
                window1.remove(A[left1])
                left1 += 1

            while window2.nonzero >= K:
                window2.remove(A[left2])
                left2 += 1

            ans += left2 - left1

        return ans
    
# Approach 2:

# atMostK algorithm

import collections

class Solution:
    def subarraysWithKDistinct(self, nums: List[int], k: int) -> int:
        # exact k = atMostK(k) - atMost(k-1)
        def atMostK(k):
            counter = collections.defaultdict(int)
            res = i = 0
            for j in range(len(nums)):
                if counter[nums[j]] == 0:
                    k -= 1
                counter[nums[j]] += 1
                while k < 0:
                    counter[nums[i]] -= 1
                    if counter[nums[i]] == 0:
                        k += 1
                    i += 1
                res += j - i + 1
            return res
        return atMostK(k) - atMostK(k-1)
 

# Approach 3:

class Solution:
    def subarraysWithKDistinct(self, nums: List[int], k: int) -> int:
        count=0
        right=0
        left=0
        dic={}
        while right < len(nums):
            if nums[right] not in dic:
                dic[nums[right]]=1
            else:
                dic[nums[right]]+=1
            while len(dic) > k:
                dic[nums[left]]-=1
                if dic[nums[left]]==0:
                      del dic[nums[left]]
                left+=1
            right+=1
            dupleft=left
            dic2=dic.copy()
            while len(dic2)==k and left <= right:
                count+=1
                dic2[nums[dupleft]]-=1
                if dic2[nums[dupleft]]==0:
                    del dic2[nums[dupleft]]
                dupleft+=1      
        return count

# Approach 4:
# prefix sum + sliding window

# you may also maintain 2 windows, but that's too complicated
class Solution:
    def atMostK(self, A, K):
        window = collections.defaultdict(int)
        left = right = 0
        limit = len(A)
        ans = 0
        while right < limit:
            n = A[right]
            
            window[n] += 1
            
            while len(window) > K:
                d = A[left]
                left += 1
                
                window[d] -= 1
                if window[d] == 0:
                    del window[d]
            ans += right - left + 1
            right += 1
        return ans
    def subarraysWithKDistinct(self, A: List[int], K: int) -> int:
        if not A:
            return 0
        
        return self.atMostK(A, K) - self.atMostK(A, K - 1)


        
