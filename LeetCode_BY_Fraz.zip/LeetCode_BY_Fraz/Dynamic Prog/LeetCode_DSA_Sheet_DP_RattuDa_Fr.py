
#Daynamic Programming 

#Q1.  Maximum Subarray
'''

Given an integer array nums, find the contiguous subarray (containing at least one number) which has the largest sum and return its sum.

A subarray is a contiguous part of an array.

 

Example 1:

Input: nums = [-2,1,-3,4,-1,2,1,-5,4]
Output: 6
Explanation: [4,-1,2,1] has the largest sum = 6.
Example 2:

Input: nums = [1]
Output: 1
Example 3:

Input: nums = [5,4,-1,7,8]
Output: 23
 

Constraints:

1 <= nums.length <= 105
-104 <= nums[i] <= 104
Follow up: If you have figured out the O(n) solution, try coding another solution using the divide and conquer approach, which is more subtle.

'''

#Solution 

#Method-1
# Traverse from left to right and find the maximum subarray.
# Rule:

# If the current sum is <= 0, we reset the current sum and add the current number to 0 (which = nums[i])
# Otherwise we add the current number to the current sum.


class Solution:
    def maxSubArray(self, nums: List[int]) -> int:
        max_sum, cur_sum = -float("inf"), -float("inf")
        for i in range(len(nums)):
            if cur_sum <= 0:
                cur_sum = nums[i]
            else:
                cur_sum += nums[i]
            max_sum = max(cur_sum, max_sum)
        return max_sum
            
#Method-2
class Solution:
    def maxSubArray(self, nums):
        Sum = nums[0]
        cur = 0
        for i in nums:
            Sum = max(Sum,cur + i) 
            cur = max(cur + i,0)            
        return Sum
 

#Method-3    
#Kadanes Algoritham

class Solution:
    def maxSubArray(self, nums: List[int]) -> int:
        overallMax = float('-inf')
        localMax = float('-inf')
        
        for num in nums:
            localMax = max(num, localMax + num)
            overallMax = max(localMax, overallMax)
    
        return overallMax
    
    
#Another way
# O(n) solution

class Solution:
    def maxSubArray(self, nums: List[int]) -> int:
        
        # calculate the prefix sum for every iteration of nums array
        # for calculating it, choose max from b/w the num and prevSum+num
        # for every sum calculated get the maxSum
        
        maxSum = _sum = float('inf')*(-1)
        for num in nums:
            _sum = max(_sum+num, num)
            maxSum = max(maxSum, _sum)
        
        return maxSum

#Method-4

class Solution:
    def maxSubArray(self, nums: List[int]) -> int:
        if len(nums) == 1: return nums[0]
        current_sum = float("-inf")
        max_sum = current_sum
        for num in nums:
            if num >= current_sum + num:
                current_sum = num
            else:
                current_sum += num
            max_sum = max(max_sum, current_sum)
        return max_sum 
    
    
#Method-5
#  (DP O(n) space, O(1) space).
# dynamic-programming

# DP, O(n) space
class Solution:
    def maxSubArray(self, nums):
        if not nums:
            return None
        dp = [0] * len(nums)
        res = dp[0] = nums[0]
        for i in range(1, len(nums)):
            dp[i] = max(dp[i-1]+nums[i], nums[i])
            res = max(res, dp[i])
        return res
       
# DP, constant space

class Solution:
    def maxSubArray2(self, nums):
        if not nums:
            return None
        loc = glo= nums[0]
        for i in range(1, len(nums)):
            loc = max(loc+nums[i], nums[i])
            glo = max(loc, glo)
        return glo


#Q2. Climbing Stairs

'''
You are climbing a staircase. It takes n steps to reach the top.

Each time you can either climb 1 or 2 steps. In how many distinct ways can you climb to the top?

 

Example 1:

Input: n = 2
Output: 2
Explanation: There are two ways to climb to the top.
1. 1 step + 1 step
2. 2 steps
Example 2:

Input: n = 3
Output: 3
Explanation: There are three ways to climb to the top.
1. 1 step + 1 step + 1 step
2. 1 step + 2 steps
3. 2 steps + 1 step
 

Constraints:

1 <= n <= 45

'''
#Solution


# Method-1
# recursive
# memomization

class Solution:
    def climbStairs(self, n: int) -> int:
        cache = {}
        def climb(n):
            # avoid duplicate calculations (memoization)
            if n in cache:
                return cache[n]
            # base case    
            # for the number of stairs 1 and 2, the prababilities are 1 and 2 respectiveley
            if n < 3:
                result = n
            else:
                # we take either 1 or 2 steps
                # so we should combine the probabilities of those two decisions recursively
                result = climb(n-1) + climb(n-2)
            # cache the result for further use (memoization)
            cache[n] = result
            return result

        return climb(n)


#Method-2

# I use factorial to solve this problem. The multiple function is used to calculate factorial. In the second part, I define a helper function. For example if n=8 (sum=8), the different combination for 2 and 1

def multiple(num):      #n!=n*(n-1)*(n-2)..1
    total = num
    if num==1 or num==0:
        return 1
    else:
        total *= multiple(num-1)
    return total

class Solution:
    def climbStairs(self, n: int) -> int:
        count=0
                
        
        #n is stair number, z is number of two
        def func(n, z):
            nonlocal count
            
            if z*2 > n:
                return 0
            count += multiple(n-z)/(multiple(z)*multiple(n-2*z))
            
            func(n, z+1)
            return int(count)
                        
            
        return func(n, 0)
    
    
#Method-3

class Solution:
    def climbStairs(self, n: int) -> int:
        if n <= 2:
            return n
        
        prev_1, prev_2 = 2, 1
        for i in range(3, n+1):
            cur = prev_1 + prev_2
            prev_1, prev_2 = cur, prev_1
        return cur
    
#Method-4    
# dynamic programming
# linear time
# constant memory

class Solution:
    def climbStairs(self, n: int) -> int:
        x, y = 1, 1
        for i in range(n-1):
            tmp = x + y
            y = x
            x = tmp
        return x
    
#Method-5
# using simple Fibb Sequence

class Solution(object):
    def climbStairs(self, n):
        
        prev,prev2=1,1
        for i in range(n-1):
            temp=prev
            prev=prev+prev2
            prev2=temp
        return prev

#Q3.Divisor Game

'''
Alice and Bob take turns playing a game, with Alice starting first.

Initially, there is a number n on the chalkboard. On each player's turn, that player makes a move consisting of:

Choosing any x with 0 < x < n and n % x == 0.
Replacing the number n on the chalkboard with n - x.
Also, if a player cannot make a move, they lose the game.

Return true if and only if Alice wins the game, assuming both players play optimally.

 

Example 1:

Input: n = 2
Output: true
Explanation: Alice chooses 1, and Bob has no more moves.
Example 2:

Input: n = 3
Output: false
Explanation: Alice chooses 1, Bob chooses 1, and Alice has no more moves.
 

Constraints:

1 <= n <= 1000

'''

#Solution

# Top Down DP | O(n^2)
# DFS

from functools import cache
class Solution:
    def divisorGame(self, n: int) -> bool:
        @cache
        def dfs(n):
            if n == 1: return False
            for i in range(1, n):
                if n%i == 0:
                    if not dfs(n-i): return True
            return False
        return dfs(n)
    
        
# Method-5
# DP with comments

import math
class Solution:
    def divisorGame(self, n: int) -> bool:
        if n<2:
            return False
		# make a dp of who won for every value<=n
        # False if bob win 
        dp=[False]*(n+1)
        # n equal 2 alice win
        dp[2]=True
        
        # iterate from 3 to n
        for i in range(3,n+1):
            # number to substaract each round
            for j in range(1,int(math.sqrt(i))+1):
                # check if j can be substract, if i-j is win by Bob, 
                # i can be win by alice, because they take turn to
                # make substract
                if i%j==0 and dp[i-j]==False:
                    dp[i]=True
        return dp[-1]


#Q4. Counting Bits

'''
Given an integer n, return an array ans of length n + 1 such that for each i (0 <= i <= n), ans[i] is the number of 1's in the binary representation of i.

 

Example 1:

Input: n = 2
Output: [0,1,1]
Explanation:
0 --> 0
1 --> 1
2 --> 10
Example 2:

Input: n = 5
Output: [0,1,1,2,1,2]
Explanation:
0 --> 0
1 --> 1
2 --> 10
3 --> 11
4 --> 100
5 --> 101
 

Constraints:

0 <= n <= 105
 

Follow up:

It is very easy to come up with a solution with a runtime of O(n log n). Can you do it in linear time O(n) and possibly in a single pass?
Can you do it without using any built-in function (i.e., like __builtin_popcount in C++)?

'''

#Solution 

#Method-1

class Solution:
    def countBits(self, n: int) -> List[int]:
        ans = []
        tmp = 0 
        #mis-interpretation!
        for i in range(n+1):
            #count the number of 1's as binary bits
            while i>0:
                if (i%2) == 1:
                    tmp = tmp+1
                i = i >> 1
            ans.append(tmp)
            tmp = 0 #to reset 
        return ans
 

#Method-2
#DP 
class Solution:
    def countBits(self, n: int) -> List[int]:
        dp = [0] * (n+1)
        offset = 1 
        for i in range(1, n+1):
            if offset * 2 == i:
                offset = i
            dp[i] = dp [i - offset] + 1
        return dp

#Method-3
#Another DP 

class Solution:
    def countBits(self, n: int) -> List[int]:
        dp = [0] * (n+1)
        
        for i in range(1, n+1):
            dp[i] = dp[i//2] + (i & 1)
            
        return dp[:n+1] 
    
    
#Method-4
# If the number i is even, then the number of 1s in i is the same as the number of 1s in i/2.
# If the number i is odd, then the number of 1s in i is ( the number of 1s in i//2 ) plus 1.

class Solution:
    def countBits(self, num):
        bits = [0] * (num + 1)
        for i in range(num+1):
            if i % 2 == 0: # even
                bits[i] = bits[i//2]
            else: # odd
                bits[i] = bits[i//2] + 1
        return bits
    
#Method-5

class Solution(object):
    def countBits(self, num):
        """
        :type num: int
        :rtype: List[int]
        """
        def sum_digits(n):
            s = 0
            while n:
                 s += n % 10
                 n //= 10
            return s
        res =[]
        for i in range(0,num+1):
            b = int('{0:08b}'.format(i))
            res.append(sum_digits(b))
        return res



 #Q5. Decode Ways

'''
A message containing letters from A-Z can be encoded into numbers using the following mapping:

'A' -> "1"
'B' -> "2"
...
'Z' -> "26"
To decode an encoded message, all the digits must be grouped then mapped back into letters using the reverse of the mapping above (there may be multiple ways). For example, "11106" can be mapped into:

"AAJF" with the grouping (1 1 10 6)
"KJF" with the grouping (11 10 6)
Note that the grouping (1 11 06) is invalid because "06" cannot be mapped into 'F' since "6" is different from "06".

Given a string s containing only digits, return the number of ways to decode it.

The test cases are generated so that the answer fits in a 32-bit integer.

 

Example 1:

Input: s = "12"
Output: 2
Explanation: "12" could be decoded as "AB" (1 2) or "L" (12).
Example 2:

Input: s = "226"
Output: 3
Explanation: "226" could be decoded as "BZ" (2 26), "VF" (22 6), or "BBF" (2 2 6).
Example 3:

Input: s = "06"
Output: 0
Explanation: "06" cannot be mapped to "F" because of the leading zero ("6" is different from "06").
 

Constraints:

1 <= s.length <= 100
s contains only digits and may contain leading zero(s).

'''
#Sloution


#Method-1

class Solution:
    def numDecodings(self, s: str) -> int:
        n = len(s)
        dp = [1]*n
        
        if s[0] == '0': return 0
        
        for i in range(1, n):
            if s[i] == '0':
                if s[i-1] == '1' or s[i-1] == '2':
                    if i > 1:
                        dp[i] = dp[i-2]
                else:
                    return 0
                
                continue
            
            if int(s[i-1:i+1]) > 26 or s[i-1] == '0':
                dp[i] = dp[i-1]
            else:
                if i > 1:
                    dp[i] = dp[i-1] + dp[i-2]
                else:
                    dp[i] = 2
        
        return dp[n-1]

#Method-2

# Dynamic Programming || O(n) time & O(1) Space

class Solution:
    def numDecodings(self, s: str) -> int:
        dp2 = dp = 0
        dp1 = 1
        for i in range(len(s) - 1, -1, -1):
            dp = 0
            if s[i] != "0":
                if int(s[i:i + 2]) <= 26:
                    dp = dp1 + dp2
                else:
                    dp = dp1
            dp2, dp1 = dp1, dp
        return dp
 
#Method-3
#Another way Dp

 #O(N), O(1)


class Solution:
    def numDecodings(self, s: str) -> int:
        if s[0] == "0":
            return 0
        
        one = two = 1
        last = s[0]
        for i in range(1, len(s)):
            curr = 0
            if 0 < int(last + s[i]) <= 26 and last != "0":
                curr += two
            if s[i] != "0":
                curr += one
            one, two, last = curr, one, s[i]

        return one
    
    
#Method-4   
#dynamic programming w/ memoizatoin

class Solution:
    def numDecodings(self, s: str) -> int:
        # DP, Memoization 
        letters, memo = dict(), dict()
        characters = 'abcdefghijklmnopqrstuvwxyz'
        for i in range(len(characters)):
            letters[str(i + 1)] = characters[i]
            
        return self.dp(s, letters, memo)
    
    def dp(self, s, letters, memo):
        # base cases
        if s in memo:
            return memo[s]
        if not s:
            return 1
        
        memo[s] = 0
        for i in range(len(s)):
            if s[0:i + 1] in letters:
                memo[s] += self.dp(s[i + 1:], letters, memo)
        
        return memo[s]
    
    
#Method-5

class Solution:
    # @param s, a string
    # @return an integer
    def numDecodings(self, s):
        length=len(s)
        if length==0:
            return 0
        D=[0]*(length+1)
        D[-1]=1
        D[-2]=1 if int(s[-1])>=1 and int(s[-1])<=26 else 0
        for i in range(length-2,-1,-1):
            bridge=True if int(s[i:i+2])>=10 and int(s[i:i+2])<=26 else False
            bonus=D[i+2] if bridge==True else 0
            if int(s[i])!=0:
                D[i]=D[i+1]+bonus
            else:
                D[i]=0
       
        return D[0]



# Q6 Word Break
'''
Given a string s and a dictionary of strings wordDict, return true if s can be segmented into a space-separated sequence of one or more dictionary words.

Note that the same word in the dictionary may be reused multiple times in the segmentation.

 

Example 1:

Input: s = "leetcode", wordDict = ["leet","code"]
Output: true
Explanation: Return true because "leetcode" can be segmented as "leet code".
Example 2:

Input: s = "applepenapple", wordDict = ["apple","pen"]
Output: true
Explanation: Return true because "applepenapple" can be segmented as "apple pen apple".
Note that you are allowed to reuse a dictionary word.
Example 3:

Input: s = "catsandog", wordDict = ["cats","dog","sand","and","cat"]
Output: false
 

Constraints:

1 <= s.length <= 300
1 <= wordDict.length <= 1000
1 <= wordDict[i].length <= 20
s and wordDict[i] consist of only lowercase English letters.
All the strings of wordDict are unique.
'''

# Solution 

#Method-1
#DP
class Solution:
	def wordBreak(self, s: str, wordDict: List[str]) -> bool:

		dp = [False] * (len(s)+1)

		dp[len(s)] = True

		for i in range(len(s) -1, -1, -1):

			for word in wordDict:
				if (i+ len(word)<= len(s) and s[i:i+len(word)]== word):
					# This is handling the non True cases
					dp[i] = dp[i+len(word)]

				if dp[i]:
					break

		return dp[0]

#Method-2
#Memoization
#DP
class Solution:
    def wordBreak(self, s: str, wordDict: List[str]) -> bool:
        map1={}
        def search(s1):
            if s1 in map1:
                return map1[s1]
            if s1=='':
                return True
            for i in wordDict:
                if(s1.find(i)==0):       
                    map1[s1] = search(s1[len(i):])
                    if map1[s1]:
                        return True
            return False
        return search(s)
    
    
#Method-3
# O(N*M*K), O(N)
# Dynamic programming

class Solution:
    def wordBreak(self, s: str, wordDict: List[str]) -> bool:
        table = [False] * (len(s) + 1)
        table[0] = True
        
        for i in range(len(s) + 1):
            for word in wordDict:
                if i < len(word):
                    continue
                if s[i-len(word):i] == word:
                    table[i] = table[i] or table[i-len(word)]

        return table[-1]

    
    
#Method-4
# BRUTE FORCE:

class Solution:
    def wordBreak(self, s: str, wordDict: List[str]) -> bool:
        myset = set(wordDict)
        
        def rec(sub):
            size = len(sub)
            if size == 0:
                return True
            for i in range(1,size+1):
                if sub[0:i] in myset:
                    if rec(sub[i:]):
                        return True
            return False
                
        return rec(s)
    
# T-> O(2^n)

#Method-5
# DYNAMIC PROGRAMMING:

class Solution:
    def wordBreak(self, s: str, wordDict: List[str]) -> bool:
        myset = set(wordDict)
        flag = [-1]*(len(s)+1)
        
        def rec(sub):
            size = len(sub)
            if size == 0:
                return True
            if flag[size] != -1:
                return flag[size]
            for i in range(1,size+1):
                if sub[0:i] in myset:
                    if rec(sub[i:]):
                        flag[size] = 1
                        return True
            flag[size] =0
            return False
                
        return rec(s)


# Q7 Delete and Earn
'''
You are given an integer array nums. You want to maximize the number of points you get by performing the following operation any number of times:

Pick any nums[i] and delete it to earn nums[i] points. Afterwards, you must delete every element equal to nums[i] - 1 and every element equal to nums[i] + 1.
Return the maximum number of points you can earn by applying the above operation some number of times.

 

Example 1:

Input: nums = [3,4,2]
Output: 6
Explanation: You can perform the following operations:
- Delete 4 to earn 4 points. Consequently, 3 is also deleted. nums = [2].
- Delete 2 to earn 2 points. nums = [].
You earn a total of 6 points.
Example 2:

Input: nums = [2,2,3,3,3,4]
Output: 9
Explanation: You can perform the following operations:
- Delete a 3 to earn 3 points. All 2's and 4's are also deleted. nums = [3,3].
- Delete a 3 again to earn 3 points. nums = [3].
- Delete a 3 once more to earn 3 points. nums = [].
You earn a total of 9 points.
 

Constraints:

1 <= nums.length <= 2 * 104
1 <= nums[i] <= 104

'''

#Solution

#Method-1

# We can break this down into several smaller problems.
# We can use a counter to put all numbers and the count of those numbers in a dictionary.
# We can use pointers on the sorted counter to find connected values.
# We can use a dynamic programming function similar to the house robber problem to find the maximum amount of value without directly touching another value.


class Solution:
    def deleteAndEarn(self, nums: List[int]) -> int:
        counter = Counter(nums)   
        def my_func(lp,rp):
            pt_range = rp - lp
            if pt_range < 2:
                return max(counter[rp]*rp,counter[lp]*lp)
            #Find the max_value that we can return for this group. (See house robber question @ https://leetcode.com/problems/house-robber/?envType=study-plan&id=dynamic-programming-i)
            values = [int((i+lp)*counter[i+lp]) for i in range(pt_range+1)]
            final_values = [0]*len(values)
            final_values[0] = values[0]
            final_values[1]=max(values[0],values[1])
            for i in range(2,len(values)):
                final_values[i]=max(final_values[i-1],final_values[i-2]+values[i])
            return final_values[-1]
        
        final_value = 0
        lp = None
        rp = None
        for i in sorted(counter):
            if lp == None:
                lp = i
                rp = i
                continue
            
            elif rp == None or rp == i-1:
                rp = i    
                continue
            else:
                final_value += my_func(lp,rp)
                lp = i
                rp = i
        final_value += my_func(lp,rp)
        return final_value
    
#Method-2


# DP Solution with DP


# We alrady know that we can build a dp to solve this problem. Just like the house robbery, we can choose to take the nums[i] - 1 or not, thus we have two branches in our dp transition function.

# some tricks:

# Using tail dp guard to solve the edge/corner case.
# Counter to calculte the points
# Although we can just use two variables to calculate the dp because the state dependency is about just two previous states, I prefer to use the whole dp array for clearness.

class Solution:
    def deleteAndEarn(self, nums: List[int]) -> int:
        points = defaultdict(lambda:0)
        max_number = max(nums)
        points = Counter(nums)
        
        max_points = [0] * (max_number + 2)
        for num in range(len(max_points)):
            max_points[num] = max(max_points[num - 1], max_points[num - 2] + points[num] * num)
        
        return max_points[max_number]
    
    
#Method-3

# constant time solution 
# house robber
# dynamic prpgramming
# constant-size-array
        
class Solution:
    def deleteAndEarn(self, nums: List[int]) -> int:
        # similar to house robbers problem
        # here you need to create a freqArr, for the length of maxNumber in nums array
        # then for the values not present in the nums, mark their frequency as 0
        # then create a dp array marking the total points for all the indexes
        # traverse the dp array, for index == 1, total points = currIndex*currIndexFreq
        # if index == 2, total_points = max(currIndex*currIndexFreq or dp[currIndex-1])
        # index > 2, total_points = max(currIndex*currIndexFreq + dp[currIndex-2] or dp[currIndex-1])
        
        freqMap = {}
        maxNumber = max(nums)
        for num in nums:
            if num not in freqMap:
                freqMap[num] = 0
            freqMap[num]+=1
        
        freqArr = [[i,0] for i in range(maxNumber+1)]
        for i in range(1, len(freqArr)):
            if i in freqMap:
                freqArr[i][1] = freqMap[i]
        
        dp = [0 for i in range(len(freqArr))]
        
        for i in range(1, len(dp)):
            currEle = freqArr[i]
            if i == 1:
                dp[i] = currEle[1]*currEle[0]
            elif i == 2:
                dp[i] = max(currEle[1]*currEle[0], dp[i-1])
            else:
                dp[i] = max(currEle[1]*currEle[0] + dp[i-2], dp[i-1])
        
        return dp[-1]

    
# Method-4
# dynamic proramming    
           
class Solution:
    def deleteAndEarn(self, nums: List[int]) -> int:
        dp = [0] * (max(nums) + 1)
        for num in nums:
            dp[num] += num
        for i in range(1, len(dp) - 1):
            dp[i + 1] = max(dp[i], dp[i - 1] + dp[i + 1])
        return dp[-1]

    
    
# Method-5

# After counting the # of occurrences of each number. compute the max # of points using only numbers <= n:

# mx[n] = max(n*count(n) + (n-2)*count(n-2), (n-1)*count(n-1))

# Since we only need the last 2 values of mx we can do it in O(1) space.

class Solution(object):
    def deleteAndEarn(self, nums):
        """
        :type nums: List[int]
        :rtype: int
        """
        d=[0]*10001
        for n in nums:
            d[n]+=1

        a,b=0,d[1]
        for n in range(2,len(d)):
            a,b=b,max(n*d[n]+a, b)
            
        return b



#Q8. Maximal Square
'''
Given an m x n binary matrix filled with 0's and 1's, find the largest square containing only 1's and return its area.

Example 1:

Input: matrix = [["1","0","1","0","0"],["1","0","1","1","1"],["1","1","1","1","1"],["1","0","0","1","0"]]
Output: 4
Example 2:


Input: matrix = [["0","1"],["1","0"]]
Output: 1
Example 3:

Input: matrix = [["0"]]
Output: 0
 

Constraints:

m == matrix.length
n == matrix[i].length
1 <= m, n <= 300
matrix[i][j] is '0' or '1'.

'''

#Solution

#Method-1


class Solution:
    def maximalSquare(self, matrix: List[List[str]]) -> int:
        row = len(matrix)
        col = len(matrix[0])
        if row > 1 and col > 1:
            for i in range(1,row):
                for j in range(1,col):
                    matrix[i][j] = int(matrix[i][j])
                    if matrix[i][j] == 1:
                        matrix[i][j] += min(int(matrix[i][j-1]),int(matrix[i-1][j-1]),int(matrix[i-1][j]))
        ans = 0
        for i in range(row):
            for j in range(col):
                ans = max(ans,int(matrix[i][j]))
        return ans*ans
    
 
#Method-2

#bottom-up (dp)

# dp[i][j] means the length of the square whose right corner at location [i, j]
# the state transition function is dp[i][j] = min(dp[i-1][j], dp[i][j-1], dp[i-1][j-1]) +1 if matrix[i][j]== '1', i in [1, len(matrix)), j in [1, len(matrix[0]) )

# for example, matrix is

# matrix[3][3] is 1, dp[2][2], dp[2][3], dp[3][2] are 1, 1, 0 respectively, so there is no square whose right corner at [3, 3] because matrix[3][2] is 0, so dp[3][3] = min(1,1,0) + 1 = 1
# the matrix[3][4] is a similar case.
# tc is O(len(matrix)*len(matrix[0])), sc is the same as tc.


class Solution:
    def maximalSquare(self, matrix: List[List[str]]) -> int:
        dp = [[0] * len(matrix[0]) for _ in range(len(matrix))]
        for rowIdx, row in enumerate(matrix):
            for colIdx, num in enumerate(row):
                if (rowIdx == 0 or colIdx == 0) and num == '1':
                    dp[rowIdx][colIdx] = 1
                elif num == '1':
                    dp[rowIdx][colIdx] = min(dp[rowIdx-1][colIdx], dp[rowIdx][colIdx-1], dp[rowIdx-1][colIdx-1]) + 1
        ans = max(max(x) for x in dp)
        return ans * ans
 

#Method-3

# # top-down (dfs)

# dfs(r,c) is to find the length of the square whose right corner at [r, c], use cache to store sub result
# if r+1 <= ans: break means there is no bigger square compared to ans * ans in the area [0,0] to [r, ...]
# if c+1 <= ans: break is the same.
# the both try to call dfs less
# tc is O(len(matrix)*len(matrix[0])), sc is the same as tc.


class Solution:
    def maximalSquare(self, matrix: List[List[str]]) -> int:
        ans = 0
        @cache
        def dfs(r, c):
            if matrix[r][c] == '1':
                if r == 0 or c == 0:
                    return 1
                else:
                    return min(dfs(r-1, c), dfs(r, c-1), dfs(r-1, c-1)) + 1
            return 0
        for r in range(len(matrix)-1, -1, -1):
            if r+1 <= ans: break
            for c in range(len(matrix[0])-1, -1, -1):
                if c+1 <= ans: break
                ans = max(ans, dfs(r,c))
        return ans * ans
   

#Method-4

class Solution:
    def maximalSquare(self, matrix: List[List[str]]) -> int:
        rows = len(matrix)
        cols = len(matrix[0])
        dp = [[0] * (cols+1) for _ in range(rows+1)]
        max_side = 0
        for i in range(rows):
            for j in range(cols):
                if matrix[i][j] != "1":
                    continue
                dp[i+1][j+1] = 1 + min([dp[i][j+1], dp[i+1][j], dp[i][j]])
                max_side = max(max_side, dp[i+1][j+1])
        return max_side * max_side
    
    
#Method-5

# O(m*n) DP
# The dp table store the maximum side length when we take matrix[i, j] as the rightmost buttom element in a square.

class Solution:
    def maximalSquare(self, matrix: List[List[str]]) -> int:
        m, n = len(matrix), len(matrix[-1])   
        dp = [[0] * n for _ in range(m)]     
        max_area = 0
        for i in range(m):
            for j in range(n): 
                if i - 1 < 0 or j - 1 < 0:
                    if matrix[i][j] == '1': dp[i][j] = 1
                else:
                    if matrix[i][j] == '1':
                        dp[i][j] = 1 + min(dp[i-1][j-1], dp[i][j-1], dp[i-1][j])
                max_area = max(max_area, dp[i][j] ** 2)
        return max_area



#Q9 Coin Change

'''

You are given an integer array coins representing coins of different denominations and an integer amount representing a total amount of money.

Return the fewest number of coins that you need to make up that amount. If that amount of money cannot be made up by any combination of the coins, return -1.

You may assume that you have an infinite number of each kind of coin.

 

Example 1:

Input: coins = [1,2,5], amount = 11
Output: 3
Explanation: 11 = 5 + 5 + 1
Example 2:

Input: coins = [2], amount = 3
Output: -1
Example 3:

Input: coins = [1], amount = 0
Output: 0
 

Constraints:

1 <= coins.length <= 12
1 <= coins[i] <= 231 - 1
0 <= amount <= 104
'''

#Solution

#Method-1

class Solution:
    def coinChange(self, coins: List[int], amount: int) -> int:
        dp = [-1] * (amount+1)
        dp[0] = 0
        
        for i in range(1, amount+1):
            temp = []
            for j in coins:
                if( i-j >=0 and dp[i-j] != -1):
                    temp.append( dp[i-j])
            if(temp):
                dp[i] = 1  + min(temp)   
        return dp[-1]
        
        
# Method-2       
# Dynamic prpgramming
# Memoization+recursion

class Solution:
    def coinChange(self, coins: List[int], amount: int) -> int:
        d = {}
        def rec(index, sm):
            if sm == 0:
                return 0
            if index < 0:
                return float('inf')
            else:
                take = float('inf')
                if coins[index] <= sm:
                    if (index, sm-coins[index]) not in d:
                        take = 1 + rec(index, sm-coins[index])
                    else:
                        take = 1 + d[(index, sm-coins[index])]
                if (index-1, sm) not in d:
                    notTake = rec(index-1, sm)
                else:
                    notTake = d[(index-1, sm)]
                d[(index, sm)] = min(take, notTake)
                return d[(index, sm)]
        
        ans = rec(len(coins)-1, amount)
        
        if ans == float('inf'):
            return -1
        else:
            return ans

# Method-3
# Solution From Recursion to Space Optimization
# Recursive Solution   
# # Tabulation
    
class Solution:
    def coinChange(self, coins: List[int], amount: int) -> int:
        n = len(coins)
        dp = [[0 for i in range(amount+1) ] for i in range(n)]
        for i in range(amount+1):
            if i % coins[0] == 0:
                dp[0][i] = i//coins[0]
            else:
                dp[0][i] = 1e9
        for ind in range(1,n):
            for amount in range(amount+1):
                notTake = 0 + dp[ind-1][amount]
                take = 1e9
                if coins[ind] <= amount:
                     take = 1 + dp[ind][amount-coins[ind]]
                dp[ind][amount] = min(notTake, take)
        ans = dp[n-1][amount]
        if ans >= 1e9:
            return -1
        return ans
    
# Method-4    
# Space Optimization Solution
# Time Complexity: O(N*T)
# Space Complexity: O(T)

class Solution:
    def coinChange(self, coins: List[int], amount: int) -> int:
        n = len(coins)
        prev = [0 for i in range(amount+1) ]
        cur = [0 for i in range(amount+1)]
        for i in range(amount+1):
            if i % coins[0] == 0:
                prev[i] = i//coins[0]
            else:
                prev[i] = 1e9
        for ind in range(1,n):
            for amount in range(amount+1):
                notTake = 0 + prev[amount]
                take = 1e9
                if coins[ind] <= amount:
                     take = 1 + cur[amount-coins[ind]]
                cur[amount] = min(notTake, take)
            prev = cur
        ans = prev[amount]
        if ans >= 1e9:
            return -1
        return ans
    


#Method-5
# Python || 4-Liner || DP || Straightforward solution
# In DP problems, it is important to define the equation of dp[i]
# Here, dp[num] = minimum number of coins used and store -1 when num cannot be mad. using coins.
# dp[num] = min(dp[num-coins[0]], dp[num-coins[1]], ..., dp[num-coins[M-1]])


class Solution:
    def coinChange(self, coins: List[int], amount: int) -> int:
        dp = [0]
        for i in range(1, amount+1):
            candidate = [dp[i-coin] for coin in coins if i-coin>=0 and dp[i-coin]!=-1]
            dp+=[min(candidate)+1 if candidate else -1]
        return dp[-1]



# Maximum Product Subarray
'''
Given an integer array nums, find a contiguous non-empty subarray within the array that has the largest product, and return the product.

The test cases are generated so that the answer will fit in a 32-bit integer.

A subarray is a contiguous subsequence of the array.

 

Example 1:

Input: nums = [2,3,-2,4]
Output: 6
Explanation: [2,3] has the largest product 6.
Example 2:

Input: nums = [-2,0,-1]
Output: 0
Explanation: The result cannot be 2, because [-2,-1] is not a subarray.
 

Constraints:

1 <= nums.length <= 2 * 104
-10 <= nums[i] <= 10
The product of any prefix or suffix of nums is guaranteed to fit in a 32-bit integer.
'''

# Solution

#Мethod-1

class Solution:
    def maxProduct(self, nums: List[int]) -> int:
        minProd = maxProd = result = nums[0]        # minimum product, maximum product and result
        for n in nums[1:]:                          # for each num
            t = [n, minProd*n, maxProd*n]           # temp array
            minProd, maxProd = min(t), max(t)       # update minProd and maxProd
            result = max(result, minProd, maxProd)  # update the result                                     
        return result
    
    
# Method-2

# Time Complexity: O(n)
# Space Complexity: O(1)
# To be Honest, I don't know much about Dynamic Programming. So, I go with my Intuision.
# Let 'n' numbers of negative integers present in an interval having no zeroes i,e only +ve and -ve integers.
# What I Found Interesting is if 'n' is even then, we include the whole array until there is no zero present in the given interval.
# For eg. [-1 , 2 , 3 , -4 ] ,Here n is 2. so, we include the whole array i,e (-1)(2)(3)* (-4) = +24.

# Similarly, if 'n' is odd then, we simply find the first_negative prefix sum and whenever I encounter a negative prefix sum after it . then, I simply divide it to make it postive.
# Basically whenever I ecounter the -ve prefixsum then it means it is a odd -ve integers in the given array out of 'n' -ve integers.
# For eg.
# nums = [ 2 , -3 , 4 , -6 , -8 ] here n is 3
# prefix = [2 , -6 , -24 , 144 , -1152 ]
# so, the first negative prefix sum is -6.
# whenever I found the -ve prefix sum following it then I simply divide it to make it +ve .
# Let Maxprod = 2 where -6 is the first -ve prefix sum
# step 1: (-24)/(-6) = 4 , Maxprod = max( 4 , 2) = 4
# step2 : 144 is +ve , Maxprod = max( 4 , 144) = 144
# step3: (-1152)/(-6) = 193 Maxprod = max(144 , 288) = 288
# Hence Maxprod = 288 = (4 * -6 * -8)

class Solution:
    def maxProduct(self, nums: List[int]) -> int:
        n = len(nums)
        first_neg = None
        currprod = 1
        maxprod = 1-(1<<32)
        for i in range(n):
            currprod = currprod*nums[i]
            if currprod == 0:
                first_neg = None
                maxprod = max(maxprod,currprod)
                currprod = 1
            elif currprod < 0:
                if first_neg == None:
                    first_neg = currprod
                    maxprod = max(maxprod,currprod)
                else:
                    maxprod = max(maxprod,(currprod//first_neg))
            else:
                maxprod = max(maxprod,currprod)
        
        return maxprod
    
     
# Method-3

# O(N) time and O(1) space, 75ms and 14.3MB

# Restarting the prefix process once we encounter a 0.

class Solution:
    def maxProduct(self, nums: List[int]) -> int:
        if(len(nums) == 1):
            return nums[0]
        prefix = 1
        ans = 0
        minNeg = -float("inf")
        for i in nums:
            prefix = prefix*i
            if(prefix<0):
                if(prefix > minNeg):
                    minNeg = prefix
                else:
                    ans = max(ans, prefix/minNeg)
            elif(prefix == 0):
                prefix = 1
                minNeg = -float("inf")
            else:
                ans = max(prefix, ans)
        return int(ans)
    

# Method-4    
# DP | O(n) Time, O(1) space

class Solution:

    def maxProduct(self, nums: List[int]) -> int:
	
		#subarr[0] stores the maximum product subarray, after reset
		#subarr[1] stores the minimum product subarray, after reset
        subarr = [0, 0]
        result = -float('inf')

        for i in nums:
		
			#whenever 0 is encountered, reset subarr
            if i == 0:
                subarr = [0, 0]
            elif i<0:
                if subarr == [0, 0]:
                    subarr = [i, i]
                else:
                    subarr = [max(i, subarr[1]*i), min(i, subarr[0]*i)]
            else:
                if subarr == [0, 0]:
                    subarr = [i, i]
                else:
                    subarr = [max(i, subarr[0]*i), min(i, subarr[1]*i)]

            result = max(result, subarr[0])

        return result
    
# Method-5

class Solution:
    def maxProduct(self, nums: List[int]) -> int:
        res = nums[0]
        
        currMin, currMax = 1, 1
        
        for n in nums:
            temp = currMax * n # to avoid update of current currMax
            currMax = max(n*currMax, n*currMin, n)
            currMin = min(temp, n*currMin, n)
            res = max(res, currMax,currMin)
           
        return res
    
    
    
    
class Solution(object):
    def maxProduct(self, nums):
        """
        :type nums: List[int]
        :rtype: int
        """
        max_prod, min_prod, ans = nums[0], nums[0], nums[0]
        for i in range(1, len(nums)):
            x = max(nums[i], max_prod*nums[i], min_prod*nums[i])
            y = min(nums[i], max_prod*nums[i], min_prod*nums[i])            
            max_prod, min_prod = x, y
            ans = max(max_prod, ans)
        return ans


#Q10.Maximum Length of Repeated Subarray

'''
Given two integer arrays nums1 and nums2, return the maximum length of a subarray that appears in both arrays.

 

Example 1:

Input: nums1 = [1,2,3,2,1], nums2 = [3,2,1,4,7]
Output: 3
Explanation: The repeated subarray with maximum length is [3,2,1].
Example 2:

Input: nums1 = [0,0,0,0,0], nums2 = [0,0,0,0,0]
Output: 5
 

Constraints:

1 <= nums1.length, nums2.length <= 1000
0 <= nums1[i], nums2[i] <= 100

'''

#Solution

# Method-1
# dynamic progarmming

class Solution:
    def findLength(self, nums1: List[int], nums2: List[int]) -> int:
        dp = [[0] * (len(nums2) + 1) for _ in range(len(nums1) + 1)]
        mx = 0
        for i in range(1, len(dp)):
            for j in range(1, len(dp[0])):
                if nums1[i-1] == nums2[j-1]:
                    dp[i][j] = 1 + dp[i-1][j-1]
                    mx = max(dp[i][j], mx)
                
        return (mx)

# Method-2
# O(mn) time complexity. It looks like a DP but it doesn't depend on previous states so we don't need to maintain the DP array. Therefore it is O(1) space complexity.

class Solution:
    def findLength(self, nums1: List[int], nums2: List[int]) -> int:
        m, n = len(nums1), len(nums2)
        res = 0
        for i in range(n):
            idx_2 = i
            idx_1 = 0
            count = 0
            while idx_2 < n and idx_1 < m:
                if nums1[idx_1] == nums2[idx_2]:
                    count += 1
                else:
                    count = 0
                if count > res:
                    res = count
                idx_1 += 1
                idx_2 += 1
        for i in range(1, m):
            idx_1 = i
            idx_2 = 0
            count = 0
            while idx_2 < n and idx_1 < m:
                if nums1[idx_1] == nums2[idx_2]:
                    count += 1
                else:
                    count = 0
                if count > res:
                    res = count
                idx_1 += 1
                idx_2 += 1
        return res
    
# method-3

class Solution:
	def findLength(self, nums1: List[int], nums2: List[int]) -> int:
		x = len(nums1)
		y = len(nums2)


		if x == 0 and y == 0:
			return 0

		dp = [[0 for i in range(x+1)] for i in range(y+1)]
		ans = 0

		for i in range(len(dp)):
			for j in range(len(dp[0])):
				if i == 0 or j == 0:
					dp[i][j] = 0
				elif nums2[i-1] == nums1[j-1]:
					dp[i][j] = dp[i-1][j-1]+1
					ans = max(ans, dp[i][j])
				else:
					dp[i][j] = 0
		return ans
    
# Method=4
class Solution(object):
    def findLength(self, A, B):
        def check(length):
            seen = set(tuple(A[i:i+length]) 
                       for i in range(len(A) - length + 1))
            return any(tuple(B[j:j+length]) in seen 
                       for j in range(len(B) - length + 1))

        lo, hi = 0, min(len(A), len(B)) + 1
        while lo < hi:
            mi = (lo + hi) // 2
            if check(mi):
                lo = mi + 1
            else:
                hi = mi
        return lo - 1
    
    
#Method-5

# Time O(NM), Space: O(1)

def f(A, B):
    N = len(A)
    M = len(B)
    ret = 0
    for i in range(N):
        alt = 0
        tmp = 0
        for j in range(M):
            a_idx = j+i
            if a_idx == N: break
            b_idx = j
            if A[a_idx] == B[b_idx]:
                tmp += 1
                ret = max(ret, tmp)
            else: tmp = 0
    return ret

class Solution:
    def findLength(self, A: List[int], B: List[int]) -> int:
        return max(f(A, B), f(B, A))


#Q11 Palindromic Substrings

'''
Given a string s, return the number of palindromic substrings in it.

A string is a palindrome when it reads the same backward as forward.

A substring is a contiguous sequence of characters within the string.

 

Example 1:

Input: s = "abc"
Output: 3
Explanation: Three palindromic strings: "a", "b", "c".
Example 2:

Input: s = "aaa"
Output: 6
Explanation: Six palindromic strings: "a", "a", "a", "aa", "aa", "aaa".
 

Constraints:

1 <= s.length <= 1000
s consists of lowercase English letters.

'''
#Solution 

# Method-1

# Just that in this one instead of checking for a paindrome with maximum length you just count the number of palindrome numbers found.

class Solution:
    def countSubstrings(self, s: str) -> int:
        total=0
        for i in range(len(s)):
            #odd
            left,right=i,i
            while(left>=0 and right<len(s) and s[left]==s[right]):
                total+=1
                left-=1
                right+=1
            #even
            left,right=i,i+1
            while(left>=0 and right<len(s) and s[left]==s[right]):
                total+=1
                left-=1
                right+=1
        return total
    
# Method-2

class Solution:
    def countSubstrings(self, s):
        """
        :type s: str
        :rtype: int
        """
        ans = 0
        for i in range(len(s)):
            for j in range(i, len(s)):
                t = s[i:j+1]
                if t == t[::-1]:
                    ans += 1
        return ans
    
# Method-3

class Solution:
    def countSubstrings(self, s: str) -> int:
        def fromMiddle(l, r):
            while l >= 0 and r < len(s) and s[l] == s[r]:
                l -= 1
                r += 1
            return (r - l)//2
        ans = 0
        for i in range(len(s)):
            ans += fromMiddle(i, i) + fromMiddle(i, i + 1)
        return ans

# Method-4

# O(n^2) Time with O(1) Space

# The approach is to iterate over each charater and assume that character as a centre of pallindrome and expand from that centre.

class Solution(object):
    def countSubstrings(self, s):
        if not s:
            return 0
        if len(s)==1:
            return 1

        result=len(s)

        for i in range(0,len(s)):
            right=i
            left=i-1
            
            ##Count for All even length pallindrome
            while left>=0 and right<len(s) and s[left]==s[right]:
                result +=1
                left -=1
                right +=1

            right =i+1
            left=i-1
            
            ## Count for all odd length pallindrome
            while left>=0 and right<len(s) and s[left]==s[right]:
                
                result +=1
                right +=1
                left -=1
        return result
    
    
#dp solution (1's and 0's)

# The idea is that you can't have a palidrome if the characters before aren't a palidrome. Enter dynamic programming to help you track in the previous characters were a palidrome!
# Going back to front (this is just personal preference).

# Set the current value to 1 (characters are always palidromes of themselves).
# Go backwards. If characters match, and the last sequence was a palidrome, set the dp to 1.
# Add accordingly.
# Hopefully the explanation makes sense. The code is below.


class Solution:
    def countSubstrings(self, s):
        """
        :type s: str
        :rtype: int
        """
        dp = [0] * len(s)
        result = 0
        for i in range(len(s)-1, -1, -1):
            dp[i] = 1
            for j in range(len(s)-1, i, -1):
                if s[i] == s[j] and dp[j-1] == 1:
                    dp[j] = 1
                    result += 1
                else:
                    dp[j] = 0
            result += 1
            # print(dp)
        return result

#Q 12 House Robber
'''

You are a professional robber planning to rob houses along a street. Each house has a certain amount of money stashed, the only constraint stopping you from robbing each of them is that adjacent houses have security systems connected and it will automatically contact the police if two adjacent houses were broken into on the same night.

Given an integer array nums representing the amount of money of each house, return the maximum amount of money you can rob tonight without alerting the police.

 

Example 1:

Input: nums = [1,2,3,1]
Output: 4
Explanation: Rob house 1 (money = 1) and then rob house 3 (money = 3).
Total amount you can rob = 1 + 3 = 4.
Example 2:

Input: nums = [2,7,9,3,1]
Output: 12
Explanation: Rob house 1 (money = 2), rob house 3 (money = 9) and rob house 5 (money = 1).
Total amount you can rob = 2 + 9 + 1 = 12.
 

Constraints:

1 <= nums.length <= 100
0 <= nums[i] <= 400
'''
#Solution

# Method-1

class Solution:
    def rob(self, nums: List[int]) -> int:
        next1 = 0
        next2 = 0
        for i in range(0, len(nums)):
            tmp = max(nums[i]+next2, next1)
            next2 = next1
            next1 = tmp
        return tmp
    
# Method-2
# dynamic programming
class Solution:
    def rob(self, nums: List[int]) -> int:
        if len(nums) <=2:
            return max(nums)
        
        amounts = [0] * (len(nums))
        amounts[0] = nums[0]
        amounts[1] = max(nums[1], nums[0])
        
        for index in range(2, len(nums)):
            current_value = nums[index]
            amounts[index] = max(amounts[index-1], current_value + amounts[index-2])
        
        return amounts[-1]


#Method-3

class Solution:
    def rob(self, nums: List[int]) -> int:
        # DP, Memoization
        memo = dict()
        return self.dp(nums, memo)
    
    def dp(self, nums, memo):
        # base case
        if len(nums) in memo:
            return memo[len(nums)]
        if not nums:
            return 0
        
        # take any house but update nums so that the next adjacent house from the chosen house is never picked
        memo[len(nums)] = 0
        for i in range(len(nums)):
            memo[len(nums)] = max(memo[len(nums)], nums[i] + self.dp(nums[i + 2:], memo))
        
        return memo[len(nums)]
    
    
# Method-4
class Solution(object):
    def rob(self, nums):
        """
        :type nums: List[int]
        :rtype: int
        """
        rob1, rob2 = 0, 0
        for n in nums:
            newRob = max(n+rob1, rob2)
            rob1 = rob2
            rob2 = newRob
        return rob2
 
# Method-5
# dynamic programming w/ memoization simple

class Solution:
    def rob(self, nums: List[int]) -> int:
        # DP, Memoization
        memo = dict()
        return self.dp(nums, memo)
    
    def dp(self, nums, memo):
        # base case
        if len(nums) in memo:
            return memo[len(nums)]
        if not nums:
            return 0
        
        # take any house but update nums so that the next adjacent house from the chosen house is never picked
        memo[len(nums)] = 0
        for i in range(len(nums)):
            memo[len(nums)] = max(memo[len(nums)], nums[i] + self.dp(nums[i + 2:], memo))
        
        return memo[len(nums)]




#Q 13 Continuous Subarray Sum


'''

Given an integer array nums and an integer k, return true if nums has a continuous subarray of size at least two whose elements sum up to a multiple of k, or false otherwise.

An integer x is a multiple of k if there exists an integer n such that x = n * k. 0 is always a multiple of k.

 

Example 1:

Input: nums = [23,2,4,6,7], k = 6
Output: true
Explanation: [2, 4] is a continuous subarray of size 2 whose elements sum up to 6.
Example 2:

Input: nums = [23,2,6,4,7], k = 6
Output: true
Explanation: [23, 2, 6, 4, 7] is an continuous subarray of size 5 whose elements sum up to 42.
42 is a multiple of 6 because 42 = 7 * 6 and 7 is an integer.
Example 3:

Input: nums = [23,2,6,4,7], k = 13
Output: false
 

Constraints:

1 <= nums.length <= 105
0 <= nums[i] <= 109
0 <= sum(nums[i]) <= 231 - 1
1 <= k <= 231 - 1

'''
#Solution


# Method-1
# Using dictionary(hash map) O(n)

class Solution:
    def checkSubarraySum(self, nums: List[int], k: int) -> bool:
        pre_sum = {0:-1}
        sum1 = 0
        for i in range(len(nums)):    # O(n)
            sum1 += nums[i]           # to calculate prefix sum of index i
            if sum1 % k in pre_sum:   # if true then that means subarray with given sum ( multiple of k ) is present
                if i - pre_sum[sum1 % k] >= 2:    # this will check if subarray which will form has size greater than 2 or not
                    return True
            else:
                pre_sum[sum1 % k] = i
        return False
    
#Method-2

# O(n) 

class Solution:
    def checkSubarraySum(self, nums: List[int], k: int) -> bool:
        currRem, prevRem = 0, {}
        for i in range(len(nums)):
            currRem = (currRem + nums[i]) % k
            if currRem not in prevRem:
                prevRem[currRem] = i
            if (currRem == 0 and i > 0) or ((i - prevRem[currRem]) > 1):
                return True
        return False
    
#Method-3

class Solution:
    def checkSubarraySum(self, nums: List[int], k: int) -> bool:
        
        if len(nums) < 2 : return False 
        seen = defaultdict(lambda:[])
        prefix = 0 
        
        for i in range(len(nums)):
            prefix += nums[i]
            if prefix%k==0 and i>=1: return True
            seen[prefix%k].append(i)
            if seen[prefix%k][-1] - seen[prefix%k][0] > 1: 
                return True 

        return False
    
#Method-4

class Solution:
    def checkSubarraySum(self, nums: List[int], k: int) -> bool:
        
        d = {0:-1}  # {remainder:index}, index is set to -1 before we traverse the list
        s = 0  # summation of list
        for i, x in enumerate(nums):
            s += x
            r = s % k
            if r in d and i-d[r] > 1:  # remainder already in dict and the distance > 1
                return True
            if r not in d:  # update dict if the remainder is new
                d[r] = i
        return False
    
# Method-5

# Two lines if you don't count the import. Using @compton_scatter's trick of simply not doing %k if k is 0, though done by doing %231 instead.

import numpy as np
class Solution(object):
    def checkSubarraySum(self, nums, k):
        X = np.cumsum([0] + nums) % (k or 2**31)
        return any(x in X[i+2:] for i, x in enumerate(X))
    
    
#Method-6

# O(n) by dict [w/ Comment]

# Think of "Congruence modulo" and prefix sum of remainder when it comes to operation on subarray with mod k.
# math
# dict
# hashmaps

class Solution:
    def checkSubarraySum(self, nums: List[int], k: int) -> bool:
        
        # use maximal integer to represent infinity
        INF = sys.maxsize
        
        # key: remainder of mod k
        # value: leftmost index if we have seen this remainder before
        modulo_dict = { 0:-1 }
        
        # prefix sum of remainder mod k, initialized to 0
        modulo_prefix = 0
            
            
        # scan each number in input array
        for i in range( len(nums) ):
            
            # update prefix sum of remainder mod k
            modulo_prefix = ( modulo_prefix + nums[i] ) % k
            
            
            # check if we have seen this remainder before with index gap >= 2
            if i - modulo_dict.get(modulo_prefix, INF) >= 2:
                return True
            
            
            # update index of current remainder if needed
            if modulo_prefix not in modulo_dict:
                modulo_dict[ modulo_prefix ] = i

        
        return False




#Q14  Knight Dialer

'''

The chess knight has a unique movement, it may move two squares vertically and one square horizontally, or two squares horizontally and one square vertically (with both forming the shape of an L). The possible movements of chess knight are shown in this diagaram:

A chess knight can move as indicated in the chess diagram below:


We have a chess knight and a phone pad as shown below, the knight can only stand on a numeric cell (i.e. blue cell).


Given an integer n, return how many distinct phone numbers of length n we can dial.

You are allowed to place the knight on any numeric cell initially and then you should perform n - 1 jumps to dial a number of length n. All jumps should be valid knight jumps.

As the answer may be very large, return the answer modulo 109 + 7.

 

Example 1:

Input: n = 1
Output: 10
Explanation: We need to dial a number of length 1, so placing the knight over any numeric cell of the 10 cells is sufficient.
Example 2:

Input: n = 2
Output: 20
Explanation: All the valid number we can dial are [04, 06, 16, 18, 27, 29, 34, 38, 40, 43, 49, 60, 61, 67, 72, 76, 81, 83, 92, 94]
Example 3:

Input: n = 3131
Output: 136006598
Explanation: Please take care of the mod.
 

Constraints:

1 <= n <= 5000

'''
#Solution

#Method-1

class Solution:
    def knightDialer(self, n: int) -> int:
        g = {0:[4,6], 1:[6,8], 2:[7,9], 3:[4,8], 4:[0,3,9],
		 5:[], 6:[0,1,7], 7:[2,6], 8:[1,3], 9:[2,4]}
        cur, mod = [1]*10, 10**9+7
        for _ in range(n-1):
            nxt = [0]*10
            for i in range(10):
                for j in g[i]:
                    nxt[j] = (cur[i]+nxt[j])%mod
            cur = nxt
        return sum(cur)%mod
    
#Method-2

class Solution:
    def knightDialer(self, n: int) -> int:
        li = [(4, 6), (8, 6), (7, 9), (4, 8), (3, 9, 0),(), (1, 7, 0), (2, 6), (1, 3), (2, 4)]
        Mod = 10**9 + 7
        def dp(crt,memo,s):
            if s==0:
                return 1
            elif (crt,s) in memo:
                return memo[(crt,s)]
            else:
                k = 0
                
                for j in li[crt]:
                    k+=dp(j,memo,s-1)
                
                memo[(crt,s)] = k%Mod
                return memo[(crt,s)]
        
        ans = 0
        memo = {}
        for i in range(10):
            ans+=dp(i,memo,n-1)
            
        return ans%Mod
    
    
#Method-3

class Solution:
    def knightDialer(self, n: int) -> int:
        unique_paths = 0
        for i in range(4):
            for j in range(3):
                if i == 3 and j == 0 or i == 3 and j == 2:
                    continue
                num_paths = self.find_paths(i, j, n)
                unique_paths += num_paths
        return unique_paths % (10 ** 9 + 7)
                
                
    def find_paths(self, i, j, n, memo={}):
        key = f"{i}{j}{n}"
        if key in memo:
            return memo[key]
        if i < 0 or i > 3 or j < 0 or j > 2 or (i == 3 and j == 0) or (i==3 and j == 2):
            return 0
        if n == 1:
            return 1
        
        paths = self.find_paths(i-2, j-1, n -1, memo) + self.find_paths(i-2, j+1, n -1, memo) + self.find_paths(i-1, j-2, n -1, memo) + self.find_paths(i-1, j+2, n -1, memo) + self.find_paths(i+2, j-1, n -1, memo) + self.find_paths(i+2, j+1, n - 1, memo) + self.find_paths(i+1, j-2, n - 1, memo) + self.find_paths(i+1, j+2, n - 1, memo)
        memo[key] = paths
        return paths
    
    
#Method-4

class Solution:
    def knightDialer(self, N):
        """
        :type N: int
        :rtype: int
        """
        c = 10**9+7
        next_step = [[4,6],[6,8],[7,9],[4,8],[0,3,9],[],[0,1,7],[2,6],[1,3],[2,4]]
        dp = [1]*10
        for i in range(N-1):
            new_dp = [0]*10
            for j in range(10):
                for n in next_step[j]:
                    new_dp[j] += dp[n]%c
                new_dp[j] %=c
            dp = new_dp
        return sum(dp)%c
    
#Method-5
# adjacency matrix solution

# If A is the adjaceny matrix, then (A^n)[i, j] is the number of paths from i to j. So the number of paths of length n is the sum of all the entries in A^n. The graph looks like


import numpy as np

adj = np.matrix([
   # 0  1  2  3  4  5  6  7  8  9
    [0, 0, 0, 0, 1, 0, 1, 0, 0, 0], # 0
    [0, 0, 0, 0, 0, 0, 1, 0, 1, 0], # 1
    [0, 0, 0, 0, 0, 0, 0, 1, 0, 1], # 2
    [0, 0, 0, 0, 1, 0, 0, 0, 1, 0], # 3
    [1, 0, 0, 1, 0, 0, 0, 0, 0, 1], # 4
    [0, 0, 0, 0, 0, 0, 0, 0, 0, 0], # 5
    [1, 1, 0, 0, 0, 0, 0, 1, 0, 0], # 6
    [0, 0, 1, 0, 0, 0, 1, 0, 0, 0], # 7
    [0, 1, 0, 1, 0, 0, 0, 0, 0, 0], # 8
    [0, 0, 1, 0, 1, 0, 0, 0, 0, 0]  # 9
], dtype=np.int64)

MOD = (10 ** 9) + 7

def knightDialer(N):
    if N == 1:
        return 10

    adj_N = adj
    for i in range(N-2):
        adj_N = np.mod(adj_N * adj, MOD)

    return np.sum(adj_N)

print(knightDialer(3))


#Q 15  Longest Increasing Subsequence

'''

Given an integer array nums, return the length of the longest strictly increasing subsequence.

A subsequence is a sequence that can be derived from an array by deleting some or no elements without changing the order of the remaining elements. For example, [3,6,2,7] is a subsequence of the array [0,3,1,6,2,2,7].

 

Example 1:

Input: nums = [10,9,2,5,3,7,101,18]
Output: 4
Explanation: The longest increasing subsequence is [2,3,7,101], therefore the length is 4.
Example 2:

Input: nums = [0,1,0,3,2,3]
Output: 4
Example 3:

Input: nums = [7,7,7,7,7,7,7]
Output: 1
 

Constraints:

1 <= nums.length <= 2500
-104 <= nums[i] <= 104
 

Follow up: Can you come up with an algorithm that runs in O(n log(n)) time complexity?

'''

#Solution

# from N^2 to NlogN
# Approach 1: Dynamic Programming

# TC=O(N^2)
# SC=O(N)

class Solution:
    def lengthOfLIS(self, nums: List[int]) -> int:
        dp = [1] * len(nums)
        for i in range(1, len(nums)):
            for j in range(i):
                if nums[i] > nums[j]:
                    dp[i] = max(dp[i], dp[j] + 1)

        return max(dp)
    
    
# Approach 2: Intelligently Build a Subsequence
# TC=O(N^2)
# SC=O(N)

class Solution:
    def lengthOfLIS(self, nums: List[int]) -> int:
        sub = [nums[0]]
        
        for num in nums[1:]:
            if num > sub[-1]:
                sub.append(num)
            else:
                # Find the first element in sub that is greater than or equal to num
                i = 0
                while num > sub[i]:
                    i += 1
                sub[i] = num

        return len(sub)
    
# Approach 3: Improve With Binary Search

# TC=O(NlogN)
# SC=O(N)

class Solution:
    def lengthOfLIS(self, nums: List[int]) -> int:
        sub = []
        for num in nums:
            i = bisect_left(sub, num)

            # If num is greater than any element in sub
            if i == len(sub):
                sub.append(num)
            
            # Otherwise, replace the first element in sub greater than or equal to num
            else:
                sub[i] = num
        
        return len(sub)
    
    
# Approach 4:greedy binary search O(NlogN)

class Solution:
    def lengthOfLIS(self, n: List[int]) -> int:
        res = 0
        N = len(n)
        q = [int(-2e4)] * (N + 1)
        for i in range(N):
            l, r = 0, res
            while l < r:
                mid = l + r + 1 >> 1
                if q[mid] < n[i]:
                    l = mid
                else:
                    r = mid - 1
            q[r + 1] = n[i]
            res = max(res, r + 1)
        return res

    
# Approach 5:O(nlogn), easy with bisect, very concise and clear

# Using l to maintain the current length of dp to avoid using len() each time.

class Solution:
    def lengthOfLIS(self, nums):
        dp = []
        l = 0
        for num in nums:
            idx = bisect.bisect_left(dp, num) # find the insert position of num
            if idx < l: # num is smaller than some number in dp
                dp[idx] = num
            else: # num is larger than any number in dp
                dp.append(num)
                l += 1
        return l


#Q16 .Unique Paths


'''

There is a robot on an m x n grid. The robot is initially located at the top-left corner (i.e., grid[0][0]). The robot tries to move to the bottom-right corner (i.e., grid[m - 1][n - 1]). The robot can only move either down or right at any point in time.

Given the two integers m and n, return the number of possible unique paths that the robot can take to reach the bottom-right corner.

The test cases are generated so that the answer will be less than or equal to 2 * 109.

 

Example 1:


Input: m = 3, n = 7
Output: 28
Example 2:

Input: m = 3, n = 2
Output: 3
Explanation: From the top-left corner, there are a total of 3 ways to reach the bottom-right corner:
1. Right -> Down -> Down
2. Down -> Down -> Right
3. Down -> Right -> Down
 

Constraints:

1 <= m, n <= 100

'''
#Solution

#Method-1

# Bottom up dp approach

class Solution:

	def uniquePaths(self, m: int, n: int) -> int:
    
		# Make an 2d array where each cell will contain the number of ways to get to 'Finish' from that cell. 
		opt = [[0]*n for _ in range(m)]
		
		# Start from the botttom right and traverse backwards. The last row and last column will contain 1's
		for i in range(m-1, -1, -1):
			for j in range(n-1, -1, -1):
				if i == m-1 or j == n-1:
					opt[i][j] = 1
				else:
				# Number of ways to go to finish = no of ways fro bottom cell + no of ways from right cell ,since the robot can only go dowm or right
					opt[i][j] = opt[i+1][j] + opt[i][j+1]
					
		# The top left cell will contain the answer.
		return opt[0][0]
    
#Method-2

# dynamic programming easy

class Solution(object):
    def uniquePaths(self, m, n):
        dp = [[0] * m for i in range(n)]
        dp[0][0] = 1
        
        for i in range(1, n):
            dp[i][0] = 1
        for j in range(1, m):
            dp[0][j] = 1
        
        for i in range(1, n):
            for j in range(1, m):
                dp[i][j] = dp[i - 1][j] + dp[i][j - 1]
        
        return dp[n - 1][m - 1]
    
#Method-3

# Recursive Solution (It will give TLE error)

class Solution:
    def uniquePaths(self, m: int, n: int) -> int:
        def fun(m,n):
            if m==0 and n==0:
                return 1
            if m<0 or n<0:
                return 0
            up=fun(m-1,n)
            left=fun(m,n-1)
            return up+left
        return fun(m-1,n-1)           



#Method-4
# DP (Top Down)

class Solution:
    def uniquePaths(self, m: int, n: int) -> int:
        dp=[[-1]*n for i in range(m)]
        def fun(m,n):
            if m==0 and n==0:
                (dp[m])[n]=1
                return (dp[m])[n]
            if m<0 or n<0:
                return 0
            if (dp[m])[n]!=-1:
                return (dp[m])[n]
            up=fun(m-1,n)
            left=fun(m,n-1)
            (dp[m])[n]=up+left
            return (dp[m])[n]
        return fun(m-1,n-1)
    
#Method-5
# Bottom Up

class Solution:
    def uniquePaths(self, m: int, n: int) -> int:
        dp=[[-1]*n for i in range(m)]
        for i in range(m):
            for j in range(n):
                if i==0 and j==0:
                    (dp[i])[j]=1
                
                else:
                    left=0
                    up=0
                    if i>0:
                        up=(dp[i-1])[j]
                    if j>0:
                        left=(dp[i])[j-1]
                    (dp[i])[j]=left+up
                    
        return (dp[m-1])[n-1]
		
#Method-6		
# Space Optimization

class Solution:
    def uniquePaths(self, m: int, n: int) -> int:
        prev=[0]*n 
        #print(prev)
        for i in range(m):
            temp=[0]*n 
            for j in range(n):
                if i==0 and j==0:
                    temp[j]=1
                    
                else:
                    left=0
                    up=0
                    if i>0:
                        up=prev[j]
                    if j>0:
                        left=temp[j-1]
                    
                    temp[j]=left+up
                    
            prev=temp
            
        return prev[n-1]


#Q17 Count Square Submatrices with All Ones

'''

Given a m * n matrix of ones and zeros, return how many square submatrices have all ones.

 

Example 1:

Input: matrix =
[
  [0,1,1,1],
  [1,1,1,1],
  [0,1,1,1]
]
Output: 15
Explanation: 
There are 10 squares of side 1.
There are 4 squares of side 2.
There is  1 square of side 3.
Total number of squares = 10 + 4 + 1 = 15.
Example 2:

Input: matrix = 
[
  [1,0,1],
  [1,1,0],
  [1,1,0]
]
Output: 7
Explanation: 
There are 6 squares of side 1.  
There is 1 square of side 2. 
Total number of squares = 6 + 1 = 7.
 

Constraints:

1 <= arr.length <= 300
1 <= arr[0].length <= 300
0 <= arr[i][j] <= 1

'''
#Solution 

# Method-1

class Solution:
    def countSquares(self, matrix):
        m, n = len(matrix), len(matrix[0])
        dp = [[0]*n for _ in range(m)]
        for i in range(m):
            for j in range(n):
                if matrix[i][j] == 1:
                    if i == 0 and j == 0:
                        dp[i][j] = 1
                    if i == 0:
                        dp[i][j] = 1
                    if j == 0:
                        dp[i][j] = 1
                    if i>0 and j>0:
                        dp[i][j] = 1 + min(dp[i-1][j],dp[i][j-1],dp[i-1][j-1])
        return sum([sum(i) for i in dp])
        
# Method-2

# dynamic programming
# dp
# optimal soln

class Solution:
    def countSquares(self, arr: List[List[int]]) -> int:
        n=len(arr)
        m=len(arr[0])
        dp=[[0 for i in range(m)]for j in range(n)]
        for i in range(n):
            dp[i][0]=arr[i][0]
        for j in range(m):
            dp[0][j]=arr[0][j]
        for i in range(1,n):
            for j in range(1,m):
                if arr[i][j]==1:
                    dp[i][j]= 1+min(dp[i-1][j],dp[i-1][j-1],dp[i][j-1])
                else:
                    dp[i][j]=0
                    
        ans=0
        for i in range(n):
            ans+=sum(dp[i])
        return ans
    
    
# Method-3

# 2D DP || O(n^2) time

# Starting from a corner, count the number of largest dimension that can be formed using all ones. the result is the sum of all the numbers. For example, the largest dimension of square that can be formed at a corner having 1 will be given by 1 + min(dp[i-1][j], dp[i][j-1], dp[i-1][j-1]). The boxes at the dp array now denote the number of squares it can contribute to. Hence, the sum of all the values in the dp matrix gives the result.

class Solution:
    def countSquares(self, matrix: List[List[int]]) -> int:
        
        m = len(matrix)
        n = len(matrix[0])
        
        dp = [[0 for _ in range(n)] for _ in range(m)]
        total = 0
        
        for i in range(m):
            for j in range(n):
                
                if i == 0:
                    dp[i][j] = matrix[0][j]
                    
                elif j == 0:
                    dp[i][j] = matrix[i][0]
                    
                else:
                    if matrix[i][j] == 1:
                        dp[i][j] = 1 + min(dp[i][j-1], dp[i-1][j-1], dp[i-1][j])
                    
                total += dp[i][j]
                
        return total


# Method-4

class Solution:
    def countSquares(self, matrix: List[List[int]]) -> int:
        m, n = len(matrix), len(matrix[0])
        total = 0
        for i in range(m):
            for j in range(n):
                if 1 <= i < m and 1 <= j < n:
                    if matrix[i][j] == 1:
                        val = 1 + min(matrix[i-1][j], matrix[i-1][j-1], matrix[i][j-1])
                        total += val
                        matrix[i][j] = val
                else:
                    total += matrix[i][j]
                    
        return total

    

# Method-5
# dynamic-programming

class Solution:
    def countSquares(self, matrix: List[List[int]]) -> int:
        
        #Define square to save the maximum size of the Square formed by the number present at each index
        
        #square will have the same dimensions as that of matrix
        
        square = []
        
        #Iterate over each row of the matrix
        
        for i in range(len(matrix)):
            
            #Add new row to the square
            
            square.append([])
            
            #Iterate over each element of the matrix
            
            for j in range(len(matrix[0])):
                
                #Size of the maximum square formed by the elements from First row and column will be equal to teh number itself
                
                if i==0 or j==0: 
                    square[i].append(matrix[i][j])
                    
                    #If number=1 then the size of max square will be 1+minimum of previous adjacent numbers
                    
                elif matrix[i][j]: 
                    square[i].append(1 + min(square[i-1][j], square[i][j-1], square[i-1][j-1]))
                    
                #If number=0 then the max size of the square will be 0 
                
                else: 
                    square[i].append(0)
        #count the total sqaures formed by taking the sum of all the sqaure formed            
        count = 0
        for sq in square: 
            count += sum(sq)
        return count

 #Q 18 Range Sum Query 2D - Immutable

'''

Given a 2D matrix matrix, handle multiple queries of the following type:

Calculate the sum of the elements of matrix inside the rectangle defined by its upper left corner (row1, col1) and lower right corner (row2, col2).
Implement the NumMatrix class:

NumMatrix(int[][] matrix) Initializes the object with the integer matrix matrix.
int sumRegion(int row1, int col1, int row2, int col2) Returns the sum of the elements of matrix inside the rectangle defined by its upper left corner (row1, col1) and lower right corner (row2, col2).
You must design an algorithm where sumRegion works on O(1) time complexity.

 

Example 1:


Input
["NumMatrix", "sumRegion", "sumRegion", "sumRegion"]
[[[[3, 0, 1, 4, 2], [5, 6, 3, 2, 1], [1, 2, 0, 1, 5], [4, 1, 0, 1, 7], [1, 0, 3, 0, 5]]], [2, 1, 4, 3], [1, 1, 2, 2], [1, 2, 2, 4]]
Output
[null, 8, 11, 12]

Explanation
NumMatrix numMatrix = new NumMatrix([[3, 0, 1, 4, 2], [5, 6, 3, 2, 1], [1, 2, 0, 1, 5], [4, 1, 0, 1, 7], [1, 0, 3, 0, 5]]);
numMatrix.sumRegion(2, 1, 4, 3); // return 8 (i.e sum of the red rectangle)
numMatrix.sumRegion(1, 1, 2, 2); // return 11 (i.e sum of the green rectangle)
numMatrix.sumRegion(1, 2, 2, 4); // return 12 (i.e sum of the blue rectangle)
 

Constraints:

m == matrix.length
n == matrix[i].length
1 <= m, n <= 200
-104 <= matrix[i][j] <= 104
0 <= row1 <= row2 < m
0 <= col1 <= col2 < n
At most 104 calls will be made to sumRegion.

'''

#Solution

#Method-1

class NumMatrix:

    def __init__(self, matrix: List[List[int]]):
        rows,cols=len(matrix),len(matrix[0])
        self.prefix=[[0]*(cols+1) for r in range(rows+1)]
        
        for i in range(rows):
            prefixsum=0
            for j in range(cols):
                prefixsum+=matrix[i][j]
                above=self.prefix[i][j+1]
                self.prefix[i+1][j+1]=prefixsum+above
        

    def sumRegion(self, r1: int, c1: int, r2: int, c2: int) -> int:
        r1,c1,r2,c2=r1+1,c1+1,r2+1,c2+1
        bottomright=self.prefix[r2][c2]
        above=self.prefix[r1-1][c2]
        left=self.prefix[r2][c1-1]
        topleft=self.prefix[r1-1][c1-1]
        
        return bottomright-above-left+topleft


    
#Method-2

class NumMatrix:

    def __init__(self, matrix: List[List[int]]):
        
        rowlen = len(matrix)
        collen = len(matrix[0])
        self.summatrix =[[0 for j in range(collen+1)] for i in range(rowlen+1)]
        
        for i in range(1,rowlen+1):   
            for j in range(1,collen+1):
                self.summatrix[i][j] = self.summatrix[i-1][j] +self.summatrix[i][j-1] + matrix[i-1][j-1] - self.summatrix[i-1][j-1]

              
    def sumRegion(self, row1: int, col1: int, row2: int, col2: int) -> int:
        row1, row2, col1,col2 = row1+1, row2+1, col1+1,col2+1
        return self.summatrix[row2][col2] - self.summatrix[row2][col1-1] - self.summatrix[row1-1][col2] + self.summatrix[row1-1][col1-1]
        

        
#Method-3

# Time Complexity - O(1) for sumRegion function and O(nm) for precomputation of cache.
# Space Complexity - O(nm)
# dynamic programming
# prefix sum
# brute force

# Approach 1

class NumMatrix:
    def __init__(self, matrix):
        self.matrix = matrix
        
    def sumRegion(self, row1, col1, row2, col2):
        summation = 0
        for i in range(row1, row2 + 1):
            for j in range(col1, col2 + 1):
                summation += self.matrix[i][j]
        return summation
    
# Time Complexity - O(nm) - Quadratic Time Complexity
# Space Complexity - O(1)
# Note : This solution gives TLE for this problem.

#Method-4
# Approach 2

class NumMatrix:
    def __init__(self, matrix):
        rows = len(matrix)
        cols = len(matrix[0])
        self.cache = [[0 for _ in range(cols + 1)] for _ in range(rows + 1)]
        for i in range(rows):
            for j in range(cols):
                self.cache[i + 1][j + 1] = self.cache[i + 1][j] + self.cache[i][j + 1] + matrix[i][j] - self.cache[i][j]
        
    def sumRegion(self, row1, col1, row2, col2):
        return self.cache[row2 + 1][col2 + 1] - self.cache[row1][col2 + 1] - self.cache[row2 + 1][col1] + self.cache[row1][col1]


    
    
#Method-5

class NumMatrix(object):
    def __init__(self, matrix):
        """
        :type matrix: List[List[int]]
        """
        self.matrix = matrix
        for i in range(len(self.matrix)):
            for j in range(len(self.matrix[0])):
                left = self.matrix[i][j-1] if j-1 >=0 else 0
                top = self.matrix[i-1][j] if i - 1 >= 0 else 0
                lefttop = self.matrix[i-1][j-1] if i-1 >= 0 and j-1 >=0 else 0
                self.matrix[i][j] +=  left + top - lefttop
                
    def sumRegion(self, row1, col1, row2, col2):
        
        """
        :type row1: int
        :type col1: int
        :type row2: int
        :type col2: int
        :rtype: int
        """
        left = self.matrix[row2][col1-1] if col1-1 >= 0 else 0
        top = self.matrix[row1-1][col2] if row1-1 >=0 else 0
        lefttop = self.matrix[row1-1][col1-1] if  col1-1 >= 0 and  row1-1 >=0 else 0
        
        return self.matrix[row2][col2] - left - top + lefttop
    
# Your NumMatrix object will be instantiated and called as such:
# obj = NumMatrix(matrix)
# param_1 = obj.sumRegion(row1,col1,row2,col2)



#Q19 Longest Arithmetic Subsequence

'''
Given an array nums of integers, return the length of the longest arithmetic subsequence in nums.

Recall that a subsequence of an array nums is a list nums[i1], nums[i2], ..., nums[ik] with 0 <= i1 < i2 < ... < ik <= nums.length - 1, and that a sequence seq is arithmetic if seq[i+1] - seq[i] are all the same value (for 0 <= i < seq.length - 1).

 

Example 1:

Input: nums = [3,6,9,12]
Output: 4
Explanation: 
The whole array is an arithmetic sequence with steps of length = 3.
Example 2:

Input: nums = [9,4,7,2,10]
Output: 3
Explanation: 
The longest arithmetic subsequence is [4,7,10].
Example 3:

Input: nums = [20,1,15,3,10,5,8]
Output: 4
Explanation: 
The longest arithmetic subsequence is [20,15,10,5].
 

Constraints:

2 <= nums.length <= 1000
0 <= nums[i] <= 500

'''
#Solution

# Method-1
# Dynamic Programming

class Solution:
    def longestArithSeqLength(self, A: List[int]) -> int:
        dp = {}
        for i in range(len(A)):
            for j in range(i + 1, len(A)):
                dp[j, A[j] - A[i]] = dp.get((i, A[j] - A[i]), 1) + 1
        return max(dp.values())
    
# Method-2
  # Hashmap
    
class Solution:
    def longestArithSeqLength(self, nums):
        dict1, max_len = defaultdict(int), 0
        for i in range(len(nums)):
            for j in range(i+1,len(nums)):
                dict1[(j, nums[j]-nums[i])] = 1 +  dict1[(i, nums[j]-nums[i])]
        return max(dict1.values()) + 1
    
#Method-3
# HASHMAP || SIMPLE || INTUTIVE ||

# Lets say we have a sequence 
# [20,1,15,3,10,5,8]

# Now if we are at 15 and 10 we see that the difference here is -5 making an AP of size 2 and difference = -5

# Now how can we increase its size ?
# If we find a number before 15 having value 15 - difference = 15 -(-5) = 20 
# Yes we have the number so size of AP = 3

# So the idea is we store the size of sequence ending at index = i with difference  = d
# using hashmap

class Solution:
    def longestArithSeqLength(self, nums: List[int]) -> int:
        n = len(nums)
        dp = {x:{} for x in range(n)}
        for i in range(n):
            for j in range(i+1,n):
                tmp = dp[i][nums[j]-nums[i]] if nums[j]-nums[i] in dp[i] else 1
                dp[j][nums[j]-nums[i]] = tmp + 1
        ans = 0
        for i in dp:
            for j in dp[i]:
                if dp[i][j] > ans: ans = dp[i][j]
        return ans

#Method-4
# Use DP. In O(N^2) time and space.

class Solution(object):
    def longestArithSeqLength(self, A):
        """
        :type A: List[int]
        :rtype: int
        """
        best = collections.defaultdict(int)
        for i, a in enumerate(A):
            for j in range(i):
                d = a - A[j]
                best[(i,d)] =1+best[(j,d)]
        return max(best.values()) + 1
 
#Method-5
# using dictonary

class Solution:
    def longestArithSeqLength(self, A: List[int]) -> int:
        dp={A[0]:{}}
        max_value=0
        for i in range(len(A)):
            if A[i] not in dp:
                dp[A[i]]={}
            for key,value in dp.items():
                if A[i]-key in value:
                    dp[A[i]][A[i]-key]=value[A[i]-key]+1
                    max_value=max(max_value,dp[A[i]][A[i]-key])
                elif key!=A[i]:
                    dp[A[i]][A[i]-key]=2
                    max_value=max(max_value,2)
                elif key==A[i]:
                    dp[A[i]][A[i]-key]=1
                    max_value=max(max_value,1)
        return max_value
	

#Q20. Trapping Rain Water

'''

Given n non-negative integers representing an elevation map where the width of each bar is 1, compute how much water it can trap after raining.

 

Example 1:


Input: height = [0,1,0,2,1,0,1,3,2,1,2,1]
Output: 6
Explanation: The above elevation map (black section) is represented by array [0,1,0,2,1,0,1,3,2,1,2,1]. In this case, 6 units of rain water (blue section) are being trapped.
Example 2:

Input: height = [4,2,0,3,2,5]
Output: 9
 

Constraints:

n == height.length
1 <= n <= 2 * 104
0 <= height[i] <= 105	
'''
#Solution

# Method-1

# stack method/include-exclude principle (96-114 ms)
# The core idea is include-exclude principle in the combinatorics: let's suppose left-end >= right-end and compute the trapped water in the current pond. If in the end we find the left-end is in fact < right-end, we need to exclude the overflow water.
    
# class Solution:
#     def trap(self, height):
#         stack = []
#         water_tot = 0
#         for h in height:
#             w = 0  # width
#             water_pond = 0  # water in the current pond
#             block = (0, 0)  # format=(height, width)
            
#             while stack and stack[-1][0]<h:
#                 block = stack.pop()
#                 # suppose the left-end >= right-end and calculate
# 			    # the water in each strip
#                 water_pond += (h-block[0])*block[1]
#                 # update width
# 			    w = w + block[1]
#                 water_tot += water_pond

# 		    if not stack:  
#                 # means left-end < right-end
# 			    # then we have to exclude the overflow water
#                 water_tot -= (h-block[0])*w
#                 # new left-end has width=1
#                 stack.append((h, 1))
# 		    else:
#                 # level the pond to the right-end and make it a new
# 			    # big chunk
#                 stack.append((h, w+1))

# 	    return water_tot
    
#Method-2

class Solution(object):
    def trap(self, height):
        n= len(height)
        if n<=1: return 0 
        left= [0 for i in range(n)] #denotes max before this element including this
        right= [0 for i in range(n)] #denotes max after this element including this
        left[0], right[-1]= height[0], height[-1] 
        for i in range(1,n):
            left[i]= max(left[i-1], height[i])
        for i in range(n-2,-1,-1):
            right[i]= max(right[i+1], height[i])
        tatal_water= 0
        for i in range(n):
            caused_by_this= min(left[i], right[i])- height[i] 
            #water collected by this bar 
            tatal_water+= caused_by_this
        return tatal_water  
    
    
# Method-3

# This array was divided into 2 parts, and the boundary is the maximum number.(if the maximum number show twice or more times, just pick the first one)
# we use the same algorithm to review the array twice, from left to right and from right to left.
# before we meet the maximum number, as long as the height goes down, fill it with water, because we must encounter the other bar which is higher than any other. After we meet the maximum number, the fill algorithm fails.
# But start again from right to left, it can calculate the water from the other side. and add them together, the answer is correct

class Solution(object):
    def trap(self, height):
        """
        :type height: List[int]
        :rtype: int
        """
        maxh=0
        water=0
        total=0
        for i in range(0,len(height)):
            if height[i]<maxh:
                water+=(maxh-height[i])
            if height[i]>maxh:
                maxh=height[i]
                total+=water
                water=0
        maxh=0        
        water=0
        for i in range(len(height)-1,-1,-1):
            if height[i]<maxh:
                water+=(maxh-height[i])
            if height[i]>=maxh:
                maxh=height[i]
                total+=water
                water=0
        return total

# Method-4
# mono stack 


class Solution(object):
    def trap(self, a):
        stack = []
        res = 0
        for i, n in enumerate(a):
            while stack and a[stack[-1]] <= n:
                curr_index = stack.pop()
                if stack:                                           # left boundary exist, right is n.
                    left_index = stack[-1]                          # left of current pop
                    min_wall = min(a[left_index], n)                # min of boundary left, right
                    pool_width = i - (left_index + 1)               # width of pool 
                    res += pool_width * (min_wall - a[curr_index])  # w * h , h = height of pop
                    
            stack.append(i)
        return res

# Method-5
# 2 Pointer

class Solution:
    def trap(self, a: List[int]) -> int:
        l, r = 0, len(a) - 1
        mxl,  mxr = a[l], a[r]
        res = 0
        while l < r:
            if mxl <= mxr:
                l += 1
                mxl = max(a[l], mxl)
                res +=  mxl - a[l]
            else: 
                r -= 1
                mxr = max(a[r], mxr)
                res += mxr - a[r]
        return res

# Method-6
# Time complexity  - O(n) and space complexity O (1)

class Solution:
    def trap(self, height: List[int]) -> int:
        count = 0
        l = 0
        r = len(height)-1
        l_max = height[0]
        r_max = height[-1]
        while l<r:
            if l_max <= r_max:
                while height[l] <= l_max and l < r:
                    count += l_max - height[l]
                    l += 1
                l_max = height[l]
            else:
                while height[r] <= r_max and l < r:
                    count += r_max - height[r]
                    r -= 1
                r_max = height[r]
        return count

#Q21 Word Break II

'''

Given a string s and a dictionary of strings wordDict, add spaces in s to construct a sentence where each word is a valid dictionary word. Return all such possible sentences in any order.

Note that the same word in the dictionary may be reused multiple times in the segmentation.

 

Example 1:

Input: s = "catsanddog", wordDict = ["cat","cats","and","sand","dog"]
Output: ["cats and dog","cat sand dog"]
Example 2:

Input: s = "pineapplepenapple", wordDict = ["apple","pen","applepen","pine","pineapple"]
Output: ["pine apple pen apple","pineapple pen apple","pine applepen apple"]
Explanation: Note that you are allowed to reuse a dictionary word.
Example 3:

Input: s = "catsandog", wordDict = ["cats","dog","sand","and","cat"]
Output: []
 

Constraints:

1 <= s.length <= 20
1 <= wordDict.length <= 1000
1 <= wordDict[i].length <= 10
s and wordDict[i] consist of only lowercase English letters.
All the strings of wordDict are unique.
'''
#Solution

# Method-1

class Solution:
    def wordBreak(self, s: str, wordDict: List[str]) -> List[str]:
        
        words = set(wordDict)
        
        ans = []
        temp = ""
        self.word_break(s, words, ans, temp)
        
        return ans
    
    def word_break(self, s, words, ans, temp):
        
        if s == "":
            ans.append(temp.strip(" "))
        
       
        
        for i in range(len(s)):

            if s[0:i+1] in words:
                self.word_break(s[i+1:], words, ans, temp + " " + s[0:i+1])
                
# Method-2
# Backtracking

class Solution:
    def wordBreak(self, s: str, wordDict: List[str]) -> List[str]:
        path, result = [], []
        
        def backtrack(i):
            if i >= len(s):
                result.append(" ".join(path))
                return
            for word in wordDict:
                if i + len(word) <= len(s) and s[i:i + len(word)] == word:
                    path.append(word)
                    backtrack(i + len(word))
                    path.pop()
        backtrack(0)
        return result
    
#Method-3

class Solution:
    def wordBreak(self, s: str, wordDict: List[str]) -> List[str]:
        def dfs(res,idx,path):
            if len(s) == idx:
                res.append(" ".join(path))
                return
            
            for i in range(idx,len(s)):
                temp = s[idx:i+1]
                if temp in wordDict:
                    dfs(res,i+1,path + [temp])
        
        res = []
        dfs(res,0,[])
        return res
    
#Method-4

# Trie + DFS Easy Solution
# trie
# dfs recusion

class TrieNode:
    def __init__(self):
        self.children = {}
        self.isEnd = False
        
class Trie:
    def __init__(self):
        self.root = TrieNode()
        
    def add_word(self, word):
        curr = self.root
        for c in word:
            if c not in curr.children:
                curr.children[c] = TrieNode()
            curr = curr.children[c]
        curr.isEnd = True
        
    def is_prefix(self, word):
        curr = self.root
        for c in word:
            if c not in curr.children:
                return False
            curr = curr.children[c]
        return True
        
class Solution:
    def wordBreak(self, s: str, wordDict: List[str]) -> List[str]:
        result = list()
        
        trie = Trie()
        for word in wordDict:
            trie.add_word(word)
        wordDict = {word:True for word in wordDict}
       
        def dfs(start, path):
            if start >= len(s):
                result.append(path[:-1])
            
            end = start
            while end < len(s):
                curr_word = s[start:end+1]
                if not trie.is_prefix(curr_word):
                    break
                if curr_word in wordDict:
                    dfs(end+1, f"{path}{curr_word} ")
                end += 1
            
        dfs(0, "")
        
        return result


#Method-5

# DFS

class Solution:
    def wordBreak(self, s: str, wordDict: List[str]) -> List[str]:
        
        words = set(wordDict)
        
        ans = []
        temp = ""
        self.word_break(s, words, ans, temp)
        
        return ans
    
    def word_break(self, s, words, ans, temp):
        
        if s == "":
            ans.append(temp.strip(" "))
        
       
        
        for i in range(len(s)):

            if s[0:i+1] in words:
                self.word_break(s[i+1:], words, ans, temp + " " + s[0:i+1])



#Q22 Regular Expression Matching


'''

Given an input string s and a pattern p, implement regular expression matching with support for '.' and '*' where:

'.' Matches any single character.​​​​
'*' Matches zero or more of the preceding element.
The matching should cover the entire input string (not partial).

 

Example 1:

Input: s = "aa", p = "a"
Output: false
Explanation: "a" does not match the entire string "aa".
Example 2:

Input: s = "aa", p = "a*"
Output: true
Explanation: '*' means zero or more of the preceding element, 'a'. Therefore, by repeating 'a' once, it becomes "aa".
Example 3:

Input: s = "ab", p = ".*"
Output: true
Explanation: ".*" means "zero or more (*) of any character (.)".
 

Constraints:

1 <= s.length <= 20
1 <= p.length <= 30
s contains only lowercase English letters.
p contains only lowercase English letters, '.', and '*'.
It is guaranteed for each appearance of the character '*', there will be a previous valid character to match.
'''
#Solution

# Method-1
# using re.match
# regular-expression
# match

class Solution:
    def isMatch(self, s: str, p: str) -> bool:
        return(re.match('^'+p+'$',s))

# Method-2
# Minimal Recursion, NOT dp

class Solution:
    def isMatch(self, s: str, p: str) -> bool:
        string_index = 0
        pattern_index = 0

        # Helper Functions
        def next_char_match():
            return s[string_index] == p[pattern_index] or p[pattern_index] == '.'

        def next_token_is_star():
            return pattern_index + 1 < len(p) and p[pattern_index + 1] == '*'

        def rest_of_pattern_matches_empty_string():
            for char in p[pattern_index + 1 :: 2]:
                if char != '*':
                    return False
            return pattern_index == len(p) or p[-1] == '*'


        while string_index < len(s) and pattern_index < len(p):
            if next_token_is_star():
                if self.isMatch(s[string_index:], p[pattern_index + 2:]):
                    return True
                elif not next_char_match():
                    return False
                else:
                    string_index += 1
            else:  # i.e. not next_token_is_star()
                if not next_char_match():
                    return False
                string_index += 1
                pattern_index += 1

        if string_index == len(s):  # If we've matched the entire string
            if rest_of_pattern_matches_empty_string():
                return True
        return False

print(Solution().isMatch("aab", "c*a*b"))


#Q23 Maximal Rectangle

'''

Given a rows x cols binary matrix filled with 0's and 1's, find the largest rectangle containing only 1's and return its area.

 

Example 1:


Input: matrix = [["1","0","1","0","0"],["1","0","1","1","1"],["1","1","1","1","1"],["1","0","0","1","0"]]
Output: 6
Explanation: The maximal rectangle is shown in the above picture.
Example 2:

Input: matrix = [["0"]]
Output: 0
Example 3:

Input: matrix = [["1"]]
Output: 1
 

Constraints:

rows == matrix.length
cols == matrix[i].length
1 <= row, cols <= 200
matrix[i][j] is '0' or '1'.

'''
#Solution

# Method-1

# monotonic stack 

#  Largest Rectangle in Histogram solution

# use monotonic stack (incremental order) to find the histogram area in each row of matrix
# use height to track the height of histogram

# # If no consecutive 1s appear in the same position on the next row, set the height to 0
# else: height[colIdx] = 0
# tc is O(len(matrix)*len(matrix[0])), sc is the same as tc.

class Solution:
    def maximalRectangle(self, matrix: List[List[str]]) -> int:
        ans, height = 0, [0] * len(matrix[0])
        peekTopOfStack = lambda stack: stack[-1]
        for rowIdx, row in enumerate(matrix):
            stack = []
            for colIdx, num in enumerate(row):
                if num == '1':
                    height[colIdx] += 1
                else: height[colIdx] = 0
                while len(stack) and height[colIdx] <= height[peekTopOfStack(stack)]:
                    h = height[stack.pop()]
                    width = colIdx - (peekTopOfStack(stack) + 1 if len(stack) else 0)
                    ans = max(ans, h*width)
                stack.append(colIdx)

            while len(stack):
                h = height[stack.pop()]
                width = len(height) - (stack[-1] + 1 if len(stack) else 0)
                ans = max(ans, h * width) 
        return ans

# Method-2

# DP + stack -> O(m*n)


# We can use stack to find the index with smaller width that is closest to i when matrix[:][j] is on the left side of a rectangle, so that we can get the longest height to form a rectangle.

class Solution:
    def maximalRectangle(self, matrix: List[List[str]]) -> int:
        m, n = len(matrix), len(matrix[-1])   
        width = [0] * m
        max_area = 0
        for j in range(n):
            for i in range(m):
                width[i] = width[i] + 1 if matrix[i][j] == '1' else 0
            # the index that is closest to i with smaller width than width[i]
            upper_smaller, lower_smaller = [0] * m, [0] * m
            stk1, stk2 = [], []
            for i in range(m):
                while stk1 and width[stk1[-1]] >= width[i]:
                    stk1.pop()
                if stk1: upper_smaller[i] = stk1[-1]
                else: upper_smaller[i] = -1
                stk1.append(i)
                
            for i in range(m-1, -1, -1):
                while stk2 and width[stk2[-1]] >= width[i]:
                    stk2.pop()
                if stk2: lower_smaller[i] = stk2[-1]
                else: lower_smaller[i] = m
                stk2.append(i)
                
            for i in range(m):
                max_area = max(
                    (lower_smaller[i] - upper_smaller[i] - 1) * width[i],
                    max_area
                )

        return max_area
 

# Method-3    
# Algorithm

# The solution is based on largest rectangle in histogram solution. Every row in the matrix is viewed as the ground with some buildings on it. The building height is the count of consecutive 1s from that row to above rows. The rest is then the same as this solution for largest rectangle in histogram
# heights[j] = heights[j] + int(matrix[i][j]) if int(matrix[i][j]) else 0 - makes sure we reset the count when we have a zero.


class Solution(object):
    def largestRectangleArea(self, heights):
        max_area, st = 0, []
        for idx,x in enumerate(heights):
            if len(st) == 0:
                st.append(idx)
            elif x >= heights[st[-1]]:
                st.append(idx)
            else:
                while st and heights[st[-1]] > x:
                    min_height = heights[st.pop()] 
                    max_area = max(max_area, min_height*(idx-1-st[-1])) if st else max(max_area, min_height*idx)
                st.append(idx)
        while st:
            min_height = heights[st.pop()] 
            max_area = max(max_area, min_height*(len(heights)-1-st[-1])) if st else max(max_area, min_height*len(heights))
        return max_area
        
    def maximalRectangle(self, matrix):
        """
        :type matrix: List[List[str]]
        :rtype: int
        """
        if matrix == []:
            return 0
        N, M = len(matrix), len(matrix[0])
        max_area, heights = 0, [0]*M
        for i in range(N):
            for j in range(M):
                heights[j] = heights[j] + int(matrix[i][j]) if int(matrix[i][j]) else 0
            max_area = max(max_area, self.largestRectangleArea(heights))
        return max_area


#Q24 Longest Valid Parentheses

'''

Given a string containing just the characters '(' and ')', find the length of the longest valid (well-formed) parentheses substring.

 

Example 1:

Input: s = "(()"
Output: 2
Explanation: The longest valid parentheses substring is "()".
Example 2:

Input: s = ")()())"
Output: 4
Explanation: The longest valid parentheses substring is "()()".
Example 3:

Input: s = ""
Output: 0
 

Constraints:

0 <= s.length <= 3 * 104
s[i] is '(', or ')'.
'''
#Solution

Method-1

class Solution:
    def longestValidParentheses(self, s: str) -> int:
        stack = []
        flags = [False] * len(s)
        
        # Set flags as True for complete parentheses
        i = 0
        for ch in s:            
            if ch == '(':
                stack.append(i)
            elif ch == ')':
                if stack:
                    flags[i] = True
                    flags[stack.pop()] = True
            i += 1  
                
        # Count the longest consecutive True
        #print(flags)
        cnt = 0
        maxCnt = 0
        for i in flags:
            if i:
                cnt += 1
            else:
                maxCnt = max(maxCnt, cnt)
                cnt = 0
        
        return max(maxCnt, cnt)
 

#Method-2

# Find and merge parentheses
# Solution:
# Using a stack, iterate through all characters in s and pair opening parentheeses with closing parentheses and store pairs in a dictionary. Then, iterate through all pairs of parentheses and merge adjacent pairs together.

# Complexity:
# Time: O(n)
# Space: O(n)

class Solution:
    def longestValidParentheses(self, s: str) -> int:

        # Initialize a dict to map open parenthesis with closing parethesis
        pairs = {}

        # A stack to keep track of unpair open parenthesis
        stack = []

        # Iterate through all characters in s
        for i, p in enumerate(s):

            # If we see an opening parenthesis, add it to the stack
            if p == "(":
                stack.append(i)

            # Else, if we see a closing parethesis, pair it with an opening parenthesis if there is one
            elif stack:

                # Save the pair to the dictionary
                pairs[stack.pop()] = i

        # Initialize the result
        res = 0

        # Iterate through all characters
        for i, _ in enumerate(s):

            # If there isn't a pair of parentheses at the current index, continue to the next one
            if i not in pairs:
                continue

            # Merge the current pair of parentheses with its adjacent pairs
            while pairs[i] + 1 in pairs:
                pairs[i] = pairs.pop(pairs[i] + 1)

            # Find the distance of merged parentheses
            res = max(res, pairs[i] - i + 1)

        return res
    
#Method-3

# Stack

class Solution:
    def longestValidParentheses(self, s: str) -> int:
        stack = []
        valid = []
        for i in range(len(s)):
            if s[i] == '(':
                stack.append(i)
            elif stack:
                x = stack.pop()
                valid.append((x,i))
        available_patterns = []    
        if valid:
            valid.sort(key=lambda x:x[0])
            available_patterns.append(valid[0])
            for i in range(1,len(valid)):
                if available_patterns[-1][0] < valid[i][0] and available_patterns[-1][1] > valid[i][1]:
                    continue
                elif valid[i][0] == available_patterns[-1][1]+1:
                    available_patterns[-1] = (available_patterns[-1][0],valid[i][1])
                else:
                    available_patterns.append(valid[i])
            mx_len = 0
            for i in range(len(available_patterns)):
                t = available_patterns[i][1]-available_patterns[i][0] + 1
                if t > mx_len:
                    mx_len = t
            return mx_len
        else:
            return 0
        
        
#Method-4
# two-stack solution in Python


class Solution:
    def longestValidParentheses(self, s: str) -> int:
        longest_forward_valid_substring = 0
        current_substring = 0
        parenthesis_stack = []
        substring_length_stack = []
        for char in s:
            if char == '(':
                parenthesis_stack.append(char)
                if len(parenthesis_stack) > len(substring_length_stack) + 1:
                    substring_length_stack.append(current_substring)
                    current_substring = 0
            if char == ')':
                if parenthesis_stack:
                    parenthesis_stack.pop()
                    current_substring += 2
                    if len(parenthesis_stack) < len(substring_length_stack):
                        current_substring += substring_length_stack.pop()
                    longest_forward_valid_substring = max(longest_forward_valid_substring, current_substring)
                else:
                    current_substring = 0
        longest_forward_valid_substring = max(longest_forward_valid_substring, current_substring)
        return longest_forward_valid_substring
    
# Method-5
class Solution(object):
    def longestValidParentheses(self, s):
        """
        :type s: str
        :rtype: int
        """
        dic = {}
        dic[-1] = 0
        stack = []
        stack.append(-1)
        result = 0
        for i in range(0, len(s)):
            if s[i] == '(':
                dic[i] = 0
                stack.append(i)
            else:
                if len(stack) < 2:
                    result = max(result, dic[stack[-1]])
                    dic[stack[-1]] = 0
                    continue
                dic[stack[-2]] += i - stack[-1] + 1
                result = max(result, dic[stack[-2]])
                stack.pop()
        return result

# Method-6

# Easy Stack
# Space Complexity: O(N)

class Solution:
    def longestValidParentheses(self, s: str) -> int:
        
        stack = [-1]
        res = 0
        
        for i,p in enumerate(s):
            if p == '(':
                stack.append(i)
            else:
                stack.pop()
                if not stack:
                    stack.append(i)
                else:
                    res = max(res,i-stack[-1])
                    
        return res
    
    
# Method-7

# O(n) time and O(n) space,

# Explaination:

# I used stack and instead of elements, added the index of elements.
# After using the standard push-pop methods, I was left with index of those locations ,whose counter part is not available.
# Lets consider example : I got a stack of [4,7,9,15,77]. And lets consider the given input string is of length 100
# The above stack states that at indexes 4, 7, 9 , 15 and 77, the values of input string s doent have the proper counter-parts
# This means that from index 0 to 3, ie (stack[0]-1-0), we have a substring which is proper and its length is 3
# Similarly, between 7 and 4, we have a substring of (7-1-4). We are substracting 1 from upper value as we dont want it to be part of substring.
# This is same for every value obtained in stack
# Finally, we substract the largest value from stack , from length of s -1.
# The answer is max value of lengths of all these substrings found
# Hit like and let me know if you have any doubts :P

class Solution:
    def longestValidParentheses(self, s: str) -> int:
        if not s:
            return 0
        stack=[]
        for i in range(len(s)):
            if s[i]==")":
                if stack and s[stack[-1]]=="(":
                     stack.pop()
                else:
                     stack.append(i)
            else:
                stack.append(i)
        #print(stack)
        if not stack:
            return len(s)
        ans=stack[0]-0
        for i in range(1,len(stack)):
            ans=max(ans,stack[i]-(stack[i-1]+1))
        ans=max(ans,len(s)-1-stack[-1])
        return ans

# Q25 Edit Distance

'''

Given two strings word1 and word2, return the minimum number of operations required to convert word1 to word2.

You have the following three operations permitted on a word:

Insert a character
Delete a character
Replace a character
 

Example 1:

Input: word1 = "horse", word2 = "ros"
Output: 3
Explanation: 
horse -> rorse (replace 'h' with 'r')
rorse -> rose (remove 'r')
rose -> ros (remove 'e')
Example 2:

Input: word1 = "intention", word2 = "execution"
Output: 5
Explanation: 
intention -> inention (remove 't')
inention -> enention (replace 'i' with 'e')
enention -> exention (replace 'n' with 'x')
exention -> exection (replace 'n' with 'c')
exection -> execution (insert 'u')
 

Constraints:

0 <= word1.length, word2.length <= 500
word1 and word2 consist of lowercase English letters.
'''
#Solution

#Method-1
# greedy
# dp
# memomization
# greedy O(n*m) dp tabulation

class Solution(object):
    def minDistance(self, word1, word2):
        n = len(word1)
        m = len(word2)
        prev_dp = [0]*(m+1)
        dp = [0]*(m+1)
        for j in range(1, m+1):
            prev_dp[j] = j
        for i in range(1, n+1):
            dp[0] = i
            for j in range(1, m+1):
                if word1[i-1] == word2[j-1]:
                    dp[j] = prev_dp[j-1]
                else:
                    dp[j] = 1 + min(prev_dp[j], dp[j-1], prev_dp[j-1])
            prev_dp = dp
            dp = [0]*(m+1)
        return prev_dp[m]  
    
#Method-2
#dynamic prpgramming

class Solution:
    def minDistance(self, w1: str, w2: str) -> int:
        N = 510
        n1, n2 = len(w1), len(w2)
        w1 = " " + w1
        w2 = " " + w2
        f = [[N] * N for _ in range(N)]
        for i in range(n1 + 1):
            f[i][0] = i
        for i in range(n2 + 1):
            f[0][i] = i
        for i in range(1, n1 + 1):
            for j in range(1, n2 + 1):
                f[i][j] = min(f[i][j], f[i - 1][j] + 1, f[i][j - 1] + 1)
                if w1[i] == w2[j]: f[i][j] = min(f[i][j], f[i - 1][j - 1])
                else: f[i][j] = min(f[i][j], f[i - 1][j - 1] + 1)
        return f[n1][n2]

#Method-3

# recursion
# dp
# memomization

class Solution:
    def minDistance(self, word1: str, word2: str) -> int:
        cache = {}
        
        def editDistance(i, j):
            if i >= len(word1):
                return len(word2)-j
            
            if j >= len(word2):
                return len(word1)-i
            
            if (i,j) in cache:
                return cache[(i, j)]
            
            if word1[i] == word2[j]:
                res = editDistance(i+1, j+1)
            else:
                res = min(editDistance(i+1, j+1)+1, editDistance(i+1, j)+1, editDistance(i, j+1)+1)
            
            cache[(i,j)] = res
            
            return res
        
        return editDistance(0, 0)
    
    
# Method-4

class Solution:
    def minDistance(self, word1: str, word2: str) -> int:
        m, n = len(word1), len(word2)
        dp = [[0]*(n+1) for _ in range(m+1)]
        for i in range(m+1):
            dp[i][0] = i
        for j in range(n+1):
            dp[0][j] = j
        
        for i in range(1, m+1):
            for j in range(1, n+1):
                if word1[i-1] == word2[j-1]:
                    dp[i][j] = dp[i-1][j-1]
                else:
                    dp[i][j] = 1 + min(dp[i][j-1], dp[i-1][j],dp[i-1][j-1])
                    #min value of either insert, delete, replace
                    
        return dp[-1][-1]
    
# Method-5  

'''
Insertion: dp[i][j] = dp[i][j-1]
if we can insert to make word1[0,i) to word2[0,j), it means for word1[0...i-1], we can just insert the last elem of current sub_word2, word2[j-1] to it, then it will be equal to word2[0...j), it also means before we make this insertion, word1[0...i-1] should be equal to word2[0...j-2] or we say word1[0,i) = word2[0,j-1). In aspect of dp[i][j], we consequently have to check dp[i][j-1]

Delete: dp[i][j] = dp[i-1][j]
if we can delete to make word1[0,i) to word2[0,j), it means for word1[0...i-1], we can just delete the last elem of current sub_word1, word1[i-1], then it will be equal to word2[0...j), it also means before we make this delete, word1[0...i-2] should be equal to word2[0...j-1] or we say word1[0,i-1) = word2[0,j). In aspect of dp[i][j], we consequently have to check dp[i-1][j]

Replace: dp[i][j] = dp[i-1]dp[j-1]
if we can replace to make word1[0,i) to word2[0,j), it means before the last elem of word1 and word2, word1[0,i-1) should be equal to word[0,j-1). In aspect of dp[i][j], we just check dp[i-1][j-1]

'''

# Since when we update dp[i][j], we only need dp[i - 1][j - 1], dp[i][j - 1] and dp[i - 1][j]. We may optimize the space:


class Solution:
    def minDistance(self, word1: str, word2: str) -> int:
        m, n = len(word1), len(word2)
        # we can have simplied time complexity as constant by two vectors or even one vector
        # we implement one vector record here
        dp = [0]*(n+1)
        
        for j in range(n+1):
            dp[j] = j
        
        # here we need an extra prev variable to save the record of previous diagonal information 
        for i in range(1, m+1):
            prev = dp[0]
            dp[0] = i
            for j in range(1, n+1):
                # we save the current unmodified value in temp
                temp = dp[j]
                if word1[i-1] == word2[j-1]:
                    dp[j] = prev
                else:
                    dp[j] = 1 + min(dp[j-1], dp[j], prev)
                # now that j move one step forwards, we have to save back the diagonal values that we might need
                prev = temp
                    
        return dp[-1]

    
#Method-6
# dynamic-programming

class Solution(object):
    def minDistance(self, word1, word2):
        m, n = map(len, (word1, word2))
        dp = [range(n + 1)] + [[i] + [0] * n for i in range(1, m + 1)]

        for i in range(1, m + 1):
            for j in range(1, n + 1):
                dp[i][j] = min(
                    dp[i][j - 1] + 1,
                    dp[i - 1][j] + 1,
                    dp[i - 1][j - 1] + (word1[i - 1] != word2[j - 1])
                )

        return dp[m][n]


# Q26  Minimum Difficulty of a Job Schedule

'''

You want to schedule a list of jobs in d days. Jobs are dependent (i.e To work on the ith job, you have to finish all the jobs j where 0 <= j < i).

You have to finish at least one task every day. The difficulty of a job schedule is the sum of difficulties of each day of the d days. The difficulty of a day is the maximum difficulty of a job done on that day.

You are given an integer array jobDifficulty and an integer d. The difficulty of the ith job is jobDifficulty[i].

Return the minimum difficulty of a job schedule. If you cannot find a schedule for the jobs return -1.

 

Example 1:


Input: jobDifficulty = [6,5,4,3,2,1], d = 2
Output: 7
Explanation: First day you can finish the first 5 jobs, total difficulty = 6.
Second day you can finish the last job, total difficulty = 1.
The difficulty of the schedule = 6 + 1 = 7 
Example 2:

Input: jobDifficulty = [9,9,9], d = 4
Output: -1
Explanation: If you finish a job per day you will still have a free day. you cannot find a schedule for the given jobs.
Example 3:

Input: jobDifficulty = [1,1,1], d = 3
Output: 3
Explanation: The schedule is one job per day. total difficulty will be 3.
 

Constraints:

1 <= jobDifficulty.length <= 300
0 <= jobDifficulty[i] <= 1000
1 <= d <= 10

'''

#Solution

#Method-1
# memoization
# dp
# dynamic proramming

class Solution:
    def minDifficulty(self, jobDifficulty: List[int], d: int) -> int:
        n = len(jobDifficulty)
        
        if n < d:
            return -1
            
        @lru_cache(maxsize = None)
        def dp(i, day):
            if day == d:
                return max(jobDifficulty[i:])
            
            best = float('inf')
            hardest = 0
            
            for j in range(i, n-(d-day)):
                hardest = max(hardest, jobDifficulty[j])
                best = min(best, hardest + dp(j+1, day+1))
                
            return best
                
        return dp(0, 1)
    
    
#Method-2   

# 1) brute-force, 2) top-down DP, 3) bottom-up DP


# Three approaches are presented:

# Brute-force backtracking: This one is to understand the problem itself. (TLE)
# Top-down DP: Slightly better but barely passing (5%)
# Bottom-up DP: The real solution (95%)


# 1. Brute-force backtracking

class Solution:    
    def minDifficulty(self, jobDifficulty: List[int], d: int) -> int:
        def backtrack(arr, start, k):
            if len(arr[start:]) < k:
                return -1
            elif len(arr[start:]) == k:
                return sum(arr[start:])
            elif k == 1:
                return max(arr[start:])

            minCost = inf
            for j in range(start, len(arr) - (k - 1)):
                curCost = max(arr[start:j + 1]) + backtrack(arr, j + 1, k - 1)
                minCost = min(minCost, curCost)

            return minCost

        dp = {}
        return backtrack(jobDifficulty, 0, d)
    
 
#Method-3

# 2. Top-down DP: Barely passing (5%)

class Solution:    
    def minDifficulty(self, jobDifficulty: List[int], d: int) -> int:
        def backtrack(arr, start, k):
            if len(arr[start:]) < k:
                return -1
            elif len(arr[start:]) == k:
                return sum(arr[start:])
            elif k == 1:
                return max(arr[start:])

            if (start, k) in dp:
                return dp[(start, k)]

            dp[(start, k)] = inf
            for j in range(start, len(arr) - (k - 1)):
                curCost = max(arr[start:j + 1]) + backtrack(arr, j + 1, k - 1)
                dp[(start, k)] = min(dp[(start, k)], curCost)

            return dp[(start, k)]

        dp = {}
        return backtrack(jobDifficulty, 0, d)

#Method-4
# 3. Bottom-up DP: Compare with backtracking approach and it will become clear.

class Solution:    
    def minDifficulty(self, jobDifficulty: List[int], d: int) -> int:
        jobs = jobDifficulty
        ntot = len(jobs)
        
        # dp memo size is: (d + 1) x (ntot + 1)
        memo = [[inf] * (ntot + 1) for _ in range(d + 1)]
        memo[0][0] = 0
        
        # k represents in how many days we want to divide 
        # the job into; ranges from 1 day to d days. Where,
        # d days is the final answer
        for k in range(1, d + 1):
            
            # jobsize represents the size of the job. As we
            # build our memo, jobsize will vary from k, which
            # is the number of days to n + 1. Note that, if we
            # want to divide the job into k days, then the mini-
            # mum job size must be k
            #
            for jobsize in range(k, ntot + 1):
                
                # now we continue to partition the job into
                # two pieces and use memo to utilize the pre-
                # calculation. Compare this to the backtracking
                # solution, where the memo replaces the recur-
                # sive call.
                maxDiff = 0
                
                # variable part represents partion
                for part in range(jobsize, k - 1, -1):
                    # now collect the maximum for this
                    # partition
                    if jobs[part - 1] > maxDiff:
                        maxDiff = jobs[part - 1]
                    
                    # combine with previous result (remember backtracking?)
                    curDiff = maxDiff + memo[k - 1][part - 1]
                    if curDiff < memo[k][jobsize]:
                        memo[k][jobsize] = curDiff
                    
        return -1 if memo[d][ntot] == inf else memo[d][ntot]
    
#Method-5
# dynamic programming

class Solution:
    def minDifficulty(self, jobDifficulty: List[int], d: int) -> int:
        n = len(jobDifficulty)
        if d > n:
            return -1

        # Memoize maximum for every cut
        max_dp = [[0 for _ in range(n)] for _ in range(n)]
        for i in range(n):
            for j in range(i, n):
                if i == j:
                    max_dp[i][j] = jobDifficulty[i]
                else:
                    max_dp[i][j] = max(max_dp[i][j - 1], jobDifficulty[j])
        
        # Calculate minimum difficulty
        dp = [[0 for _ in range(n)] for _ in range(d)]
        for i in range(d):
            for j in range(i, min(n, n - d + i + 1)):
                if i == 0:
                    dp[i][j] = max_dp[i][j]
                else:
                    dp[i][j] = min(
                        dp[i - 1][k - 1] + max_dp[k][j]
                        for k in range(i, j + 1)
                    )
        return dp[d - 1][n - 1]


  #Method-6
# 2-D dp


# Solution – Here we will use 2-D dp as we have 2 parameters day and jobs . ith Row will represent i+1 day and jth column will represent j+1 job.
# dp[0][0]=jobDifficulty[0] because day=1 and job=1 so minimum difficulty will be the job only.
# Now for jobs from j=1 to j=n of first day we fill the dp by taking max of previous element.(BaseCase)
# Ex – [ 7 ,1 ,7 ,1 ,7 ,1] day=3
# If we are at i=1 and j=3 means 2nd day and 4th job

# Job             day1         day2 
# 7 1 7 1         7 1 7         1
# 7 1 7 1         7 1           7 1
# 7 1 7 1         7             1 7 1
# We have to find minimum of above 3 possibilities and store in dp[1][3] . Similar of every dp[i][j].

class Solution:
    def minDifficulty(self, jobDifficulty: List[int], d: int) -> int:
        jobs=len(jobDifficulty)
        dp=[[float('inf') for i in range(jobs)] for j in range(d)]
        dp[0][0]=jobDifficulty[0]
        for i in range(1,jobs):
            dp[0][i]=max(jobDifficulty[i],dp[0][i-1])
        for day in range(1,d):
            for job in range(jobs):
                if job+1<day+1:
                    dp[day][job]=-1
                else:    
                    curr_max=jobDifficulty[job]
                    for k in range(job,day-1,-1):
                        curr_max=max(curr_max,jobDifficulty[k])
                        dp[day][job]=min(dp[day][job],dp[day-1][k-1]+curr_max)
        return dp[d-1][jobs-1]


#Q27 Frog Jump

'''

A frog is crossing a river. The river is divided into some number of units, and at each unit, there may or may not exist a stone. The frog can jump on a stone, but it must not jump into the water.

Given a list of stones' positions (in units) in sorted ascending order, determine if the frog can cross the river by landing on the last stone. Initially, the frog is on the first stone and assumes the first jump must be 1 unit.

If the frog's last jump was k units, its next jump must be either k - 1, k, or k + 1 units. The frog can only jump in the forward direction.

 

Example 1:

Input: stones = [0,1,3,5,6,8,12,17]
Output: true
Explanation: The frog can jump to the last stone by jumping 1 unit to the 2nd stone, then 2 units to the 3rd stone, then 2 units to the 4th stone, then 3 units to the 6th stone, 4 units to the 7th stone, and 5 units to the 8th stone.
Example 2:

Input: stones = [0,1,2,3,4,8,9,11]
Output: false
Explanation: There is no way to jump to the last stone as the gap between the 5th and 6th stone is too large.
 

Constraints:

2 <= stones.length <= 2000
0 <= stones[i] <= 231 - 1
stones[0] == 0
stones is sorted in a strictly increasing order.

'''
#Solution

# Method-1

class Solution:
    def canCross(self, stones: List[int]) -> bool:
        hashmap = {}
        for stone in stones:
            hashmap[stone] = set()
        hashmap[stones[0]].add(0)
        for i in range(len(stones)):
            pos = stones[i]
            for j in hashmap[pos]:
                for k in (j-1,j,j+1):
                    if k>0 and pos+k in hashmap:
                        hashmap[pos+k].add(k)
        return len(hashmap[stones[-1]])
    
# Method-2

# DFS+Memo

# TC--O(N*N)

class Solution:
	def canCross(self, stones: List[int]) -> bool:
		a=set(stones)
		if stones[1]!=1:
			return False
		@cache
		def dfs(last,pos):
			if pos==stones[-1]:
				return True
			if last==pos:
				return False
			jump=pos-last
			for x in [pos+jump-1,pos+jump,pos+jump+1]:
				if x in a:
					if dfs(pos,x):
						return True
			return False
		return dfs(0,1)
    
# Method-3

class Solution:
    def canCross(self, stones: List[int]) -> bool:
        stoneSet = set(stones)
        
        @cache
        def dp(i, k) -> bool:
            nonlocal stoneSet
            nonlocal stones
            if i not in stoneSet:
                return False
            if i == stones[-1]:
                return True

            return dp(i+k, k) or dp(i+k+1, k+1) or (False if k-1 == 0 else dp(i+k-1, k-1))
        
        return dp(1,1)
    
# Method-4

# I initially wrote a bottom-up DP, but got the TLE. So I switched to DFS with memorization and it worked. Haven't really thought about how to clean it up yet.

class Solution:
    
    def canCross(self, stones):
        """
        :type stones: List[int]
        :rtype: bool
        """
        def canCrossHelper(dp, i, step):
            if (i, step) in dp:
                return dp[(i, step)]
            if i == len(stones) - 1:
                dp[(i, step)] = True
                return True
            j = i + 1
            while j < len(stones) and stones[j] <= stones[i] + step + 1:
                if stones[j] - stones[i] in [step - 1, step, step + 1] and canCrossHelper(dp, j, stones[j] - stones[i]):
                    dp[(i, step)] = True
                    return True
                j += 1
            dp[(i, step)] = False
            return False
        
        if len(stones) == 1:
            return True
        if stones[1] != 1:
            return False
        return canCrossHelper({}, 1, 1)
    
# Method-5
#Stack

class Solution(object):
    def canCross(self, stones):
        """
        :type stones: List[int]
        :rtype: bool
        """
        n = len(stones)
        dic = dict()
        visit = set()
        for idx, num in enumerate(stones):
            dic[num] = idx
        stack = [(0,0)]
        while stack:
            idx, step = stack.pop(0)
            if idx == n-1:
                return True
            for jump in range(step-1, step + 2):
                if jump <= 0:
                    continue
                step_ = stones[idx] + jump
                if step_ in dic and (dic[step_], jump) not in visit:
                    stack.append((dic[step_], jump))
                    visit.add((dic[step_], jump))
        return False


#Q28 Best Time to Buy and Sell Stock IV

'''

You are given an integer array prices where prices[i] is the price of a given stock on the ith day, and an integer k.

Find the maximum profit you can achieve. You may complete at most k transactions.

Note: You may not engage in multiple transactions simultaneously (i.e., you must sell the stock before you buy again).

 

Example 1:

Input: k = 2, prices = [2,4,1]
Output: 2
Explanation: Buy on day 1 (price = 2) and sell on day 2 (price = 4), profit = 4-2 = 2.
Example 2:

Input: k = 2, prices = [3,2,6,5,0,3]
Output: 7
Explanation: Buy on day 2 (price = 2) and sell on day 3 (price = 6), profit = 6-2 = 4. Then buy on day 5 (price = 0) and sell on day 6 (price = 3), profit = 3-0 = 3.
 

Constraints:

0 <= k <= 100
0 <= prices.length <= 1000
0 <= prices[i] <= 1000
'''
#Solution

# Method-1 

# DP with List comprehension

# Similar to Best Time III, except we keep an array for k transactions.
# dp[0] stays unchanged because without any transactions, max profit = 0

# Complexity: time O(nk), space O(k)

class Solution:
    def maxProfit(self, k: int, prices: List[int]) -> int:
        dp = [[-float('inf'), -float('inf')] for _ in range(k + 1)]
        dp[0][1] = 0
        for price in prices:
            dp = [dp[0]] + [[max(dp[i][0], dp[i - 1][1] - price), max(dp[i][1], dp[i][0] + price)] for i in range(1, len(dp))]
        return max(dp[i][1] for i in range(len(dp)))

    
# Method-2

# Top Down + Bottom Up

# dynamic programming

class Solution:
    
    def memoization(self, ind, transNo, k, n, prices, mem_dp):
        if ind == n or transNo == 2*k:
            return 0
        
        profit = 0
        
        if mem_dp[ind][transNo] != -1:
            return mem_dp[ind][transNo]
        
        if transNo % 2 == 0: #buy
            profit = max(-1* prices[ind] + self.memoization(ind+1, transNo + 1, k, n, prices, mem_dp), 0 + self.memoization(ind+1, transNo, k, n, prices, mem_dp))
            mem_dp[ind][transNo] = profit
        else:
            profit = max(prices[ind] + self.memoization(ind+1, transNo+1, k, n, prices, mem_dp), 0 + self.memoization(ind+1, transNo, k, n, prices, mem_dp))
            mem_dp[ind][transNo] = profit
        
        return mem_dp[ind][transNo]
    
    def maxProfit(self, k: int, prices: List[int]) -> int:
        n = len(prices)
        mem_dp = [[-1 for _ in range(2*k)] for _ in range(n)]
        return self.memoization(0, 0, k, n, prices, mem_dp)
    
        dp = [[0 for _ in range(2*k+1)] for _ in range(n+1)]
        
        for ind in range(n-1, -1, -1):
            for transNo in range(2*k-1, -1, -1):
                if transNo % 2 == 0:
                    profit = max(-1*prices[ind] + dp[ind+1][transNo+1], 0 + dp[ind+1][transNo])
                else:
                    profit = max(prices[ind] + dp[ind+1][transNo+1], 0 + dp[ind+1][transNo])
                dp[ind][transNo] = profit
        
        return dp[0][0]
    
#Method-3

class Solution:
    # @param prices, a list of integer
    # @return an integer
    def maxProfit(self, k, prices):
        if k >= len(prices)//2:
            return sum(i-j for i, j in zip(prices[1:], prices[:-1]) if i-j > 0)
        hold, release = [float('-inf')]*(k+1), [0]*(k+1)
        for p in prices:
            for i in range(1, k+1):
                release[i] = max(release[i], hold[i]+p)
                hold[i] = max(hold[i], release[i-1]-p)
        return release[k]
    
    
#Method-4


class Solution(object):
    def maxProfit(self, k, prices):
        n = len(prices)
        # avoid MemoryError
        if k >= (n>>1):
            return self.buyAsMany(prices)
        dp = [[0] * n for _ in range(k+1)]
        for i in range(1, k+1):
            # reduce O(knn) to O(kn)
            tmp = -prices[0]
            for j in range(1, n):
                # sell or not sell
                dp[i][j] = max(dp[i][j-1], prices[j]+tmp)
                tmp = max(tmp, dp[i-1][j-1]-prices[j])
        return dp[k][n-1]
    
    def buyAsMany(self, prices):
        if len(prices) < 2:
            return 0
        profit = 0
        for i in range(1, len(prices)):
            # sell only if price increased
            profit += max(0, prices[i]-prices[i-1])
        return profit

    
#Method-5
# DP, Concise O(NK)


class Solution:
    def maxProfit(self, k: int, prices: List[int]) -> int:
        if not prices or k==0:
            return 0
        
        s = [[-math.inf for _ in range(2)] for _ in range(k)]
        s[0][0] = -prices[0]
        for i in range(1, len(prices)):
            for k_ in range(k):
                s[k_][0] = max(s[k_][0], (0 if k_==0 else s[k_-1][1]) - prices[i])
                s[k_][1] = max(s[k_][1], s[k_][0]+prices[i])
        
        return max(0, s[-1][-1]



#Q 29  Burst Balloons

'''
You are given n balloons, indexed from 0 to n - 1. Each balloon is painted with a number on it represented by an array nums. You are asked to burst all the balloons.

If you burst the ith balloon, you will get nums[i - 1] * nums[i] * nums[i + 1] coins. If i - 1 or i + 1 goes out of bounds of the array, then treat it as if there is a balloon with a 1 painted on it.

Return the maximum coins you can collect by bursting the balloons wisely.

 

Example 1:

Input: nums = [3,1,5,8]
Output: 167
Explanation:
nums = [3,1,5,8] --> [3,5,8] --> [3,8] --> [8] --> []
coins =  3*1*5    +   3*5*8   +  1*3*8  + 1*8*1 = 167
Example 2:

Input: nums = [1,5]
Output: 10
 

Constraints:

n == nums.length
1 <= n <= 300
0 <= nums[i] <= 100

'''

#Solution 

# Method-1
# dynamic programming 


# based on scoring rule, the score of bursting nums[i] is nums[i - 1] * nums[i] * nums[i + 1], and i - 1 or i + 1 goes out of bounds of the array, treat it as if there is a balloon with a 1 painted on it.
# So, add 1 at the first and the end of nums
# dp[i][j] means how much score we can get from nums[i+1:j] -> (i, j) open interval.

# k is the balloon we is to burst last in the open interval (i, j), we can calculate score after burst every balloons in the open interval (i, j), and find the max score.
# dp[i][k] is the max score we can from open interval (i, k), dp[k][j] is the max score we can from open interval (k, j),
# dp[i][k] means the balloons in the closed interval [i+1, k-1] have been bursted, dp[k][j] is the same.
# so dp[i][j] is max(dp[i][k] + dp[k][j] + nums[i] * nums[k] * nums[j] for k in closed interval [i+1, j-1])

# eg. nums=[3,1,5,8]
# iteration
# dp array is filled from bottom to top, from left to right
# tc isO(len(nums)**3), sc is O(0.5*len(nums)**2)

class Solution:
    def maxCoins(self, nums: List[int]) -> int:
        if len(nums) == 1: return nums[0]
        nums = [1] + nums + [1]
        leng = len(nums)
        dp = [[0] * leng for _ in range(leng)]
        for i in range(leng-2,-1,-1):
            for j in range(i, leng):
                for k in range(i+1, j):
                    dp[i][j] = max(dp[i][j], dp[i][k] + dp[k][j] + nums[i]*nums[j]*nums[k])
        return dp[0][leng-1]
    
    
    
# Method-2    
# dfs
# tc isO(len(nums)**3), sc is O(0.5*len(nums)**2)

class Solution:
    def maxCoins(self, nums: List[int]) -> int:
        if len(nums) == 1: return nums[0]
        nums = [1] + nums + [1]
        leng = len(nums)
        @cache
        def dfs(i, j):
            if j - i <= 1: return 0 # there is no balloon between the neighbor
            ans = 0
            for k in range(i+1, j):
                ans = max(ans, dfs(i,k) + dfs(k,j) + nums[i] * nums[j] * nums[k])
            return  ans
        return dfs(0, leng-1)
    

# Method-3
# Recursion + Memoization | DP Tabulation


class Solution:
    def maxCoins(self, nums):
        # Solution - Dynamic Programming - Tabulation
        # Time - O(N*N*N)
        # Space - O(N*N)
        
        n = len(nums)
        nums = [1] + nums + [1]
        dp = [[0] * (n+2) for _ in range(n+2)]
        
        for i in reversed(range(1, n+1)):
            for j in range(1, n+1):
                if i > j: continue
                    
                maxi = float('-inf')
                for k in range(i, j+1):
                    cost = ((nums[i-1] * nums[k] * nums[j+1]) + 
                           dp[i][k-1] + dp[k+1][j])
                    maxi = max(maxi, cost)
                
                dp[i][j] = maxi
        
        return dp[1][n]
    
                    
# Method-4

class Solution(object):
    def maxCoins(self, nums):
        """
        :type nums: List[int]
        :rtype: int
        """
        if not nums:
            return 0
        
        nums = [1] + nums + [1]
        dp = [[0 for _ in xrange(len(nums))] for _ in xrange(len(nums))]
        
        for k in xrange(2,len(nums)):
            for i in xrange(len(nums) - k):
                start,end = i,i + k
                for j in xrange(start + 1,end):
                    dp[start][end] = max(dp[start][end],nums[start] * nums[j] * nums[end] + dp[j][end] + dp[start][j])
        
        return dp[0][len(nums) - 1]

# Method-5
#Tabular Dynamic Programming | Gap Strategy
# bottom up approach
# no recursion
# gaph strategy
# dynamic prpgramming

class Solution:
    def maxCoins(self, nums: List[int]) -> int:
        nums=[1]+nums+[1]
        length=len(nums)
        DP=[[0 for _ in range(length)] for _ in range(length)]
        for gap in range(1, length-1, 1):
            i=1
            for j in range(gap, length-1, 1):
                DP[i][j]=max(DP[i][k-1]+(nums[i-1])*(nums[k])*(nums[j+1])+DP[k+1][j] for k in range(i, j+1))
                i+=1
        return DP[1][length-2]


#Q30 Minimum Cost to Merge Stones

'''

There are n piles of stones arranged in a row. The ith pile has stones[i] stones.

A move consists of merging exactly k consecutive piles into one pile, and the cost of this move is equal to the total number of stones in these k piles.

Return the minimum cost to merge all piles of stones into one pile. If it is impossible, return -1.

 

Example 1:

Input: stones = [3,2,4,1], k = 2
Output: 20
Explanation: We start with [3, 2, 4, 1].
We merge [3, 2] for a cost of 5, and we are left with [5, 4, 1].
We merge [4, 1] for a cost of 5, and we are left with [5, 5].
We merge [5, 5] for a cost of 10, and we are left with [10].
The total cost was 20, and this is the minimum possible.
Example 2:

Input: stones = [3,2,4,1], k = 3
Output: -1
Explanation: After any merge operation, there are 2 piles left, and we can't merge anymore.  So the task is impossible.
Example 3:

Input: stones = [3,5,1,2,6], k = 3
Output: 25
Explanation: We start with [3, 5, 1, 2, 6].
We merge [5, 1, 2] for a cost of 8, and we are left with [3, 8, 6].
We merge [3, 8, 6] for a cost of 17, and we are left with [17].
The total cost was 25, and this is the minimum possible.
 

Constraints:

n == stones.length
1 <= n <= 30
1 <= stones[i] <= 100
2 <= k <= 30

'''
#Solution

# Method-1

# top-down DP: think backwards
 # We can first address the case it which it is impossible to merge to 1 element as in Example 2:
    # In each merge, length of stones reduces by k-1
    # If n - m*(k-1) cannot reach 1, we must return -1 (or infinity when we calculate cost)
    # Then we go into the test cases which are ok
    # This problem involves minimizing cost, let's think backward from the final state
    # As an example, stones = [3,5,1,2,6], k = 3
    # At final state we know it must be stones = [17], cost = 17, which is the sum of all stones
    # The minimum cost might come from merging [9,2,6], [3,8,6] or [3,5,9]
    # Translating the logic, we are trying to get what is the minimum cost to get stones into k (= 3 in this case) piles
    # Then each element might come from a merge
    # i.e. 9 comes from [3,5,1] (stones[0:3]), 8 comes from [5,1,2] (stones[1:4]) and 9 comes from [1,2,6] (stones[2:5])
    # We are seeing a recursive relation and a minimization among different options.
    # Therefore the top-down DP approach is first thing to try.
    # Here we define dp[i][j][m] = minimum cost to split nums[i:j+1] into m piles
    # Base cases: dp[i][i][m] = 0 for m = 1, otherwise inf (one element, can only break into 1 pile)
    # dp[i][j][m] = inf if (j+1-i-m) % (k-1) != 0 
    # (Try for example: stones = [3,5,1,2,6], k = 3, m = 2, i=0, j=4)
    # Recurrence relation:
    # dp[i][j][1] = dp[i][j][k] + sum(nums[i:j+1])
    # dp[i][j][m] = min(dp[i][K][1] + dp[K+1][j][m-1]), loop K from i to j-1, progress by k-1 to avoid getting infinities
    # We want to know what is dp[0][n-1][1]

class Solution:
    def dp(self, i, j, m):
        if (i,j,m) in self.memo:
            return self.memo[(i,j,m)]
        if i == j:
            if m == 1:
                return 0
            else:
                return float('Inf')
        if m == 1:
            return self.dp(i,j,self.k) + self.prefix[j+1] - self.prefix[i]
        else:
            result = float('Inf')
            for K in range(i, j, self.k-1):
                result = min(result, self.dp(i,K,1) + self.dp(K+1, j, m-1))
            self.memo[(i,j,m)] = result
        return result
        
    def mergeStones(self, stones: List[int], k: int) -> int:
        n = len(stones)
        if (n-1) % (k-1) != 0:
            return -1

        self.k, self.stones, self.memo = k, stones, {}
        self.prefix = [0]
        for stone in stones:
            self.prefix.append(self.prefix[-1] + stone)
        return self.dp(0,len(stones)-1,1)
    
# Method-2

class Solution:
    def mergeStones(self, stones, K):
        from functools import lru_cache
        @lru_cache(None) 
        def dfs(l, r, pile):
            if pile == K and (r - l ) % (pile-1):
                return float('inf')
            if l == r:
                return 0
            if pile == 1:
                return dfs(l,r,K) + sum(stones[l:r+1]) 
            return min(dfs(l,i,1) + dfs(i+1, r, pile-1) for i in range(l, r))
        ans = dfs(0, len(stones)-1, 1)
        return -1 if ans == float('inf') else ans
    
#Method-3

# Top Down solution
# DP, 2D array, O(n^3/K)


class Solution:
    def mergeStones(self, stones: List[int], K: int) -> int:
        n = len(stones)
        if (n-1)%(K-1) != 0:
            return -1
        dp = [[0]*n for _ in range(n)]
        sums = [0]*(n+1)
        for i in range(1,n+1):
            sums[i] = sums[i-1]+stones[i-1]
        for length in range(K,n+1):
            for i in range(n-length+1):
                j = i+length-1
                dp[i][j] = float('inf')
                for t in range(i,j,K-1):
                    dp[i][j] = min(dp[i][j], dp[i][t]+dp[t+1][j])
                if (j-i)%(K-1)==0:
                    dp[i][j] += sums[j+1]-sums[i]
        return dp[0][n-1]
    
#Method-4

# Standard Top-down DP + Segmentation Generation

class Solution(object):
    def mergeStones(self, stones, K):
        """
        :type stones: List[int]
        :type K: int
        :rtype: int
        """
        # DP problem
        if len(stones) == 1:
            return 0
        if len(stones) < K:
            return -1
        if (len(stones) - K) % (K - 1) != 0:
            return -1
        # DP problem
        global L, R
        R = []
        L = []
        D = {}
        M = {}
        candidate = [1]
        while candidate[-1] < 100:
            candidate.append(candidate[-1] + K - 1)

        ccsum = [0]
        for i in stones:
            ccsum.append(ccsum[-1]+i)

        def generate(total, k, cursum, K):
            global L, R
            if k == K:
                if cursum == total:
                    R.append(L[:])
            else:
                for i in range(100):
                    if cursum + candidate[i] <= total:
                        L.append(candidate[i])
                        generate(total,k+1,cursum + candidate[i],K)
                        L.pop()
                    else:
                        break

        def GenerateSeg(start, end, K):
            global L, R
            total = end - start + 1
            if total in M:
                return M[total]
            R = []
            L = []
            generate(total, 0, 0, K)
            M[total] = R[:]
            return M[total]

        def Find(start, end, K):
            if start == end:
                return stones[start]
            if (start, end) in D:
                return D[(start, end)]
            m = 100000000000
            R = GenerateSeg(start, end, K)
            for r in R:
                temp = 0
                tstart = start
                for i in r:
                    temp += Find(tstart,tstart+i-1,K)
                    if i>1:
                        temp += ccsum[tstart+i] - ccsum[tstart]
                    tstart += i

                m = min(m, temp)
            D[(start, end)] = m
            return m

        return Find(0, len(stones)-1,K)
    
#Method-5

# 3D DP
# Intuition
# Seem that most of games, especially stone games, are solved by dp?

# Explanation

# dp[i][j][m] means the cost needed to merge stone[i] ~ stones[j] into m piles.

# Initial status dp[i][i][1] = 0 and dp[i][i][m] = infinity

# dp[i][j][1] = dp[i][j][k] + stonesNumber[i][j]
# dp[i][j][m] = min(dp[i][mid][1] + dp[mid + 1][j][m - 1])

# The origine python2 solution is a bit too long on the memorization part.
# So I rewrote it in python3 with cache helper,
# so it will be clear for logic.

# Complexity
# Time O(N^3/K), Space O(KN^2)

class Solution:
    def mergeStones(self, stones, K):
        n = len(stones)
        inf = float('inf')
        prefix = [0] * (n + 1)
        for i in range(n):
            prefix[i + 1] = prefix[i] + stones[i]

        import functools

        @functools.lru_cache(None)
        def dp(i, j, m):
            if (j - i + 1 - m) % (K - 1):
                return inf
            if i == j:
                return 0 if m == 1 else inf
            if m == 1:
                return dp(i, j, K) + prefix[j + 1] - prefix[i]
            return min(dp(i, mid, 1) + dp(mid + 1, j, m - 1) for mid in range(i, j, K - 1))
        res = dp(0, n - 1, 1)
        return res if res < inf else -1


#Method-6

class Solution:
    def mergeStones(self, stones, K):
        n = len(stones)
        if (n - 1) % (K - 1): return -1
        prefix = [0] * (n + 1)
        for i in range(n):
            prefix[i + 1] = prefix[i] + stones[i]

        import functools
        @functools.lru_cache(None)
        def dp(i, j):
            if j - i + 1 < K: return 0
            res = min(dp(i, mid) + dp(mid + 1, j) for mid in range(i, j, K - 1))
            if (j - i) % (K - 1) == 0:
                res += prefix[j + 1] - prefix[i]
            return res
        return dp(0, n - 1)


#Q31 Minimum Insertion Steps to Make a String Palindrome

'''

Given a string s. In one step you can insert any character at any index of the string.

Return the minimum number of steps to make s palindrome.

A Palindrome String is one that reads the same backward as well as forward.

 

Example 1:

Input: s = "zzazz"
Output: 0
Explanation: The string "zzazz" is already palindrome we don't need any insertions.
Example 2:

Input: s = "mbadm"
Output: 2
Explanation: String can be "mbdadbm" or "mdbabdm".
Example 3:

Input: s = "leetcode"
Output: 5
Explanation: Inserting 5 characters the string becomes "leetcodocteel".
 

Constraints:

1 <= s.length <= 500
s consists of lowercase English letters.

'''

#Solution

#Method-1

class Solution:
    def minInsertions(self, s: str) -> int:

        @functools.cache
        def helper(l,r):
            if l>=r: return 0
            return helper(l+1,r-1) if s[l]==s[r] else 1+min(helper(l+1,r),helper(l,r-1))
        
        return helper(0,len(s)-1)
   

# Method-2
# dynamic prpgramming

class Solution:
	def minInsertions(self, s: str) -> int:
		if s == s[::-1]:return 0
		n = len(s)
		dp = [[0 for i in range(n+1)] for j in range(n+1)]

		s2 = s[::-1]

		for i in range(0,len(dp)):
			for j in range(0, len(dp[0])):
				if i == 0 or j == 0:
					dp[i][j] = 0
				elif s2[i-1] == s[j-1]:
					dp[i][j] = dp[i-1][j-1]+1
				else:
					dp[i][j] = max(dp[i-1][j], dp[i][j-1])
		ans = abs(n - dp[-1][-1]) 
		return ans
  

# Method-3

# 2D Bottom Up Dynamic Programming
# Calculate dp[i][j] that is the minimal steps needed to convert substring [i,j] (inclusive) to palindrome.

class Solution:
    def minInsertions(self, s: str) -> int:
        N = len(s)
        dp = [[0 for _ in range(N)] for _ in range(N)]
        
        for k in range(1, N):
            for i in range(N-k):
                if s[i] == s[i+k]:
                    dp[i][i+k] = dp[i+1][i+k-1]
                else:
                    dp[i][i+k] = min(dp[i][i+k-1],dp[i+1][i+k])+1
                    
        return dp[0][N-1]

# Method-4

# get the LCS from dp[n][n]. Then just remove the number from string size, simple!!!
# dynamic programming
# top down dp

class Solution:
    def minInsertions(self, s: str) -> int:
        n = len(s)
        r = s[::-1]
        dp = [[0]*(n+1) for _ in range(n+1)]
        for i in range(1,n+1):
            for j in range(1,n+1):
                if s[i-1]==r[j-1]:
                    dp[i][j] = 1+dp[i-1][j-1]
                else:
                    dp[i][j] = max(dp[i-1][j], dp[i][j-1])
        return n-dp[n][n]
    
# Method-5

class Solution:
    def minInsertions(self, s: str) -> int:
        n = len(s)
        dp = [[0]*(n+1) for _ in range(n+1)]
        for i in range(1, n+1)[::-1]:
            for j in range(i+1, n+1):
                if i >= j:
                    dp[i][j] = 0
                elif s[i-1] == s[j-1]:
                    dp[i][j] = dp[i+1][j-1]
                else:
                    dp[i][j] = 1+min(dp[i+1][j], dp[i][j-1])
        return dp[1][n]


#Q32 Super Egg Drop

'''

You are given k identical eggs and you have access to a building with n floors labeled from 1 to n.

You know that there exists a floor f where 0 <= f <= n such that any egg dropped at a floor higher than f will break, and any egg dropped at or below floor f will not break.

Each move, you may take an unbroken egg and drop it from any floor x (where 1 <= x <= n). If the egg breaks, you can no longer use it. However, if the egg does not break, you may reuse it in future moves.

Return the minimum number of moves that you need to determine with certainty what the value of f is.

 

Example 1:

Input: k = 1, n = 2
Output: 2
Explanation: 
Drop the egg from floor 1. If it breaks, we know that f = 0.
Otherwise, drop the egg from floor 2. If it breaks, we know that f = 1.
If it does not break, then we know f = 2.
Hence, we need at minimum 2 moves to determine with certainty what the value of f is.
Example 2:

Input: k = 2, n = 6
Output: 3
Example 3:

Input: k = 3, n = 14
Output: 4
 

Constraints:

1 <= k <= 100
1 <= n <= 104

'''
#Solution

#Method-1

class Solution:
    def superEggDrop(self, k: int, n: int) -> int:
        #dp[i][j] = Number of floors that can be checked with i drops & j eggs
        dp = [[0]*(k+1) for _ in range(n+1)]
        
        for i in range(1,n+1):
            for j in range(1,1+k):
                dp[i][j] = 1 + dp[i-1][j] + dp[i-1][j-1]
                if dp[i][k]>=n:
                    return i
                
                
# Method-2

# DP O(K*N) with 5 lines
# egg broken dp[floor-1][egg-1]
# egg not broken dp[floor-1][egg]
# dp 
    
class Solution:
    def superEggDrop(self, k: int, n: int) -> int:
        dp = [[0] * (k + 1) for _ in range(n + 1)]
        for floor in range(1, n + 1):
            for egg in range(1, k + 1):
                dp[floor][egg] = 1 + dp[floor - 1][egg - 1] + dp[floor - 1][egg]
                if dp[floor][egg] >= n: return floor
        return -1

# Method-3
# Dynamic Programming with Binary Search

# Time Complexity: O(K N \log N)O(KNlogN).

# Space Complexity: O(K N)O(KN).



class Solution:
    def superEggDrop(self, K: int, N: int) -> int:
        @lru_cache(None)
        def dp(k, n):
            if n == 0:
                return 0
            if k == 1:
                return n
            lo, hi = 1, n
            # keep a gap of 2 X values to manually check later
            while lo + 1 < hi:
                x = (lo + hi) // 2
                t1 = dp(k-1, x-1)
                t2 = dp(k, n-x)

                if t1 < t2:
                    lo = x
                elif t1 > t2:
                    hi = x
                else:
                    lo = hi = x
            return 1 + min(max(dp(k-1, x-1), dp(k, n-x))for x in (lo, hi))

        return dp(K, N)
    
# Method-4

# Dynamic Programming with Optimality Criterion

# Time Complexity: O(KN)O(KN).

# Space Complexity: O(N)O(N).

class Solution:
    def superEggDrop(self, K: int, N: int) -> int:

        # Right now, dp[i] represents dp(1, i)
        dp = range(N+1)

        for k in range(2, K+1):
            # Now, we will develop dp2[i] = dp(k, i)
            dp2 = [0]
            x = 1
            for n in range(1, N+1):
                # Let's find dp2[n] = dp(k, n)
                # Increase our optimal x while we can make our answer better.
                # Notice max(dp[x-1], dp2[n-x]) > max(dp[x], dp2[n-x-1])
                # is simply max(T1(x-1), T2(x-1)) > max(T1(x), T2(x)).
                while x < n and max(dp[x-1], dp2[n-x]) > \
                                max(dp[x], dp2[n-x-1]):
                    x += 1

                # The final answer happens at this x.
                dp2.append(1 + max(dp[x-1], dp2[n-x]))

            dp = dp2
        return dp[-1]
    
    
# Method-5    
# Mathematical
# Time Complexity: O(K\log N)O(KlogN).

# Space Complexity: O(1)O(1).

class Solution:
    def superEggDrop(self, K: int, N: int) -> int:
        def f(x):
            ans = 0
            r = 1
            for i in range(1, K+1):
                r *= x-i+1
                r //= i
                ans += r
                if ans >= N: break
            return ans

        lo, hi = 1, N
        while lo < hi:
            mi = (lo + hi) // 2
            if f(mi) < N:
                lo = mi + 1
            else:
                hi = mi
        return lo

#Q33 Count Different Palindromic Subsequences

'''

Given a string s, return the number of different non-empty palindromic subsequences in s. Since the answer may be very large, return it modulo 109 + 7.

A subsequence of a string is obtained by deleting zero or more characters from the string.

A sequence is palindromic if it is equal to the sequence reversed.

Two sequences a1, a2, ... and b1, b2, ... are different if there is some i for which ai != bi.

 

Example 1:

Input: s = "bccb"
Output: 6
Explanation: The 6 different non-empty palindromic subsequences are 'b', 'c', 'bb', 'cc', 'bcb', 'bccb'.
Note that 'bcb' is counted only once, even though it occurs twice.
Example 2:

Input: s = "abcdabcdabcdabcdabcdabcdabcdabcddcbadcbadcbadcbadcbadcbadcbadcba"
Output: 104860361
Explanation: There are 3104860382 different non-empty palindromic subsequences, which is 104860361 modulo 109 + 7.
 

Constraints:

1 <= s.length <= 1000
s[i] is either 'a', 'b', 'c', or 'd'.

'''
#Solution 

#Method-1
# dynamic progarmming
# recursion

# Approach : so the appraoch is like ---- lets say we devide string into 3 parts a,b and c
# case 1:
# so whenenver part a of string != part c of string or a != c then the number of palidomes in string is equal to palidromes in the a+b part of string + parlidromes in b+c part of string - palidromes in b part of string

# case 2:
# if part a of string is equal to part c of the string then number of palidromes in string is number of palidromes in b part of string + 2 (take it like a__c without taking any character of b and a alone is palidrome too)

# but there is some twist we have to remove the duplicate palidromes in too

# for that there are 3 cases for that part if a and c part of string is equal

# for that we have to remove that part of string in b where a is repeating

# the recursive code will give a better picture

class Solution:
    def countPalindromicSubsequences(self, s: str) -> int:
        def recursion(i,j):
		#whenever the starting index of string is greater than the last index of string
            if i > j:
                return 0
			#for the string of length 1 there is only one palidrome
            if i == j :
                return 1
			# as said in explaination if a part is not equal to c part then the palidromes is equal to 
			#cnt(a+b) + cnt(b+c) - cnt(b)
            if s[i] != s[j]:
                return recursion(i+1,j) + recursion(i,j-1) - recursion(i+1,j-1)
            else:
			# cheching if the equal part of the string lies in between of the string or not from both starting index and last index
                first = i+1
                while first < j and s[first] != s[i]:
                    first += 1
                last = j - 1
                
                while last > i and s[last] != s[j]:
                    last -= 1
                # if there is no occurence of repeating part then the number of palidromic subsequences is
				#cnt(b) + 2
                if first == j:
                    return 2*recursion(i+1,j-1) + 2
				#if there is just one repeatition then the a alone if already counted as palidrome so its count be
				#cnt(b) + 1
                elif first == last:
                    return 2*recursion(i+1,j-1) + 1
				# if there are multiple ocuurences then delete those occurences by deleting number of palidromes between that part
				# cnt(b) - cnt(first,last)
                else:
                    return 2*recursion(i+1,j-1) - recursion(first+1,last-1)
        
        return recursion(0,len(s)-1) % (10**9 + 7)
    
    
#Method-2
# Now the code below is just the space optimised top- down version of the above recursive appraoch

class Solution:
    def countPalindromicSubsequences(self, s: str) -> int:        
        n = len(s)
        dp = [[0 for i in range(n)]for j in range(n)]
        
        for i in range(n-1,-1,-1):
            for j in range(n):
                if i > j :
                    continue
                elif i == j:
                    dp[i][j] = 1
                elif s[i] != s[j]:
                    dp[i][j] = dp[i+1][j] + dp[i][j-1] - dp[i+1][j-1]
                else:
                    first = i+1
                    while first < j and s[first] != s[i]:
                        first += 1
                        
                    last = j - 1
                    while last > i and s[last] != s[j]:
                        last -= 1
                
                    if first == j:
                        dp[i][j] =  2*dp[i+1][j-1] + 2
                    elif first == last:
                        dp[i][j] =  2*dp[i+1][j-1] + 1
                    else:
                        dp[i][j] =  2*dp[i+1][j-1] - dp[first+1][last-1]
                
        return dp[0][n-1] % (10**9 + 7)
    
    
#Method-3
class Solution:
    def countPalindromicSubsequences(self, S: str) -> int:
        @cache
        def dfs(s, e):
            res = 0
            for c in 'abcd':
                if c in S[s:e]:
                    i = S[s:e].index(c)
                    j = S[s:e].rindex(c)
                    res += dfs(s + i + 1, s + j) + 2 if i != j else 1
            return res % (10**9 + 7)
                
        return dfs(0, len(S))

    
#Method-4

# dynamic proramming

class Solution:
    def countPalindromicSubsequences(self, s: str) -> int:
        
        N = len(s)
        mod = 10**9 + 7
        memo = {}
        
        def backTrack(start,end):
            
            if start >= N or end < 0: return 0
            
            key = (start,end) 
            
            if key in memo: return memo[key]
            
            strn = s[start:end+1]

            memo[key] = 0

            for char in "abcd":
                if not char in strn: continue
                i = start + strn.index(char)
                j = start + strn.rindex(char)
                memo[key] += backTrack(i+1,j-1) + 2 if i != j else 1
            
            memo[key] %= mod
            
            return memo[key]
        
        return backTrack(0,N-1)

#Method-5

# DP

# First it is obvious to try DP for counting.
# dp[i][j]: is the ans for string s[i:j+1].
# if s[i]==s[j]: we can reduce to the substring s[i+1:j-1]. However there might be duplicates of s[i] in the middle substring. One can count the next left and right apprearance of such s[i] in the substring, the cases are:
# (1) there is no such char, i.e, l<r;
# (2) there is one such char , ie, l==r;
# (3) there are more than one, l<r;

class Solution: 
    def countPalindromicSubsequences(self, s: str) -> int:
        mod=10**9+7
        n=len(s)
        dp=[[0]*n for i in range(n)]
        res=n ##length of 1 palindromes
        for i in range(n):
            dp[i][i]=1
            if i+1<n:
                dp[i][i+1]=2
        for leng in range(3,n+1):
            for i in range(0,n-leng+1):
                j=i+leng-1
                if s[i]==s[j]:
                    l,r=i+1,j-1
                    while l<=r and s[l]!=s[i]:l+=1
                    while r<=r and s[r]!=s[i]:r-=1
                    if l>r:
                        dp[i][j]=2*dp[i+1][j-1]+ 2
                    elif l==r:
                        dp[i][j]=2*dp[i+1][j-1]+1
                    else:
                        dp[i][j]=2*dp[i+1][j-1]-dp[l+1][r-1]
                else:
                    dp[i][j]=dp[i][j-1]+dp[i+1][j]-dp[i+1][j-1]

        return dp[0][n-1]%mod


#Q33 Minimum Cost to Cut a Stick

'''

Given a wooden stick of length n units. The stick is labelled from 0 to n. For example, a stick of length 6 is labelled as follows:


Given an integer array cuts where cuts[i] denotes a position you should perform a cut at.

You should perform the cuts in order, you can change the order of the cuts as you wish.

The cost of one cut is the length of the stick to be cut, the total cost is the sum of costs of all cuts. When you cut a stick, it will be split into two smaller sticks (i.e. the sum of their lengths is the length of the stick before the cut). Please refer to the first example for a better explanation.

Return the minimum total cost of the cuts.

 

Example 1:


Input: n = 7, cuts = [1,3,4,5]
Output: 16
Explanation: Using cuts order = [1, 3, 4, 5] as in the input leads to the following scenario:

The first cut is done to a rod of length 7 so the cost is 7. The second cut is done to a rod of length 6 (i.e. the second part of the first cut), the third is done to a rod of length 4 and the last cut is to a rod of length 3. The total cost is 7 + 6 + 4 + 3 = 20.
Rearranging the cuts to be [3, 5, 1, 4] for example will lead to a scenario with total cost = 16 (as shown in the example photo 7 + 4 + 3 + 2 = 16).
Example 2:

Input: n = 9, cuts = [5,6,1,4,2]
Output: 22
Explanation: If you try the given cuts ordering the cost will be 25.
There are much ordering with total cost <= 25, for example, the order [4, 6, 5, 2, 1] has total cost = 22 which is the minimum possible.
 

Constraints:

2 <= n <= 106
1 <= cuts.length <= min(n - 1, 100)
1 <= cuts[i] <= n - 1
All the integers in cuts array are distinct.

'''

#Solution 

#Method-1
# dynamic programming
# optimal soln
# memomization
# recursive-memoization
    
# Tabulation : Accepted
class Solution:
    def minCost(self, N: int, cuts: List[int]) -> int:
        c=len(cuts)
        cuts.append(0)
        cuts.append(N)
        cuts.sort()
        dp=[[0 for i in range(c+2)]for j in range(c+2)]  
        for i in range(c,0,-1):
            for j in range(1,c+1):
                if i>j:
                    continue
                mini=float("inf")
                for ind in range(i,j+1):
                    cost=cuts[j+1]-cuts[i-1] +dp[i][ind-1] + dp[ind+1][j]
                    mini=min(mini,cost)
                dp[i][j]=mini
        return dp[1][c]

#Method-2
class Solution:
    def minCost(self, n: int, cuts: List[int]) -> int:
        cache={}
        cuts.sort()
        def Helper(startIdx,endIdx):
            if (startIdx,endIdx) in cache:
                return cache[(startIdx,endIdx)]
            canCut=False
            result=float('inf')
            for cut in cuts:
                if cut>=endIdx:
                    break
                if cut>startIdx:
                    canCut=True
                    curr=endIdx-startIdx+Helper(startIdx,cut)+Helper(cut,endIdx)
                    result=min(result,curr)
            if not canCut:
                return 0
            cache[(startIdx,endIdx)]=result
            return cache[(startIdx,endIdx)]
        return Helper(0,n)
 
#Method-3
# Recursion + Memoization

# We start with entire length of stick (0 to n) and then try cutting at every possible position and keep track of minimum cost
# The cost will be length of stick i.e., end - start
# When we cut a stick it will be devided into two parts - start to cut (index where we cut) + cur to end

# memoziation

class Solution:
    def minCost(self, n: int, cuts: List[int]) -> int:
        cache = {}
		
        def helper(start, end):
            if (start, end) in cache:
                return cache[(start,end)]
            res = float("Inf")
            for cut in cuts:
                if start < cut < end:
                    res = min(res, helper(start, cut) + helper(cut, end) + end-start)
            
            cache[(start, end)] = res if res != float("Inf") else 0
            return cache[(start, end)]
        
        return helper(0, n)
    
# Method-4

# Top Down Solution O(N^3)

class Solution:
    def minCost(self, n: int, cuts: List[int]) -> int:
        cuts.append(0)
        cuts.append(n)
        cuts.sort()
        m = len(cuts)
        dp = [[-1 for i in range(m)]for j in range(m)]
        
        def func(l,r):
            nonlocal dp
            if l+1==r:
                return 0
            if dp[l][r]!=-1:
                return dp[l][r]
            ans = 10**100
            for i in range(l+1,r):
                cost = cuts[r]-cuts[l]
                ans = min(ans,func(l,i)+func(i,r)+cost)
            dp[l][r] = ans
            return ans
        func(0,m-1)
        return  dp[0][-1]

# Method-5
# Recursion + Memoization

class Solution:
    def minCost(self, n: int, cuts: List[int]) -> int:
        seen={}
        def find_min(cuts,curr,length):
            if not cuts:
                return curr
            if (length[0],length[1]) in seen:
                return seen[length[0],length[1]]
            temp=float("inf")
            temp2=[i for i in cuts if length[0]<=i<=length[1]]
            for i in range(len(temp2)):
                temp3=length[1]-length[0]
                temp3+=find_min(temp2[:i]+temp2[i+1:],0,[temp2[i],length[1]])
                temp3+=find_min(temp2[:i]+temp2[i+1:],0,[length[0],temp2[i]])
                temp=min(temp,temp3)
            seen[length[0],length[1]]=temp if temp!=float("inf") else 0
            return seen[length[0],length[1]]
        return find_min(cuts,0,[0,n])
