 

#BFS

#Q1. Number of Islands
''' 
Given an m x n 2D binary grid grid which represents a map of '1's (land) and '0's (water), return the number of islands.

An island is surrounded by water and is formed by connecting adjacent lands horizontally or vertically. You may assume all four edges of the grid are all surrounded by water.

 

Example 1:

Input: grid = [
  ["1","1","1","1","0"],
  ["1","1","0","1","0"],
  ["1","1","0","0","0"],
  ["0","0","0","0","0"]
]
Output: 1
Example 2:

Input: grid = [
  ["1","1","0","0","0"],
  ["1","1","0","0","0"],
  ["0","0","1","0","0"],
  ["0","0","0","1","1"]
]
Output: 3
 

Constraints:

m == grid.length
n == grid[i].length
1 <= m, n <= 300
grid[i][j] is '0' or '1'.

'''
#Solution:


#Approach-1: UnionFind


class Solution:
    def numIslands(self, grid: List[List[str]]) -> int:
        uf = UnionFind(grid)
        m = len(grid)
        n = len(grid[0])
        for i in range(m):
            for j in range(n):
                if grid[i][j] == "1":
                    grid[i][j] = "0"
                    if i + 1 < m and grid[i+1][j] == "1":
                        uf.union(i*n+j, (i+1)*n+j)
                    if i - 1 >= m and grid[i-1][j] == "1":
                        uf.union(i*n+j, (i-1)*n+j)
                    if j + 1 < n and grid[i][j+1] == "1":
                        uf.union(i*n+j, i*n+j+1)
                    if j - 1 >= 0 and grid[i][j-1] == "1":
                        uf.union(i*n+j, i*n+j-1)
        return uf.cnt
        
        
class UnionFind:
    def __init__(self, grid):
        self.parent = {}
        self.rank = {}
        self.cnt = 0
        
        m = len(grid)
        n = len(grid[0])
        for i in range(m):
            for j in range(n):
                if grid[i][j] == "1":
                    self.parent[i*n+j] = i*n+j
                    self.rank[i*n+j] = 0
                    self.cnt += 1
        
    def union(self, a, b):
        a = self.find(a)
        b = self.find(b)
        if a == b:
            return
        if self.rank[a] == self.rank[b]:
            self.rank[a] += 1
        elif self.rank[a] < self.rank[b]:
            a, b = b, a
        self.parent[b] = a
        self.cnt -= 1
    
    def find(self, x):
        if x != self.parent[x]:
            self.parent[x] = self.find(self.parent[x])
        return self.parent[x]
    
    
#Approach-2:dfs


class Solution:
    def numIslands(self, grid: List[List[str]]) -> int:
        h, w = len(grid), len(grid[0])
        num_islands = 0
        def dfs(i, j):
            grid[i][j] = "0"
            d = [[-1, 0], [1, 0], [0, -1], [0, 1]]
            for pi, pj in d:
                ni, nj = i + pi, j + pj
                if 0 <= ni < h and 0 <= nj < w and grid[ni][nj] == "1":
                    dfs(ni, nj)

        for i in range(h):
            for j in range(w):
                if grid[i][j] == "1":
                    dfs(i, j)
                    num_islands += 1
        return num_islands

    
#Approach-3:BFS


class Solution:
    def numIslands(self, grid: List[List[str]]) -> int:
        
        
        rows = len(grid)
        cols = len(grid[0])
        ans = 0 
        for i in range( 0 , rows ):
            for j in range( 0 , cols ):
                if grid[i][j] == '1' :
                    ans  = ans + 1 
                    grid[i][j] = '0'
                    queue = []
                    queue.append((i,j))
                    
                    while len(queue):
                        x , y = queue.pop(0)
                        
                        dx = [0,1,0,-1]
                        dy = [1,0,-1,0]
                        
                        for j in range( 0 , 4 ):
                            to_x = x + dx[j]
                            to_y = y + dy[j]
                            
                            if to_x >= 0 and to_x < rows and to_y >= 0 \
                            and to_y < cols and grid[to_x][to_y] == '1' :
                                grid[to_x][to_y] = '0'
                                queue.append((to_x , to_y))
        return ans 

    
#Approach-4:[BFS] Calling BFS for Unvisited Nodes


# Traversing through matrix considering each cell as a node. If node found is '1', call DFS/BFS to identify nearby land and mark everything as visited. Such that for each DFS/BFS call will cover one island. Now skip the visited cells when encountered in matrix traversal. Count each BFS call to find island.

class Solution:
    def numIslands(self, grid: List[List[str]]) -> int:
        vis=[[0]*len(grid[0]) for _ in range(len(grid))]
        cnt=0
        for i in range(len(grid)):
            for j in range(len(grid[0])):
                if (not vis[i][j]) and grid[i][j]=='1':     #call only unvisited nodes
                    cnt+=1                                  #counter for each call
                    self.bfs(i, j, vis, grid)
        return cnt
    
    def bfs(self, row, col, vis, grid):      #standard bfs traversal
        vis[row][col]=1
        dq=deque([(row,col)]) 
        while dq:
            row,col=dq.popleft()
            for delt in [-1,1]:      #to form four directions (row,col+1) (row,col-1) and (row-1,col) (row+1,col)
                if col+delt>=0 and col+delt<len(grid[0]) and (not vis[row][col+delt]) and grid[row][col+delt]=='1':
                    vis[row][col+delt]=1
                    dq.append((row, col+delt))
                if row+delt>=0 and row+delt<len(grid) and (not vis[row+delt][col]) and grid[row+delt][col]=='1': 
                    vis[row+delt][col]=1
                    dq.append((row+delt, col))
        return


##Approach-5: O(n) DFS Solution

class Solution:
    def numIslands(self, grid):
        """
        :type grid: List[List[str]]
        :rtype: int
        """
        
        islands = 0
        for row in range(len(grid)):
            for col in range(len(grid[0])):
                if grid[row][col] != '0':
                    self.helper(grid, row, col)
                    islands += 1
        return islands
        
        
    def helper(self, grid, row, col):
        if row < 0 or row >= len(grid) or col >= len(grid[0]) or col < 0:
            return
        if grid[row][col] == '0':
            return
        
        grid[row][col] = '0'
        
        [self.helper(grid, row + i[0], col + i[1]) for i in [(0,1), (0,-1), (-1, 0), (1,0)]]
        
        
#Approach-6: Graph Problem (BFS)

class Solution(object):
    def numIslands(self, grid):
        if not grid :
            return 0 ;
        rows ,  cols = len(grid) , len(grid[0]) ;
        visit = set();
        island = 0 ;
        
        def BFS(r , c):
            q = collections.deque()
            visit.add((r , c))
            q.append((r , c))
            while q :
                row , col = q.popleft()
                direction = [[1 , 0] , [-1 , 0] , [0 , 1 ] , [0 , -1]]
                for dr , dc in direction:
                    r , c = row + dr , col + dc
                    if(r in range(rows) 
                       and c in range(cols) 
                       and grid[r][c] == "1"
                       and (r , c) not in visit):
                        q.append((r , c))
                        visit.add((r , c))
        
        for r in range(rows):
            for c in range(cols):
                if grid[r][c] == "1" and (r , c ) not in visit :
                    BFS(r ,c )
                    island += 1
        return island 


#Q2. Rotting Oranges

'''

You are given an m x n grid where each cell can have one of three values:

0 representing an empty cell,
1 representing a fresh orange, or
2 representing a rotten orange.
Every minute, any fresh orange that is 4-directionally adjacent to a rotten orange becomes rotten.

Return the minimum number of minutes that must elapse until no cell has a fresh orange. If this is impossible, return -1.

 

Example 1:


Input: grid = [[2,1,1],[1,1,0],[0,1,1]]
Output: 4
Example 2:

Input: grid = [[2,1,1],[0,1,1],[1,0,1]]
Output: -1
Explanation: The orange in the bottom left corner (row 2, column 0) is never rotten, because rotting only happens 4-directionally.
Example 3:

Input: grid = [[0,2]]
Output: 0
Explanation: Since there are already no fresh oranges at minute 0, the answer is just 0.
 

Constraints:

m == grid.length
n == grid[i].length
1 <= m, n <= 10
grid[i][j] is 0, 1, or 2.       
'''

#Solution:

#Approach-1:  bfs O(NM), O(NM)

class Solution:
    def orangesRotting(self, grid: List[List[int]]) -> int:
        queue = deque()
        for i in range(len(grid)):
            for j in range(len(grid[i])):
                if grid[i][j] == 2:
                    queue.append((i, j))
        
        while queue:
            r, c = queue.popleft()
            for x, y in {(0, 1), (1, 0), (-1, 0), (0, -1)}:
                row, col =  r + x, c + y
                if 0 <= row < len(grid) and 0 <= col < len(grid[row]):
                    if grid[row][col] == 1:
                        grid[row][col] = grid[r][c] + 1
                        queue.append((row, col))
        result = 0
        for i in range(len(grid)):
            for j in range(len(grid[i])):
                if grid[i][j] == 1:
                    return -1
                result = max(result, grid[i][j])
        
        return max(result - 2, 0)


#Approach-2:BFS 


class Solution:
    def orangesRotting(self, grid: List[List[int]]) -> int:
        #get dimensions of the grid
        m = len(grid) 
        n = len(grid[0])
    #Define dimensionss we can traverse
        directions = [(-1, 0), (0, 1), (0, -1), (1, 0)]
        
    #Declare a variable to keep track of fresh oranges
        fresh_oranges = 0
        queue = deque() #Declare a queue
        time = 0
        
        for r in range(m):
            for c in range(n):
                if grid[r][c] == 2:
                    queue.append((r,c)) #Find all the rotten orange positions and push them into the queue
                elif grid[r][c] == 1:
                    fresh_oranges += 1 #Keep a tab of the number of fresh oranges initially
        
        queue.append((-1, -1))
        
    #Defining a function to get the neighbors
        def get_neighbors(row, col):
            for r,c in directions:
                new_row = row + r
                new_col = col + c
                
                if not(0 <= new_row < m and 0 <= new_col < n):
                    continue
                
                yield (new_row, new_col) #Yield returns a value, then loops again, and returns for the next loop
        
        
        while queue:
            row, col = queue.popleft()
            
      #We finish one round of processing
            if row == -1:
                time += 1
                if queue:
                    queue.append((-1, -1))
                    
            else:
                for nrow, ncol in get_neighbors(row, col):
                    if grid[nrow][ncol] == 1:
                        grid[nrow][ncol] = 2
                        fresh_oranges -= 1 #Reducing the number of fresh oranges, it should become 0 at the end to indicate that all the oranges have rotten
                        
                        queue.append((nrow, ncol))
                        
        return time - 1 if fresh_oranges == 0 else -1
    #We return time -1 because we start at time = 0, and at last, we'll also do an iteration and updation of time even after visiting all the nodes.
                
    
#Approach-3:Using BFS

class Solution:
    def orangesRotting(self, grid: List[List[int]]) -> int:
        q = deque()
        time, fresh = 0, 0
        row, col = len(grid), len(grid[0])
        
        for r in range(row):
            for c in range(col):
                if grid[r][c] == 1:
                    fresh += 1 
                if grid[r][c] == 2:
                    q.append([r,c])
        
        directions = [[0,1], [0,-1], [1,0],[-1,0]]
        while q and fresh > 0:
            for i in range(len(q)):
                r, c = q.popleft()
                for dr, dc in directions:
                    row, col = dr+r, dc+c
                    if (row < 0 or row == len(grid) or 
                       col < 0 or col == len(grid[0]) or 
                       grid[row][col] != 1):
                        continue
                    grid[row][col] = 2
                    q.append([row, col])
                    fresh -= 1 
            time += 1 
        return time if fresh == 0 else -1
    
#Approach-4: using list

class Solution:
    def orangesRotting(self, grid: List[List[int]]) -> int:

        if len(grid) == 0:
            return 0
        
        move = [(-1, 0), (1, 0), (0, -1), (0, 1)]
        ROTTEN = 2
        FRESH = 1
        EMPTY = 0
        
        temp = []
        box = []
        
        minute = 0
        height = len(grid)
        width = len(grid[0])
    
        # check rotten oranges
        for x in range(height):
            for y in range(width):
                if grid[x][y] == ROTTEN:
                    box.append((x, y))

        while len(box) != 0:
            temp = box
            box = []
            while len(temp) != 0:
                x, y = temp.pop()
                for (dx, dy) in move:
                    mx, my = x + dx, y + dy
                    if mx >= 0 and mx < height and my >= 0 and my < width and grid[mx][my] == FRESH:
                        grid[mx][my] = ROTTEN
                        box.append((mx, my))

            if len(box) != 0:
                minute += 1
        
        for x in range(height):
            for y in range(width):
                if grid[x][y] == FRESH:
                    return -1
        return minute

    
#Approach-5:

class Solution:
    def orangesRotting(self, grid: List[List[int]]) -> int:
        q = collections.deque()
        count = 0                               # count the fresh oranges
        
        # add all rotten-orange cell co-ordinates into queue
        for x in range(len(grid)):
            for j in range(len(grid[0])):
                if grid[x][j] == 2:                 # if rotten orange cell,
                    q.append((x, j, 0))             # - add coordinate with level 0
                elif grid[x][j] == 1:               # if fresh orange cell,
                    count += 1                      # - increment count of fresh oranges

        level = 0                                   # level counter
        dirs = [(0, 1), (1, 0), (0, -1), (-1, 0)]   # 4 directions
        while q:                                    # while queue not empty
            x, y, level = q.popleft()               # take rotten-orange cell from queue
            for dx, dy in dirs:
                i, j = x+dx, y+dy
                if not (0 <= i < len(grid) and      # if out of bounds
                        0 <= j < len(grid[x])):     # - do nothing
                    continue
                
                if grid[i][j] == 1:                 # if fresh orange cell, it will become rotten
                    count -= 1                      # decrement fresh orange count
                    grid[i][j] = 2                  # mark the cell as rotten
                    q.append((i, j, level+1))       # add new rotten cell with current-level+1
        
        # if count become 0, means all fresh oranges become rotten, so return level, else -1 (impossible)
        return level if count == 0 else -1



#Q3. Snakes and Ladders
'''

You are given an n x n integer matrix board where the cells are labeled from 1 to n2 in a Boustrophedon style starting from the bottom left of the board (i.e. board[n - 1][0]) and alternating direction each row.

You start on square 1 of the board. In each move, starting from square curr, do the following:

Choose a destination square next with a label in the range [curr + 1, min(curr + 6, n2)].
This choice simulates the result of a standard 6-sided die roll: i.e., there are always at most 6 destinations, regardless of the size of the board.
If next has a snake or ladder, you must move to the destination of that snake or ladder. Otherwise, you move to next.
The game ends when you reach the square n2.
A board square on row r and column c has a snake or ladder if board[r][c] != -1. The destination of that snake or ladder is board[r][c]. Squares 1 and n2 do not have a snake or ladder.

Note that you only take a snake or ladder at most once per move. If the destination to a snake or ladder is the start of another snake or ladder, you do not follow the subsequent snake or ladder.

For example, suppose the board is [[-1,4],[-1,3]], and on the first move, your destination square is 2. You follow the ladder to square 3, but do not follow the subsequent ladder to 4.
Return the least number of moves required to reach the square n2. If it is not possible to reach the square, return -1.

 

Example 1:


Input: board = [[-1,-1,-1,-1,-1,-1],[-1,-1,-1,-1,-1,-1],[-1,-1,-1,-1,-1,-1],[-1,35,-1,-1,13,-1],[-1,-1,-1,-1,-1,-1],[-1,15,-1,-1,-1,-1]]
Output: 4
Explanation: 
In the beginning, you start at square 1 (at row 5, column 0).
You decide to move to square 2 and must take the ladder to square 15.
You then decide to move to square 17 and must take the snake to square 13.
You then decide to move to square 14 and must take the ladder to square 35.
You then decide to move to square 36, ending the game.
This is the lowest possible number of moves to reach the last square, so return 4.
Example 2:

Input: board = [[-1,-1],[-1,3]]
Output: 1
 

Constraints:

n == board.length == board[i].length
2 <= n <= 20
grid[i][j] is either -1 or in the range [1, n2].
The squares labeled 1 and n2 do not have any ladders or snakes.

'''

#Solution 

#Apprach-1
# BFS Solution - Using board mapping
# bfs
# breadth first search


class Solution:
    def snakesAndLadders(self, board: List[List[int]]) -> int:
        
        # creating a borad map to loop-up the square value
        board_map = {}
        i = 1
        b_rev = board[::-1]
        for d, r in enumerate(b_rev):
      # reverse for even rows - here d is taken as direction 
            if d%2 != 0: r = r[::-1] 
            for s in r:
                board_map[i] = s
                i += 1
        
        # BFS Algorithm
        q = [(1, 0)] # (curr, moves)
        v = set()
        goal = len(board) * len(board) # end square
        
        while q:
            curr, moves = q.pop(0)
            # win situation
            if curr == goal: return moves
            # BFS on next 6 places (rolling a die)
            for i in range(1, 7):
                # skip square outside board
                if curr+i > goal: continue
                # get value from mapping
                next_pos = curr+i if board_map[curr+i] == -1 else board_map[curr+i]
                if next_pos not in v:
                    v.add(next_pos)
                    q.append((next_pos, moves+1))
        
        return -1

#Apprach-2:

class Solution:
    def snakesAndLadders(self, board: List[List[int]]) -> int:
        if not board: return -1
        n = len(board)
        idx_to_moves = {1: 0}
        queue = deque([1])
        while queue:
            curr = queue.popleft()
            for next_idx in range(curr + 1, curr + 7):
                r, c = (next_idx - 1) // n, (next_idx - 1) % n
                if board[~r][c if r % 2 == 0 else ~c]  != -1: 
                    next_idx = board[~r][c if r % 2 == 0 else ~c] 
                if next_idx == n * n:
                    return idx_to_moves[curr] + 1
                if next_idx not in idx_to_moves:
                    idx_to_moves[next_idx] = idx_to_moves[curr] + 1
                    queue.append(next_idx)
        return -1
    

        

#Apprach-3:
# Use 1D array to store the minimum steps for each cell with comments


class Solution(object):
    def snakesAndLadders(self, board):
        """
        :type board: List[List[int]]
        :rtype: int
        """
        n = len(board)
        lst_board = []
    
        # flatten board to a 1D array
        rev = 1
        for row in board[::-1]:
            if rev == -1:
                lst_board+= row[::-1]
            else:
                lst_board+=row
            rev*=-1
        
        # BFS to search for shortest steps to destination
        queue = deque([(1,0)])
        
    # Initial a n*n 1D array for the minimum steps needed to arrive at each cell.
        step_count = [float('inf') for _ in range(n*n)]
        step_count[0]=0 
        
        while queue:
            cur, step = queue.popleft()
            if cur==n*n:
                return step
      
      # roll the dice to decide the next position we are about to move to.
            for i in range(1,7):
                nxt = cur+i
        
        # if the dice roll leads us to a value larger than n*n, we just set nxt to n*n
                if nxt>n*n:
                    nxt = n*n
          
                # Use ladders or snakes
                if lst_board[nxt-1]!=-1:
                    nxt = lst_board[nxt-1]
               
                # If the nxt cell we are about to visit has a larger step count than step+1, which means we found a better path , then we push the (nxt, step+1) to queue and update the step_count accordingly. 
                if step_count[nxt-1]>step+1:
                    queue.append((nxt,step+1))
                    step_count[nxt-1] = step+1
     
        return -1
    
#Apprach-4:
# BFS
class Solution:
    def snakesAndLadders(self, board: List[List[int]]) -> int:
        n=len(board)
        def convert(pos):
            row,col=divmod(pos-1,n)
            if row%2!=0: col=n-1-col
            row=abs(row-n+1)
            return (row,col)
        dct={}
        for i in range(1,n**2+1):
            x,y=convert(i)
            if board[x][y]>-1: dct[i]=board[x][y]
        
        target=n**2
        deque=collections.deque([(1,0)])
        seen=set([1])
        while deque:
            pos,cur=deque.popleft()
            if pos in dct:
                pos=dct[pos]
            if pos==target: return cur
            for i in range(1,7):
                new=min(pos+i,target)
                if new not in seen:
                    seen.add(new)
                    deque.append((new,cur+1))
        return -1

#Apprach-5:Preprocess the board to simplify logic

# First convert the board into a 1-D array. The rest is standard BFS.

import heapq
class Solution:
    def snakesAndLadders(self, board):
        """
        :type board: List[List[int]]
        :rtype: int
        """
        n = len(board)
        b = []
        to_right = True
        for i in range(n-1, -1, -1):
            if to_right:
                b += board[i][:]
                to_right = False
            else:
                b += board[i][:][::-1]
                to_right = True

        
        Q = [[0,0]]    # moves, -(current position) (0-based)
        seen = set()
        max_step = n*n
        while Q:
            step, pos = heapq.heappop(Q)
            pos = -pos
            if pos == n*n-1: return step
            if pos in seen: continue
            if step >= max_step: return -1
            seen.add(pos)
            for j in range(1,7):
                if pos + j >= n*n: break
                if b[pos+j] == -1:
                    heapq.heappush(Q, [step+1, -(pos+j)])
                else:
                    dest = b[pos+j]-1
                    heapq.heappush(Q, [step+1, -dest])
        return -1

#Apprach-6:    

# The most important optimization in this solution is that:
# because optimally, you should always go as far as you can when you don't jump, so instead of adding all possible points (x+1,x+2,x+3,x+4,x+5,x+6) to the queue, only add:
# 1.ones that can jump
# 2.the highest grid that can be reached without jumping

# e.g:
# index : 1 2 3 4 5 6 7
# board : -1 -1 8 -1 -1 -1 3
# for x=1, instead of adding 2, 8, 4, 5, 6, 3 to the queue, only add 8, 6, 7

class Solution:
    def snakesAndLadders(self, board: List[List[int]]) -> int:
        n = len(board)
        # 1. find all jump points:
        jumps = {}
        dists = {}
        dists[1] = 0
        for i in range(n):
            for j in range(n):
                if board[i][j] != -1:
                    jumps[(n-1-i)*n + (j+1 if (n-1-i) % 2 == 0 else n-j)] = board[i][j]
        
        # in example 1, jumps = {14: 35, 17: 13, 2: 15}
        
        
        # 2. breadth first search:
        q = [1]
        for x in q:   # x: a grid in the board
            max_non_skip = x
            for y in range(x+1,x+7):   # loop all possible destination from x
                if y==n*n: return dists[x]+1  #check if reached the end
                if y in jumps:   # this is a jump point
                    if jumps[y] == n*n: return dists[x]+1  #check if it reaches the end
                    if jumps[y] not in dists: 
                        dists[jumps[y]] = dists[x]+1 #save the distance of the endpoint
                        q.append(jumps[y])    #add to queue as next x
                else:
                    max_non_skip = y      # update the highest grid that can be reached without jumping

            if max_non_skip not in dists:
                dists[max_non_skip] = dists[x]+1  #save this point too
                q.append(max_non_skip)
        
        return -1
            

#Q4.  Is Graph Bipartite?

'''

There is an undirected graph with n nodes, where each node is numbered between 0 and n - 1. You are given a 2D array graph, where graph[u] is an array of nodes that node u is adjacent to. More formally, for each v in graph[u], there is an undirected edge between node u and node v. The graph has the following properties:

There are no self-edges (graph[u] does not contain u).
There are no parallel edges (graph[u] does not contain duplicate values).
If v is in graph[u], then u is in graph[v] (the graph is undirected).
The graph may not be connected, meaning there may be two nodes u and v such that there is no path between them.
A graph is bipartite if the nodes can be partitioned into two independent sets A and B such that every edge in the graph connects a node in set A and a node in set B.

Return true if and only if it is bipartite.

 

Example 1:


Input: graph = [[1,2,3],[0,2],[0,1,3],[0,2]]
Output: false
Explanation: There is no way to partition the nodes into two independent sets such that every edge connects a node in one and a node in the other.
Example 2:


Input: graph = [[1,3],[0,2],[1,3],[0,2]]
Output: true
Explanation: We can partition the nodes into two sets: {0, 2} and {1, 3}.
 

Constraints:

graph.length == n
1 <= n <= 100
0 <= graph[u].length < n
0 <= graph[u][i] <= n - 1
graph[u] does not contain u.
All the values of graph[u] are unique.
If graph[u] contains v, then graph[v] contains u.

'''

#Solution 


# Approach-1
# bfs

from collections import deque
class Solution:
    def isBipartite(self, graph: List[List[int]]) -> bool:
        q = deque()
        n = len(graph)
        visited = [-1] * n
        for i in range(n):
            if visited[i] != -1:
                continue
            visited[i] = 1
            q.append(i)
            while q:
                node = q.popleft()
                for nbr in graph[node]:
                    if visited[nbr] != -1 and visited[nbr] == visited[node]:
                        return False
                    if visited[nbr] == -1:
                        visited[nbr] = 1 - visited[node]
                        q.append(nbr)
        return True

# Approach-2
# Python --> Time: O(V + E), Space: O(V)
# Time: O(V + E)
# Space: O(V) for the colors list

class Solution:
    def isBipartite(self, graph: List[List[int]]) -> bool:
        N = len(graph)
        BLACK = 1
        RED = -1
        colors = [0] * N
        
        def bfs(node):
            q = deque([(node, BLACK)])
            while q:
                node, color = q.popleft()
                colors[node] = color
                for neigh in graph[node]:
                    if colors[neigh] != 0 and color == colors[neigh]:
                        return False
                    if colors[neigh] == 0:
                        q.append((neigh, -color))
            return True
        
        for node in range(N):
            if colors[node] == 0 and not bfs(node):
                return False
        return True

    

# Approach-3

# DFS
# We use standard dfs algorithm, but instead of using used array to store visited nodes, we use color array and try to color vertexes. 0 color means that we haven't visit this node yet. 1 or 2 colors in which we colored the nodes. It doesn't matter from which color to start.

# Also the graph can have different connected components so we need to call dfs for each.

# Time complexity: O(V + E), V = n, E - number of edges
# Memory complexity: O(V), V = n
        

class Solution:
    def isBipartite(self, graph: List[List[int]]) -> bool:
        def dfs(i, c):
            if color[i] != 0:
                if color[i] != c:
                    return False
                return True
            color[i] = c
            for v in graph[i]:
                if not dfs(v, 3 - c):
                    return False
            return True
             
        n = len(graph)
        color = [0] * n
        for i in range(n):
            if color[i] == 0:
                if not dfs(i, 1):
                    return False
        return True
    



# Approach- 4: DFS

class Solution:
    def isBipartite(self, graph: List[List[int]]) -> bool:

        n = len(graph)

        visited = [-1]*(n)
        color = [1]*(n)
        parent = [-1]*(n)
        
        def dfs(node):
            visited[node] = 1
            
            if parent[node] == -1:
                color[node] = 0
            else:
                color[node] = 1- color[parent[node]]

            for neighbor in graph[node]:
                if visited[neighbor] == -1:
                    parent[neighbor] = node
                    
                    if dfs(neighbor) == False:
                        return False
                else:
                    if color[node] == color[neighbor]:
                        return False
            return True
        
        for v in range(n):
            if visited[v] == -1:
                if not dfs(v):
                    return False
                
        return True
    
    
# Approach-5:BFS

class Solution:
    def isBipartite(self, graph: List[List[int]]) -> bool:
        
        
        visited= [-1]*len(graph)
        parent = {}
        distance = [-1] *(len(graph))
        
        def bfs(node):
            
            visited[node] = 1
            distance[node] = 0
            
            q = collections.deque()
            q.append(node)
            
            while q:
                new_node = q.popleft()
                
                for nbr in graph[new_node]:
                    if visited[nbr] == -1:
                        visited[nbr] = 1
                        parent[nbr] = new_node
                        distance[nbr] = distance[new_node]+1 
                        q.append(nbr)
                    else:
                        if parent[new_node] != nbr and  distance[nbr] == distance[new_node]:
                            return False
            return True
        
        for i in range(len(graph)):
            if visited[i] == -1:
                if bfs(i) is False: 
                    return False
        return True
            

#Q5 Minimum Jumps to Reach Home

'''
A certain bug's home is on the x-axis at position x. Help them get there from position 0.

The bug jumps according to the following rules:

It can jump exactly a positions forward (to the right).
It can jump exactly b positions backward (to the left).
It cannot jump backward twice in a row.
It cannot jump to any forbidden positions.
The bug may jump forward beyond its home, but it cannot jump to positions numbered with negative integers.

Given an array of integers forbidden, where forbidden[i] means that the bug cannot jump to the position forbidden[i], and integers a, b, and x, return the minimum number of jumps needed for the bug to reach its home. If there is no possible sequence of jumps that lands the bug on position x, return -1.

 

Example 1:

Input: forbidden = [14,4,18,1,15], a = 3, b = 15, x = 9
Output: 3
Explanation: 3 jumps forward (0 -> 3 -> 6 -> 9) will get the bug home.
Example 2:

Input: forbidden = [8,3,16,6,12,20], a = 15, b = 13, x = 11
Output: -1
Example 3:

Input: forbidden = [1,6,2,14,5,17,4], a = 16, b = 9, x = 7
Output: 2
Explanation: One jump forward (0 -> 16) then one jump backward (16 -> 7) will get the bug home.
 

Constraints:

1 <= forbidden.length <= 1000
1 <= a, b, forbidden[i] <= 2000
0 <= x <= 2000
All the elements in forbidden are distinct.
Position x is not forbidden.

'''

#Solution


#Approach-1


# BFS 
class Solution:
    def minimumJumps(self, forbidden: List[int], a: int, b: int, x: int) -> int:

        l =  a + b + x + max(forbidden)
        queue = deque([(0, 0)])
        step = 0
        memory = {}
        while queue:
            lens = len(queue)
            i = 0 
            while i < lens:
                node, direction = queue.pop()
                if node >= l or (node in forbidden) or (node < 0) or memory.get((node, direction)):
                    i += 1
                    continue
                if node == x:
                    return step
                memory[(node, direction)] = True
                if direction == -1:
                    queue.appendleft((a + node, 1))
                else:
                    queue.appendleft((a + node, 1))
                    queue.appendleft((node - b, -1))
                i += 1
            step += 1
        return -1
    
    
#Approach-2
# BFS and My Interpretation of How to Find The Upper Bound


class Solution1:
    def minimumJumps(self, forbidden: List[int], a: int, b: int, x: int) -> int:
        """Very difficult one. I had the intuition correct, that by using BFS,
        we can always find the solution when x is reachable. The difficulty is
        when x is not reachable. Since we can always add a, there is no end
        to BFS. Thus, the key to the problem is to find the upper bound for
        BFS. If no solution is found within the upper bound, we can say x is
        not reachable.

        To determine the upper bound, we have to use the Bezout's Identity,
        which stipulates that given any integers u and v, a * v + b * v = n *
        gcd(a, b). In addition, we need some ingenuity, which is detailed in
        this post: https://leetcode.com/problems/minimum-jumps-to-reach-home/discuss/978357/C%2B%2B-bidirectional-BFS-solution-with-proof-for-search-upper-bound

        I am going to describe here my understanding of finding the upper bound.

        We know that if a >= b, we basically cannot go left. Thus, the upper
        bound is x itself. This means if we go beyond x, there is no way we
        can go back. So whenever we go beyond x, we know x is not reachable.

        If a < b, we can go right and left. Now we can definitely go beyond x.
        Furthermore, to verify all possibilities, we have to go beyond
        max(forbidden), because the forbidden values add another layer of
        complexity. We must go beyond that to hit all possibilities associated
        with the forbidden value. Thus, the upper bound must be beyond max(x,
        max(forbidden)).

        Given Bezout's Identity, let p = n * gcd(a, b) that is the smallest
        value bigger than max(x, max(forbidden)). p is the left most point that
        we can reach beyond max(x, max(forbidden)). Notice that there is no
        more forbidden value to the right of p. Therefore, we don't have to
        worry about the added complexity of forbidden values now.

        Let's say we are at p right now. The first move we can make that will
        land us in the new territory is p + a. Since a is a multiple of
        gcd(a, b), there are other points we can reach between p and p + a,
        such as:

        p + gcd(a, b), p + 2 * gcd(a, b), ..., p - gcd(a, b) + a

        Note that all these positions can only be reached by a left jump.
        Therefore, the upper bound must be p - gcd(a, b) + a + b.

        One might ask, why can't we go beyond p - gcd(a, b) + a + b? We
        certainly can, but going beyond p - gcd(a, b) + a + b won't help us to
        reach x if we don't go left. And if we go left, eventually we will end
        up at one of the positions in [p, p + a] again, and when that happens,
        we have already taken more steps than visiting the positions in
        [p, p + a] for the first time.

        Therefore, the upper bound must be p - gcd(a, b) + a + b.

        Since p = n * gcd(a, b) is the smallest multiple of gcd(a, b) that is
        larger than max(x, max(forbidden)), we have
        p - gcd(a, b) <= max(x, max(forbidden)). Thus, p - gcd(a, b) + a + b <=
        max(x, max(forbidden)) + a + b.

        Therefore, it is perfectly okay for us to set the upper bound to be
        max(x, max(forbidden)) + a + b

        Once we have the upper bound, we can use BFS to find the solution.

        O(max(x, max(forbidden)) + a + b), 264 ms, faster than 31.58%
        """
        upper_bound = max(x, max(forbidden)) + a + b
        forbidden = set(forbidden)
        queue = set([(0, False)])
        steps = 0
        visited = set()
        while queue:
            temp = set()
            for pos, is_pre_left in queue:
                visited.add(pos)
                if pos == x:
                    return steps
                if pos + a <= upper_bound and pos + a not in forbidden and pos + a not in visited:
                    temp.add((pos + a, False))
                if pos - b >= 0 and pos - b not in forbidden and pos - b not in visited and not is_pre_left:
                    temp.add((pos - b, True))
            if temp:
                steps += 1
            queue = temp
        return -1

#Approach-3

# memoization


# The tricky part is to figure out the upper bound to stop the DFS. In the worst case, you could jump beyond home to avoid a forbidden point.

class Solution:
    def minimumJumps(self, forbidden: List[int], a: int, b: int, x: int) -> int:
        forbidden = set(forbidden)
        bound = max(max(forbidden) + a + b, x + b)
        memo = {}

        def dp(pos, backward):
            if pos > bound or pos < 0 or pos in forbidden:
                return float('inf')
            if pos == x:
                return 0
            if (pos, backward) not in memo:
                memo[pos, backward] = 1 + dp(pos + a, False)
                if not backward:
                    memo[pos, backward] = min(memo[pos, backward],
                                              1 + dp(pos - b, True))
            return memo[pos, backward]

        ans = dp(0, True)
        return ans if ans != float('inf') else -1
    
    
#Approach-4

# BFS | Trick is to find the max value to jump
class Solution:
    def minimumJumps(self, forbidden: List[int], a: int, b: int, x: int) -> int:
        """
        let's try to solve this problem using bfs
        """
        que = deque()
        visited = {0}
        que.append((0, 'f', 0))
        forbidden = set(forbidden)
        max_val = max(x, max(forbidden)) + a + b
        while len(que):
            mag, direc, count = que.popleft()
            if mag == x:
                return count
            if mag - b >= 0 and direc != 'b':
                if mag - b not in forbidden and mag - b not in visited:
                    que.append((mag-b, 'b', count+1))
                    visited.add(mag-b)
            if mag + a not in visited and mag + a not in forbidden and mag + a <= max_val: 
                que.append((mag+a, 'f', count+1))
                visited.add(mag+a)
        return -1

#Approach-5

# DFS Readable


# in each move you have 2 decisions:
# 1 - move forward -> we can move forward but there is an upper limit (otherwise stack overflow)
# 2 - move backward -> we can move backward only once (so keep track of the last step)

# then compare the result of both ways and return the minimum.

class Solution:
    def minimumJumps(self, forbidden, a, b, x):
        forbidden = set(forbidden)
        seen = set()
        upper = max(forbidden) + a + b + x

        def dp(pos, is_back=False):
            if pos > upper or pos < 0: return math.inf
            if pos == x: return 0
            if pos in forbidden: return math.inf
            if (pos, is_back) in seen: return math.inf
            seen.add((pos, is_back))
            forward_move = dp(pos + a, is_back=False)
            backward_move = dp(pos - b, is_back=True) if not is_back else math.inf
            sol = min(forward_move, backward_move)
            return 1 + sol

        res = dp(0)
        return res if res != math.inf else -1



#Q6. Word Ladder
'''
A transformation sequence from word beginWord to word endWord using a dictionary wordList is a sequence of words beginWord -> s1 -> s2 -> ... -> sk such that:

Every adjacent pair of words differs by a single letter.
Every si for 1 <= i <= k is in wordList. Note that beginWord does not need to be in wordList.
sk == endWord
Given two words, beginWord and endWord, and a dictionary wordList, return the number of words in the shortest transformation sequence from beginWord to endWord, or 0 if no such sequence exists.

 

Example 1:

Input: beginWord = "hit", endWord = "cog", wordList = ["hot","dot","dog","lot","log","cog"]
Output: 5
Explanation: One shortest transformation sequence is "hit" -> "hot" -> "dot" -> "dog" -> cog", which is 5 words long.
Example 2:

Input: beginWord = "hit", endWord = "cog", wordList = ["hot","dot","dog","lot","log"]
Output: 0
Explanation: The endWord "cog" is not in wordList, therefore there is no valid transformation sequence.
 

Constraints:

1 <= beginWord.length <= 10
endWord.length == beginWord.length
1 <= wordList.length <= 5000
wordList[i].length == beginWord.length
beginWord, endWord, and wordList[i] consist of lowercase English letters.
beginWord != endWord
All the words in wordList are unique.

'''
#Solution

# Approach-1
# shortest path algorithm
# djisktras algo
# graph
# dfs, shortest path algo sols for reference.

class Solution:
    def ladderLength(self, beginWord: str, endWord: str, wordList: List[str]) -> int:
        N = len(wordList)

        def compare(a, b):
            N = len(a)
            c = 0 
            
            for i in range(N):
                if a[i] == b[i]:
                    c += 1
            return c == N-1
        
        g = defaultdict(set)
        
        for w1 in range(N):
            for w2 in range(w1+1, N):
                if compare(wordList[w1], wordList[w2]):
                    g[wordList[w1]].add(wordList[w2])
                    g[wordList[w2]].add(wordList[w1])
        
        visited = defaultdict(int)
        ans = float('inf')
        @lru_cache(None)
        def dfs(node, cnt):
            nonlocal ans
            
            if ans and cnt > ans:
                return
            
            if node == endWord:
                ans = min(ans, cnt+1)                    
                return 

            visited[node] = 1
                        
            for nei in g[node]:
                if visited[nei] == 0:
                    dfs(nei, cnt+1)
            
            visited[node] = 0
            
        for w in wordList:
            if compare(w, beginWord):
                dfs(w, 1)
                
        return ans if ans != float('inf') else 0
    
    
# Approach-2
# shortest path algorithm
# djisktras algo
# graph
# Shortest path (distances from endWord to others word via graph and then beginWord to neighbors ) [TLE]

class Solution:
    def ladderLength(self, beginWord: str, endWord: str, wordList: List[str]) -> int:
        N = len(wordList)
        g = defaultdict(list)
                
        def compare(a, b):
            return len([a for a,b in zip(a, b) if a!=b]) 
        
        for w1 in range(N):
            for w2 in range(w1+1, N):
                if compare(wordList[w1], wordList[w2]) == 1:
                    g[w1].append(w2)
                    g[w2].append(w1)
                                    
        visited = defaultdict(int)
        ans = float('inf')
        dists = [float('inf')]*N
        
        try:
            endWordIndex = wordList.index(endWord)
        except:
            return 0
        
        dists[endWordIndex] = 1
        st = [(1, endWordIndex)] 
        
        while st:
            dist, node = heapq.heappop(st)
            visited[node] = 1

            for nei in g[node]:
                if visited[nei] == 0 and dists[nei] > dist + 1:
                    dists[nei] = dist + 1
                    st.append((dists[nei], nei))
        
        for i in range(N):
            diff = compare(wordList[i], beginWord)
            
            if diff == 0:
                return dists[i]
            
            if diff == 1:
                ans = min(ans, dists[i] + 1)
                
        return ans if ans != float('inf') else 0

# Approach-3
# shortest path algorithm
# djisktras algo
# graph
# Optimizing the graph preprocessing + shortest path, accepted solution. ( after a hint from forum )

class Solution:
    def ladderLength(self, beginWord: str, endWord: str, wordList: List[str]) -> int:
        N = len(wordList)
        g = defaultdict(list)
        
        for w1 in range(N):
            for i in range(len(wordList[0])):
                g[wordList[w1][:i] + "*" + wordList[w1][i+1:]].append(w1)
                                  
        visited = defaultdict(int)
        ans = float('inf')
        dists = [float('inf')]*N
        
        try:
            endWordIndex = wordList.index(endWord)
        except:
            return 0
        
        dists[endWordIndex] = 1
        st = [(1, endWordIndex)] 
        
        while st:
            dist, node = heapq.heappop(st)
            visited[node] = 1
            for i in range(len(wordList[0])):
                for nei in g[wordList[node][:i] + "*" + wordList[node][i+1:]]:
                    if visited[nei] == 0 and dists[nei] > dist + 1:
                        dists[nei] = dist + 1
                        st.append((dists[nei], nei))
        
        for i in range(len(wordList[0])):
            for n in g[beginWord[:i] + "*" + beginWord[i+1:]]:
                ans = min(dists[n] + 1, ans)
        
        return ans if ans != float('inf') else 0

    
# Approach-4

from collections import defaultdict
class Solution:
    def ladderLength(self, beginWord: str, endWord: str, wordList: List[str]) -> int:
        
        # p=set("log")-set("cog")
        # print(len(p))
        
        g=defaultdict(list)
        wordList.append(beginWord)
        words=list(map(list, wordList))
        # print(words)
        # print(wordList)
        for i in range(len(words)):
            for j in range(len(words[i])):
                pt=words[i].copy()
                pt[j]="*"
                # print(pt)
                pt="".join(pt)
                d="".join(words[i])
                # print(d)
                g[pt].append(d)
        
        # print(g)
        
        
        
#         for i in wordList:
#             for j in wordList:
#                 if i!=j:
#                     cnt=0
#                     for u,t in zip(i,j):
#                         if u!=t:
#                             cnt+=1
#                     if cnt==1:
                        
                    
#                         g[i].add(j)
#                         g[j].add(i)
                    
#         # print(g)
        
#         for i in wordList:
#             if i!=beginWord:
                
#                 cnt=0
#                 for u,t in zip(i,beginWord):
#                     if u!=t:
#                         cnt+=1
#                 if cnt==1:
#                     g[i].add(beginWord)
#                     g[beginWord].add(i)
                
#         # print(g)
        
        q=[]
        visit=set()
        # for i in range(len(beginWord)):
        #     p=list(beginWord).copy()
        #     p[i]="*"
        #     p="".join(p)
        #     q.append(p)
        #     visit.add(p)
            
            
        q.append(beginWord)
        visit.add(beginWord)
        # print(q)
        
        
        ns=0
        while(q):
            ns+=1
            for i in range(len(q)):
                cr=q.pop(0)
                if cr==endWord:
                    return ns
                
                for i in range(len(cr)):
                    pattern=cr[:i]+"*"+cr[i+1:]
                    for j in g[pattern]:
                        if j not in visit:
                            visit.add(j)
                            q.append(j)
                            
                # for i in g[cr]:
                    # if i not in visit:
                        # visit.add(i) 
                    # q.append(i)
                        
        # print(ns)    
        return 0
                
# Approach-5
# BFS | Queue
# Time : O(26NL^2)
# Space : O(N)

class Solution:
    def ladderLength(self, beginWord: str, endWord: str, wordList: List[str]) -> int:
        st = set(wordList)
        queue = [[beginWord, 1]]
        
        while queue:
            word, length = queue.pop(0)
            if word == endWord:
                return length
            for i in range(len(word)):
                for letter in "abcdefghijklmnopqrstuvwxyz":
                    if word[:i] + letter + word[i+1:] in st:
                        temp = word[:i] + letter + word[i+1:]
                        st.remove(temp)
                        queue.append([temp, length+1])
        return 0


#Q7. Word Ladder II

'''

A transformation sequence from word beginWord to word endWord using a dictionary wordList is a sequence of words beginWord -> s1 -> s2 -> ... -> sk such that:

Every adjacent pair of words differs by a single letter.
Every si for 1 <= i <= k is in wordList. Note that beginWord does not need to be in wordList.
sk == endWord
Given two words, beginWord and endWord, and a dictionary wordList, return all the shortest transformation sequences from beginWord to endWord, or an empty list if no such sequence exists. Each sequence should be returned as a list of the words [beginWord, s1, s2, ..., sk].

 

Example 1:

Input: beginWord = "hit", endWord = "cog", wordList = ["hot","dot","dog","lot","log","cog"]
Output: [["hit","hot","dot","dog","cog"],["hit","hot","lot","log","cog"]]
Explanation: There are 2 shortest transformation sequences:
"hit" -> "hot" -> "dot" -> "dog" -> "cog"
"hit" -> "hot" -> "lot" -> "log" -> "cog"
Example 2:

Input: beginWord = "hit", endWord = "cog", wordList = ["hot","dot","dog","lot","log"]
Output: []
Explanation: The endWord "cog" is not in wordList, therefore there is no valid transformation sequence.
 

Constraints:

1 <= beginWord.length <= 5
endWord.length == beginWord.length
1 <= wordList.length <= 500
wordList[i].length == beginWord.length
beginWord, endWord, and wordList[i] consist of lowercase English letters.
beginWord != endWord
All the words in wordList are unique.
The sum of all shortest transformation sequences does not exceed 105. 

'''

#Solution

# Approach-1
# BFS + DFS + SET


class Solution:
    def findLadders(self, beginWord: str, endWord: str, wordList: List[str]) -> List[List[str]]:
    # Sections:
        # (1). error and corner cases handling
        # (2). connection construction
        # (3). BFS: find the "shortest connections" between end and begin
        # (4). DFS: construction paths for answer
        
        # ***The game changer is "Using set as BFS stack". Explain in BFS section.

        # - (1). error and corner case handling
        if beginWord == endWord: # error
            print("input violation beginWord == endWord")
            return -1
        if endWord not in wordList: # return if it's impossible to reach endWord
            return [] 
            
        # - global variable
        n = len(beginWord)
        
        # - (2). esatblish the connections
        con = defaultdict(list) 
        if beginWord not in wordList: # deal with the case beginWord not int wordList
            for i in range(n):
                con[beginWord[:i]+"*"+beginWord[i+1:]].append(beginWord)
        for w in wordList:
            for i in range(n):
                con[w[:i]+"*"+w[i+1:]].append(w)
        
        
        # - (3). BFS: searhcing from endWord to beginWord
        curStack = set([endWord]) # use set as BFS stack
        # Reason:
        # - we can't add node into visited_set immediately because it'll block possible answers
        # - however we still have to reduce the duplication(by using SET) or you'll get TLE(if you use deque)
        visited = set(endWord)
        reverse = defaultdict(list) ## For answer construction
        # Note: 
        # - Recording paths in BFS is costly. Require a memory allocation for each access.
        beginNotFound = True  
        while curStack and beginNotFound:
            NextStack = set()
            for w in curStack:
                if w == beginWord: # leave BFS if we found beginWord.
                    beginNotFound = False
                    break
                for i in range(n):
                    for nw in con[w[:i]+"*"+w[i+1:]]:
                        if nw not in visited:
                            NextStack.add(nw)
                            reverse[nw].append(w)
            visited.update(NextStack) # add nodes into visited
            curStack = NextStack
       
        # - (4). DFS: answer construction
        # use tuple and set to prevent duplication.
        # (However, it might have no duplication at all.)
        ans = set()
        def DFS(w,path):
            for nw in reverse[w]:
                path.append(nw)
                if nw != endWord:
                    DFS(nw,path)
                else:
                    ans.add(tuple(path))
                path.pop()
        DFS(beginWord,[beginWord])
        
        return list(ans)
    
# Approach-2

# BFS and Backtracking

class Solution:
    def findLadders(self, beginWord: str, endWord: str, wordList: List[str]) -> List[List[str]]:
        @lru_cache(None)
        def dfs(word: str) -> List[List[str]]:
            if word == beginWord:
                return [[beginWord]]
            else:
                ans = []
                for parent in tree[word]:
                    for path in dfs(parent):
                        ans.append([word] + path)
                return ans
        
        d = set(wordList)
        d.discard(beginWord)
        if endWord not in d:
            return []
        q, q1 = set(), set()
        tree = defaultdict(list)
        q.add(beginWord)
        found = False
        while q:
            seen_on_level = set()
            while q: 
                word = q.pop()
                for i in range(len(word)):
                    for j in 'abcdefghijklmnopqrstuvwxyz':
                        new_word = ''.join((word[:i], j, word[i + 1:]))
                        if new_word in d:
                            if new_word != endWord:
                                q1.add(new_word)
                            else:
                                found = True
                            tree[new_word].append(word)
                            seen_on_level.add(new_word)
            d -= seen_on_level
            q, q1 = q1, q
            
            if found:
                ans = dfs(endWord)
                return [path[::-1] for path in ans]
            
            
# Approach-3

# Easy-to-Understand Solution

class Solution:
  def findLadders(self, beginWord: str, endWord: str, wordList: List[str]) -> List[List[str]]:
    d = defaultdict(list)
    for word in wordList:
      for i in range(len(word)):
        d[word[:i]+"*"+word[i+1:]].append(word)

    if endWord not in wordList:
      return []

    visited1 = defaultdict(list)
    q1 = deque([beginWord])
    visited1[beginWord] = []

    visited2 = defaultdict(list)
    q2 = deque([endWord])
    visited2[endWord] = []

    ans = []
    def dfs(v, visited, path, paths):
      path.append(v)
      if not visited[v]:
        if visited is visited1:
          paths.append(path[::-1])
        else:
          paths.append(path[:])
      for u in visited[v]:
        dfs(u, visited, path, paths)
      path.pop()

    def bfs(q, visited1, visited2, frombegin):
      level_visited = defaultdict(list)
      for _ in range(len(q)):
        u = q.popleft()

        for i in range(len(u)):
          for v in d[u[:i]+"*"+u[i+1:]]:
            if v in visited2:
              paths1 = []
              paths2 = []
              dfs(u, visited1, [], paths1)
              dfs(v, visited2, [], paths2)
              if not frombegin:
                paths1, paths2 = paths2, paths1
              for a in paths1:
                for b in paths2:
                  ans.append(a+b)
            elif v not in visited1:
              if v not in level_visited:
                q.append(v)
              level_visited[v].append(u)
      visited1.update(level_visited)

    while q1 and q2 and not ans:
      if len(q1) <= len(q2):
        bfs(q1, visited1, visited2, True)
      else:
        bfs(q2, visited2, visited1, False)

    return ans
    


# Approach-4:  BFS + DFS With Explanation Why Optimization Is Needed to Not TLE

'''
Most approaches start off with an adjacency list with a pattern node for quick lookups.

Then we perform BFS until we reach an endWord. Since the question requires us to return all possible paths, it is very tempting to start constructing the path during our BFS
a. However, this will always give us TLE. Algorithmically, this feels wrong since we need to explore and hit all the nodes at least once to form our path (i.e. O(n)).
b. But looking at it more closely, we are creating/destroying paths at every node of a BFS traversal. Space and compute are not free.

What if we can defer our path creation to later? That's good, but not enough because we would have to start our traversal from beginWord all over again.

What about the paths we traversed via BFS? Most of them led to dead-ends. If only we don't have to traverse down these paths. This is the crux of the optimization. We can do this by traversing in reverse from endWord to beginWord instead!

When we perform BFS (step 2), we construct a tree where the key is a child node and values are parent nodes. When endWord is found, the wordTree will contain a way to traverse from endWord to beginWord.

Then we perform DFS on the wordTree and return our results.

p.s. this was HARD to figure out...rip if anyone ever needs to make this optimization in an interview.

Solution
'''

class Solution:

    WILDCARD = "."
    
    def findLadders(self, beginWord: str, endWord: str, wordList: List[str]) -> List[List[str]]:
        """
        Given a wordlist, we perform BFS traversal to generate a word tree where
        every node points to its parent node.
        
        Then we perform a DFS traversal on this tree starting at the endWord.
        """
        if endWord not in wordList:
            # end word is unreachable
            return []
        
        # first generate a word tree from the wordlist
        word_tree = self.getWordTree(beginWord, endWord, wordList)
        
        # then generate a word ladder from the word tree
        return self.getLadders(beginWord, endWord, word_tree)
    
    
    def getWordTree(self,
                    beginWord: str,
                    endWord: str,
                    wordList: List[str]) -> Dict[str, List[str]]:
        """
        BFS traversal from begin word until end word is encountered.
        
        This functions constructs a tree in reverse, starting at the endWord.
        """
        # Build an adjacency list using patterns as keys
        # For example: ".it" -> ("hit"), "h.t" -> ("hit"), "hi." -> ("hit")
        adjacency_list = defaultdict(list)
        for word in wordList:
            for i in range(len(word)):
                pattern = word[:i] + Solution.WILDCARD + word[i+1:]
                adjacency_list[pattern].append(word)
        
        # Holds the tree of words in reverse order
        # The key is an encountered word.
        # The value is a list of preceding words.
        # For example, we got to beginWord from no other nodes.
        # {a: [b,c]} means we got to "a" from "b" and "c"
        visited_tree = {beginWord: []}
        
        # start off the traversal without finding the word
        found = False
        
        q = deque([beginWord])
        while q and not found:
            n = len(q)
            
            # keep track of words visited at this level of BFS
            visited_this_level = {}

            for i in range(n):
                word = q.popleft()
                
                for i in range(len(word)):
                    # for each pattern of the current word
                    pattern = word[:i] + Solution.WILDCARD + word[i+1:]

                    for next_word in adjacency_list[pattern]:
                        if next_word == endWord:
                            # we don't return immediately because other
                            # sequences might reach the endWord in the same
                            # BFS level
                            found = True
                        if next_word not in visited_tree:
                            if next_word not in visited_this_level:
                                visited_this_level[next_word] = [word]
                                # queue up next word iff we haven't visited it yet
                                # or already are planning to visit it
                                q.append(next_word)
                            else:
                                visited_this_level[next_word].append(word)
            
            # add all seen words at this level to the global visited tree
            visited_tree.update(visited_this_level)
            
        return visited_tree
    
    
    def getLadders(self,
                   beginWord: str,
                   endWord: str,
                   wordTree: Dict[str, List[str]]) -> List[List[str]]:
        """
        DFS traversal from endWord to beginWord in a given tree.
        """
        def dfs(node: str) -> List[List[str]]:
            if node == beginWord:
                return [[beginWord]]
            if node not in wordTree:
                return []

            res = []
            parents = wordTree[node]
            for parent in parents:
                res += dfs(parent)
            for r in res:
                r.append(node)
            return res

        return dfs(endWord)
    
    
    
# Approach-5: single BFS level order traversal

class Solution(object):
    def findLadders(self, beginWord, endWord, wordList):
        words = set(wordList)
        if endWord not in words:
            return []
        q = collections.defaultdict() #map last word to path
        q[beginWord] = [[beginWord]]
        res = []
        found = False
        
        while q:
            nq = collections.defaultdict(list)
            rem = set()
            for word in q:
                for i in range(len(word)):
                    for char in string.ascii_lowercase:
                        changed = word[:i] + char + word[i+1:]
                        if changed == endWord:
                            found = True
                            res.extend([path + [changed] for path in q[word]])
                        else:
                            if char == word[i]:continue
                            if changed in words:
                                nq[changed] += [j + [changed] for j in q[word]]
                                rem.add(changed)
            if found:
                return res
            q = nq
            words -= rem
        return []

    

# Approach-6:BFS Approach 

class Solution:
    def findLadders(self, startword: str, endword: str, lst: List[str]) -> List[List[str]]:
        result = []
        path = []

        def DFS(startword, endword, adj):
            path.append(startword)
            if startword == endword:
                result.append(copy.deepcopy(path))
                path.pop()
                return

            for neighbour in adj[startword]:
                DFS(neighbour, endword, adj)
            path.pop()

        adj = defaultdict(list)
        st = set(lst)
        visited = {}
        q = deque()
        q.append(startword)
        visited[startword] = 0

        while q:
            node = q.popleft()
            tmp = copy.deepcopy(node)
            for i in range(len(tmp)):
                for c in range(97, 123):
                    if tmp[i] == chr(c):
                        continue
                    tmp = list(tmp)
                    tmp[i] = chr(c)
                    tmp = "".join(tmp)
                    if tmp in st:
                        if tmp not in visited:
                            visited[tmp] = 1 + visited[node]
                            q.append(tmp)
                            adj[node].append(tmp)
                        elif visited[tmp] == visited[node] + 1:
                            adj[node].append(tmp)
                tmp = list(tmp)
                tmp[i] = node[i]
        # path = []
        DFS(startword, endword, adj)
        return result


    
#Q8. Cut Off Trees for Golf Event

'''

You are asked to cut off all the trees in a forest for a golf event. The forest is represented as an m x n matrix. In this matrix:

0 means the cell cannot be walked through.
1 represents an empty cell that can be walked through.
A number greater than 1 represents a tree in a cell that can be walked through, and this number is the tree's height.
In one step, you can walk in any of the four directions: north, east, south, and west. If you are standing in a cell with a tree, you can choose whether to cut it off.

You must cut off the trees in order from shortest to tallest. When you cut off a tree, the value at its cell becomes 1 (an empty cell).

Starting from the point (0, 0), return the minimum steps you need to walk to cut off all the trees. If you cannot cut off all the trees, return -1.

Note: The input is generated such that no two trees have the same height, and there is at least one tree needs to be cut off.

 

Example 1:


Input: forest = [[1,2,3],[0,0,4],[7,6,5]]
Output: 6
Explanation: Following the path above allows you to cut off the trees from shortest to tallest in 6 steps.
Example 2:


Input: forest = [[1,2,3],[0,0,0],[7,6,5]]
Output: -1
Explanation: The trees in the bottom row cannot be accessed as the middle row is blocked.
Example 3:

Input: forest = [[2,3,4],[0,0,5],[8,7,6]]
Output: 6
Explanation: You can follow the same path as Example 1 to cut off all the trees.
Note that you can cut off the first tree at (0, 0) before making any steps.
 

Constraints:

m == forest.length
n == forest[i].length
1 <= m, n <= 50
0 <= forest[i][j] <= 109
Heights of all trees are distinct. 

'''
#Solution

# Approach-1
# hadlock's algorithm, time complexity O((m*n)^2)


class Solution:
    def cutOffTree(self, forest: List[List[int]]) -> int:
        def dist(forest, sr, sc, tr, tc):
            processed = set()
            deque = collections.deque([(0, sr, sc)])
            while deque:
                detours, r, c = deque.popleft()
                if (r, c) not in processed:
                    processed.add((r, c))
                    if r == tr and c == tc:
                        return abs(sr-tr) + abs(sc-tc) + 2*detours
                    for nr, nc, closer in ((r-1, c, r > tr), (r+1, c, r < tr),
                                   (r, c-1, c > tc), (r, c+1, c < tc)):
                        if 0 <= nr < m and 0 <= nc < n and forest[nr][nc]:
                            if closer:
                                deque.appendleft((detours, nr, nc))
                            else:
                                deque.append((detours+1, nr, nc))
            return -1
        trees = []
        m,n = len(forest),len(forest[0])
        for i in range(m):
            for j in range(n):
                if forest[i][j] > 1:
                    trees.append([forest[i][j],i,j])
        trees = sorted(trees)
                
        sr = sc = ans = 0
        for _, tr, tc in trees:
            d = dist(forest, sr, sc, tr, tc)
            if d < 0: return -1
            ans += d
            sr, sc = tr, tc
        return ans
    
# Approach-2

# (BFS + Graph)


import collections
from functools import reduce
class Solution:
    def cutOffTree(self, forest: List[List[int]]) -> int:
        graph = collections.defaultdict(list)
        m = len(forest)
        n = len(forest[0])
        for i in range(m):
            for j in range(n):
                if forest[i][j] != 0:
                    north = forest[i-1][j] if i-1 >= 0 and forest[i-1][j] != 0 else None
                    east = forest[i][j+1] if j+1 < n and forest[i][j+1] != 0 else None
                    south = forest[i+1][j] if i+1 < m and forest[i+1][j] != 0 else None
                    west = forest[i][j-1] if j-1 >= 0 and forest[i][j-1] != 0 else None
                    graph[forest[i][j]] = list(filter(lambda x: x != None,[north,east,south,west]))
        trees = []
        for i in forest: trees.extend(filter(lambda x: x != 0 and x!= 1, i))
        trees.sort()
        moves = 0
        initial_point = forest[0][0]
        for i in trees:
            tmp_move = self.min_dist(initial_point,i,graph)
            if tmp_move == None:
                return -1
            moves += tmp_move
            initial_point = i
        return moves
    
    def min_dist(self,begin:int,target:int,graph:dict[int,list]) -> int:
        visited = set()
        stack = collections.deque([])
        visited.add(begin)
        distance = {}
        for d in graph.keys() : distance[d] = None
        distance[begin] = 0
        stack.append(begin)
        while len(stack) > 0:
            t = stack.popleft()
            if t == target:
                return distance[t]
            for i in graph[t]:
                if i not in visited:
                    visited.add(i)
                    stack.append(i)
                    distance[i] = distance[t] + 1
                    
                    


# Q9 Reachable Nodes In Subdivided Graph

'''

You are given an undirected graph (the "original graph") with n nodes labeled from 0 to n - 1. You decide to subdivide each edge in the graph into a chain of nodes, with the number of new nodes varying between each edge.

The graph is given as a 2D array of edges where edges[i] = [ui, vi, cnti] indicates that there is an edge between nodes ui and vi in the original graph, and cnti is the total number of new nodes that you will subdivide the edge into. Note that cnti == 0 means you will not subdivide the edge.

To subdivide the edge [ui, vi], replace it with (cnti + 1) new edges and cnti new nodes. The new nodes are x1, x2, ..., xcnti, and the new edges are [ui, x1], [x1, x2], [x2, x3], ..., [xcnti-1, xcnti], [xcnti, vi].

In this new graph, you want to know how many nodes are reachable from the node 0, where a node is reachable if the distance is maxMoves or less.

Given the original graph and maxMoves, return the number of nodes that are reachable from node 0 in the new graph.

 

Example 1:


Input: edges = [[0,1,10],[0,2,1],[1,2,2]], maxMoves = 6, n = 3
Output: 13
Explanation: The edge subdivisions are shown in the image above.
The nodes that are reachable are highlighted in yellow.
Example 2:

Input: edges = [[0,1,4],[1,2,6],[0,2,8],[1,3,1]], maxMoves = 10, n = 4
Output: 23
Example 3:

Input: edges = [[1,2,4],[1,4,5],[1,3,1],[2,3,4],[3,4,5]], maxMoves = 17, n = 5
Output: 1
Explanation: Node 0 is disconnected from the rest of the graph, so only node 0 is reachable.
 

Constraints:

0 <= edges.length <= min(n * (n - 1) / 2, 104)
edges[i].length == 3
0 <= ui < vi < n
There are no multiple edges in the graph.
0 <= cnti <= 104
0 <= maxMoves <= 109
1 <= n <= 3000 

'''

#Solution

# Approach 1: Dijkstra's

# Time Complexity: O(E \log N)O(ElogN), where EE is the length of edges.

# Space Complexity: O(E)O(E).

# Dijktra with Explanation
# min-heap
# shortest path
# dijsktra

class CNT:
    def __init__(self, val):
        self.val = val
class Solution:
    def reachableNodes(self, edges: List[List[int]], maxMoves: int, n: int) -> int:
        #creating the graph
        graph = defaultdict(list)
        for u, v, cnt in edges:
            #sharing the object makes it easier to change the value
            #on both edges at the same time
            cnT = CNT(cnt)
            graph[u].append([v, cnT])
            graph[v].append([u, cnT])
        
        #realise that in order to reach maximum number of nodes u must follow the shortest path
        #i.e, dijkstra algo
        heap = [[0, 0]]
        visited = set()
        reachable = 0
        
        while len(heap):
            c_dist, c_node = heappop(heap)
            
            if c_node in visited: continue
            visited.add(c_node)
                
            #nodes outside the maxMoves distance are useless, because u can never reach them
            if c_dist > maxMoves: continue
            reachable += 1
            
            for i in range(len(graph[c_node])):
                neigh, cnT = graph[c_node][i]
                
                if neigh not in visited:
                    heappush(heap, [c_dist + cnT.val + 1, neigh])
                
                #if you can not cover all nodes in this edge, just cover the difference
                if maxMoves <= cnT.val + c_dist:
                    reachable += (maxMoves - c_dist)
                    cnT.val -= (maxMoves - c_dist) #takeaway the covered distance to prevent overcounting
                #you can cover all nodes in the edge
                else:
                    reachable += cnT.val
                    cnT.val -= cnT.val #takeaway the covered distance to prevent overcounting
        
        return reachable 

    
    
# Approach 2:
# heap
# priority queue
# dijstra 

class Solution:
    def reachableNodes(self, edges: List[List[int]], maxMoves: int, n: int) -> int:
        m = defaultdict(list)
        for a, b, p in edges:
            m[a].append((p, b))
            m[b].append((p, a))
            
        vis = set()
        queue = []
        heappush(queue, (0, 0))
        edgevis = set()
        edgeofl = defaultdict(lambda: 0)
        ans = 0
        while queue:
            # print(queue)
            cost, cur = heappop(queue)
            vis.add(cur)
            for p, nxt in m[cur]:
                if p < maxMoves - cost:
                    if (cur, nxt) not in edgevis and (nxt, cur) not in edgevis:
                        ans += p
                        # if nxt in vis:
                        #     ans -= 1
                        edgevis.add((cur, nxt))
                        edgevis.add((nxt, cur))
                        if nxt not in vis:
                            heappush(queue, (cost + p + 1, nxt))
                else:
                    bal = maxMoves - cost
                    if (cur, nxt) in edgevis:
                        continue
                    if bal <= edgeofl[(cur, nxt)]:
                        continue
                    if bal + edgeofl[(nxt, cur)] < p:
                        ans += bal - edgeofl[(cur, nxt)]
                        edgeofl[(cur, nxt)] = bal
                    else:
                        ans += p - edgeofl[(nxt, cur)] - edgeofl[(cur, nxt)]
                        edgevis.add((cur, nxt))
                        edgevis.add((nxt, cur))
        return ans + len(vis)

# Approach 3:

# Dijkstra Algorith | Simple Solution With Explanation
# heapq
# priorityqueues
# dijkastras algorithm


# Logic:
# 1. To solve this question, we will use the Dijkstras Algorithm to find the shortest path for all the connected nodes from a given node.
# 2. However, we have a constraint of maxMoves that means the maximum distance between the source node and any other node would be maxMoves.
# 3. So initially, let us find the nodes(of original graph) which can be reached from source node within maxMoves.
# 4. While finding the nodes, we store the moves left at the time of visiting the node. (This will help later when we will calculate the subdivided nodes).
# 5. Once we have found all the possible nodes (of original graph), we move to subdivided nodes as, for each edge from u o v having cnt nodes between them,
#     - The total number of subdivided nodes that can be reached between u -> v would be:
#         - minimum((moves left(while visiting u) + moves left(while visiting v)), total number of subdivided nodes between u->v)


import heapq
class Solution:
    def reachableNodes(self, edges: List[List[int]], maxMoves: int, n: int) -> int:
        graph = [[] for _ in range(n)]

        for u, v, cnt in edges:
            graph[u].append([v, cnt])
            graph[v].append([u, cnt])

        visited = [-1 for _ in range(n)]

        heap = [[-maxMoves, 0]]
        heapq.heapify(heap)

        while heap:
            movesLeft, u = heapq.heappop(heap)
            if visited[u] == -1:
                visited[u] = -movesLeft
                for v, cnt in graph[u]:
                    movesRequired = -movesLeft - (cnt + 1)
                    if visited[v] == -1 and movesRequired >= 0:
                        heapq.heappush(heap, [-movesRequired, v])

        nodesReached = 0

        # Nodes Reached of original graph
        for u in visited:
            if u >= 0:
                nodesReached += 1

        # Nodes Reached of subdivided graph except the nodes of original graph
        for u, v, cnt in edges:
            moves = 0
            # Moves left while visiting u
            if visited[u] >= 0:
                moves += visited[u]
            # Moves left while visiting v
            if visited[v] >= 0:
                moves += visited[v]

            nodesReached += min(moves, cnt)

        return nodesReached

    
# Approach 4:
# Heap | Dijkstra | Clean Code
# dijkstra

from collections import defaultdict
from heapq import heappush, heappop

class Solution:
    def reachableNodes(self, edges: List[List[int]], maxMoves: int, n: int) -> int:
        G = defaultdict(lambda: defaultdict(int))
        for v, w, cnt in edges:
            G[v][w] = G[w][v] = cnt
        heap = [(0,0)]
        dist = defaultdict(int)
        visited = set()
        res = 0
        while heap:
            d, v = heappop(heap)
            if v in visited: continue
            visited.add(v)
            res += 1
            dist[v] = d
            for w in G[v]:
                cnt = G[v][w]
                if w not in visited:
                    if d + cnt + 1 > maxMoves:
                        res += maxMoves - d
                    else:
                        res += cnt
                        heappush(heap, (d + cnt + 1,w))
                else:
                    if dist[w] + cnt + 1 > maxMoves:
                        res += min(maxMoves - dist[v], cnt - (maxMoves - dist[w]))
        return res

    
# Approach 5:

# queue + dijstra

class Solution:
    def reachableNodes(self, edges: List[List[int]], M: int, N: int) -> int:
        g = collections.defaultdict(dict)
        for edge in edges:
            u, v, w = edge
            g[u][v] = w
            g[v][u] = w
        
        pq = [(-M, 0)]
        HP = {}
        while pq:
            hp, node = heapq.heappop(pq)
            hp = -hp
            if node in HP:
                continue
            HP[node] = hp
            for child in g[node]:
                if child not in HP and  hp - g[node][child] -1 >= 0:
                    heapq.heappush(pq, (-(hp - g[node][child]-1), child))
                    
        res = len(HP)
        for edge in edges:
            u, v = edge[0], edge[1]
            uv = HP[u] if u in HP else 0
            vu = HP[v] if v in HP else 0
            res += min(edge[2], uv + vu)
        return res
    
