
#LinkedList

#Q1.  Delete Node in a Linked List

'''
There is a singly-linked list head and we want to delete a node node in it.

You are given the node to be deleted node. You will not be given access to the first node of head.

All the values of the linked list are unique, and it is guaranteed that the given node node is not the last node in the linked list.

Delete the given node. Note that by deleting the node, we do not mean removing it from memory. We mean:

The value of the given node should not exist in the linked list.
The number of nodes in the linked list should decrease by one.
All the values before node should be in the same order.
All the values after node should be in the same order.
Custom testing:

For the input, you should provide the entire linked list head and the node to be given node. node should not be the last node of the list and should be an actual node in the list.
We will build the linked list and pass the node to your function.
The output will be the entire list after calling your function.
 

Example 1:


Input: head = [4,5,1,9], node = 5
Output: [4,1,9]
Explanation: You are given the second node with value 5, the linked list should become 4 -> 1 -> 9 after calling your function.
Example 2:


Input: head = [4,5,1,9], node = 1
Output: [4,5,9]
Explanation: You are given the third node with value 1, the linked list should become 4 -> 5 -> 9 after calling your function.
 

Constraints:

The number of the nodes in the given list is in the range [2, 1000].
-1000 <= Node.val <= 1000
The value of each node in the list is unique.
The node to be deleted is in the list and is not a tail node.

'''

#Solution


# # Definition for singly-linked list.
# # class ListNode:
# #     def __init__(self, x):
# #         self.val = x
# #         self.next = None

# class Solution:
#     def deleteNode(self, node):
#         """
#         :type node: ListNode
#         :rtype: void Do not return anything, modify node in-place instead.
#         """
        
#Approach-1:

class Solution:
    def deleteNode(self, node):
        """
        :type node: ListNode
        :rtype: void Do not return anything, modify node in-place instead.
        """
        prev = None
        
        while node.next:
            node.val = node.next.val
            prev = node
            node = node.next
        
        prev.next = None



#Q2. . Middle of the Linked List
'''

Given the head of a singly linked list, return the middle node of the linked list.

If there are two middle nodes, return the second middle node.

 

Example 1:


Input: head = [1,2,3,4,5]
Output: [3,4,5]
Explanation: The middle node of the list is node 3.
Example 2:


Input: head = [1,2,3,4,5,6]
Output: [4,5,6]
Explanation: Since the list has two middle nodes with values 3 and 4, we return the second one.
 

Constraints:

The number of nodes in the list is in the range [1, 100].
1 <= Node.val <= 100

'''
#Solution

# Definition for singly-linked list.
# class ListNode:
#     def __init__(self, val=0, next=None):
#         self.val = val
#         self.next = next

#Approach-1

class Solution:
    def middleNode(self, head: Optional[ListNode]) -> Optional[ListNode]:
        temp=[]
        while (head):
           
            temp.append(head)
        
            head=head.next
            
        if len(temp)%2==0:
            print((len(temp)+1)//2)
            return temp[(len(temp)+1)//2]
        else:
            return temp[(len(temp)//2)]
        

#Approach-2

# linked list
# memory

# two pionters

# Definition for singly-linked list.
# class ListNode:
#     def __init__(self, val=0, next=None):
#         self.val = val
#         self.next = next
class Solution:
    def middleNode(self, head: Optional[ListNode]) -> Optional[ListNode]:
        
        # convert linked list to array and return second middle
        lst = []
        while head != None:
            lst.append(head.val)
            head = head.next
        data = lst[len(lst)//2:]
        
        # put extracted elements in linked list
        Out = ListNode()
        t = Out
        
        for el in data:
            node = ListNode(el)
            t.next = node
            t = t.next
        return Out.next
    
#Approach-3:Using 2 Pointers

class Solution:
    def middleNode(self, head: Optional[ListNode]) -> Optional[ListNode]:
        strt = end = head
        while end and end.next:
            strt = strt.next
            end = end.next.next
        return strt


#Q3.Convert Binary Number in a Linked List to Integer
'''

Given head which is a reference node to a singly-linked list. The value of each node in the linked list is either 0 or 1. The linked list holds the binary representation of a number.

Return the decimal value of the number in the linked list.

The most significant bit is at the head of the linked list.

 

Example 1:


Input: head = [1,0,1]
Output: 5
Explanation: (101) in base 2 = (5) in base 10
Example 2:

Input: head = [0]
Output: 0
 

Constraints:

The Linked List is not empty.
Number of nodes will not exceed 30.
Each node's value is either 0 or 1.
'''

#Solution

#Approach-1  
class Solution:
    def getDecimalValue(self, head: ListNode) -> int:
        ans=0
        while head:
            ans=ans*2+head.val
            head=head.next
        return ans

        
        
#Approach-2        
#Counter Loop

class Solution:
    def getDecimalValue(self, head: ListNode) -> int:
        n = 0
        while head is not None:
            n+=n+head.val
            head=head.next
        return n

    
#Approach-3
# iteration
# linked-list
    
class Solution:
    def getDecimalValue(self, head: ListNode) -> int:
        str_head = ""
        
        while head:
            str_head += str(head.val)
            head = head.next
            
        return int(str_head, 2)



#Q4.  Design HashSet

'''

Design a HashSet without using any built-in hash table libraries.

Implement MyHashSet class:

void add(key) Inserts the value key into the HashSet.
bool contains(key) Returns whether the value key exists in the HashSet or not.
void remove(key) Removes the value key in the HashSet. If key does not exist in the HashSet, do nothing.
 

Example 1:

Input
["MyHashSet", "add", "add", "contains", "contains", "add", "contains", "remove", "contains"]
[[], [1], [2], [1], [3], [2], [2], [2], [2]]
Output
[null, null, null, true, false, null, true, null, false]

Explanation
MyHashSet myHashSet = new MyHashSet();
myHashSet.add(1);      // set = [1]
myHashSet.add(2);      // set = [1, 2]
myHashSet.contains(1); // return True
myHashSet.contains(3); // return False, (not found)
myHashSet.add(2);      // set = [1, 2]
myHashSet.contains(2); // return True
myHashSet.remove(2);   // set = [1]
myHashSet.contains(2); // return False, (already removed)
 

Constraints:

0 <= key <= 106
At most 104 calls will be made to add, remove, and contains.
'''
#Solution

# class MyHashSet:

#     def __init__(self):
        

#     def add(self, key: int) -> None:
        

#     def remove(self, key: int) -> None:
        

#     def contains(self, key: int) -> bool:
        


# # Your MyHashSet object will be instantiated and called as such:
# # obj = MyHashSet()
# # obj.add(key)
# # obj.remove(key)
# # param_3 = obj.contains(key)


# array
# linkedlist
# hash table

# HashTable, Array and LinkedList


# Approach-1: Using Dictionary

class MyHashSet:

    def __init__(self):
        self.d = {}

    def add(self, key: int) -> None:
        self.d[key] = 1

    def remove(self, key: int) -> None:
        self.d[key] = 0

    def contains(self, key: int) -> bool:
        return self.d.get(key,0)!=0
    
    
    
# Approach-2: Using Array+Linked-List

class ListNode:
    def __init__(self, val=0, next=None):
        self.val = val
        self.next = next
    
class MyHashSet:    
    
    def __init__(self):
        self.size = 1000
        self.arr = [None]*self.size

    def find_index(self, key):
        return key % self.size
    
    def find_value(self, key):
        idx = self.find_index(key)
        head = self.arr[idx]
        while head:
            if head.val == key: return 1
            head = head.next
        return 0

    def add(self, key: int) -> None:
        if self.find_value(key): return
        idx = self.find_index(key)
        self.arr[idx] = ListNode(key, self.arr[idx])

    def remove(self, key: int) -> None:
        idx = self.find_index(key)
        node = self.arr[idx]
        if node is None: 
            return 
        if node.val==key:
            self.arr[idx] = node.next
            return 
        first, second = node, node.next
        while second:
            if second.val == key:
                first.next = second.next
                return
            first, second = first.next, second.next

    def contains(self, key: int) -> bool:
        return self.find_value(key)
    
# Approach-3:

class MyHashSet:
    def __init__(self):
        self.hash_set = [[] for _ in range(1000)]
        self.z = lambda key:key%1000
    def add(self, key: int) -> None:
        hash = self.z(key)
        if not self.contains(key):
            self.hash_set[hash].append(key)
        
    def contains(self, key: int) -> bool:
        hash = self.z(key)
        if not self.hash_set[hash]:
            return False
        else:
            if key in self.hash_set[hash]:
                return True
            else:
                return False
            
        
    def remove(self, key: int) -> None:
        hash = self.z(key)
        if self.contains(key):
            self.hash_set[hash].remove(key)

# Approach-4:
#AVL Tree

class TreeNode:
    def __init__(self, key):
        self.key = key
        self.left = None
        self.right = None
        self.height = 1


class AVL_Tree:
    def __init__(self):
        self.root = None
        self.length = 0

    def __insert(self, root, key):
        if not root:
            self.length += 1
            return TreeNode(key)
        elif key < root.key:
            root.left = self.__insert(root.left, key)
        elif key > root.key:
            root.right = self.__insert(root.right, key)
        else:
            return root

        root.height = 1 + max(self.getHeight(root.left),
                              self.getHeight(root.right))

        balance = self.getBalance(root)

        if balance > 1 and key < root.key:
            return self.rightRotate(root)

        if balance < -1 and key > root.key:
            return self.leftRotate(root)

        if balance > 1 and key > root.key:
            root.left = self.leftRotate(root.left)
            return self.rightRotate(root)

        if balance < -1 and key < root.key:
            root.right = self.rightRotate(root.right)
            return self.leftRotate(root)

        return root

    def insert(self, key):
        self.root = self.__insert(self.root, key)

    def getMinValueNode(self, root):
        if root is None or root.left is None:
            return root

        return self.getMinValueNode(root.left)

    def __delete(self, root, key):
        if not root:
            return root

        elif key < root.key:
            root.left = self.__delete(root.left, key)

        elif key > root.key:
            root.right = self.__delete(root.right, key)

        else:
            self.length -= 1
            if root.left is None:
                temp = root.right
                root = None
                return temp

            elif root.right is None:
                temp = root.left
                root = None
                return temp

            temp = self.getMinValueNode(root.right)
            root.key = temp.key
            root.right = self.__delete(root.right,
                                       temp.key)

        if root is None:
            return root

        root.height = 1 + max(self.getHeight(root.left),
                              self.getHeight(root.right))

        balance = self.getBalance(root)

        if balance > 1 and self.getBalance(root.left) >= 0:
            return self.rightRotate(root)

        if balance < -1 and self.getBalance(root.right) <= 0:
            return self.leftRotate(root)

        if balance > 1 and self.getBalance(root.left) < 0:
            root.left = self.leftRotate(root.left)
            return self.rightRotate(root)

        if balance < -1 and self.getBalance(root.right) > 0:
            root.right = self.rightRotate(root.right)
            return self.leftRotate(root)

        return root

    def delete(self, key):
        self.root = self.__delete(self.root, key)

    def leftRotate(self, z):
        y = z.right
        T2 = y.left

        y.left = z
        z.right = T2

        z.height = 1 + max(self.getHeight(z.left),
                           self.getHeight(z.right))
        y.height = 1 + max(self.getHeight(y.left),
                           self.getHeight(y.right))

        return y

    def rightRotate(self, z):
        y = z.left
        T3 = y.right

        y.right = z
        z.left = T3

        z.height = 1 + max(self.getHeight(z.left),
                           self.getHeight(z.right))
        y.height = 1 + max(self.getHeight(y.left),
                           self.getHeight(y.right))
        return y

    def getHeight(self, root):
        if not root:
            return 0
        return root.height

    def getBalance(self, root):
        if not root:
            return 0
        return self.getHeight(root.left) - self.getHeight(root.right)

    def __avl_search(self, root, key):
        if root is None or key is None:
            return False
        elif key < root.key:
            return self.__avl_search(root.left, key)
        elif key > root.key:
            return self.__avl_search(root.right, key)
        else:
            return True

    def search(self, key):
        return self.__avl_search(self.root, key)


class MyHashSet:
    def __init__(self):
        self.buckets = [AVL_Tree() for i in range(2069)]

    def add(self, key: int) -> None:
        self.buckets[key % len(self.buckets)].insert(key)

    def remove(self, key: int) -> None:
        self.buckets[key % len(self.buckets)].delete(key)

    def contains(self, key: int) -> bool:
        return self.buckets[key % len(self.buckets)].search(key)


# Your MyHashSet object will be instantiated and called as such:
# obj = MyHashSet()
# obj.add(key)
# obj.remove(key)
# param_3 = obj.contains(key)




# Approach-5:
class MyHashSet(object):

    def __init__(self):
        """
        Initialize your data structure here.
        """
        self.capacity = 8
        self.size = 0
        self.s = [None]*8
        self.lf = float(2)/3
        
    def myhash(self, key): # can be modified to hash other hashable objects like built in python hash function
        return key%self.capacity
        

    def add(self, key):
        """
        :type key: int
        :rtype: void
        """
        if float(self.size)/self.capacity >= self.lf:
            self.capacity <<= 1
            ns = [None]*self.capacity
            for i in range(self.capacity >> 1):
                if self.s[i] and self.s[i] != "==TOMBSTONE==":
                    n = self.myhash(self.s[i])
                    while ns[n] is not None:
                        n = (5*n+1)%self.capacity
                    ns[n] = self.s[i]
            self.s = ns
        h = self.myhash(key)
        while self.s[h] is not None:
            if self.s[h] == key:
                return
            h = (5*h + 1) % self.capacity
            if self.s[h] == "==TOMBSTONE==":
                break
        self.s[h] = key
        self.size += 1
        
        

    def remove(self, key):
        """
        :type key: int
        :rtype: void
        """
        h = self.myhash(key)
        while self.s[h]:
            if self.s[h] == key:
                self.s[h] = "==TOMBSTONE=="
                self.size -= 1
                return
            h = (5*h+1)%self.capacity
        

    def contains(self, key):
        """
        Returns true if this set contains the specified element
        :type key: int
        :rtype: bool
        """
        h = self.myhash(key)
        while self.s[h] is not None:
            if self.s[h] == key:
                return True
            h = (5*h + 1)%self.capacity
        return False

#Q5 Design HashMap
'''

Design a HashMap without using any built-in hash table libraries.

Implement the MyHashMap class:

MyHashMap() initializes the object with an empty map.
void put(int key, int value) inserts a (key, value) pair into the HashMap. If the key already exists in the map, update the corresponding value.
int get(int key) returns the value to which the specified key is mapped, or -1 if this map contains no mapping for the key.
void remove(key) removes the key and its corresponding value if the map contains the mapping for the key.
 

Example 1:

Input
["MyHashMap", "put", "put", "get", "get", "put", "get", "remove", "get"]
[[], [1, 1], [2, 2], [1], [3], [2, 1], [2], [2], [2]]
Output
[null, null, null, 1, -1, null, 1, null, -1]

Explanation
MyHashMap myHashMap = new MyHashMap();
myHashMap.put(1, 1); // The map is now [[1,1]]
myHashMap.put(2, 2); // The map is now [[1,1], [2,2]]
myHashMap.get(1);    // return 1, The map is now [[1,1], [2,2]]
myHashMap.get(3);    // return -1 (i.e., not found), The map is now [[1,1], [2,2]]
myHashMap.put(2, 1); // The map is now [[1,1], [2,1]] (i.e., update the existing value)
myHashMap.get(2);    // return 1, The map is now [[1,1], [2,1]]
myHashMap.remove(2); // remove the mapping for 2, The map is now [[1,1]]
myHashMap.get(2);    // return -1 (i.e., not found), The map is now [[1,1]]
 

Constraints:

0 <= key, value <= 106
At most 104 calls will be made to put, get, and remove.
'''
#Solution

# Approach-1
# solution using two mapped arrays for keys and values
# hashmap
# easy-understanding

class MyHashMap:
    
    def __init__(self):
        # choose a prime number
        self.size = 211
        # create a bucket as list of lists to be able to store different keys with the same hash value
        self.bucket_keys = [[] for _ in range(self.size)]   
        # create a bucket as list of lists to be able to store values mapped to the keys     
        self.bucket_values = [[] for _ in range(self.size)]        


    # create a simple hash function using modulo operator
    def hash_func(self, key: int):
        return key % self.size        


    def put(self, key: int, value: int) -> None:
        # index will never be greater than the initial size of the bucket because of modulo operation within hash function
        # so we will never get an index error
        index = self.hash_func(key)
        if not key in self.bucket_keys[index]:
            self.bucket_keys[index].append(key)
            self.bucket_values[index].append(value)
        else:
            val_index = self.bucket_keys[index].index(key)     
            self.bucket_values[index][val_index] = value


    def get(self, key: int) -> int:
        index = self.hash_func(key)
        if key in self.bucket_keys[index]:
            val_index = self.bucket_keys[index].index(key)     
            return self.bucket_values[index][val_index]
        return -1


    def remove(self, key: int) -> None:
        index = self.hash_func(key)
        if key in self.bucket_keys[index]:
            val_index = self.bucket_keys[index].index(key)     
            self.bucket_keys[index].remove(key) 
            del self.bucket_values[index][val_index]
            
# Approach-2            
class Bucket:
    def __init__(self):
        self.Bucket=list()

    def get(self, key):
        for item in self.Bucket:
            if item[0]==key:
                return item[1]
        return -1

    def update(self, key, value):
        index=0
        for item in self.Bucket:
            if item[0]==key:
                self.Bucket[index]=(key,value)
                return 
            index+=1
        
        self.Bucket.append((key,value))

    def remove(self, key):
        point2=0
        point1=0
        while point1<len(self.Bucket):
            if self.Bucket[point1][0]!=key:
                self.Bucket[point2]=self.Bucket[point1]
                point2+=1
            point1+=1
        self.Bucket=self.Bucket[0:point2]


class MyHashMap:
    def __init__(self):
        self.key_space=2069
        self.hash_table=[Bucket() for i in range(self.key_space)]

    def put(self, key: int, value: int) -> None:
        indexKey=self._hash(key)
        self.hash_table[indexKey].update(key,value)
        
    def get(self, key: int) -> int:
        indexKey=self._hash(key)
        return self.hash_table[indexKey].get(key)
     
    def remove(self, key: int) -> None:
        indexKey=self._hash(key)
        self.hash_table[indexKey].remove(key)
        
    def _hash(self,key):
        return key%self.key_space 

            
# Approach-3

# Lists and Dictionaries


"""
HashMap utilizing a Python list and Python dictionaries for key/value storage.
Dictionaries are only instantiated when required. Try/except statements are used 
to handle cases where we don't have a dictionary setup yet.
"""

class MyHashMap:

    def __init__(self):
        """
        Initialize your data structure here.
        """
        self.num_elements = 1000
        self.hash_map = [-1] * self.num_elements

    def put(self, key, value):
        """
        value will always be non-negative.
        :type key: int
        :type value: int
        :rtype: void
        """
        index = key % self.num_elements
        
        if self.hash_map[index] == -1:
            self.hash_map[index] = {}
            
        self.hash_map[index][str(key)] = value

    def get(self, key):
        """
        Returns the value to which the specified key is mapped, or -1 if this map contains no mapping for the key
        :type key: int
        :rtype: int
        """
        index = key % self.num_elements
        
        try:
            return self.hash_map[index][str(key)]
        except:
            return -1

    def remove(self, key):
        """
        Removes the mapping of the specified value key if this map contains a mapping for the key
        :type key: int
        :rtype: void
        """
        index = key % self.num_elements
        
        try:
            del self.hash_map[index][str(key)]
        except:
            return


#Q6. Reverse Linked List
'''

Given the head of a singly linked list, reverse the list, and return the reversed list.

 

Example 1:


Input: head = [1,2,3,4,5]
Output: [5,4,3,2,1]
Example 2:


Input: head = [1,2]
Output: [2,1]
Example 3:

Input: head = []
Output: []
 

Constraints:

The number of nodes in the list is the range [0, 5000].
-5000 <= Node.val <= 5000
 

Follow up: A linked list can be reversed either iteratively or recursively. Could you implement both?

'''

#Solution

# # Definition for singly-linked list.
# # class ListNode:
# #     def __init__(self, val=0, next=None):
# #         self.val = val
# #         self.next = next
# class Solution:
#     def reverseList(self, head: Optional[ListNode]) -> Optional[ListNode]:
        

#Approach-1

class Solution:
    def reverseList(self, head: Optional[ListNode]) -> Optional[ListNode]:
        curr= head
        prev= None
        while curr!= None:
            next= curr.next
            curr.next= prev
            prev= curr
            curr= next
        return prev

#Approach-2
# Iterative approach
# we take the help of prev pointer to reverse the connections

# Time and space complexity - O(n) and O(1)

# Code:

class Solution:
    def reverseList(self, head: Optional[ListNode]) -> Optional[ListNode]:
        curr = head
        prev = None
        while curr is not None:
            n = curr.next
            curr.next = prev
            prev = curr
            curr = n
        
        return prev
    

#Approach-3

class Solution:
    def reverseList(self, head: Optional[ListNode]) -> Optional[ListNode]:
        prev = None
        while head:
            head.next, head, prev = prev, head.next, head
        return prev
    
#Approach-4

# iterative
# recursive

class Solution(object):
    def reverse_recursively(self, head, new_head):
        if not head:
            return new_head
        nxt = head.next
        head.next = new_head
        return self.reverse_recursively(nxt, head)
    def reverseList(self, head):
        # recursively
        return self.reverse_recursively(head, None)
    def reverseList(self, head):
        """
        :type head: ListNode
        :rtype: ListNode
        """
        new_head = None
        while head:
            nxt = head.next
            head.next = new_head
            new_head = head
            head = nxt
        return new_head


#Q7.Reverse Nodes in k-Group
'''

Given the head of a linked list, reverse the nodes of the list k at a time, and return the modified list.

k is a positive integer and is less than or equal to the length of the linked list. If the number of nodes is not a multiple of k then left-out nodes, in the end, should remain as it is.

You may not alter the values in the list's nodes, only nodes themselves may be changed.

 

Example 1:


Input: head = [1,2,3,4,5], k = 2
Output: [2,1,4,3,5]
Example 2:


Input: head = [1,2,3,4,5], k = 3
Output: [3,2,1,4,5]
 

Constraints:

The number of nodes in the list is n.
1 <= k <= n <= 5000
0 <= Node.val <= 1000
 

Follow-up: Can you solve the problem in O(1) extra memory space?

'''
#Solution

# Definition for singly-linked list.
# class ListNode:
#     def __init__(self, val=0, next=None):
#         self.val = val
#         self.next = next

#Approach-1

class Solution:
    def reverseKGroup(self, head: Optional[ListNode], k: int) -> Optional[ListNode]:
        n=0
        cur=head
        while cur:
            n+=1
            cur=cur.next
        if k==1 or n==1:
            return head
        ks=n//k
        ct=1
        cur1=head
        dummy=ListNode(-1)
        prev=dummy
        prev.next=cur1
        cur2=head.next 
        firstgpnd=cur1
        while ks>0:
            while cur2 and ct<k:
                nexcur2=cur2.next
                cur2.next=cur1
                cur1=cur2
                cur2=nexcur2
                ct+=1
            ks-=1
            ct=1
            prev.next=cur1
            prev=firstgpnd
            if ks==0 and n%k==0:
                firstgpnd.next=None
            else:
                firstgpnd=cur1=cur2
            
            if cur2:
                cur2=cur2.next   
        if cur1 and n%k:
            prev.next=cur1
        return dummy.next
   

        
#Approach-2

# Definition for singly-linked list.
# class ListNode:
#     def __init__(self, val=0, next=None):
#         self.val = val
#         self.next = next
class Solution:
    def reverseKGroup(self, head: Optional[ListNode], k: int) -> Optional[ListNode]:
        dummy = ListNode(0, head)
        prevGroup = dummy
        while True:
            k_temp = k
            kth_element = self.getNextKthElement(prevGroup, k)
            if not kth_element:
                break
            prev, curr = kth_element.next, prevGroup.next                
            while curr and k_temp > 0:
                temp = curr.next
                curr.next = prev
                prev = curr
                curr = temp
                k_temp -= 1
            tmp = prevGroup.next
            prevGroup.next = kth_element
            prevGroup = tmp
        return dummy.next
            
    def getNextKthElement(self, curr, k):
        while curr and k > 0:
            curr = curr.next
            k -= 1
        return curr


#Q8.Merge Two Sorted Lists
'''

You are given the heads of two sorted linked lists list1 and list2.

Merge the two lists in a one sorted list. The list should be made by splicing together the nodes of the first two lists.

Return the head of the merged linked list.

 

Example 1:


Input: list1 = [1,2,4], list2 = [1,3,4]
Output: [1,1,2,3,4,4]
Example 2:

Input: list1 = [], list2 = []
Output: []
Example 3:

Input: list1 = [], list2 = [0]
Output: [0]
 

Constraints:

The number of nodes in both lists is in the range [0, 50].
-100 <= Node.val <= 100
Both list1 and list2 are sorted in non-decreasing order. 

'''
#Solution

# Definition for singly-linked list.
# class ListNode:
#     def __init__(self, val=0, next=None):
#         self.val = val
#         self.next = next
# class Solution:
#     def mergeTwoLists(self, list1: Optional[ListNode], list2: Optional[ListNode]) -> Optional[ListNode]:
  
#Approach-1

# For simplicity, we create a dummy node to which we attach nodes from lists. We iterate over lists using two-pointers and build up a resulting list so that values are monotonically increased.

# Time: O(n)
# Space: O(1)

class Solution:
    def mergeTwoLists(self, list1: Optional[ListNode], list2: Optional[ListNode]) -> Optional[ListNode]:
        cur = dummy = ListNode()
        while list1 and list2:               
            if list1.val < list2.val:
                cur.next = list1
                list1, cur = list1.next, list1
            else:
                cur.next = list2
                list2, cur = list2.next, list2
                
        if list1 or list2:
            cur.next = list1 if list1 else list2
            
        return dummy.next
    

#Approach-2

# O(1) Space
# iterative
# linkedlist
# pointers-approach

# Definition for singly-linked list.
# class ListNode:
#     def __init__(self, val=0, next=None):
#         self.val = val
#         self.next = next

class Solution:
    def mergeTwoLists(self, list1: Optional[ListNode], list2: Optional[ListNode]) -> Optional[ListNode]:

        if not list1:
            return list2
        if not list2:
            return list1
        

        curr1, curr2 = list1, list2
        if curr1.val < curr2.val:
            head = list1
            curr1 = list1.next
        else:
            head = list2
            curr2 = list2.next
        
        node = head
        while curr1 and curr2:
            if curr1.val < curr2.val:
                node.next, curr1 = curr1, curr1.next
            else:
                node.next, curr2 = curr2, curr2.next
            node = node.next
            
        if curr1:
            node.next = curr1
        if curr2:
            node.next = curr2
            
        return head

#Approach-3
# merge-sorted-list

class Solution:
    def mergeTwoLists(self, l1: Optional[ListNode], l2: Optional[ListNode]) -> Optional[ListNode]:
        dummy = ListNode()
        cur = dummy
        while l1 and l2:
            if l1.val <= l2.val:
                cur.next = l1
                l1 = l1.next
            else:
                cur.next = l2
                l2 = l2.next
            cur = cur.next
        cur.next = l1 or l2
        return dummy.next

    
#Approach-4
# If both lists are non-empty, I first make sure a starts smaller, use its head as result, and merge the remainders behind it. Otherwise, i.e., if one or both are empty, I just return what's there.

class Solution:
    def mergeTwoLists(self, a, b):
        if a and b:
            if a.val > b.val:
                a, b = b, a
            a.next = self.mergeTwoLists(a.next, b)
        return a or b
    
#Approach-5

# First make sure that a is the "better" one (meaning b is None or has larger/equal value). Then merge the remainders behind a.
class Solution:
    def mergeTwoLists(self, a, b):
        if not a or b and a.val > b.val:
            a, b = b, a
        if a:
            a.next = self.mergeTwoLists(a.next, b)
        return a

#Q9. Remove Duplicates from Sorted List
'''

Given the head of a sorted linked list, delete all duplicates such that each element appears only once. Return the linked list sorted as well.

 

Example 1:


Input: head = [1,1,2]
Output: [1,2]
Example 2:


Input: head = [1,1,2,3,3]
Output: [1,2,3]
 

Constraints:

The number of nodes in the list is in the range [0, 300].
-100 <= Node.val <= 100
The list is guaranteed to be sorted in ascending order.

'''
#Solution

 # Definition for singly-linked list.
# class ListNode:
#     def __init__(self, val=0, next=None):
#         self.val = val
#         self.next = next
# class Solution:
#     def deleteDuplicates(self, head: Optional[ListNode]) -> Optional[ListNode]:


#Approach-1

# fast

# linked list

# easy
# Explanation:

# In the first while loop, we continue as long as the current node and the next node exist.

# In the second while loop, we continue to replace the next value, if it is the same as the current value. In a sense, we skip the next value if it is the same.

# When we reach the end of the linked list, and current node or next node is None, we can return the linked list from the beginning (head).



# Definition for singly-linked list.
# class ListNode(object):
#     def __init__(self, val=0, next=None):
#         self.val = val
#         self.next = next
class Solution(object):
    def deleteDuplicates(self, head):
        """
        :type head: ListNode
        :rtype: ListNode
        """
        current = head
        while current != None and current.next != None:
            while current.val == current.next.val:
                    current.next = current.next.next
                    if current.next == None:
                        break
            current = current.next
        return head

#Approach-2

# linked list

# Definition for singly-linked list.
# class ListNode:
#     def __init__(self, val=0, next=None):
#         self.val = val
#         self.next = next

#Solution 1:

class Solution:
    def deleteDuplicates(self, head: Optional[ListNode]) -> Optional[ListNode]:
        l=[]
        n=head
        while n is not None:
            l.append(n.val)
            n=n.next
        k=sorted(set(l))
        
        class LL:
            def __init__(self):
                self.head=None
                
            def add(self, val):
                new_node =ListNode(val)
                if self.head is None:
                    self.head = new_node
                else:
                    n= self.head
                    while n.next is not None:
                        n=n.next
                    n.next=new_node
        
        new_ll= LL()
        for i in k:
            new_ll.add(i)
            
        return new_ll.head
		
#Approach-3		


class Solution:
	def deleteDuplicates(self, head: ListNode) -> ListNode:
		cur=head
		while cur:
			if cur.next and cur.next.val==cur.val:
				cur.next=cur.next.next
			else:
				cur=cur.next
		return head

#Approach-4

# using two pointers

class Solution:
    def deleteDuplicates(self, head: Optional[ListNode]) -> Optional[ListNode]:
        if not head:
            return None
        prev, curr = head, head.next
        while curr:
            if prev.val == curr.val:
                # remove node
                prev.next = curr.next
                # change current pointer
                curr = prev.next  # previous remains the same
            else:
                prev, curr = curr, curr.next
                
        return head
    
    
#Approach-5
#Math
class Solution:
    def deleteDuplicates(self, head):
        cur, res = head, []
        while cur and cur.next:
            if cur.next.val == cur.val:
                cur.next = cur.next.next
            else:
                cur = cur.next
        return head


#Q 10. Linked List Cycle
'''

Given head, the head of a linked list, determine if the linked list has a cycle in it.

There is a cycle in a linked list if there is some node in the list that can be reached again by continuously following the next pointer. Internally, pos is used to denote the index of the node that tail's next pointer is connected to. Note that pos is not passed as a parameter.

Return true if there is a cycle in the linked list. Otherwise, return false.

 

Example 1:


Input: head = [3,2,0,-4], pos = 1
Output: true
Explanation: There is a cycle in the linked list, where the tail connects to the 1st node (0-indexed).
Example 2:


Input: head = [1,2], pos = 0
Output: true
Explanation: There is a cycle in the linked list, where the tail connects to the 0th node.
Example 3:


Input: head = [1], pos = -1
Output: false
Explanation: There is no cycle in the linked list.
 

Constraints:

The number of the nodes in the list is in the range [0, 104].
-105 <= Node.val <= 105
pos is -1 or a valid index in the linked-list.
 

Follow up: Can you solve it using O(1) (i.e. constant) memory?

'''
#Solution:
# Definition for singly-linked list.
# class ListNode:
#     def __init__(self, x):
#         self.val = x
#         self.next = None

# class Solution:
#     def hasCycle(self, head: Optional[ListNode]) -> bool:
        
#Approach-1

# two-pointers
# linked-list    

class Solution:
    def hasCycle(self, head: Optional[ListNode]) -> bool:
        slow= head
        fast= head
        while fast is not None and fast.next is not None:
            fast= fast.next.next
            slow= slow.next
            if slow== fast:
                return True
        return False

    
#Approach-2

# Basic idea is to create two pointer slow and fast slow points at head and fast at head.next run a loop untill either fast or slow or fast.next is not None. check if fast and slow point at same node then cycle if found and return True if the loop breaks then no cycle is found return false. Increment the slow pointer by 1 steps and fast pointer by 2 steps.

class Solution:
    def hasCycle(self, head: Optional[ListNode]) -> bool:
        
        # Base case if head is empty return False
        if not head: return False
        
        # two pointers slow pointing at head and fast pointing at head.next
        slow = head
        fast = head.next
        
        # keep the loop untill either fast or slow or fast.next is not None
        while slow and fast and fast.next:
            
            # check if fast and slow point at same node then cycle is fount
            if slow == fast: return True
            
            # increment the slow pointer by 1 step and fast by two step
            slow = slow.next
            fast = fast.next.next
            
        # if loop breaks then there is no cycle so return False
        return False
    
#Approach-3

# Definition for singly-linked list.
# class ListNode:
#     def __init__(self, x):
#         self.val = x
#         self.next = None

class Solution:
    def hasCycle(self, head: Optional[ListNode]) -> bool:
        temp = head
        
        temp2 = head.next if head else None
        while temp and temp2 and temp2.next is not None:
            if temp == temp2:
                return True
            
            temp = temp.next
            temp2 = temp2.next.next
        return False

    
#Approach-4    
# using Floyd's Cycle

class Solution:
    def hasCycle(self, head: Optional[ListNode]) -> bool:
        slow = head
        fast = head
        while(fast and fast.next):
            slow = slow.next
            fast = fast.next.next
            if slow == fast:
                return True
        return False
    
#Approach-5

# Slow and Fast Pointer approach
#--- MAIN EXECUTION
class Solution:
    def hasCycle(self, head: Optional[ListNode]) -> bool:
        
        if(head == None or head.next == None):
            return False
        
        return self.ansv1(head)
    
    
    def ansv1(self,head):
        
        slow,fast = head,head.next
        while(fast != None and fast.next != None):
            if(slow == fast):
                return True
            slow = slow.next    
            fast = fast.next.next
        
        return False

#Q 11. Linked List Cycle II
'''

Given the head of a linked list, return the node where the cycle begins. If there is no cycle, return null.

There is a cycle in a linked list if there is some node in the list that can be reached again by continuously following the next pointer. Internally, pos is used to denote the index of the node that tail's next pointer is connected to (0-indexed). It is -1 if there is no cycle. Note that pos is not passed as a parameter.

Do not modify the linked list.

 

Example 1:


Input: head = [3,2,0,-4], pos = 1
Output: tail connects to node index 1
Explanation: There is a cycle in the linked list, where tail connects to the second node.
Example 2:


Input: head = [1,2], pos = 0
Output: tail connects to node index 0
Explanation: There is a cycle in the linked list, where tail connects to the first node.
Example 3:


Input: head = [1], pos = -1
Output: no cycle
Explanation: There is no cycle in the linked list.
 

Constraints:

The number of the nodes in the list is in the range [0, 104].
-105 <= Node.val <= 105
pos is -1 or a valid index in the linked-list.
 

Follow up: Can you solve it using O(1) (i.e. constant) memory?
'''
#Solution:

# Definition for singly-linked list.
# class ListNode:
#     def __init__(self, x):
#         self.val = x
#         self.next = None

# class Solution:
#     def detectCycle(self, head: Optional[ListNode]) -> Optional[ListNode]:

#Approach-1

# floyd
# linkedlist cycle

class Solution:
    def detectCycle(self, head: Optional[ListNode]) -> Optional[ListNode]:
        if head is None:
            return None

        slow = head
        fast = head
        intersection = None

        while intersection is None:
            if fast is None or fast.next is None:
                return None

            slow = slow.next
            fast = fast.next.next
            if slow == fast:
                intersection = fast

        start = head

        while start != intersection:
            start = start.next
            intersection = intersection.next

        return start

#Approach-2

class Solution:
    def detectCycle(self, head):
        """
        :type head: ListNode
        :rtype: ListNode
        """
        linked=[]
        while(head!=None):
            if(head not in linked):
                linked.append(head) 
            else:
                return head
            head = head.next
            
            
#Approach-3            
# (O(n) || O(1)) Floyd's algorithm

# two pointer
class Solution:
    def detectCycle(self, head: Optional[ListNode]) -> Optional[ListNode]:
        
        slow = fast = head
        flag = False
        
        while fast and fast.next:
            slow = slow.next
            fast = fast.next.next
            
            if slow == fast:
                flag = True
                break
        
        if not flag:
            return
        
        fast = head        
        while not slow == fast:
            slow = slow.next
            fast = fast.next
                    
        return slow
    
#Approach-4

# Dictionary Approach

# Definition for singly-linked list.
# class ListNode:
#     def __init__(self, x):
#         self.val = x
#         self.next = None

class Solution:
	def detectCycle(self, head: Optional[ListNode]) -> Optional[ListNode]:

		if not head:
			return None

		cur = head
		nodes = {}
		
		while cur.next != None:
			if cur in nodes.keys():
				return cur

			else:
				nodes[cur] = cur.next
				cur = cur.next

		return None

    
#Approach-5

class Solution(object):
    def detectCycle(self, head):

        slow,fast = head, head
        while fast and fast.next:
            slow, fast = slow.next, fast.next.next
            if slow == fast:
                index1, index2 = slow, head
                while index1 != index2:
                    index1, index2 = index1.next, index2.next
                    
                return index1
            
        return


#Q 12.  Intersection of Two Linked Lists

'''

Given the heads of two singly linked-lists headA and headB, return the node at which the two lists intersect. If the two linked lists have no intersection at all, return null.

For example, the following two linked lists begin to intersect at node c1:


The test cases are generated such that there are no cycles anywhere in the entire linked structure.

Note that the linked lists must retain their original structure after the function returns.

Custom Judge:

The inputs to the judge are given as follows (your program is not given these inputs):

intersectVal - The value of the node where the intersection occurs. This is 0 if there is no intersected node.
listA - The first linked list.
listB - The second linked list.
skipA - The number of nodes to skip ahead in listA (starting from the head) to get to the intersected node.
skipB - The number of nodes to skip ahead in listB (starting from the head) to get to the intersected node.
The judge will then create the linked structure based on these inputs and pass the two heads, headA and headB to your program. If you correctly return the intersected node, then your solution will be accepted.

 

Example 1:


Input: intersectVal = 8, listA = [4,1,8,4,5], listB = [5,6,1,8,4,5], skipA = 2, skipB = 3
Output: Intersected at '8'
Explanation: The intersected node's value is 8 (note that this must not be 0 if the two lists intersect).
From the head of A, it reads as [4,1,8,4,5]. From the head of B, it reads as [5,6,1,8,4,5]. There are 2 nodes before the intersected node in A; There are 3 nodes before the intersected node in B.
- Note that the intersected node's value is not 1 because the nodes with value 1 in A and B (2nd node in A and 3rd node in B) are different node references. In other words, they point to two different locations in memory, while the nodes with value 8 in A and B (3rd node in A and 4th node in B) point to the same location in memory.
Example 2:


Input: intersectVal = 2, listA = [1,9,1,2,4], listB = [3,2,4], skipA = 3, skipB = 1
Output: Intersected at '2'
Explanation: The intersected node's value is 2 (note that this must not be 0 if the two lists intersect).
From the head of A, it reads as [1,9,1,2,4]. From the head of B, it reads as [3,2,4]. There are 3 nodes before the intersected node in A; There are 1 node before the intersected node in B.
Example 3:


Input: intersectVal = 0, listA = [2,6,4], listB = [1,5], skipA = 3, skipB = 2
Output: No intersection
Explanation: From the head of A, it reads as [2,6,4]. From the head of B, it reads as [1,5]. Since the two lists do not intersect, intersectVal must be 0, while skipA and skipB can be arbitrary values.
Explanation: The two lists do not intersect, so return null.
 

Constraints:

The number of nodes of listA is in the m.
The number of nodes of listB is in the n.
1 <= m, n <= 3 * 104
1 <= Node.val <= 105
0 <= skipA < m
0 <= skipB < n
intersectVal is 0 if listA and listB do not intersect.
intersectVal == listA[skipA] == listB[skipB] if listA and listB intersect.
 

Follow up: Could you write a solution that runs in O(m + n) time and use only O(1) memory?
'''
#Solution

# Definition for singly-linked list.
# class ListNode:
#     def __init__(self, x):
#         self.val = x
#         self.next = None

#Approach-1

class Solution:
    def getIntersectionNode(self, headA, headB):
        pA, pB = headA, headB
        while pA != pB:
            pA = headB if pA is None else pA.next
            pB = headA if pB is None else pB.next
        return pA

    
#Approach-2

# Simple Solution by Pre-calculating Length of Two Lists
# two-pointers

class Solution:
    def getIntersectionNode(self, headA: ListNode, headB: ListNode) -> Optional[ListNode]:
        # calculate difference of length between two lists
        lengthA, lengthB = 0, 0
        currA, currB = headA, headB
        while currA:
            lengthA += 1
            currA = currA.next
        while currB:
            lengthB += 1
            currB = currB.next
        
        # make the longer list move abs(lengthA-lengthB) steps first
        currA, currB = headA, headB
        if lengthA > lengthB:
            for i in range(lengthA-lengthB):
                currA = currA.next
        else:
            for i in range(lengthB-lengthA):
                currB = currB.next
        
        # check if at some node, two lists will instersect
        while currA and currB:
            if currA == currB:
                return currA
            currA = currA.next
            currB = currB.next
        
        return None


#Q13.  Palindrome Linked List
'''
Given the head of a singly linked list, return true if it is a palindrome or false otherwise.

 

Example 1:


Input: head = [1,2,2,1]
Output: true
Example 2:


Input: head = [1,2]
Output: false
 

Constraints:

The number of nodes in the list is in the range [1, 105].
0 <= Node.val <= 9
 

Follow up: Could you do it in O(n) time and O(1) space?
'''
#Solution:


# Definition for singly-linked list.
# class ListNode:
#     def __init__(self, val=0, next=None):
#         self.val = val
#         self.next = next

#Approach-1

class Solution:
    def reversed(self, head):
        prev = None
        
        while head:
            temp = head.next
            head.next = prev
            prev = head
            head = temp
        
        return prev
    def isPalindrome(self, head):
        fast = slow = head
        
        while fast and fast.next:
            fast = fast.next.next
            slow = slow.next
        
        slow = self.reversed(slow)
        while slow:
            if slow.val != head.val:
                return False
            head = head.next
            slow = slow.next
        
        return True

        
#Approach-2   

# Definition for singly-linked list.
# class ListNode:
#     def __init__(self, val=0, next=None):
#         self.val = val
#         self.next = next
class Solution:
    def isPalindrome(self, head: Optional[ListNode]) -> bool:
        _l = []
        while head:
            _l.append(head.val)
            head = head.next

        return _l == _l[::-1]
    
#Approach-3

class Solution:
    def isPalindrome(self, head: Optional[ListNode]) -> bool:
        a=[]
        curr=head
        while(curr):
            a.append(curr.val)
            curr=curr.next
        return a==a[::-1]

#Q 14. Remove Linked List Elements
'''

Given the head of a linked list and an integer val, remove all the nodes of the linked list that has Node.val == val, and return the new head.

 

Example 1:


Input: head = [1,2,6,3,4,5,6], val = 6
Output: [1,2,3,4,5]
Example 2:

Input: head = [], val = 1
Output: []
Example 3:

Input: head = [7,7,7,7], val = 7
Output: []
 

Constraints:

The number of nodes in the list is in the range [0, 104].
1 <= Node.val <= 50
0 <= val <= 50

'''
#Solution:

# Definition for singly-linked list.
# class ListNode:
#     def __init__(self, val=0, next=None):
#         self.val = val
#         self.next = next
# class Solution:
#     def removeElements(self, head: Optional[ListNode], val: int) -> Optional[ListNode]:
        
    
#Approach-1

class Solution:
    def removeElements(self, head: Optional[ListNode], val: int) -> Optional[ListNode]:
        
        false_head = ListNode(next=head)
        curr=false_head
                   
        while curr.next:
            if curr.next.val==val:
                curr.next=curr.next.next
            
            else:
                curr=curr.next
            
        return false_head.next

#Approach-2

# Three major cases may arise:

# linked list
# empty LL
# First element is equal to val
# Element somewhere in between the list is equal to val
# Big Idea: always keep track of node before the node with which you are comparing val, because if the node in comparision is equal to val, you could simply make a connection of previous node to the next node of the node in comparision.

# Definition for singly-linked list.
# class ListNode:
#     def __init__(self, val=0, next=None):
#         self.val = val
#         self.next = next
class Solution:
    def removeElements(self, head: Optional[ListNode], val: int) -> Optional[ListNode]:
        th = head
        prev = None
        
        while th != None:
           
            if th.val == val:
                
                if head == th:
                    prev = head
                    prev.next = th.next
                    th = th.next
                    head = th
                    
                else:
                    prev.next = th.next
                    th = th.next
                
            else:
                prev = th
                th = th.next
                
        return head

#Q15.  Design Browser History
'''

You have a browser of one tab where you start on the homepage and you can visit another url, get back in the history number of steps or move forward in the history number of steps.

Implement the BrowserHistory class:

BrowserHistory(string homepage) Initializes the object with the homepage of the browser.
void visit(string url) Visits url from the current page. It clears up all the forward history.
string back(int steps) Move steps back in history. If you can only return x steps in the history and steps > x, you will return only x steps. Return the current url after moving back in history at most steps.
string forward(int steps) Move steps forward in history. If you can only forward x steps in the history and steps > x, you will forward only x steps. Return the current url after forwarding in history at most steps.
 

Example:

Input:
["BrowserHistory","visit","visit","visit","back","back","forward","visit","forward","back","back"]
[["leetcode.com"],["google.com"],["facebook.com"],["youtube.com"],[1],[1],[1],["linkedin.com"],[2],[2],[7]]
Output:
[null,null,null,null,"facebook.com","google.com","facebook.com",null,"linkedin.com","google.com","leetcode.com"]

Explanation:
BrowserHistory browserHistory = new BrowserHistory("leetcode.com");
browserHistory.visit("google.com");       // You are in "leetcode.com". Visit "google.com"
browserHistory.visit("facebook.com");     // You are in "google.com". Visit "facebook.com"
browserHistory.visit("youtube.com");      // You are in "facebook.com". Visit "youtube.com"
browserHistory.back(1);                   // You are in "youtube.com", move back to "facebook.com" return "facebook.com"
browserHistory.back(1);                   // You are in "facebook.com", move back to "google.com" return "google.com"
browserHistory.forward(1);                // You are in "google.com", move forward to "facebook.com" return "facebook.com"
browserHistory.visit("linkedin.com");     // You are in "facebook.com". Visit "linkedin.com"
browserHistory.forward(2);                // You are in "linkedin.com", you cannot move forward any steps.
browserHistory.back(2);                   // You are in "linkedin.com", move back two steps to "facebook.com" then to "google.com". return "google.com"
browserHistory.back(7);                   // You are in "google.com", you can move back only one step to "leetcode.com". return "leetcode.com"
 

Constraints:

1 <= homepage.length <= 20
1 <= url.length <= 20
1 <= steps <= 100
homepage and url consist of  '.' or lower case English letters.
At most 5000 calls will be made to visit, back, and forward.

'''
#Solution

# class BrowserHistory:

#     def __init__(self, homepage: str):
        

#     def visit(self, url: str) -> None:
        

#     def back(self, steps: int) -> str:
        

#     def forward(self, steps: int) -> str:
        


# # Your BrowserHistory object will be instantiated and called as such:
# # obj = BrowserHistory(homepage)
# # obj.visit(url)
# # param_2 = obj.back(steps)
# # param_3 = obj.forward(steps)

#Approach-1

class BrowserHistory:

	def __init__(self, homepage: str):
		self.back_stack = []
		self.forward_stack = []
		self.cur = homepage

	def visit(self, url: str) -> None:
		self.back_stack.append(self.cur)
		self.cur = url
		self.forward_stack.clear()

	def back(self, steps: int) -> str:
		while self.back_stack and steps > 0:
			self.forward_stack.append(self.cur)
			self.cur = self.back_stack.pop()
			steps -= 1
		return self.cur

	def forward(self, steps: int) -> str:
		while self.forward_stack and steps > 0:
			self.back_stack.append(self.cur)
			self.cur = self.forward_stack.pop()
			steps -= 1
		return self.cur
    
#Approach-2

# Double Linked List Python

class Node(object):
    def __init__(self, url):
        self.url = url
        self.next = None
        self.prev = None
        
class BrowserHistory:

    def __init__(self, homepage: str):
        self.curNode = Node(homepage)

    def visit(self, url: str) -> None:
        #print(f"visit")
        # sanity check
        if not url: 
            raise ValueError("Invalid url!")
        
        visitNode = Node(url)
        visitNode.prev = self.curNode
        
        self.curNode.next = visitNode
        self.curNode = self.curNode.next
        
        #print(f"curNode: {self.curNode.url}")
        #print(f"prevNode: {self.curNode.prev.url}")
        #print()
        
        return

    def back(self, steps: int) -> str:
        #print(f"back: {steps}")
        while steps > 0 and self.curNode.prev:
            self.curNode = self.curNode.prev
            steps -= 1
        
        #print(f"node after: {self.curNode.url}")
        
        return self.curNode.url
        

    def forward(self, steps: int) -> str:
        #print(f"forward: {steps}")
        while steps > 0 and self.curNode.next:
            self.curNode = self.curNode.next
            steps -= 1
            
        #print(f"node after: {self.curNode.url}")
            
        return self.curNode.url


#Q16. LRU Cache
'''

Design a data structure that follows the constraints of a Least Recently Used (LRU) cache.

Implement the LRUCache class:

LRUCache(int capacity) Initialize the LRU cache with positive size capacity.
int get(int key) Return the value of the key if the key exists, otherwise return -1.
void put(int key, int value) Update the value of the key if the key exists. Otherwise, add the key-value pair to the cache. If the number of keys exceeds the capacity from this operation, evict the least recently used key.
The functions get and put must each run in O(1) average time complexity.

 

Example 1:

Input
["LRUCache", "put", "put", "get", "put", "get", "put", "get", "get", "get"]
[[2], [1, 1], [2, 2], [1], [3, 3], [2], [4, 4], [1], [3], [4]]
Output
[null, null, null, 1, null, -1, null, -1, 3, 4]

Explanation
LRUCache lRUCache = new LRUCache(2);
lRUCache.put(1, 1); // cache is {1=1}
lRUCache.put(2, 2); // cache is {1=1, 2=2}
lRUCache.get(1);    // return 1
lRUCache.put(3, 3); // LRU key was 2, evicts key 2, cache is {1=1, 3=3}
lRUCache.get(2);    // returns -1 (not found)
lRUCache.put(4, 4); // LRU key was 1, evicts key 1, cache is {4=4, 3=3}
lRUCache.get(1);    // return -1 (not found)
lRUCache.get(3);    // return 3
lRUCache.get(4);    // return 4
 

Constraints:

1 <= capacity <= 3000
0 <= key <= 104
0 <= value <= 105
At most 2 * 105 calls will be made to get and put.

'''




#Solution


# class LRUCache:

#     def __init__(self, capacity: int):
        

#     def get(self, key: int) -> int:
        

#     def put(self, key: int, value: int) -> None:
        


# Your LRUCache object will be instantiated and called as such:
# obj = LRUCache(capacity)
# param_1 = obj.get(key)
# obj.put(key,value)


#Approach-1

from collections import OrderedDict
class LRUCache:
    
    def __init__(self, capacity: int):
        self.cache = OrderedDict()
        self.cap = capacity

    def get(self, key: int) -> int:
        if key not in self.cache: return -1
        val = self.cache[key]
        self.cache.move_to_end(key)
        return val

    def put(self, key: int, value: int) -> None:
        if key in self.cache: del self.cache[key]
        self.cache[key] = value
        if len(self.cache) > self.cap:
            self.cache.popitem(last=False)

#Approach-2

# OrderedSet

from collections import OrderedDict

class LRUCache:

    def __init__(self, capacity: int):
        self.d = OrderedDict()
        self.cap = capacity
        
    def get(self, key: int) -> int:
        if key not in self.d:
            return -1
        value = self.d[key]
        del self.d[key]
        self.d[key] = value
        return value
        
    def put(self, key: int, value: int) -> None:
        if key not in self.d:
            if len(self.d) == self.cap:
                k = next(iter(self.d))
                del self.d[k]
            self.d[key] = value
        else:
            del self.d[key]
            self.d[key] = value
 

#Approach-3

# Dict + Doubly Linked List


class Node:
    def __init__(self, k, v):
        self.key = k
        self.value = v
        self.prev = None
        self.next = None


class LRUCache:
    def __init__(self, capacity: int):
        self.capacity = capacity
        self.head = Node(0, 0)
        self.tail = Node(0, 0)
        self.head.next = self.tail
        self.tail.prev = self.head
        # a mapping of (k, Node)
        self.mappings = {}
        # current size
        self.size = 0
    
    
    def get(self, key: int) -> int:
        # if the key exists
        if key in self.mappings:
            # move the Node to the front
            self.remove(self.mappings[key])
            self.addToFirst(self.mappings[key])
            return self.mappings[key].value
        return -1
    

    def put(self, key: int, value: int) -> None:
        # if the key exists
        if key in self.mappings:
            # update the value
            self.mappings[key].value = value
            # move to the first
            self.remove(self.mappings[key])
            self.addToFirst(self.mappings[key])
        elif self.size < self.capacity:
            # create a node and add it to the front
            n = Node(key, value)
            self.addToFirst(n)
            self.size += 1
            # also add it to the map
            self.mappings[key] = n
        elif self.size >= self.capacity:
            lastNode = self.tail.prev
            # evit the last node
            self.remove(lastNode)
            # also need to remove the key from mapping
            self.mappings.pop(lastNode.key, None)
            # create a node and add it to the front
            n = Node(key, value)
            self.addToFirst(n)
            self.size += 1
            self.mappings[key] = n
    
    
    def addToFirst(self, node) -> None:
        """Add a node to the head """
        curFirst = self.head.next
        self.head.next = node
        node.next = curFirst
        curFirst.prev = node
        node.prev = self.head
        
        
    def remove(self, node) -> None:
        """Remove a node """
        p = node.prev
        p.next = node.next
        node.next.prev = p
        node.next = None
        node.prev = None
            


# Your LRUCache object will be instantiated and called as such:
# obj = LRUCache(capacity)
# param_1 = obj.get(key)
# obj.put(key,value)

#Approach-4

# Dict + DLinkedList with proper abstractions

class LinkedListNode:
    def __init__(self, key: int, val: int):
        self.key = key
        self.val = val
        self.prev = None
        self.next = None
        
class DLinkedList:
    def __init__(self):
        # Head and Tail are dummy nodes
        self.head = LinkedListNode(0, 0)
        self.tail = LinkedListNode(0, 0)
        
        # Link head and tail
        self.head.next = self.tail
        self.tail.prev = self.head
        
    def add(self, node: LinkedListNode) -> None:
        # Add node in the front after head
        head_next = self.head.next
        head_next.prev = node
        
        self.head.next = node
        
        node.prev = self.head
        node.next = head_next
        
    def remove(self, node: LinkedListNode) -> None:
        # Remove node from DLinkedList
        node_next = node.next
        node_prev = node.prev
        
        node_next.prev = node_prev
        node_prev.next = node_next
        
class LRUCache:
    def __init__(self, capacity: int):
        self.capacity = capacity
        self.cache = {}
        self.ll = DLinkedList()

    def get(self, key: int) -> int:
        if key not in self.cache:
            return -1
        
        node = self.cache[key]
        self.ll.remove(node)
        self.ll.add(node)
        
        return node.val

    def put(self, key: int, value: int) -> None:
        if key in self.cache:
            self.__replace_value_for_key(key, value)
            return
        
        if len(self.cache) >= self.capacity:
            self.__remove_least_recently_used()
        
        node = LinkedListNode(key, value)
        self.cache[key] = node
        self.ll.add(node)
       
    def __replace_value_for_key(self, key: int, value: int) -> None:
        if key not in self.cache:
            return
        
        node = self.cache[key]
        self.ll.remove(node)
        node.val = value
        self.ll.add(node)
        self.cache[key] = node
    
    def __remove_least_recently_used(self) -> None:
        if not self.cache:
            return
        
        lru = self.ll.tail.prev
        self.ll.remove(lru)
        self.cache.pop(lru.key)
        
# Your LRUCache object will be instantiated and called as such:
# obj = LRUCache(capacity)
# param_1 = obj.get(key)
# obj.put(key,value)


#Approach-5

# Hash Table and Doubly Linked List Solution | O(1) Time | O(n) Space
# * Hash Table and Doubly Linked List Solution | O(1) Time | O(n) Space
# * n -> The given input capacity


# Definition for a doubly linked list.
class Node:
    def __init__(self, key=0, val=0, prev=None, next=None):
        self.key = key
        self.val = val
        self.prev = prev
        self.next = next


class LRUCache:
    def __init__(self, capacity: int):
        """Initialize the LRU cache with positive size capacity."""
        self.capacity = capacity
        # * Stores a key-value pair where the key is the given key and value is a doubly linked list.
        self.cache = collections.defaultdict(Node)
        # * Dummy head and tail help us to easily manage LRU cache eviction.
        self.dummy_head = Node()
        self.dummy_tail = Node()
        self.dummy_head.next = self.dummy_tail
        self.dummy_tail.prev = self.dummy_head

    def get(self, key: int) -> int:
        """Returns the value of the key if the key exists, otherwise returns -1."""
        if key in self.cache:
            cur_node = self.cache[key]
            self._remove_from_list(cur_node)
            self._insert_into_head(cur_node)
            return cur_node.val

        return -1

    def put(self, key: int, value: int) -> None:
        """Updates the value of the key if the key exists.
        Otherwise, adds the key-value pair to the cache. If the number of keys
        exceeds the capacity from this operation then evicts the least recently used key.
        """
        # * Updates the value of the key if the key exists and removes the node from the list
        # * so as to insert the node to the front of the list as it's the MRU key.
        if key in self.cache:
            cur_node = self.cache[key]
            cur_node.val = value
            self._remove_from_list(cur_node)
        # * Adds the key-value pair to the cache.
        else:
            self.cache[key] = Node(key, value)

        # * Inserts the node to the front of the list as it's the MRU key.
        self._insert_into_head(self.cache[key])
        # * Evicts the LRU key if the cache exceeds the given capacity.
        if len(self.cache) > self.capacity:
            lru_node = self.dummy_tail.prev
            self._remove_from_list(lru_node)
            del self.cache[lru_node.key]

    def _insert_into_head(self, node):
        """Inserts a given node into the head.
        This is mainly used to insert the most recently used (MRU) key to the front of the list.
        """
        next = self.dummy_head.next
        node.next, next.prev = next, node
        self.dummy_head.next, node.prev = node, self.dummy_head

    def _remove_from_list(self, node):
        """Removes a given node from the list.
        This is mainly used to remove the least recently used (LRU) key from the list.
        """
        prev, next = node.prev, node.next
        prev.next, next.prev = next, prev


# Your LRUCache object will be instantiated and called as such:
# obj = LRUCache(capacity)
# param_1 = obj.get(key)
# obj.put(key,value)


#Q17. Copy List with Random Pointer
'''

A linked list of length n is given such that each node contains an additional random pointer, which could point to any node in the list, or null.

Construct a deep copy of the list. The deep copy should consist of exactly n brand new nodes, where each new node has its value set to the value of its corresponding original node. Both the next and random pointer of the new nodes should point to new nodes in the copied list such that the pointers in the original list and copied list represent the same list state. None of the pointers in the new list should point to nodes in the original list.

For example, if there are two nodes X and Y in the original list, where X.random --> Y, then for the corresponding two nodes x and y in the copied list, x.random --> y.

Return the head of the copied linked list.

The linked list is represented in the input/output as a list of n nodes. Each node is represented as a pair of [val, random_index] where:

val: an integer representing Node.val
random_index: the index of the node (range from 0 to n-1) that the random pointer points to, or null if it does not point to any node.
Your code will only be given the head of the original linked list.

 

Example 1:


Input: head = [[7,null],[13,0],[11,4],[10,2],[1,0]]
Output: [[7,null],[13,0],[11,4],[10,2],[1,0]]
Example 2:


Input: head = [[1,1],[2,1]]
Output: [[1,1],[2,1]]
Example 3:



Input: head = [[3,null],[3,0],[3,null]]
Output: [[3,null],[3,0],[3,null]]
 

Constraints:

0 <= n <= 1000
-104 <= Node.val <= 104
Node.random is null or is pointing to some node in the linked list.

'''
#Solution


"""
# Definition for a Node.
class Node:
    def __init__(self, x: int, next: 'Node' = None, random: 'Node' = None):
        self.val = int(x)
        self.next = next
        self.random = random
"""

# class Solution:
#     def copyRandomList(self, head: 'Optional[Node]') -> 'Optional[Node]':
        

#Method-1

# O(1) space and O(N) time complexity without side effect after the invoke


"""
# Definition for a Node.
class Node:
    def __init__(self, x: int, next: 'Node' = None, random: 'Node' = None):
        self.val = int(x)
        self.next = next
        self.random = random
"""

class Solution:
    def copyRandomList(self, head: 'Optional[Node]') -> 'Optional[Node]':
        cur = head
        while cur is not None:
            cur.next = Node(cur.val, cur.next, None)
            cur = cur.next.next
        cur = head
        while cur is not None:
            if cur.random is not None:
                cur.next.random = cur.random.next
            else:
                cur.next.random = None
            cur = cur.next.next
        dummy = Node(0)
        cur = head
        cur2 = dummy
        while cur is not None:
            cur2.next = cur.next
            cur.next = cur.next.next
            cur2 = cur2.next
            cur = cur.next
        return dummy.next
    
#Method-2

# Dictionary Solution
# easy
# faster

"""
# Definition for a Node.
class Node:
	def __init__(self, x: int, next: 'Node' = None, random: 'Node' = None):
		self.val = int(x)
		self.next = next
		self.random = random
"""

class Solution:
	def copyRandomList(self, head: 'Optional[Node]') -> 'Optional[Node]':

		oldCopyDict = {None:None}

		curr = head

		while curr:
			copy = Node(curr.val)
			oldCopyDict[curr] = copy
			curr = curr.next

		curr = head

		while curr:
			copy = oldCopyDict[curr]
			copy.next = oldCopyDict[curr.next]
			copy.random = oldCopyDict[curr.random]

			curr = curr.next

		return oldCopyDict[head]

#Method-3

"""
Time: O(N)
Space: O(1)

The easiest way would be maintaining a hash map for original node to the copy and the other way around. Then the rest is easy.
But this will take us O(N) of extra space.

Two pass solution with constant space.
First pass.
Create a copy of the original and store it inside "random".
The copy points to original's next and original's random.

Second pass.
Iterate through the nodes again.
This time we adjust the copy to point to the other copies.
"""
class Solution:
    def copyRandomList(self, head: 'Optional[Node]') -> 'Optional[Node]':
        if not head: return head
        
        node = head
        while node:
            copy = Node(node.val, node.next, node.random)
            node.random = copy
            node = node.next
        
        node = head
        while node:
            newNode = node.random
            if node.next: newNode.next = node.next.random
            if newNode.random: newNode.random = newNode.random.random
            node = node.next
        
        return head.random
