#ARRAY/List


# Q1. Two Sum


'''
Add to List

Given an array of integers nums and an integer target, return indices of the two numbers such that they add up to target.

You may assume that each input would have exactly one solution, and you may not use the same element twice.

You can return the answer in any order.

 

Example 1:

Input: nums = [2,7,11,15], target = 9
Output: [0,1]
Explanation: Because nums[0] + nums[1] == 9, we return [0, 1].
Example 2:

Input: nums = [3,2,4], target = 6
Output: [1,2]
Example 3:

Input: nums = [3,3], target = 6
Output: [0,1]
 

Constraints:

2 <= nums.length <= 104
-109 <= nums[i] <= 109
-109 <= target <= 109
Only one valid answer exists.
 

Follow-up: Can you come up with an algorithm that is less than O(n2) time complexity?
'''
#sloution
#method-1

def two_sum(num):
    target =int(input())
    for i in range(len(num)):
        for j in range(i+1,len(num)):
            if num[i]+num[j]==target:
                return [i,j]

n=int(input())
num=[ ]
for i in range(n):
    ele=int(input())
    num.append(ele)
print(num)
print(two_sum(num))

#method-2

class Solution:
    def twoSum(self, nums: List[int], target: int) -> List[int]:
        for i in range(len(nums)):
            for j in range(i + 1, len(nums)):
                if nums[j] == target - nums[i]:
                    return [i, j]




#Q2. Best Time to Buy and Sell Stock



'''
You are given an array prices where prices[i] is the price of a given stock on the ith day.

You want to maximize your profit by choosing a single day to buy one stock and choosing a different day in the future to sell that stock.

Return the maximum profit you can achieve from this transaction. If you cannot achieve any profit, return 0.

 

Example 1:

Input: prices = [7,1,5,3,6,4]
Output: 5
Explanation: Buy on day 2 (price = 1) and sell on day 5 (price = 6), profit = 6-1 = 5.
Note that buying on day 2 and selling on day 1 is not allowed because you must buy before you sell.
Example 2:

Input: prices = [7,6,4,3,1]
Output: 0
Explanation: In this case, no transactions are done and the max profit = 0.
 

Constraints:

1 <= prices.length <= 105
0 <= prices[i] <= 104
'''
#Solution
#Method-1

def maxProfit(prices):
    left = 0 #Buy
    right = 1 #Sell
    max_profit = 0
    while right < len(prices):
        currentProfit = prices[right] - prices[left] #our current Profit
        if prices[left] < prices[right]:
            max_profit =max(currentProfit,max_profit)
        else:
            left = right
        right += 1
    return max_profit
        
n=int(input())
prices=[ ]
for i in range(n):
    ele=int(input())
    prices.append(ele)
print(prices)
x=maxProfit(prices)
print(x)

#Method-2

class Solution:
    def maxProfit(self,prices):
        left = 0 #Buy
        right = 1 #Sell
        max_profit = 0
        while right < len(prices):
            currentProfit = prices[right] - prices[left] #our current Profit
            if prices[left] < prices[right]:
                max_profit =max(currentProfit,max_profit)
            else:
                left = right
            right += 1
        return max_profit




#Q3 Merge Sorted Array




'''
You are given two integer arrays nums1 and nums2, sorted in non-decreasing order, and two integers m and n, representing the number of elements in nums1 and nums2 respectively.

Merge nums1 and nums2 into a single array sorted in non-decreasing order.

The final sorted array should not be returned by the function, but instead be stored inside the array nums1. To accommodate this, nums1 has a length of m + n, where the first m elements denote the elements that should be merged, and the last n elements are set to 0 and should be ignored. nums2 has a length of n.

 

Example 1:

Input: nums1 = [1,2,3,0,0,0], m = 3, nums2 = [2,5,6], n = 3
Output: [1,2,2,3,5,6]
Explanation: The arrays we are merging are [1,2,3] and [2,5,6].
The result of the merge is [1,2,2,3,5,6] with the underlined elements coming from nums1.
Example 2:

Input: nums1 = [1], m = 1, nums2 = [], n = 0
Output: [1]
Explanation: The arrays we are merging are [1] and [].
The result of the merge is [1].
Example 3:

Input: nums1 = [0], m = 0, nums2 = [1], n = 1
Output: [1]
Explanation: The arrays we are merging are [] and [1].
The result of the merge is [1].
Note that because m = 0, there are no elements in nums1. The 0 is only there to ensure the merge result can fit in nums1.
 

Constraints:

nums1.length == m + n
nums2.length == n
0 <= m, n <= 200
1 <= m + n <= 200
-109 <= nums1[i], nums2[j] <= 109
 

Follow up: Can you come up with an algorithm that runs in O(m + n) time?

'''
# Sloution

#Method-1

class Solution:
    def merge(self, nums1: List[int], m: int, nums2: List[int], n: int) -> None:
    
        i=0
        j=0
        # 2 pointer approach, keeping the second array always sorted
        while nums2 and i<m:
          # If current number present in the first array is smaller than current number in the second array move the first pointer by 1
          if nums1[i]<=nums2[j]:
            i+=1
          # If the current no. in second array is smaller, swap and then sort the second array
          else:
            nums1[i],nums2[j]=nums2[j],nums1[i]
            
            # Sort the second array after swapping elements
            k=1
            temp=nums2[0]
            while k<n and nums2[k]<temp:
              nums2[k-1]=nums2[k]
              k+=1
            nums2[k-1]=temp
            i+=1
        # Appending the sorted second array to the first array
        else:
          while j<n:
            nums1[i]=nums2[j]
            i+=1
            j+=1
        
 #Method-2 
# I used List slicing here for easy to do merging and sorting within the same list without creating a new list.
 class Solution:
    def merge(self, nums1: List[int], m: int, nums2: List[int], n: int) -> None:       
        nums1[:] = nums1[0:m]+nums2[0:n]
        nums1.sort()
        

               
 #Method-3       
               
        # Store nums2 array in second part of nums1
class Solution:
    def merge(self, nums1: List[int], m: int, nums2: List[int], n: int) -> None:
        for i in range(n):
          nums1[m+i]=nums2[i]
        
        # Set gap as ceiling of (m+n)/2
        gap = int(math.ceil((m+n)//2))
        
        
        while gap>=1:
          for i in range(gap,m+n):  
            for j in range(i-gap,-1,-gap):
              # Till previous element is greater, keep swapping current and previous element
              if nums1[j]>nums1[j+gap]:
                nums1[j+gap],nums1[j]=nums1[j],nums1[j+gap]
              else:
                break
                  
          gap = gap//2
        
        
        
 #Method-4       
class Solution:
    def merge(self, nums1: List[int], m: int, nums2: List[int], n: int) -> None:        
        tempNums1 = nums1[:]
        i, j = 0, 0
        index = 0
        while index < len(tempNums1):
            if i > m - 1:
                nums1[index] = nums2[j]
                j += 1
            elif j > n - 1:
                nums1[index] = tempNums1[i]
                i += 1
            elif tempNums1[i] <= nums2[j]:
                nums1[index] = tempNums1[i]
                i += 1
            else:
                nums1[index] = nums2[j]
                j += 1
            index += 1

        
        
        
 #Method-5          
        
        # merge two array from the back
class Solution:
    def merge(self, nums1: List[int], m: int, nums2: List[int], n: int) -> None:
        p1 = m - 1
        p2 = n - 1
        k = m + n - 1
        
        while p1 >= 0 and p2 >= 0:
            if nums1[p1] > nums2[p2]:
                nums1[k] = nums1[p1]
                p1 -= 1
            else: 
                nums1[k] = nums2[p2]
                p2 -= 1
            k -= 1
            
        if p2 >= 0:
            nums1[:k + 1] = nums2[:p2 + 1]



#Q4. Move Zeroes

'''

Given an integer array nums, move all 0's to the end of it while maintaining the relative order of the non-zero elements.

Note that you must do this in-place without making a copy of the array.

Example 1:

Input: nums = [0,1,0,3,12]
Output: [1,3,12,0,0]
Example 2:

Input: nums = [0]
Output: [0]
 

Constraints:

1 <= nums.length <= 104
-231 <= nums[i] <= 231 - 1
 

Follow up: Could you minimize the total number of operations done?

'''
# Sloution 

#Method-1      
#Here's my python solution in O(n) I believe

class Solution:
    def moveZeroes(self, nums):
        """
        :type nums: List[int]
        :rtype: void Do not return anything, modify nums in-place instead.
        """
        pos = 0
        
        for i in range(len(nums)):
            el = nums[i]
            if el != 0:
                nums[pos], nums[i] = nums[i], nums[pos]
                pos += 1 
                
 #Method-2                     
#Python3 Solution:Not fast but easy understand:

class Solution(object):
    def moveZeroes(self, nums):
        append_times=nums.count(0)
        for i in range(append_times):
            nums.remove(0) #  Delete the front zero
            nums.append(0) # append it at the end of nums, the times of the addition and substraction shall be equal
 

#Method-3     
# # Starts from the first element and goes toward the end, if the element is zero, it #pops the element and appends it to the end.

class Solution(object):
    def moveZeroes(self, nums):
        i = count = 0
        while count < len(nums):
            if nums[i] == 0: nums.append(nums.pop(i))
            else: i += 1
            count += 1
            
 
#Method-4      
# #here is my simple python version, the idea is throw 0 to the end of array, and left #shift the array.

class Solution:
    def moveZeroes(self, nums):
        length=len(nums)
        j=0
        for i in range(length-1):
            if(nums[j]==0):
                nums[j:length-1]=nums[j+1:length]
                nums[length-1]=0
            else:
                j+=1
 #Method-5                     
#Do not return anything, modify nums in-place instead.
              
class Solution:
    def moveZeroes(self, nums: List[int]) -> None:
        numsLen = len(nums)
        backTrack = 0
        for x in range(numsLen):
            x = x - backTrack
            if nums[x] == 0:
                backTrack += 1
                nums.pop(x)
                nums.append(0)
            
            
            
#Method-6                  
# #python3 solution without using list methods, because the problem is about arrays:
class Solution:
    def moveZeroes(self, nums):
        i = 0
        j = 0
        while i < len(nums):
            if nums[j] == 0:
                if nums[i] != 0:
                    nums[j] = nums[i]
                    nums[i] = 0
            
                i += 1
            else:
                j += 1




#Q5. Best Time to Buy and Sell Stock II


'''
You are given an integer array prices where prices[i] is the price of a given stock on the ith day.

On each day, you may decide to buy and/or sell the stock. You can only hold at most one share of the stock at any time. However, you can buy it then immediately sell it on the same day.

Find and return the maximum profit you can achieve.

 

Example 1:

Input: prices = [7,1,5,3,6,4]
Output: 7
Explanation: Buy on day 2 (price = 1) and sell on day 3 (price = 5), profit = 5-1 = 4.
Then buy on day 4 (price = 3) and sell on day 5 (price = 6), profit = 6-3 = 3.
Total profit is 4 + 3 = 7.
Example 2:

Input: prices = [1,2,3,4,5]
Output: 4
Explanation: Buy on day 1 (price = 1) and sell on day 5 (price = 5), profit = 5-1 = 4.
Total profit is 4.
Example 3:

Input: prices = [7,6,4,3,1]
Output: 0
Explanation: There is no way to make a positive profit, so we never buy the stock to achieve the maximum profit of 0.
 

Constraints:

1 <= prices.length <= 3 * 104
0 <= prices[i] <= 104
'''

# Solution 
#Method-1

class Solution:
    def maxProfit(self, prices: List[int]) -> int:
        profit = 0
        for i in range(1, len(prices)):
            profit += max(prices[i]-prices[i-1], 0)
        return profit

#Method-2    
class Solution:
    def maxProfit(self, prices: List[int]) -> int:
        max_profit=0
        min_price=prices[0]
        for i in range(1,len(prices)):
            if prices[i]<min_price:
                min_price=prices[i]
            elif max_profit<max_profit+prices[i]-min_price:
                max_profit+=prices[i]-min_price
                min_price=prices[i]
            
        return max_profit

#Method-3
# Why I feel this question is easier than the buy and sell stock version 1:
# Python:

class Solution:
    def maxProfit(self, prices: List[int]) -> int:
        maxPrice = 0
        for i in range(len(prices)-1):
            if prices[i+1] < prices[i]:
                continue
            else:
                maxPrice += prices[i+1] - prices[i]
        return maxPrice
  
 
 #Method-4   
class Solution:
    def maxProfit(self, prices: List[int]) -> int:
        # [7,1,5,3,6,4]
        stack = deque()
        result = 0
        for i,num in enumerate(prices):
            # monotonic decreasing stack, only pop once
            #while stack and num > prices[stack[-1]]:
            if stack and num > prices[stack[-1]]:
                top = stack.pop()
                result += num - prices[top]
            stack.append(i)
        return result


#Method-5
# This problem can also be solved using DP.
# Even O(n^2) should be acceptable for this question but for some reason, I'm getting the time limit exceeded on the last test case.

class Solution:
    def maxProfit(self, prices: List[int]) -> int:
        dp=[0 for i in range(len(prices)+1)]
        for i in range(1,len(prices)+1):
            for j in range(i+1,len(prices)+1):
                dp[j]=max(prices[j-1]-prices[i-1]+dp[i],dp[j],dp[j-1])
        return dp[-1]



#Method-6
# My two pointer solution in python:

class Solution:
    def maxProfit(self, prices: List[int]) -> int:
        i = 0
        profit = 0
        for j in range(1, len(prices)):
            if prices[j] <= prices[j-1]:
                profit += prices[j-1] - prices[i]
                i = j
            if j == len(prices)-1:
                profit += prices[j] - prices[i]
        return profit            


 #Method-7   
class Solution:
    def maxProfit(self, prices: List[int]) -> int:
        profit = 0
        if len(prices)==0:
            return 0
        for i in range(1, len(prices)):
            if prices[i] > prices[i - 1]:
                profit += prices[i] - prices[i-1]
        return profit



#Method-7
class Solution:
    def maxProfit(self, prices: List[int]) -> int:
        profit = 0
        buy = 0
        sell = 0
        hold = 0
        i = 0
        while i < len(prices) - 1:
            if prices[i] < prices[i + 1]:
                if hold == 0:
                    buy = prices[i]
                    hold = 1
            elif prices[i] > prices[i + 1]:
                if hold == 1:
                    sell = prices[i]
                    profit += sell - buy
                    buy = 0
                    hold = 0     
            i += 1
        if hold == 1 and prices[i - 1] <= prices[i]:
            sell = prices[i]
            profit += sell - buy
        return profit
    

 #Method-8   
class Solution:
    def maxProfit(self, prices: List[int]) -> int:
        
        lowidx = 0
        maxprofit = 0
        profit = 0
        
        for idx in range(1,len(prices)):
            if prices[idx] > prices[idx-1]:
                # rising
                profit = prices[idx] - prices[lowidx]
            elif prices[idx] < prices[idx-1]:
                # falling
                maxprofit += profit
                profit = 0
                lowidx = idx
        
        maxprofit += profit
        return maxprofit
 
 #Method-9   
# one line solution in python

class Solution:
    def maxProfit(self, prices: List[int]) -> int:
        profit = sum([prices[ind+1] - prices[ind] for ind in range(len(prices)-1) if (prices[ind+1] - prices[ind]) > 0])

        return profit


#Q6. Running Sum of 1d Array


'''
Given an array nums. We define a running sum of an array as runningSum[i] = sum(nums[0]…nums[i]).

Return the running sum of nums.

 

Example 1:

Input: nums = [1,2,3,4]
Output: [1,3,6,10]
Explanation: Running sum is obtained as follows: [1, 1+2, 1+2+3, 1+2+3+4].
Example 2:

Input: nums = [1,1,1,1,1]
Output: [1,2,3,4,5]
Explanation: Running sum is obtained as follows: [1, 1+1, 1+1+1, 1+1+1+1, 1+1+1+1+1].
Example 3:

Input: nums = [3,1,2,10,1]
Output: [3,4,6,16,17]
 

Constraints:

1 <= nums.length <= 1000
-10^6 <= nums[i] <= 10^6

'''

#Solution 

#Method-1
class Solution:
    def runningSum(self, nums: List[int]) -> List[int]:
        for i in range(1, len(nums)):
            nums[i] += nums[i - 1]
        return nums

#Method-2

class Solution:
    def runningSum(self, nums):
        return [sum(nums[:i+1]) for i in range(len(nums))]

#Method-3
class Solution:
    def runningSum(self, nums: List[int]) -> List[int]:
        output = [nums[0]]
        for i in range (1, len(nums)):
            nums[i] += nums[i - 1]
            output.append(nums[i])
        return output


#Method-4

class Solution:
    def runningSum(self, nums: List[int]) -> List[int]:
        output = []
        for i in range(1, len(nums)+1):
            output.append(sum(nums[:i]))
        return output


#Method-5

class Solution:
    def runningSum(self, nums: List[int]) -> List[int]:
        sum_ = []
        for i in range(1, len(nums)+1):
            sum_.append(sum(nums[:i]))
        return sum_

 
#Q7 Find Pivot Index

'''
Given an array of integers nums, calculate the pivot index of this array.

The pivot index is the index where the sum of all the numbers strictly to the left of the index is equal to the sum of all the numbers strictly to the index's right.

If the index is on the left edge of the array, then the left sum is 0 because there are no elements to the left. This also applies to the right edge of the array.

Return the leftmost pivot index. If no such index exists, return -1.

 

Example 1:

Input: nums = [1,7,3,6,5,6]
Output: 3
Explanation:
The pivot index is 3.
Left sum = nums[0] + nums[1] + nums[2] = 1 + 7 + 3 = 11
Right sum = nums[4] + nums[5] = 5 + 6 = 11
Example 2:

Input: nums = [1,2,3]
Output: -1
Explanation:
There is no index that satisfies the conditions in the problem statement.
Example 3:

Input: nums = [2,1,-1]
Output: 0
Explanation:
The pivot index is 0.
Left sum = 0 (no elements to the left of index 0)
Right sum = nums[1] + nums[2] = 1 + -1 = 0
 

Constraints:

1 <= nums.length <= 104
-1000 <= nums[i] <= 1000

'''
#Solution

#Method-1
class Solution:
    def pivotIndex(self, nums: List[int]) -> int:
        """
        :type nums: List[int]
        :rtype: int
        """
        sumL = 0
        sumR = sum(nums)
        for i in range(len(nums)):
            sumR -= nums[i]
            if sumL == sumR:
                return i
            sumL += nums[i]
        return -1
        
        
#Method-2

class Solution:
    def pivotIndex(self, nums: List[int]) -> int:
        left = 0
        right = sum(nums)
        for i in range(0,len(nums)):
            if i > 0:
                left += nums[i-1]
            right -= nums[i]
            if left == right:
                break
        else:
            return -1
        return i


#Method-3
#Leftmost
class Solution:
    def pivotIndex(self, nums: List[int]) -> int:
        leftSum=0
        rightSum=0
        # Each time, except for the value of the pivot, we are going to add
        # the numbers to leftSum or to rightSum 
        # There are n-1 numbers summed, where n is the length of the list
        
        # Let's check if the pivot index is at index==0
        # We are going to sum all the numbers from index 1 to index n-1 (end of the array)
        for i in range(1,len(nums)):
            rightSum+=nums[i]
        if rightSum==0:
            return 0 # Pivot index is 0
        # We are going to check if the pivot index is between 1 and n-1
        # We just have to add progressively the numbers from index 0 to n-2 to leftSum
        # For rightSum, we can just progressively subtract
        # the value of the number we want to check if it's the pivot
        for j in range(1,len(nums)):
            leftSum+=nums[j-1]
            rightSum-=nums[j]
            if leftSum==rightSum:
                return j # Pivot index is j
        return -1 # No pivot

#Method-4

class Solution(object):
    def pivotIndex(self, nums):
        S = sum(nums)
        leftsum = 0
        for i, x in enumerate(nums):
            if leftsum == (S - leftsum - x):
                return i
            leftsum += x
        return -1


#Method-5

class Solution:
    def pivotIndex(self, nums: List[int]) -> int:
        length_of_nums = len(nums)
        
        if any(length_of_nums == item for item in [0,2]):
            return -1
        
        start = 0
        end = length_of_nums
        while start < end:
            left_sum = sum(nums[:start]) or 0
            right_sum = sum(nums[start+1:]) or 0
            if left_sum == right_sum:
                return start
            
            start += 1
        return -1
# the time complexity ( I guess would be ) O(N) ( for iterating through nums) + O(k) ( for left slicing) + O(k) for right slicing === O(n + 2k) ~ O(n+k)


#Q8 Majority Element
'''
Given an array nums of size n, return the majority element.

The majority element is the element that appears more than ⌊n / 2⌋ times. You may assume that the majority element always exists in the array.

 

Example 1:

Input: nums = [3,2,3]
Output: 3
Example 2:

Input: nums = [2,2,1,1,1,2,2]
Output: 2
 

Constraints:

n == nums.length
1 <= n <= 5 * 104
-109 <= nums[i] <= 109
 

Follow-up: Could you solve the problem in linear time and in O(1) space?
'''

# Solution 

Approach 1: Brute Force

class Solution:
    def majorityElement(self, nums):
        majority_count = len(nums)//2
        for num in nums:
            count = sum(1 for elem in nums if elem == num)
            if count > majority_count:
                return num
            

# Approach 2: HashMap
class Solution:
    def majorityElement(self, nums):
        counts = collections.Counter(nums)
        return max(counts.keys(), key=counts.get)


# Approach 3: Sorting

class Solution:
    def majorityElement(self, nums):
        nums.sort()
        return nums[len(nums)//2]


# Approach 4: Randomization

import random

class Solution:
    def majorityElement(self, nums):
        majority_count = len(nums)//2
        while True:
            candidate = random.choice(nums)
            if sum(1 for elem in nums if elem == candidate) > majority_count:
                return candidate


# Approach 5: Divide and Conquer

class Solution:
    def majorityElement(self, nums, lo=0, hi=None):
        def majority_element_rec(lo, hi):
            # base case; the only element in an array of size 1 is the majority
            # element.
            if lo == hi:
                return nums[lo]

            # recurse on left and right halves of this slice.
            mid = (hi-lo)//2 + lo
            left = majority_element_rec(lo, mid)
            right = majority_element_rec(mid+1, hi)

            # if the two halves agree on the majority element, return it.
            if left == right:
                return left

            # otherwise, count each element and return the "winner".
            left_count = sum(1 for i in range(lo, hi+1) if nums[i] == left)
            right_count = sum(1 for i in range(lo, hi+1) if nums[i] == right)

            return left if left_count > right_count else right

        return majority_element_rec(0, len(nums)-1)


# Approach 6: Boyer-Moore Voting Algorithm

class Solution:
    def majorityElement(self, nums):
        count = 0
        candidate = None

        for num in nums:
            if count == 0:
                candidate = num
            count += (1 if num == candidate else -1)

        return candidate


# Approach 7:
class Solution:
    def majorityElement(self, nums: List[int]) -> int:
        nums.sort()
        return nums[len(nums)//2]
 
 #Q 9 Fibonacci Number 

'''
 The Fibonacci numbers, commonly denoted F(n) form a sequence, called the Fibonacci sequence, such that each number is the sum of the two preceding ones, starting from 0 and 1. That is,

F(0) = 0, F(1) = 1
F(n) = F(n - 1) + F(n - 2), for n > 1.
Given n, calculate F(n).

 

Example 1:

Input: n = 2
Output: 1
Explanation: F(2) = F(1) + F(0) = 1 + 0 = 1.
Example 2:

Input: n = 3
Output: 2
Explanation: F(3) = F(2) + F(1) = 1 + 1 = 2.
Example 3:

Input: n = 4
Output: 3
Explanation: F(4) = F(3) + F(2) = 2 + 1 = 3.
 

Constraints:

0 <= n <= 30  
'''
# Solution 
#Method-1
class Solution:
    def fib(self, N: int) -> int:
        if N == 0:
            return 0
        if N == 1:
            return 1
        last_two = [1,1]
        counter = 3
        while counter <= N:
            nextfib = last_two[0] + last_two[1]
            last_two[0] = last_two[1]
            last_two[1] = nextfib
            counter += 1
        return last_two[1] 

#Method-2    
class Solution:
    def fib(self,N):
        """
        :type N: int
        :rtype: int
        """        
        a = 0
        b = 1
        if N == 0:
            return 0
        elif N == 1:
            return 1
        else:
            for i in range(2,N+1):
                c = a + b 
                a = b
                b = c
            return b


#Q10 Squares of a Sorted Array

'''

Given an integer array nums sorted in non-decreasing order, return an array of the squares of each number sorted in non-decreasing order.

 

Example 1:

Input: nums = [-4,-1,0,3,10]
Output: [0,1,9,16,100]
Explanation: After squaring, the array becomes [16,1,0,9,100].
After sorting, it becomes [0,1,9,16,100].
Example 2:

Input: nums = [-7,-3,2,3,11]
Output: [4,9,9,49,121]
 

Constraints:

1 <= nums.length <= 104
-104 <= nums[i] <= 104
nums is sorted in non-decreasing order.
 

Follow up: Squaring each element and sorting the new array is very trivial, could you find an O(n) solution using a different approach?
'''

# Solution

#Method-1

class Solution:
    def sortedSquares(self, nums: List[int]) -> List[int]:
        return sorted([x**2 for x in nums])

#Method-2

#Two-pointers O(n) Solution

class Solution:
    def sortedSquares(self, nums: List[int]) -> List[int]:
        arr = [None] * len(nums)
        insert = len(nums) - 1
        left, right = 0, insert
        
        while left <= right:
            leftSqr = nums[left] ** 2
            rightSqr = nums[right] ** 2
            if leftSqr > rightSqr:
                arr[insert] = leftSqr
                left += 1
            else:
                arr[insert] = rightSqr
                right -= 1
            insert -= 1
        
        return arr

#Method-3

class Solution:
    def sortedSquares(self, A):
        """
        :type A: List[int]
        :rtype: List[int]
        """
        l = []
        for i in A:
            l.append(i**2)
        l.sort()
        return l

#Method-4
# Easy to understand solution.
# Time Complexity: O(NlogN)

class Solution(object):
    def sortedSquares(self, A):
        return sorted(list(map(lambda x:pow(abs(x),2),A)))
#OR
class Solution:
    def sortedSquares(self, A):
        return sorted(map(lambda x: x**2, A))


#Method-5

class Solution:
		def sortedSquares(self, A):

			output = []

			if A == []:
				return output

			if A[0] <= 0:
				breakpoint = len(A)
			else:
				breakpoint = 0

			for i in range(len(A)-1):
				if A[i]*A[i+1] <= 0:
					breakpoint = i + 1
					break
			A_neg = A[:breakpoint]
			A_pos = A[breakpoint:]


			for i, element in enumerate(A_neg):
				A_neg[i] = element*element

			A_neg = A_neg[::-1]

			for i, element in enumerate(A_pos):
				A_pos[i] = element*element

			while A_neg != [] and A_pos != []:
				if A_neg[0] > A_pos[0]:
					output  += [A_pos.pop(0)]
				else:
					output  += [A_neg.pop(0)]

			for element in A_neg:
				output += [element]

			for element in A_pos:
				output += [element]

			return output


#Q11 Pascal's Triangle
'''


Given an integer numRows, return the first numRows of Pascal's triangle.

In Pascal's triangle, each number is the sum of the two numbers directly above it as shown:


Example 1:

Input: numRows = 5
Output: [[1],[1,1],[1,2,1],[1,3,3,1],[1,4,6,4,1]]
Example 2:

Input: numRows = 1
Output: [[1]]
 

Constraints:

1 <= numRows <= 30
'''


#Solution 

 #Method-1

class Solution:
    def generate(self, numRows: int) -> List[List[int]]:
        pascal = [[1]]
        for row in range(1, numRows):
            pascal.append([])
            for col in range(row+1):
                if 0 < col < row:
                    num = pascal[row-1][col-1] + pascal[row-1][col]
                else: 
                    num = 1
                pascal[row].append(num)
        return pascal


#Method-2
class Solution:
    def generate(self, numRows: int) -> List[List[int]]:
        
        ans = []
        for i in range(0 , numRows):
            inner = []
            for j in range(0 , i + 1):
                if i == j or j == 0:
                    inner.append(1)
                else:
                    inner.append(ans[i-1][j] + ans[i-1][j-1])
            ans.append(inner)
        return ans



#Method-3
class Solution:
    def generate(self,numRows):
        pascal = [[1]*(i+1) for i in range(numRows)]
        for i in range(numRows):
            for j in range(1,i):
                pascal[i][j] = pascal[i-1][j-1] + pascal[i-1][j]
        return pascal

#Method-4
class Solution:
    def generate(self, numRows):
        """
        :type numRows: int
        :rtype: List[List[int]]
        """
        triangle = [[1]]
        for _ in range(numRows-1):
            curr_level = [1]
            prev_level = triangle[-1]
            for i in range(len(prev_level)-1):
                curr_level.append(prev_level[i] + prev_level[i+1])
            curr_level.append(1)
            triangle += [curr_level]
        return triangle[1:] if not numRows else triangle


#Method-5
class Solution:
    def generate(self, numRows: int) -> List[List[int]]:
        ans = [[1],[1,1]]
        i = 2
        if numRows == 1: return ans[:1]
        if numRows == 2: return ans
        
        while i < numRows:
            i += 1
            ans.append([1]*(len(ans[-1])+1))
            for j in range(1,len(ans[-1])-1):
                ans[-1][j] = ans[-2][j-1] + ans[-2][j]
        
        return ans


#Q12 Remove Duplicates from Sorted Array

'''
Given an integer array nums sorted in non-decreasing order, remove the duplicates in-place such that each unique element appears only once. The relative order of the elements should be kept the same.

Since it is impossible to change the length of the array in some languages, you must instead have the result be placed in the first part of the array nums. More formally, if there are k elements after removing the duplicates, then the first k elements of nums should hold the final result. It does not matter what you leave beyond the first k elements.

Return k after placing the final result in the first k slots of nums.

Do not allocate extra space for another array. You must do this by modifying the input array in-place with O(1) extra memory.

Custom Judge:

The judge will test your solution with the following code:

int[] nums = [...]; // Input array
int[] expectedNums = [...]; // The expected answer with correct length

int k = removeDuplicates(nums); // Calls your implementation

assert k == expectedNums.length;
for (int i = 0; i < k; i++) {
    assert nums[i] == expectedNums[i];
}
If all assertions pass, then your solution will be accepted.

 

Example 1:

Input: nums = [1,1,2]
Output: 2, nums = [1,2,_]
Explanation: Your function should return k = 2, with the first two elements of nums being 1 and 2 respectively.
It does not matter what you leave beyond the returned k (hence they are underscores).
Example 2:

Input: nums = [0,0,1,1,1,2,2,3,3,4]
Output: 5, nums = [0,1,2,3,4,_,_,_,_,_]
Explanation: Your function should return k = 5, with the first five elements of nums being 0, 1, 2, 3, and 4 respectively.
It does not matter what you leave beyond the returned k (hence they are underscores).
 

Constraints:

1 <= nums.length <= 3 * 104
-100 <= nums[i] <= 100
nums is sorted in non-decreasing order.


'''

#Method-1

 class Solution:
    def removeDuplicates(self, nums):
        """
        :type nums: List[int]
        :rtype: int
        """
        len_ = 1
        if len(nums)==0:
            return 0
        for i in range(1,len(nums)):
            if nums[i] != nums[i-1]:
                nums[len_] = nums[i]
                len_ +=1
        return len_
    
#Method-2 

class Solution:
    # @param a list of integers
    # @return an integer
    def removeDuplicates(self, A):
        if len(A) == 0:
            return 0
        temp = A[0]
        n = 1
        for num in A[1:]:
            if num != temp:
                temp = num
                A[n] = num
                n += 1
        A = A[:n]
        return n


#Method-3

class Solution:
    def removeDuplicates(self, nums: List[int]) -> int:
        j = 1
        for i in range(1,len(nums)):
            if(nums[i]!=nums[i-1]):
                print(nums[i])
                
                nums[j] = nums[i]
                
                j+=1
        return j

#Method-4

class Solution(object):
    def removeDuplicates(self, nums):
        """
        :type nums: List[int]
        :rtype: int
        """
        index = 0
        now_num = None
        while index < len(nums):
            if nums[index] == now_num:
                del nums[index]
            else:
                now_num = nums[index]
                index += 1
        return len(nums)

#Method-5

class Solution:
    def removeDuplicates(self, nums: List[int]) -> int:
        i = 1
        
        for j in range(len(nums)-1):
            if nums[j] != nums[j+1]:
                nums[i] = nums[j+1]
                i += 1
        return i



#Mediaum 
# Q13 3Sum

'''
Given an integer array nums, return all the triplets [nums[i], nums[j], nums[k]] such that i != j, i != k, and j != k, and nums[i] + nums[j] + nums[k] == 0.

Notice that the solution set must not contain duplicate triplets.

 

Example 1:

Input: nums = [-1,0,1,2,-1,-4]
Output: [[-1,-1,2],[-1,0,1]]
Explanation: 
nums[0] + nums[1] + nums[2] = (-1) + 0 + 1 = 0.
nums[1] + nums[2] + nums[4] = 0 + 1 + (-1) = 0.
nums[0] + nums[3] + nums[4] = (-1) + 2 + (-1) = 0.
The distinct triplets are [-1,0,1] and [-1,-1,2].
Notice that the order of the output and the order of the triplets does not matter.
Example 2:

Input: nums = [0,1,1]
Output: []
Explanation: The only possible triplet does not sum up to 0.
Example 3:

Input: nums = [0,0,0]
Output: [[0,0,0]]
Explanation: The only possible triplet sums up to 0.
 

Constraints:

3 <= nums.length <= 3000
-105 <= nums[i] <= 105

'''

# Solution 

class Solution:
    def threeSum(self, nums: List[int]) -> List[List[int]]:
        
        #TO REACH THE OPTIMAL SOLUTION YOU HAVE TO SORT AND THEN USE TWO POINTERS INSTEAD OF HASHMAP
        #NOW SORTING IS SECOND INSTINCTIVE REACTION TO SOLVE A PROBLEM THAT DOESNT SEEM TO MOVE AFTER HASHMAP
        
        res = []
        nums.sort(key = lambda x:x)
        
        for  i in range(0,len(nums)-2):
#           [1,-3,-3,2,1]
            if i >0 and nums[i] == nums[i-1]:
                continue
            
            l = i +1
            r = len(nums)-1
            
            while l <r:
                result = nums[i] + nums[l] + nums[r]
                
                #if greater reduce right pointer to reduce the sum and bring closer to zero
                if result > 0 :
                    r = r-1
                
                elif result <0 :
                    l = l +1
                    
                
                else:
                    #DO THIS TO AVOID DUPLICATE 
                    if [nums[i], nums[l], nums[r]] in res:
                        l = l+1
                        r = r-1
                        continue
                    else:
                        res.append([nums[i], nums[l], nums[r]])
                        l = l+1
                        r = r-1
                    
        return res

 #Q14 Product of Array Except Self
'''

 Given an integer array nums, return an array answer such that answer[i] is equal to the product of all the elements of nums except nums[i].

The product of any prefix or suffix of nums is guaranteed to fit in a 32-bit integer.

You must write an algorithm that runs in O(n) time and without using the division operation.

 

Example 1:

Input: nums = [1,2,3,4]
Output: [24,12,8,6]
Example 2:

Input: nums = [-1,1,0,-3,3]
Output: [0,0,9,0,0]
 

Constraints:

2 <= nums.length <= 105
-30 <= nums[i] <= 30
The product of any prefix or suffix of nums is guaranteed to fit in a 32-bit integer.
 

Follow up: Can you solve the problem in O(1) extra space complexity? (The output array does not count as extra space for space complexity analysis.)
'''

# Solution 

# #Method-1

class Solution:
    def productExceptSelf(self, nums: List[int]) -> List[int]:
        leftToRight, rightToLeft = [], []
        N = len(nums)
        for i in range(N):
            if not leftToRight:
                leftToRight.append(nums[i])
            else:
                leftToRight.append(leftToRight[-1] * nums[i])

        for i in range(N - 1, -1 , -1):
            if not rightToLeft:
                rightToLeft.append(nums[i])
            else:
                rightToLeft.insert(0, rightToLeft[0] * nums[i])

        res = []
        for i in range(N):
            if i==0:
                res.append(rightToLeft[i + 1])
            elif i == N - 1:
                res.append(leftToRight[i - 1])
            else:
                res.append(leftToRight[i - 1] * rightToLeft[i + 1])
        return res


#  #Method-2
    
# postfix/prefix array

# The logic revolves around having res hold prefix products from nums[0:i] and then multiply that with postfix products from nums[i+1: len(nums)-1].

# TC - O(n)
# SC - O(n)

class Solution:
    def productExceptSelf(self, nums: List[int]) -> List[int]:
        res = [1] * len(nums)
        
        prefix =1
        for i in range(len(nums)):
            res[i] = prefix
            prefix *= nums[i]
            
        postfix = 1
        for i in range(len(nums) - 1, -1, -1):
            res[i] *= postfix
            postfix *= nums[i]
            
        return res
    

# #Method-3
# #Space Optimized

class Solution:
    def productExceptSelf(self, nums: List[int]) -> List[int]:
        right = 1
        output = [1] * (len(nums))
        for i in range(0, len(nums)-1):
            output[i+1] = output[i] * nums[i]

        for i in range(len(nums)-1, -1, -1):
            output[i] = output[i] * right
            right = right * nums[i]

        return output
    
# # #Method-4
# # #Dynamic Programming  

class Solution:
    def productExceptSelf(self, nums):
        
        if len(nums) < 2:
            return nums
        
        
        ret = [0 for i in range(len(nums))]
    
        '''
        From left to right, construct left-prodcut
        array, i.e., ret[i] = product(nums[0]...nums[i])
        '''
        ret[0] = nums[0]
        for i in range(1,len(nums)-1):
            ret[i] = nums[i] * ret[i-1]
        
        # The right product beyond current index
        rt = 1
    
        '''
        From right to left, ret[i] = ret[i-1] * rt
        '''
        for i in range(len(nums) - 1, 0, -1):
            ret[i] = ret[i-1] * rt
            rt *= nums[i]
        ret[0] = rt   
          
        return ret

# #Method-5

class Solution(object):
    def productExceptSelf(self, nums):
        product = 1
        zeros_index = -1
        output = [0] * len(nums)
        for i in range(len(nums)):
            if nums[i] == 0:
                if zeros_index == -1:
                    zeros_index = i
                else:
                    return [0] * len(nums)
            else:
                product *= nums[i]
        if zeros_index != -1:
            output[zeros_index] = product
        else:
            for i in range(len(nums)):
                output[i] = product // nums[i]
        return output

# Q15 Insert Delete GetRandom O(1)
'''
Implement the RandomizedSet class:

RandomizedSet() Initializes the RandomizedSet object.
bool insert(int val) Inserts an item val into the set if not present. Returns true if the item was not present, false otherwise.
bool remove(int val) Removes an item val from the set if present. Returns true if the item was present, false otherwise.
int getRandom() Returns a random element from the current set of elements (it's guaranteed that at least one element exists when this method is called). Each element must have the same probability of being returned.
You must implement the functions of the class such that each function works in average O(1) time complexity.

 

Example 1:

Input
["RandomizedSet", "insert", "remove", "insert", "getRandom", "remove", "insert", "getRandom"]
[[], [1], [2], [2], [], [1], [2], []]
Output
[null, true, false, true, 2, true, false, 2]

Explanation
RandomizedSet randomizedSet = new RandomizedSet();
randomizedSet.insert(1); // Inserts 1 to the set. Returns true as 1 was inserted successfully.
randomizedSet.remove(2); // Returns false as 2 does not exist in the set.
randomizedSet.insert(2); // Inserts 2 to the set, returns true. Set now contains [1,2].
randomizedSet.getRandom(); // getRandom() should return either 1 or 2 randomly.
randomizedSet.remove(1); // Removes 1 from the set, returns true. Set now contains [2].
randomizedSet.insert(2); // 2 was already in the set, so return false.
randomizedSet.getRandom(); // Since 2 is the only number in the set, getRandom() will always return 2.
 

Constraints:

-231 <= val <= 231 - 1
At most 2 * 105 calls will be made to insert, remove, and getRandom.
There will be at least one element in the data structure when getRandom is called.
'''

# Solution

# Method-1 
# hashmap
# list

class RandomizedSet:    
  
    def __init__(self):
        self.numList = []
        self.numMap = {} # val: index

    def insert(self, val: int) -> bool:
        notPresent = val not in self.numMap
        if notPresent:
            self.numMap[val] = len(self.numList)
            self.numList.append(val)
        return notPresent

    def remove(self, val: int) -> bool:
        present = val in self.numMap
        if present:
            index = self.numMap[val]
            self.numList[index] = self.numList[-1]
            self.numMap[self.numList[-1]] = index
            self.numList.pop()
            del self.numMap[val]
        
        return present
        

    def getRandom(self) -> int:
        return random.choice(self.numList)


# Method-2
# #Solution using HashMap and Array

class RandomizedSet:

    def __init__(self):
        self.numMap = {}
        self.numList = []

    def insert(self, val: int) -> bool:
        
        result = val not in self.numMap
        if result:
            self.numMap[val] = len(self.numList)
            self.numList.append(val)
        return result

    def remove(self, val: int) -> bool:
        result = val in self.numMap
        if result:
            indx = self.numMap[val]
            lastVal = self.numList[-1]
            self.numList[indx] = lastVal
            self.numList.pop()
            self.numMap[lastVal] = indx
            del self.numMap[val]
        return result

    def getRandom(self) -> int:
        return random.choice(self.numList)

# Method-3

#use dictionary for the index and array for value to solve the issue

class RandomizedSet:
    def __init__(self):
        self.map={}
        self.nums=[]
    
    def insert(self, val: int) -> bool:
        if val in self.map :
            return False;
        self.map[val]=len(self.nums)
        self.nums.append(val);
        return True; 
    def remove(self, val: int) -> bool:
        if not val in self.map :
            return False;
        self.nums[self.map[val]]=self.nums[-1]
        self.map[self.nums[-1]]=self.map[val];
        self.nums.pop()
        del self.map[val]
        return True;
    def getRandom(self) -> int:
        return choice(self.nums)


# Method-4
# using list and dict beats 


class RandomizedSet(object):

    def __init__(self):
        """
        Initialize your data structure here.
        """
        self.values = []
        self.positions = {}

    def insert(self, val):
        """
        Inserts a value to the set. Returns true if the set did not already contain the specified element.
        :type val: int
        :rtype: bool
        """
        if val not in self.positions:
            self.values.append(val)
            self.positions[val] = len(self.values) - 1
            return True
        return False
        

    def remove(self, val):
        """
        Removes a value from the set. Returns true if the set contained the specified element.
        :type val: int
        :rtype: bool
        """
        if val in self.positions:
            current_index = self.positions[val]
            last_value = self.values[-1]
			
			# Since we do not care about maintaining the order of elements
			# in self.values, copy the last element of the list to replace the current element with
			# Then pop the list to remove the old copy of the last element
			# This ensures O(1) time complexity
			
            self.values[current_index] = last_value
            self.positions[last_value] = current_index
            self.values.pop()
            del self.positions[val]
			
            return True
			
        return False

    def getRandom(self):
        """
        Get a random element from the set.
        :rtype: int
        """
        if self.values:
            return random.choice(self.values)
        return -1


# Your RandomizedSet object will be instantiated and called as such:
# obj = RandomizedSet()
# param_1 = obj.insert(val)
# param_2 = obj.remove(val)
# param_3 = obj.getRandom()


# Q16 Subarray Sum Equals K
'''
Given an array of integers nums and an integer k, return the total number of subarrays whose sum equals to k.

A subarray is a contiguous non-empty sequence of elements within an array.

 

Example 1:

Input: nums = [1,1,1], k = 2
Output: 2
Example 2:

Input: nums = [1,2,3], k = 3
Output: 2
 

Constraints:

1 <= nums.length <= 2 * 104
-1000 <= nums[i] <= 1000
-107 <= k <= 107
'''

# Sloution

# Method-1
# Using PrefixSum and Dictionary 🔥✌

class Solution:
	def subarraySum(self, nums: List[int], k: int) -> int:

		ans=0
		prefsum=0
		d={0:1}

		for num in nums:
			prefsum = prefsum + num

			if prefsum-k in d:
				ans = ans + d[prefsum-k]

			if prefsum not in d:
				d[prefsum] = 1
			else:
				d[prefsum] = d[prefsum]+1

		return ans

# Method-2    
# using dictionary O(n)

class Solution:
    def subarraySum(self, nums, k):
        """
        :type nums: List[int]
        :type k: int
        :rtype: int
        """
        if not nums: return 0
        ans = 0
        # row sum only j, i is implicit
        # memo[i+1][j] = memo[i][j+1]-nums[i]
        memo = []
        for i in range(1):
            for j in range(i,len(nums)):
                partial_sum = sum(nums[i:j+1])
                if partial_sum == k:
                    ans+=1
                memo.append(partial_sum)
        for i in range(1,len(memo)):
            for j in range(i,len(memo)):
                memo[j]-=memo[i-1]
                if memo[j]==k:
                    ans+=1
        return ans

# Method-3

class Solution:
    def subarraySum(self, nums: List[int], k: int) -> int:
        
        d = {0 : 1}
        
        res, sum_ = 0, 0
        
        for i in nums:
            
            
            sum_ += i
            
            diff = sum_ - k
            
            res += d.get(diff, 0)
            
            d[sum_] = 1 + d.get(sum_, 0)
        
        return res
 

# Method-4

class Solution:
    def subarraySum(self, nums, k):
        d = {0:1}
        res = 0
        s = 0
        for i in nums:
            s += i
            try:
                res += d[s-k]
            except:
                pass
            try:
                d[s] += 1
            except:
                d[s] = 1
        return res
    
# Let sum of index [0,i] be Si, then sum of [i,j] would be Sj - Si.
# Make a list whose index location records the sum from 0 up to that index.

#The HashMap solution is just an improvement of the brute force:

# Method-5
# brute force

class Solution:
    def subarraySum(self, nums, k):
        d = {0:1}
        res = 0
        s = 0
        for i in nums:
            s += i

            for l in d.keys():
				# note that the keys would be the sum from index 0 to any  
				# one of the index in the array, considered Si, and s == Sj
				
				# Conversely speaking, if there exist a range sum Si such that Sj - Si == k,  we can find the number of Si by 
				# accessing the value of Si in the map without any regards to the start and end of the subarray.
                if s - l == k:
                    res += d[l]
            try:
                d[s] += 1
            except:
                d[s] = 1
        return res
# instead of checking all the existing sums, simply reverse the equation from
# s - l == k to s - k = l, and use l as a key to TRY to access the number of sums of subarrays that make up k together with the existing range. Because hashmap is fast on this kind of operation, it is considered O(n)



