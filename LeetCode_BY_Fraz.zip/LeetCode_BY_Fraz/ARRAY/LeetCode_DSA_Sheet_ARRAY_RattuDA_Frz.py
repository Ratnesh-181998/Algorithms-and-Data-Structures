#ARRAY/List


# Q1. Two Sum


'''
Add to List

Given an array of integers nums and an integer target, return indices of the two numbers such that they add up to target.

You may assume that each input would have exactly one solution, and you may not use the same element twice.

You can return the answer in any order.

 

Example 1:

Input: nums = [2,7,11,15], target = 9
Output: [0,1]
Explanation: Because nums[0] + nums[1] == 9, we return [0, 1].
Example 2:

Input: nums = [3,2,4], target = 6
Output: [1,2]
Example 3:

Input: nums = [3,3], target = 6
Output: [0,1]
 

Constraints:

2 <= nums.length <= 104
-109 <= nums[i] <= 109
-109 <= target <= 109
Only one valid answer exists.
 

Follow-up: Can you come up with an algorithm that is less than O(n2) time complexity?
'''
#sloution
#method-1

def two_sum(num):
    target =int(input())
    for i in range(len(num)):
        for j in range(i+1,len(num)):
            if num[i]+num[j]==target:
                return [i,j]

n=int(input())
num=[ ]
for i in range(n):
    ele=int(input())
    num.append(ele)
print(num)
print(two_sum(num))

#method-2

class Solution:
    def twoSum(self, nums: List[int], target: int) -> List[int]:
        for i in range(len(nums)):
            for j in range(i + 1, len(nums)):
                if nums[j] == target - nums[i]:
                    return [i, j]




#Q2. Best Time to Buy and Sell Stock



'''
You are given an array prices where prices[i] is the price of a given stock on the ith day.

You want to maximize your profit by choosing a single day to buy one stock and choosing a different day in the future to sell that stock.

Return the maximum profit you can achieve from this transaction. If you cannot achieve any profit, return 0.

 

Example 1:

Input: prices = [7,1,5,3,6,4]
Output: 5
Explanation: Buy on day 2 (price = 1) and sell on day 5 (price = 6), profit = 6-1 = 5.
Note that buying on day 2 and selling on day 1 is not allowed because you must buy before you sell.
Example 2:

Input: prices = [7,6,4,3,1]
Output: 0
Explanation: In this case, no transactions are done and the max profit = 0.
 

Constraints:

1 <= prices.length <= 105
0 <= prices[i] <= 104
'''
#Solution
#Method-1

def maxProfit(prices):
    left = 0 #Buy
    right = 1 #Sell
    max_profit = 0
    while right < len(prices):
        currentProfit = prices[right] - prices[left] #our current Profit
        if prices[left] < prices[right]:
            max_profit =max(currentProfit,max_profit)
        else:
            left = right
        right += 1
    return max_profit
        
n=int(input())
prices=[ ]
for i in range(n):
    ele=int(input())
    prices.append(ele)
print(prices)
x=maxProfit(prices)
print(x)

#Method-2

class Solution:
    def maxProfit(self,prices):
        left = 0 #Buy
        right = 1 #Sell
        max_profit = 0
        while right < len(prices):
            currentProfit = prices[right] - prices[left] #our current Profit
            if prices[left] < prices[right]:
                max_profit =max(currentProfit,max_profit)
            else:
                left = right
            right += 1
        return max_profit




#Q3 Merge Sorted Array




'''
You are given two integer arrays nums1 and nums2, sorted in non-decreasing order, and two integers m and n, representing the number of elements in nums1 and nums2 respectively.

Merge nums1 and nums2 into a single array sorted in non-decreasing order.

The final sorted array should not be returned by the function, but instead be stored inside the array nums1. To accommodate this, nums1 has a length of m + n, where the first m elements denote the elements that should be merged, and the last n elements are set to 0 and should be ignored. nums2 has a length of n.

 

Example 1:

Input: nums1 = [1,2,3,0,0,0], m = 3, nums2 = [2,5,6], n = 3
Output: [1,2,2,3,5,6]
Explanation: The arrays we are merging are [1,2,3] and [2,5,6].
The result of the merge is [1,2,2,3,5,6] with the underlined elements coming from nums1.
Example 2:

Input: nums1 = [1], m = 1, nums2 = [], n = 0
Output: [1]
Explanation: The arrays we are merging are [1] and [].
The result of the merge is [1].
Example 3:

Input: nums1 = [0], m = 0, nums2 = [1], n = 1
Output: [1]
Explanation: The arrays we are merging are [] and [1].
The result of the merge is [1].
Note that because m = 0, there are no elements in nums1. The 0 is only there to ensure the merge result can fit in nums1.
 

Constraints:

nums1.length == m + n
nums2.length == n
0 <= m, n <= 200
1 <= m + n <= 200
-109 <= nums1[i], nums2[j] <= 109
 

Follow up: Can you come up with an algorithm that runs in O(m + n) time?

'''
# Sloution

#Method-1

class Solution:
    def merge(self, nums1: List[int], m: int, nums2: List[int], n: int) -> None:
    
        i=0
        j=0
        # 2 pointer approach, keeping the second array always sorted
        while nums2 and i<m:
          # If current number present in the first array is smaller than current number in the second array move the first pointer by 1
          if nums1[i]<=nums2[j]:
            i+=1
          # If the current no. in second array is smaller, swap and then sort the second array
          else:
            nums1[i],nums2[j]=nums2[j],nums1[i]
            
            # Sort the second array after swapping elements
            k=1
            temp=nums2[0]
            while k<n and nums2[k]<temp:
              nums2[k-1]=nums2[k]
              k+=1
            nums2[k-1]=temp
            i+=1
        # Appending the sorted second array to the first array
        else:
          while j<n:
            nums1[i]=nums2[j]
            i+=1
            j+=1
        
 #Method-2 
# I used List slicing here for easy to do merging and sorting within the same list without creating a new list.
 class Solution:
    def merge(self, nums1: List[int], m: int, nums2: List[int], n: int) -> None:       
        nums1[:] = nums1[0:m]+nums2[0:n]
        nums1.sort()
        

               
 #Method-3       
               
        # Store nums2 array in second part of nums1
class Solution:
    def merge(self, nums1: List[int], m: int, nums2: List[int], n: int) -> None:
        for i in range(n):
          nums1[m+i]=nums2[i]
        
        # Set gap as ceiling of (m+n)/2
        gap = int(math.ceil((m+n)//2))
        
        
        while gap>=1:
          for i in range(gap,m+n):  
            for j in range(i-gap,-1,-gap):
              # Till previous element is greater, keep swapping current and previous element
              if nums1[j]>nums1[j+gap]:
                nums1[j+gap],nums1[j]=nums1[j],nums1[j+gap]
              else:
                break
                  
          gap = gap//2
        
        
        
 #Method-4       
class Solution:
    def merge(self, nums1: List[int], m: int, nums2: List[int], n: int) -> None:        
        tempNums1 = nums1[:]
        i, j = 0, 0
        index = 0
        while index < len(tempNums1):
            if i > m - 1:
                nums1[index] = nums2[j]
                j += 1
            elif j > n - 1:
                nums1[index] = tempNums1[i]
                i += 1
            elif tempNums1[i] <= nums2[j]:
                nums1[index] = tempNums1[i]
                i += 1
            else:
                nums1[index] = nums2[j]
                j += 1
            index += 1

        
        
        
 #Method-5          
        
        # merge two array from the back
class Solution:
    def merge(self, nums1: List[int], m: int, nums2: List[int], n: int) -> None:
        p1 = m - 1
        p2 = n - 1
        k = m + n - 1
        
        while p1 >= 0 and p2 >= 0:
            if nums1[p1] > nums2[p2]:
                nums1[k] = nums1[p1]
                p1 -= 1
            else: 
                nums1[k] = nums2[p2]
                p2 -= 1
            k -= 1
            
        if p2 >= 0:
            nums1[:k + 1] = nums2[:p2 + 1]



#Q4. Move Zeroes

'''

Given an integer array nums, move all 0's to the end of it while maintaining the relative order of the non-zero elements.

Note that you must do this in-place without making a copy of the array.

Example 1:

Input: nums = [0,1,0,3,12]
Output: [1,3,12,0,0]
Example 2:

Input: nums = [0]
Output: [0]
 

Constraints:

1 <= nums.length <= 104
-231 <= nums[i] <= 231 - 1
 

Follow up: Could you minimize the total number of operations done?

'''
# Sloution 

#Method-1      
#Here's my python solution in O(n) I believe

class Solution:
    def moveZeroes(self, nums):
        """
        :type nums: List[int]
        :rtype: void Do not return anything, modify nums in-place instead.
        """
        pos = 0
        
        for i in range(len(nums)):
            el = nums[i]
            if el != 0:
                nums[pos], nums[i] = nums[i], nums[pos]
                pos += 1 
                
 #Method-2                     
#Python3 Solution:Not fast but easy understand:

class Solution(object):
    def moveZeroes(self, nums):
        append_times=nums.count(0)
        for i in range(append_times):
            nums.remove(0) #  Delete the front zero
            nums.append(0) # append it at the end of nums, the times of the addition and substraction shall be equal
 

#Method-3     
# # Starts from the first element and goes toward the end, if the element is zero, it #pops the element and appends it to the end.

class Solution(object):
    def moveZeroes(self, nums):
        i = count = 0
        while count < len(nums):
            if nums[i] == 0: nums.append(nums.pop(i))
            else: i += 1
            count += 1
            
 
#Method-4      
# #here is my simple python version, the idea is throw 0 to the end of array, and left #shift the array.

class Solution:
    def moveZeroes(self, nums):
        length=len(nums)
        j=0
        for i in range(length-1):
            if(nums[j]==0):
                nums[j:length-1]=nums[j+1:length]
                nums[length-1]=0
            else:
                j+=1
 #Method-5                     
#Do not return anything, modify nums in-place instead.
              
class Solution:
    def moveZeroes(self, nums: List[int]) -> None:
        numsLen = len(nums)
        backTrack = 0
        for x in range(numsLen):
            x = x - backTrack
            if nums[x] == 0:
                backTrack += 1
                nums.pop(x)
                nums.append(0)
            
            
            
#Method-6                  
# #python3 solution without using list methods, because the problem is about arrays:
class Solution:
    def moveZeroes(self, nums):
        i = 0
        j = 0
        while i < len(nums):
            if nums[j] == 0:
                if nums[i] != 0:
                    nums[j] = nums[i]
                    nums[i] = 0
            
                i += 1
            else:
                j += 1




#Q5. Best Time to Buy and Sell Stock II


'''
You are given an integer array prices where prices[i] is the price of a given stock on the ith day.

On each day, you may decide to buy and/or sell the stock. You can only hold at most one share of the stock at any time. However, you can buy it then immediately sell it on the same day.

Find and return the maximum profit you can achieve.

 

Example 1:

Input: prices = [7,1,5,3,6,4]
Output: 7
Explanation: Buy on day 2 (price = 1) and sell on day 3 (price = 5), profit = 5-1 = 4.
Then buy on day 4 (price = 3) and sell on day 5 (price = 6), profit = 6-3 = 3.
Total profit is 4 + 3 = 7.
Example 2:

Input: prices = [1,2,3,4,5]
Output: 4
Explanation: Buy on day 1 (price = 1) and sell on day 5 (price = 5), profit = 5-1 = 4.
Total profit is 4.
Example 3:

Input: prices = [7,6,4,3,1]
Output: 0
Explanation: There is no way to make a positive profit, so we never buy the stock to achieve the maximum profit of 0.
 

Constraints:

1 <= prices.length <= 3 * 104
0 <= prices[i] <= 104
'''

# Solution 
#Method-1

class Solution:
    def maxProfit(self, prices: List[int]) -> int:
        profit = 0
        for i in range(1, len(prices)):
            profit += max(prices[i]-prices[i-1], 0)
        return profit

#Method-2    
class Solution:
    def maxProfit(self, prices: List[int]) -> int:
        max_profit=0
        min_price=prices[0]
        for i in range(1,len(prices)):
            if prices[i]<min_price:
                min_price=prices[i]
            elif max_profit<max_profit+prices[i]-min_price:
                max_profit+=prices[i]-min_price
                min_price=prices[i]
            
        return max_profit

#Method-3
# Why I feel this question is easier than the buy and sell stock version 1:
# Python:

class Solution:
    def maxProfit(self, prices: List[int]) -> int:
        maxPrice = 0
        for i in range(len(prices)-1):
            if prices[i+1] < prices[i]:
                continue
            else:
                maxPrice += prices[i+1] - prices[i]
        return maxPrice
  
 
 #Method-4   
class Solution:
    def maxProfit(self, prices: List[int]) -> int:
        # [7,1,5,3,6,4]
        stack = deque()
        result = 0
        for i,num in enumerate(prices):
            # monotonic decreasing stack, only pop once
            #while stack and num > prices[stack[-1]]:
            if stack and num > prices[stack[-1]]:
                top = stack.pop()
                result += num - prices[top]
            stack.append(i)
        return result


#Method-5
# This problem can also be solved using DP.
# Even O(n^2) should be acceptable for this question but for some reason, I'm getting the time limit exceeded on the last test case.

class Solution:
    def maxProfit(self, prices: List[int]) -> int:
        dp=[0 for i in range(len(prices)+1)]
        for i in range(1,len(prices)+1):
            for j in range(i+1,len(prices)+1):
                dp[j]=max(prices[j-1]-prices[i-1]+dp[i],dp[j],dp[j-1])
        return dp[-1]



#Method-6
# My two pointer solution in python:

class Solution:
    def maxProfit(self, prices: List[int]) -> int:
        i = 0
        profit = 0
        for j in range(1, len(prices)):
            if prices[j] <= prices[j-1]:
                profit += prices[j-1] - prices[i]
                i = j
            if j == len(prices)-1:
                profit += prices[j] - prices[i]
        return profit            


 #Method-7   
class Solution:
    def maxProfit(self, prices: List[int]) -> int:
        profit = 0
        if len(prices)==0:
            return 0
        for i in range(1, len(prices)):
            if prices[i] > prices[i - 1]:
                profit += prices[i] - prices[i-1]
        return profit



#Method-7
class Solution:
    def maxProfit(self, prices: List[int]) -> int:
        profit = 0
        buy = 0
        sell = 0
        hold = 0
        i = 0
        while i < len(prices) - 1:
            if prices[i] < prices[i + 1]:
                if hold == 0:
                    buy = prices[i]
                    hold = 1
            elif prices[i] > prices[i + 1]:
                if hold == 1:
                    sell = prices[i]
                    profit += sell - buy
                    buy = 0
                    hold = 0     
            i += 1
        if hold == 1 and prices[i - 1] <= prices[i]:
            sell = prices[i]
            profit += sell - buy
        return profit
    

 #Method-8   
class Solution:
    def maxProfit(self, prices: List[int]) -> int:
        
        lowidx = 0
        maxprofit = 0
        profit = 0
        
        for idx in range(1,len(prices)):
            if prices[idx] > prices[idx-1]:
                # rising
                profit = prices[idx] - prices[lowidx]
            elif prices[idx] < prices[idx-1]:
                # falling
                maxprofit += profit
                profit = 0
                lowidx = idx
        
        maxprofit += profit
        return maxprofit
 
 #Method-9   
# one line solution in python

class Solution:
    def maxProfit(self, prices: List[int]) -> int:
        profit = sum([prices[ind+1] - prices[ind] for ind in range(len(prices)-1) if (prices[ind+1] - prices[ind]) > 0])

        return profit


#Q6. Running Sum of 1d Array


'''
Given an array nums. We define a running sum of an array as runningSum[i] = sum(nums[0]…nums[i]).

Return the running sum of nums.

 

Example 1:

Input: nums = [1,2,3,4]
Output: [1,3,6,10]
Explanation: Running sum is obtained as follows: [1, 1+2, 1+2+3, 1+2+3+4].
Example 2:

Input: nums = [1,1,1,1,1]
Output: [1,2,3,4,5]
Explanation: Running sum is obtained as follows: [1, 1+1, 1+1+1, 1+1+1+1, 1+1+1+1+1].
Example 3:

Input: nums = [3,1,2,10,1]
Output: [3,4,6,16,17]
 

Constraints:

1 <= nums.length <= 1000
-10^6 <= nums[i] <= 10^6

'''

#Solution 

#Method-1
class Solution:
    def runningSum(self, nums: List[int]) -> List[int]:
        for i in range(1, len(nums)):
            nums[i] += nums[i - 1]
        return nums

#Method-2

class Solution:
    def runningSum(self, nums):
        return [sum(nums[:i+1]) for i in range(len(nums))]

#Method-3
class Solution:
    def runningSum(self, nums: List[int]) -> List[int]:
        output = [nums[0]]
        for i in range (1, len(nums)):
            nums[i] += nums[i - 1]
            output.append(nums[i])
        return output


#Method-4

class Solution:
    def runningSum(self, nums: List[int]) -> List[int]:
        output = []
        for i in range(1, len(nums)+1):
            output.append(sum(nums[:i]))
        return output


#Method-5

class Solution:
    def runningSum(self, nums: List[int]) -> List[int]:
        sum_ = []
        for i in range(1, len(nums)+1):
            sum_.append(sum(nums[:i]))
        return sum_

 
#Q7 Find Pivot Index

'''
Given an array of integers nums, calculate the pivot index of this array.

The pivot index is the index where the sum of all the numbers strictly to the left of the index is equal to the sum of all the numbers strictly to the index's right.

If the index is on the left edge of the array, then the left sum is 0 because there are no elements to the left. This also applies to the right edge of the array.

Return the leftmost pivot index. If no such index exists, return -1.

 

Example 1:

Input: nums = [1,7,3,6,5,6]
Output: 3
Explanation:
The pivot index is 3.
Left sum = nums[0] + nums[1] + nums[2] = 1 + 7 + 3 = 11
Right sum = nums[4] + nums[5] = 5 + 6 = 11
Example 2:

Input: nums = [1,2,3]
Output: -1
Explanation:
There is no index that satisfies the conditions in the problem statement.
Example 3:

Input: nums = [2,1,-1]
Output: 0
Explanation:
The pivot index is 0.
Left sum = 0 (no elements to the left of index 0)
Right sum = nums[1] + nums[2] = 1 + -1 = 0
 

Constraints:

1 <= nums.length <= 104
-1000 <= nums[i] <= 1000

'''
#Solution

#Method-1
class Solution:
    def pivotIndex(self, nums: List[int]) -> int:
        """
        :type nums: List[int]
        :rtype: int
        """
        sumL = 0
        sumR = sum(nums)
        for i in range(len(nums)):
            sumR -= nums[i]
            if sumL == sumR:
                return i
            sumL += nums[i]
        return -1
        
        
#Method-2

class Solution:
    def pivotIndex(self, nums: List[int]) -> int:
        left = 0
        right = sum(nums)
        for i in range(0,len(nums)):
            if i > 0:
                left += nums[i-1]
            right -= nums[i]
            if left == right:
                break
        else:
            return -1
        return i


#Method-3
#Leftmost
class Solution:
    def pivotIndex(self, nums: List[int]) -> int:
        leftSum=0
        rightSum=0
        # Each time, except for the value of the pivot, we are going to add
        # the numbers to leftSum or to rightSum 
        # There are n-1 numbers summed, where n is the length of the list
        
        # Let's check if the pivot index is at index==0
        # We are going to sum all the numbers from index 1 to index n-1 (end of the array)
        for i in range(1,len(nums)):
            rightSum+=nums[i]
        if rightSum==0:
            return 0 # Pivot index is 0
        # We are going to check if the pivot index is between 1 and n-1
        # We just have to add progressively the numbers from index 0 to n-2 to leftSum
        # For rightSum, we can just progressively subtract
        # the value of the number we want to check if it's the pivot
        for j in range(1,len(nums)):
            leftSum+=nums[j-1]
            rightSum-=nums[j]
            if leftSum==rightSum:
                return j # Pivot index is j
        return -1 # No pivot

#Method-4

class Solution(object):
    def pivotIndex(self, nums):
        S = sum(nums)
        leftsum = 0
        for i, x in enumerate(nums):
            if leftsum == (S - leftsum - x):
                return i
            leftsum += x
        return -1


#Method-5

class Solution:
    def pivotIndex(self, nums: List[int]) -> int:
        length_of_nums = len(nums)
        
        if any(length_of_nums == item for item in [0,2]):
            return -1
        
        start = 0
        end = length_of_nums
        while start < end:
            left_sum = sum(nums[:start]) or 0
            right_sum = sum(nums[start+1:]) or 0
            if left_sum == right_sum:
                return start
            
            start += 1
        return -1
# the time complexity ( I guess would be ) O(N) ( for iterating through nums) + O(k) ( for left slicing) + O(k) for right slicing === O(n + 2k) ~ O(n+k)


#Q8 Majority Element
'''
Given an array nums of size n, return the majority element.

The majority element is the element that appears more than ⌊n / 2⌋ times. You may assume that the majority element always exists in the array.

 

Example 1:

Input: nums = [3,2,3]
Output: 3
Example 2:

Input: nums = [2,2,1,1,1,2,2]
Output: 2
 

Constraints:

n == nums.length
1 <= n <= 5 * 104
-109 <= nums[i] <= 109
 

Follow-up: Could you solve the problem in linear time and in O(1) space?
'''

# Solution 

Approach 1: Brute Force

class Solution:
    def majorityElement(self, nums):
        majority_count = len(nums)//2
        for num in nums:
            count = sum(1 for elem in nums if elem == num)
            if count > majority_count:
                return num
            

# Approach 2: HashMap
class Solution:
    def majorityElement(self, nums):
        counts = collections.Counter(nums)
        return max(counts.keys(), key=counts.get)


# Approach 3: Sorting

class Solution:
    def majorityElement(self, nums):
        nums.sort()
        return nums[len(nums)//2]


# Approach 4: Randomization

import random

class Solution:
    def majorityElement(self, nums):
        majority_count = len(nums)//2
        while True:
            candidate = random.choice(nums)
            if sum(1 for elem in nums if elem == candidate) > majority_count:
                return candidate


# Approach 5: Divide and Conquer

class Solution:
    def majorityElement(self, nums, lo=0, hi=None):
        def majority_element_rec(lo, hi):
            # base case; the only element in an array of size 1 is the majority
            # element.
            if lo == hi:
                return nums[lo]

            # recurse on left and right halves of this slice.
            mid = (hi-lo)//2 + lo
            left = majority_element_rec(lo, mid)
            right = majority_element_rec(mid+1, hi)

            # if the two halves agree on the majority element, return it.
            if left == right:
                return left

            # otherwise, count each element and return the "winner".
            left_count = sum(1 for i in range(lo, hi+1) if nums[i] == left)
            right_count = sum(1 for i in range(lo, hi+1) if nums[i] == right)

            return left if left_count > right_count else right

        return majority_element_rec(0, len(nums)-1)


# Approach 6: Boyer-Moore Voting Algorithm

class Solution:
    def majorityElement(self, nums):
        count = 0
        candidate = None

        for num in nums:
            if count == 0:
                candidate = num
            count += (1 if num == candidate else -1)

        return candidate


# Approach 7:
class Solution:
    def majorityElement(self, nums: List[int]) -> int:
        nums.sort()
        return nums[len(nums)//2]
 
 #Q 9 Fibonacci Number 

'''
 The Fibonacci numbers, commonly denoted F(n) form a sequence, called the Fibonacci sequence, such that each number is the sum of the two preceding ones, starting from 0 and 1. That is,

F(0) = 0, F(1) = 1
F(n) = F(n - 1) + F(n - 2), for n > 1.
Given n, calculate F(n).

 

Example 1:

Input: n = 2
Output: 1
Explanation: F(2) = F(1) + F(0) = 1 + 0 = 1.
Example 2:

Input: n = 3
Output: 2
Explanation: F(3) = F(2) + F(1) = 1 + 1 = 2.
Example 3:

Input: n = 4
Output: 3
Explanation: F(4) = F(3) + F(2) = 2 + 1 = 3.
 

Constraints:

0 <= n <= 30  
'''
# Solution 
#Method-1
class Solution:
    def fib(self, N: int) -> int:
        if N == 0:
            return 0
        if N == 1:
            return 1
        last_two = [1,1]
        counter = 3
        while counter <= N:
            nextfib = last_two[0] + last_two[1]
            last_two[0] = last_two[1]
            last_two[1] = nextfib
            counter += 1
        return last_two[1] 

#Method-2    
class Solution:
    def fib(self,N):
        """
        :type N: int
        :rtype: int
        """        
        a = 0
        b = 1
        if N == 0:
            return 0
        elif N == 1:
            return 1
        else:
            for i in range(2,N+1):
                c = a + b 
                a = b
                b = c
            return b


#Q10 Squares of a Sorted Array

'''

Given an integer array nums sorted in non-decreasing order, return an array of the squares of each number sorted in non-decreasing order.

 

Example 1:

Input: nums = [-4,-1,0,3,10]
Output: [0,1,9,16,100]
Explanation: After squaring, the array becomes [16,1,0,9,100].
After sorting, it becomes [0,1,9,16,100].
Example 2:

Input: nums = [-7,-3,2,3,11]
Output: [4,9,9,49,121]
 

Constraints:

1 <= nums.length <= 104
-104 <= nums[i] <= 104
nums is sorted in non-decreasing order.
 

Follow up: Squaring each element and sorting the new array is very trivial, could you find an O(n) solution using a different approach?
'''

# Solution

#Method-1

class Solution:
    def sortedSquares(self, nums: List[int]) -> List[int]:
        return sorted([x**2 for x in nums])

#Method-2

#Two-pointers O(n) Solution

class Solution:
    def sortedSquares(self, nums: List[int]) -> List[int]:
        arr = [None] * len(nums)
        insert = len(nums) - 1
        left, right = 0, insert
        
        while left <= right:
            leftSqr = nums[left] ** 2
            rightSqr = nums[right] ** 2
            if leftSqr > rightSqr:
                arr[insert] = leftSqr
                left += 1
            else:
                arr[insert] = rightSqr
                right -= 1
            insert -= 1
        
        return arr

#Method-3

class Solution:
    def sortedSquares(self, A):
        """
        :type A: List[int]
        :rtype: List[int]
        """
        l = []
        for i in A:
            l.append(i**2)
        l.sort()
        return l

#Method-4
# Easy to understand solution.
# Time Complexity: O(NlogN)

class Solution(object):
    def sortedSquares(self, A):
        return sorted(list(map(lambda x:pow(abs(x),2),A)))
#OR
class Solution:
    def sortedSquares(self, A):
        return sorted(map(lambda x: x**2, A))


#Method-5

class Solution:
		def sortedSquares(self, A):

			output = []

			if A == []:
				return output

			if A[0] <= 0:
				breakpoint = len(A)
			else:
				breakpoint = 0

			for i in range(len(A)-1):
				if A[i]*A[i+1] <= 0:
					breakpoint = i + 1
					break
			A_neg = A[:breakpoint]
			A_pos = A[breakpoint:]


			for i, element in enumerate(A_neg):
				A_neg[i] = element*element

			A_neg = A_neg[::-1]

			for i, element in enumerate(A_pos):
				A_pos[i] = element*element

			while A_neg != [] and A_pos != []:
				if A_neg[0] > A_pos[0]:
					output  += [A_pos.pop(0)]
				else:
					output  += [A_neg.pop(0)]

			for element in A_neg:
				output += [element]

			for element in A_pos:
				output += [element]

			return output


#Q11 Pascal's Triangle
'''


Given an integer numRows, return the first numRows of Pascal's triangle.

In Pascal's triangle, each number is the sum of the two numbers directly above it as shown:


Example 1:

Input: numRows = 5
Output: [[1],[1,1],[1,2,1],[1,3,3,1],[1,4,6,4,1]]
Example 2:

Input: numRows = 1
Output: [[1]]
 

Constraints:

1 <= numRows <= 30
'''


#Solution 

 #Method-1

class Solution:
    def generate(self, numRows: int) -> List[List[int]]:
        pascal = [[1]]
        for row in range(1, numRows):
            pascal.append([])
            for col in range(row+1):
                if 0 < col < row:
                    num = pascal[row-1][col-1] + pascal[row-1][col]
                else: 
                    num = 1
                pascal[row].append(num)
        return pascal


#Method-2
class Solution:
    def generate(self, numRows: int) -> List[List[int]]:
        
        ans = []
        for i in range(0 , numRows):
            inner = []
            for j in range(0 , i + 1):
                if i == j or j == 0:
                    inner.append(1)
                else:
                    inner.append(ans[i-1][j] + ans[i-1][j-1])
            ans.append(inner)
        return ans



#Method-3
class Solution:
    def generate(self,numRows):
        pascal = [[1]*(i+1) for i in range(numRows)]
        for i in range(numRows):
            for j in range(1,i):
                pascal[i][j] = pascal[i-1][j-1] + pascal[i-1][j]
        return pascal

#Method-4
class Solution:
    def generate(self, numRows):
        """
        :type numRows: int
        :rtype: List[List[int]]
        """
        triangle = [[1]]
        for _ in range(numRows-1):
            curr_level = [1]
            prev_level = triangle[-1]
            for i in range(len(prev_level)-1):
                curr_level.append(prev_level[i] + prev_level[i+1])
            curr_level.append(1)
            triangle += [curr_level]
        return triangle[1:] if not numRows else triangle


#Method-5
class Solution:
    def generate(self, numRows: int) -> List[List[int]]:
        ans = [[1],[1,1]]
        i = 2
        if numRows == 1: return ans[:1]
        if numRows == 2: return ans
        
        while i < numRows:
            i += 1
            ans.append([1]*(len(ans[-1])+1))
            for j in range(1,len(ans[-1])-1):
                ans[-1][j] = ans[-2][j-1] + ans[-2][j]
        
        return ans


#Q12 Remove Duplicates from Sorted Array

'''
Given an integer array nums sorted in non-decreasing order, remove the duplicates in-place such that each unique element appears only once. The relative order of the elements should be kept the same.

Since it is impossible to change the length of the array in some languages, you must instead have the result be placed in the first part of the array nums. More formally, if there are k elements after removing the duplicates, then the first k elements of nums should hold the final result. It does not matter what you leave beyond the first k elements.

Return k after placing the final result in the first k slots of nums.

Do not allocate extra space for another array. You must do this by modifying the input array in-place with O(1) extra memory.

Custom Judge:

The judge will test your solution with the following code:

int[] nums = [...]; // Input array
int[] expectedNums = [...]; // The expected answer with correct length

int k = removeDuplicates(nums); // Calls your implementation

assert k == expectedNums.length;
for (int i = 0; i < k; i++) {
    assert nums[i] == expectedNums[i];
}
If all assertions pass, then your solution will be accepted.

 

Example 1:

Input: nums = [1,1,2]
Output: 2, nums = [1,2,_]
Explanation: Your function should return k = 2, with the first two elements of nums being 1 and 2 respectively.
It does not matter what you leave beyond the returned k (hence they are underscores).
Example 2:

Input: nums = [0,0,1,1,1,2,2,3,3,4]
Output: 5, nums = [0,1,2,3,4,_,_,_,_,_]
Explanation: Your function should return k = 5, with the first five elements of nums being 0, 1, 2, 3, and 4 respectively.
It does not matter what you leave beyond the returned k (hence they are underscores).
 

Constraints:

1 <= nums.length <= 3 * 104
-100 <= nums[i] <= 100
nums is sorted in non-decreasing order.


'''

#Method-1

 class Solution:
    def removeDuplicates(self, nums):
        """
        :type nums: List[int]
        :rtype: int
        """
        len_ = 1
        if len(nums)==0:
            return 0
        for i in range(1,len(nums)):
            if nums[i] != nums[i-1]:
                nums[len_] = nums[i]
                len_ +=1
        return len_
    
#Method-2 

class Solution:
    # @param a list of integers
    # @return an integer
    def removeDuplicates(self, A):
        if len(A) == 0:
            return 0
        temp = A[0]
        n = 1
        for num in A[1:]:
            if num != temp:
                temp = num
                A[n] = num
                n += 1
        A = A[:n]
        return n


#Method-3

class Solution:
    def removeDuplicates(self, nums: List[int]) -> int:
        j = 1
        for i in range(1,len(nums)):
            if(nums[i]!=nums[i-1]):
                print(nums[i])
                
                nums[j] = nums[i]
                
                j+=1
        return j

#Method-4

class Solution(object):
    def removeDuplicates(self, nums):
        """
        :type nums: List[int]
        :rtype: int
        """
        index = 0
        now_num = None
        while index < len(nums):
            if nums[index] == now_num:
                del nums[index]
            else:
                now_num = nums[index]
                index += 1
        return len(nums)

#Method-5

class Solution:
    def removeDuplicates(self, nums: List[int]) -> int:
        i = 1
        
        for j in range(len(nums)-1):
            if nums[j] != nums[j+1]:
                nums[i] = nums[j+1]
                i += 1
        return i



#Mediaum 
# Q13 3Sum

'''
Given an integer array nums, return all the triplets [nums[i], nums[j], nums[k]] such that i != j, i != k, and j != k, and nums[i] + nums[j] + nums[k] == 0.

Notice that the solution set must not contain duplicate triplets.

 

Example 1:

Input: nums = [-1,0,1,2,-1,-4]
Output: [[-1,-1,2],[-1,0,1]]
Explanation: 
nums[0] + nums[1] + nums[2] = (-1) + 0 + 1 = 0.
nums[1] + nums[2] + nums[4] = 0 + 1 + (-1) = 0.
nums[0] + nums[3] + nums[4] = (-1) + 2 + (-1) = 0.
The distinct triplets are [-1,0,1] and [-1,-1,2].
Notice that the order of the output and the order of the triplets does not matter.
Example 2:

Input: nums = [0,1,1]
Output: []
Explanation: The only possible triplet does not sum up to 0.
Example 3:

Input: nums = [0,0,0]
Output: [[0,0,0]]
Explanation: The only possible triplet sums up to 0.
 

Constraints:

3 <= nums.length <= 3000
-105 <= nums[i] <= 105

'''

# Solution 

class Solution:
    def threeSum(self, nums: List[int]) -> List[List[int]]:
        
        #TO REACH THE OPTIMAL SOLUTION YOU HAVE TO SORT AND THEN USE TWO POINTERS INSTEAD OF HASHMAP
        #NOW SORTING IS SECOND INSTINCTIVE REACTION TO SOLVE A PROBLEM THAT DOESNT SEEM TO MOVE AFTER HASHMAP
        
        res = []
        nums.sort(key = lambda x:x)
        
        for  i in range(0,len(nums)-2):
#           [1,-3,-3,2,1]
            if i >0 and nums[i] == nums[i-1]:
                continue
            
            l = i +1
            r = len(nums)-1
            
            while l <r:
                result = nums[i] + nums[l] + nums[r]
                
                #if greater reduce right pointer to reduce the sum and bring closer to zero
                if result > 0 :
                    r = r-1
                
                elif result <0 :
                    l = l +1
                    
                
                else:
                    #DO THIS TO AVOID DUPLICATE 
                    if [nums[i], nums[l], nums[r]] in res:
                        l = l+1
                        r = r-1
                        continue
                    else:
                        res.append([nums[i], nums[l], nums[r]])
                        l = l+1
                        r = r-1
                    
        return res

 #Q14 Product of Array Except Self
'''

 Given an integer array nums, return an array answer such that answer[i] is equal to the product of all the elements of nums except nums[i].

The product of any prefix or suffix of nums is guaranteed to fit in a 32-bit integer.

You must write an algorithm that runs in O(n) time and without using the division operation.

 

Example 1:

Input: nums = [1,2,3,4]
Output: [24,12,8,6]
Example 2:

Input: nums = [-1,1,0,-3,3]
Output: [0,0,9,0,0]
 

Constraints:

2 <= nums.length <= 105
-30 <= nums[i] <= 30
The product of any prefix or suffix of nums is guaranteed to fit in a 32-bit integer.
 

Follow up: Can you solve the problem in O(1) extra space complexity? (The output array does not count as extra space for space complexity analysis.)
'''

# Solution 

# #Method-1

class Solution:
    def productExceptSelf(self, nums: List[int]) -> List[int]:
        leftToRight, rightToLeft = [], []
        N = len(nums)
        for i in range(N):
            if not leftToRight:
                leftToRight.append(nums[i])
            else:
                leftToRight.append(leftToRight[-1] * nums[i])

        for i in range(N - 1, -1 , -1):
            if not rightToLeft:
                rightToLeft.append(nums[i])
            else:
                rightToLeft.insert(0, rightToLeft[0] * nums[i])

        res = []
        for i in range(N):
            if i==0:
                res.append(rightToLeft[i + 1])
            elif i == N - 1:
                res.append(leftToRight[i - 1])
            else:
                res.append(leftToRight[i - 1] * rightToLeft[i + 1])
        return res


#  #Method-2
    
# postfix/prefix array

# The logic revolves around having res hold prefix products from nums[0:i] and then multiply that with postfix products from nums[i+1: len(nums)-1].

# TC - O(n)
# SC - O(n)

class Solution:
    def productExceptSelf(self, nums: List[int]) -> List[int]:
        res = [1] * len(nums)
        
        prefix =1
        for i in range(len(nums)):
            res[i] = prefix
            prefix *= nums[i]
            
        postfix = 1
        for i in range(len(nums) - 1, -1, -1):
            res[i] *= postfix
            postfix *= nums[i]
            
        return res
    

# #Method-3
# #Space Optimized

class Solution:
    def productExceptSelf(self, nums: List[int]) -> List[int]:
        right = 1
        output = [1] * (len(nums))
        for i in range(0, len(nums)-1):
            output[i+1] = output[i] * nums[i]

        for i in range(len(nums)-1, -1, -1):
            output[i] = output[i] * right
            right = right * nums[i]

        return output
    
# # #Method-4
# # #Dynamic Programming  

class Solution:
    def productExceptSelf(self, nums):
        
        if len(nums) < 2:
            return nums
        
        
        ret = [0 for i in range(len(nums))]
    
        '''
        From left to right, construct left-prodcut
        array, i.e., ret[i] = product(nums[0]...nums[i])
        '''
        ret[0] = nums[0]
        for i in range(1,len(nums)-1):
            ret[i] = nums[i] * ret[i-1]
        
        # The right product beyond current index
        rt = 1
    
        '''
        From right to left, ret[i] = ret[i-1] * rt
        '''
        for i in range(len(nums) - 1, 0, -1):
            ret[i] = ret[i-1] * rt
            rt *= nums[i]
        ret[0] = rt   
          
        return ret

# #Method-5

class Solution(object):
    def productExceptSelf(self, nums):
        product = 1
        zeros_index = -1
        output = [0] * len(nums)
        for i in range(len(nums)):
            if nums[i] == 0:
                if zeros_index == -1:
                    zeros_index = i
                else:
                    return [0] * len(nums)
            else:
                product *= nums[i]
        if zeros_index != -1:
            output[zeros_index] = product
        else:
            for i in range(len(nums)):
                output[i] = product // nums[i]
        return output

# Q15 Insert Delete GetRandom O(1)
'''
Implement the RandomizedSet class:

RandomizedSet() Initializes the RandomizedSet object.
bool insert(int val) Inserts an item val into the set if not present. Returns true if the item was not present, false otherwise.
bool remove(int val) Removes an item val from the set if present. Returns true if the item was present, false otherwise.
int getRandom() Returns a random element from the current set of elements (it's guaranteed that at least one element exists when this method is called). Each element must have the same probability of being returned.
You must implement the functions of the class such that each function works in average O(1) time complexity.

 

Example 1:

Input
["RandomizedSet", "insert", "remove", "insert", "getRandom", "remove", "insert", "getRandom"]
[[], [1], [2], [2], [], [1], [2], []]
Output
[null, true, false, true, 2, true, false, 2]

Explanation
RandomizedSet randomizedSet = new RandomizedSet();
randomizedSet.insert(1); // Inserts 1 to the set. Returns true as 1 was inserted successfully.
randomizedSet.remove(2); // Returns false as 2 does not exist in the set.
randomizedSet.insert(2); // Inserts 2 to the set, returns true. Set now contains [1,2].
randomizedSet.getRandom(); // getRandom() should return either 1 or 2 randomly.
randomizedSet.remove(1); // Removes 1 from the set, returns true. Set now contains [2].
randomizedSet.insert(2); // 2 was already in the set, so return false.
randomizedSet.getRandom(); // Since 2 is the only number in the set, getRandom() will always return 2.
 

Constraints:

-231 <= val <= 231 - 1
At most 2 * 105 calls will be made to insert, remove, and getRandom.
There will be at least one element in the data structure when getRandom is called.
'''

# Solution

# Method-1 
# hashmap
# list

class RandomizedSet:    
  
    def __init__(self):
        self.numList = []
        self.numMap = {} # val: index

    def insert(self, val: int) -> bool:
        notPresent = val not in self.numMap
        if notPresent:
            self.numMap[val] = len(self.numList)
            self.numList.append(val)
        return notPresent

    def remove(self, val: int) -> bool:
        present = val in self.numMap
        if present:
            index = self.numMap[val]
            self.numList[index] = self.numList[-1]
            self.numMap[self.numList[-1]] = index
            self.numList.pop()
            del self.numMap[val]
        
        return present
        

    def getRandom(self) -> int:
        return random.choice(self.numList)


# Method-2
# #Solution using HashMap and Array

class RandomizedSet:

    def __init__(self):
        self.numMap = {}
        self.numList = []

    def insert(self, val: int) -> bool:
        
        result = val not in self.numMap
        if result:
            self.numMap[val] = len(self.numList)
            self.numList.append(val)
        return result

    def remove(self, val: int) -> bool:
        result = val in self.numMap
        if result:
            indx = self.numMap[val]
            lastVal = self.numList[-1]
            self.numList[indx] = lastVal
            self.numList.pop()
            self.numMap[lastVal] = indx
            del self.numMap[val]
        return result

    def getRandom(self) -> int:
        return random.choice(self.numList)

# Method-3

#use dictionary for the index and array for value to solve the issue

class RandomizedSet:
    def __init__(self):
        self.map={}
        self.nums=[]
    
    def insert(self, val: int) -> bool:
        if val in self.map :
            return False;
        self.map[val]=len(self.nums)
        self.nums.append(val);
        return True; 
    def remove(self, val: int) -> bool:
        if not val in self.map :
            return False;
        self.nums[self.map[val]]=self.nums[-1]
        self.map[self.nums[-1]]=self.map[val];
        self.nums.pop()
        del self.map[val]
        return True;
    def getRandom(self) -> int:
        return choice(self.nums)


# Method-4
# using list and dict beats 


class RandomizedSet(object):

    def __init__(self):
        """
        Initialize your data structure here.
        """
        self.values = []
        self.positions = {}

    def insert(self, val):
        """
        Inserts a value to the set. Returns true if the set did not already contain the specified element.
        :type val: int
        :rtype: bool
        """
        if val not in self.positions:
            self.values.append(val)
            self.positions[val] = len(self.values) - 1
            return True
        return False
        

    def remove(self, val):
        """
        Removes a value from the set. Returns true if the set contained the specified element.
        :type val: int
        :rtype: bool
        """
        if val in self.positions:
            current_index = self.positions[val]
            last_value = self.values[-1]
			
			# Since we do not care about maintaining the order of elements
			# in self.values, copy the last element of the list to replace the current element with
			# Then pop the list to remove the old copy of the last element
			# This ensures O(1) time complexity
			
            self.values[current_index] = last_value
            self.positions[last_value] = current_index
            self.values.pop()
            del self.positions[val]
			
            return True
			
        return False

    def getRandom(self):
        """
        Get a random element from the set.
        :rtype: int
        """
        if self.values:
            return random.choice(self.values)
        return -1


# Your RandomizedSet object will be instantiated and called as such:
# obj = RandomizedSet()
# param_1 = obj.insert(val)
# param_2 = obj.remove(val)
# param_3 = obj.getRandom()


# Q16 Subarray Sum Equals K
'''
Given an array of integers nums and an integer k, return the total number of subarrays whose sum equals to k.

A subarray is a contiguous non-empty sequence of elements within an array.

 

Example 1:

Input: nums = [1,1,1], k = 2
Output: 2
Example 2:

Input: nums = [1,2,3], k = 3
Output: 2
 

Constraints:

1 <= nums.length <= 2 * 104
-1000 <= nums[i] <= 1000
-107 <= k <= 107
'''

# Sloution

# Method-1
# Using PrefixSum and Dictionary 🔥✌

class Solution:
	def subarraySum(self, nums: List[int], k: int) -> int:

		ans=0
		prefsum=0
		d={0:1}

		for num in nums:
			prefsum = prefsum + num

			if prefsum-k in d:
				ans = ans + d[prefsum-k]

			if prefsum not in d:
				d[prefsum] = 1
			else:
				d[prefsum] = d[prefsum]+1

		return ans

# Method-2    
# using dictionary O(n)

class Solution:
    def subarraySum(self, nums, k):
        """
        :type nums: List[int]
        :type k: int
        :rtype: int
        """
        if not nums: return 0
        ans = 0
        # row sum only j, i is implicit
        # memo[i+1][j] = memo[i][j+1]-nums[i]
        memo = []
        for i in range(1):
            for j in range(i,len(nums)):
                partial_sum = sum(nums[i:j+1])
                if partial_sum == k:
                    ans+=1
                memo.append(partial_sum)
        for i in range(1,len(memo)):
            for j in range(i,len(memo)):
                memo[j]-=memo[i-1]
                if memo[j]==k:
                    ans+=1
        return ans

# Method-3

class Solution:
    def subarraySum(self, nums: List[int], k: int) -> int:
        
        d = {0 : 1}
        
        res, sum_ = 0, 0
        
        for i in nums:
            
            
            sum_ += i
            
            diff = sum_ - k
            
            res += d.get(diff, 0)
            
            d[sum_] = 1 + d.get(sum_, 0)
        
        return res
 

# Method-4

class Solution:
    def subarraySum(self, nums, k):
        d = {0:1}
        res = 0
        s = 0
        for i in nums:
            s += i
            try:
                res += d[s-k]
            except:
                pass
            try:
                d[s] += 1
            except:
                d[s] = 1
        return res
    
# Let sum of index [0,i] be Si, then sum of [i,j] would be Sj - Si.
# Make a list whose index location records the sum from 0 up to that index.

#The HashMap solution is just an improvement of the brute force:

# Method-5
# brute force

class Solution:
    def subarraySum(self, nums, k):
        d = {0:1}
        res = 0
        s = 0
        for i in nums:
            s += i

            for l in d.keys():
				# note that the keys would be the sum from index 0 to any  
				# one of the index in the array, considered Si, and s == Sj
				
				# Conversely speaking, if there exist a range sum Si such that Sj - Si == k,  we can find the number of Si by 
				# accessing the value of Si in the map without any regards to the start and end of the subarray.
                if s - l == k:
                    res += d[l]
            try:
                d[s] += 1
            except:
                d[s] = 1
        return res
# instead of checking all the existing sums, simply reverse the equation from
# s - l == k to s - k = l, and use l as a key to TRY to access the number of sums of subarrays that make up k together with the existing range. Because hashmap is fast on this kind of operation, it is considered O(n)


#Q18  Next Permutation


'''
A permutation of an array of integers is an arrangement of its members into a sequence or linear order.

For example, for arr = [1,2,3], the following are considered permutations of arr: [1,2,3], [1,3,2], [3,1,2], [2,3,1].
The next permutation of an array of integers is the next lexicographically greater permutation of its integer. More formally, if all the permutations of the array are sorted in one container according to their lexicographical order, then the next permutation of that array is the permutation that follows it in the sorted container. If such arrangement is not possible, the array must be rearranged as the lowest possible order (i.e., sorted in ascending order).

For example, the next permutation of arr = [1,2,3] is [1,3,2].
Similarly, the next permutation of arr = [2,3,1] is [3,1,2].
While the next permutation of arr = [3,2,1] is [1,2,3] because [3,2,1] does not have a lexicographical larger rearrangement.
Given an array of integers nums, find the next permutation of nums.

The replacement must be in place and use only constant extra memory.

 

Example 1:

Input: nums = [1,2,3]
Output: [1,3,2]
Example 2:

Input: nums = [3,2,1]
Output: [1,2,3]
Example 3:

Input: nums = [1,1,5]
Output: [1,5,1]
 

Constraints:

1 <= nums.length <= 100
0 <= nums[i] <= 100

'''
# Solution

# Method-1

class Solution(object):
    def nextPermutation(self, nums):
        """
        :type nums: List[int]
        :rtype: void Do not return anything, modify nums in-place instead.
        """
        
        if len(nums) == 1:
            return
        
        i = len(nums) - 1
        while i > 0:
            if nums[i] > nums[i - 1]: # look for the first ascedent incident backwardly
                
                AJ = nums[i] # look for the 'just' larger than a[i - 1] element in a[i:len(nums)]
                j = i
                for m in range(i, len(nums)):
                    if nums[m] <= AJ and nums[m] > nums[i-1]:
                        AJ = nums[m]
                        j = m
                nums[j], nums[i - 1] = nums[i - 1], nums[j] # switch
                
                nums[i:] = nums[len(nums) - 1:(i - 1):-1] # reverse new a[i:len(nums)]
                return
            i = i - 1
            
             
        else:
            nums[:] = nums[::-1] # reverse the whole list
            return
        
        
# Method-2
# Two pointer approach

class Solution:
    def nextPermutation(self, nums: List[int]) -> None:
        """
        Do not return anything, modify nums in-place instead.
        """
        
        end = len(nums)-1
        while end > 0 and nums[end] <= nums[end-1]:
            end -= 1
        
        if end > 0:
            pointer = len(nums)-1
            while nums[pointer] <= nums[end-1]:
                pointer -= 1
            
            nums[end-1], nums[pointer] = nums[pointer], nums[end-1]
            
        nums[end:] = reversed(nums[end:]) # reversed or sorted both work or  reverse list using two pointer swap method.
        
 

# Method-3

# Explanation

# Going over a few examples to derive a pattern

# a) Increasing monotonic

# 1,2,3,4 -> swap the last two -> 1,2,4,3

# b) Decreasing monotonic

# 4,3,2,1 -> return the sorted

# c) Bitonic sequence

# Scan the array to find the last peak ie where the array goes down from increasing to decreasing order

# ie in e.g [1,2,3,1,2,5,3,1,0], the last peak is element 5 after which the array is decreasing

# So the case can be simplified as increasing until 5 and decreasing thereafter.

# Using e.g a) and b) above, we can write the rules as

# i) Apply swapping rule for until 5 (Increasing sequence)

# There is a small trick here though, in increasing sequence e.g 1,2,3,9 we swapped 3 and 9 to get next perm, since 9 is the next highest number for 3.
# So likewise we find what is the next highest number for '2' (idx 4) [1,2,3,1,2,5,3,1,0]. So that instead of swapping 2(idx 4) and 5 (idx 5), we should swap 2 with the next highest number
# which is 3.

# So applying this rule, the array will become [1,2,3,1,3,5,2,1,0]

# ii) Apply sorting for elements after 5 (Decreasing sequence)

# So the array becomes: [1,2,3,1,3,5,0,1,2], which is the next permutation for [1,2,3,1,2,5,3,1,0].

class Solution(object):
    def nextPermutation(self, nums):
        """
        :type nums: List[int]
        :rtype: void Do not return anything, modify nums in-place instead.
        """
        last_peak = None

        for i in range(1 if nums else 0, len(nums)):
            last_peak = i - 1 if nums[i] > nums[i-1] else last_peak

        if last_peak is not None:
            min_idx = last_peak + 1 + min((val, idx) for idx, val in enumerate(nums[last_peak+1:]) if val > nums[last_peak])[1]
            nums[min_idx], nums[last_peak] = nums[last_peak], nums[min_idx]
            nums[:] = nums[:last_peak+1]+sorted(nums[last_peak+1:])
        else:
            nums[:] = nums[::-1]

            
# Method-4            
# Using pivot


class Solution(object):
    def nextPermutation(self, nums):
        """
        :type nums: List[int]
        :rtype: None Do not return anything, modify nums in-place instead.
        """
        N = len(nums)
        pivot = -1
        
        for i in range(N-1,0,-1):
            if nums[i-1]<nums[i]:
                pivot = i-1
                break
                
        if pivot > -1:
            for i in range(N-1,pivot,-1):
                if nums[i] > nums[pivot]:
                    nums[i], nums[pivot] = nums[pivot], nums[i]
                    break
            
            nums[pivot+1:N] = nums[pivot+1:N][::-1]
        else:
            nums.sort()


# Method-5
# Time O(n)/Memory O(1)

class Solution:
    def nextPermutation(self, nums: List[int]) -> None:
        i=j=len(nums)-1
        while i>0 and nums[i-1]>=nums[i]: i-=1
        if i>0:
            while nums[j]<=nums[i-1]: j-=1
            nums[i-1],nums[j]=nums[j],nums[i-1] 
        nums[i:]=nums[i:][::-1]


#Q19   Spiral Matrix

'''
Given an m x n matrix, return all elements of the matrix in spiral order.

 

Example 1:


Input: matrix = [[1,2,3],[4,5,6],[7,8,9]]
Output: [1,2,3,6,9,8,7,4,5]
Example 2:


Input: matrix = [[1,2,3,4],[5,6,7,8],[9,10,11,12]]
Output: [1,2,3,4,8,12,11,10,9,5,6,7]
 

Constraints:

m == matrix.length
n == matrix[i].length
1 <= m, n <= 10
-100 <= matrix[i][j] <= 100



'''

#Solution 

# Method-1

class Solution:
    def spiralOrder(self, matrix: List[List[int]]) -> List[int]:
        res = []
        l , r = 0 , len(matrix[0])
        t , b = 0 , len(matrix)
        
        while l < r and t < b:
            
            for i in range(l, r):
                res.append(matrix[t][i])
            t += 1
            
            for i in range(t, b):
                res.append(matrix[i][r - 1])
            r -= 1
            
            if not (l < r and t < b):
                break
            
            for i in range(r - 1, l - 1, -1):
                res.append(matrix[b - 1][i])
            b -= 1
            
            for i in range(b - 1, t - 1, -1):
                res.append(matrix[i][l])
            l += 1
        return res

    
# Method-2

# using zip

class Solution:
    def spiralOrder(self, matrix: List[List[int]]) -> List[int]:
        a = []
        while matrix:
            a.extend(matrix.pop(0))
            matrix = list(zip(*matrix))[::-1]
        return a

    
# Method-3

class Solution:
    def spiralOrder(self, matrix: List[List[int]]) -> List[int]:
        
        left,right = 0,len(matrix[0])
        top,bottom = 0,len(matrix)
        
        result = []
        
        while left < right and top < bottom:
            
#           Cover Top Row
            for i in range(left,right):
                result.append(matrix[top][i])
            top += 1
            
#           Cover Right Col
            for i in range(top,bottom):
                result.append(matrix[i][right-1])
            right -= 1
            
            if not (left < right and top < bottom):
                break
                
#           Traverse Bottom Row
            for i in range(right-1,left-1,-1):
                result.append(matrix[bottom-1][i])
            bottom -= 1
            
#           Traverse Left Col
            for i in range(bottom-1,top-1,-1):
                result.append(matrix[i][left])
            left += 1
        
        return result
 
# Method-4

class Solution:
    def spiralOrder(self, matrix: List[List[int]]) -> List[int]:
        res = []
        if len(matrix) == 0:
            return res
        row_begin = 0
        col_begin = 0
        row_end = len(matrix)-1 
        col_end = len(matrix[0])-1
        while (row_begin <= row_end and col_begin <= col_end):
            for i in range(col_begin,col_end+1):
                res.append(matrix[row_begin][i])
            row_begin += 1
            for i in range(row_begin,row_end+1):
                res.append(matrix[i][col_end])
            col_end -= 1
            if (row_begin <= row_end):
                for i in range(col_end,col_begin-1,-1):
                    res.append(matrix[row_end][i])
                row_end -= 1
            if (col_begin <= col_end):
                for i in range(row_end,row_begin-1,-1):
                    res.append(matrix[i][col_begin])
                col_begin += 1
        return res

# Q19 Container With Most Water
'''

You are given an integer array height of length n. There are n vertical lines drawn such that the two endpoints of the ith line are (i, 0) and (i, height[i]).

Find two lines that together with the x-axis form a container, such that the container contains the most water.

Return the maximum amount of water a container can store.

Notice that you may not slant the container

Example 1:


Input: height = [1,8,6,2,5,4,8,3,7]
Output: 49
Explanation: The above vertical lines are represented by array [1,8,6,2,5,4,8,3,7]. In this case, the max area of water (blue section) the container can contain is 49.
Example 2:

Input: height = [1,1]
Output: 1
 

Constraints:

n == height.length
2 <= n <= 105
0 <= height[i] <= 104
'''
#Solution 



#Method-1

class Solution:
    def maxArea(self, height: List[int]) -> int:
        left = 0
        right = len(height) - 1
        ans = 0
        
        while left < right:
            if height[left] > height[right]:
                ans = max(ans, height[right] * (right - left))
                right -= 1
            else:
                ans = max(ans, height[left] * (right - left))
                left += 1
        
        return ans

#Method-2
# Using two pointers, shift the pointer with the least value. Basically, if l * r > res, then res = l * r. Afterwards, return res.

class Solution:
    def maxArea(self, height: List[int]) -> int:
        l, r = 0, len(height) - 1
        res = 0

        while l < r:
            res = max(res, min(height[l], height[r]) * (r - l))
            if height[l] < height[r]:
                l += 1
            elif height[r] <= height[l]:
                r -= 1
        return res
# O(n) time
# O(1) space


#Method-3
# Brute force solution tests every pair and computes the container with most water.

class Solution:
    def maxArea(self, height):
        """
        :type height: List[int]
        :rtype: int
        """
        N = len(height)
        max_water = -1
        for i in range(N):
            for j in range(i+1,N):
                max_water = max(max_water, min(height[i], height[j])*(j-i))
        return max_water


    
    
# Two Pointer

# O(N) solution which is explained in editorial. Why the solution works needs some thought.
# Use two pointers start and end initialized at 0 and N-1
# Now compute the area implied by these pointers as (end-start) * min (height[start], height[end])
# if height[start] < height[end], start = start + 1 else end = end -1
# Why? Imagine height[start] < height[end]. Then is there any need to compare height[end-1] with height[start]? There is no way we can now get a larger area using height[start] as one of the end points. We should therefore move start.

class Solution(object):
    def maxArea(self, height):
        """
        :type height: List[int]
        :rtype: int
        """
        s, e = 0, len(height)-1
        max_water = -1
        while s < e:
            max_water = max(max_water, (e-s)*min(height[s], height[e]))
            if height[s] < height[e]:
                s = s+1
            else:
                e = e-1
        return max_water
#Another 
class Solution:
    def maxArea(self, height: List[int]) -> int:
        
        l, r, maxi = 0, len(height)-1, 0
        
        while l < r:
       
            maxi = max(maxi, min(height[l], height[r])*(r-l))
            if height[l] < height[r]: l += 1
            else: r -= 1
        
        return maxi




#Another 
class Solution:
    def maxArea(self, height):
        """
        :type height: List[int]
        :rtype: int
        """
        l = []
        i = 0
        j = len(height) - 1
        while j > i:
            if height[i] > height[j]:
                l.append(height[j] * (j - i))
                j -= 1
            else:
                l.append(height[i] * (j - i))
                i += 1
        return max(l)

#Q 20 Rotate Image
'''
You are given an n x n 2D matrix representing an image, rotate the image by 90 degrees (clockwise).

You have to rotate the image in-place, which means you have to modify the input 2D matrix directly. DO NOT allocate another 2D matrix and do the rotation.

 

Example 1:


Input: matrix = [[1,2,3],[4,5,6],[7,8,9]]
Output: [[7,4,1],[8,5,2],[9,6,3]]
Example 2:


Input: matrix = [[5,1,9,11],[2,4,8,10],[13,3,6,7],[15,14,12,16]]
Output: [[15,13,2,5],[14,3,4,1],[12,6,8,9],[16,7,10,11]]
 

Constraints:

n == matrix.length == matrix[i].length
1 <= n <= 20
-1000 <= matrix[i][j] <= 1000
'''

#Solution 

#Method-1

# It's a math trick where we first determine the matrix's transpose, then we reverse all the rows, and when we compare them, we can see that they have been rotated by 90 degrees.

class Solution:
    def rotate(self, mat: List[List[int]]) -> None:
        """
        Do not return anything, modify matrix in-place instead.
        """
        n = len(mat)
        
        # here we convert the matrix into its transpose
        for i in range(n-1):
            for j in range(i+1,n):
                mat[i][j],mat[j][i] = mat[j][i],mat[i][j]
        
        # now we reverse all the rows
        for i in range(n):
            mat[i] = mat[i][::-1]

#Method-2
# here are two steps two this problem which make it actually a very easy problem if you are comfortable with swapping values in matrices.

# Step 1) Transpose the matrix (rows become columns, columns become rows)
# Step 2) Reverse each row

# Time Comp = O(N^2)
# Space Comp = O(1)

class Solution:
    def rotate(self, matrix: List[List[int]]) -> None:
        """
        Do not return anything, modify matrix in-place instead.
        """
        
        #first transpose the matrix
        # then reverse each row.
        
        n = len(matrix)
        for row in range(n):
            for col in range(row):
                matrix[row][col], matrix[col][row] = matrix[col][row], matrix[row][col]
        
        for row in matrix:
            row.reverse()

#Method-3           

class Solution:
    def rotate(self, matrix: List[List[int]]) -> None:
        
        mat1=matrix.copy()
        for i in range(len(matrix)):
            mat=[]
            for j in range(len(matrix)-1,-1,-1):
                mat.append(mat1[j][i])
                matrix[i]=mat        

 
#Method-4

class Solution:
    def rotate(self, matrix):
        n = len(matrix)
        for i in range(n):
            for k in range(0, n - 1 - i):
                matrix[i][k], matrix[n - 1 - k][n - 1 - i] = matrix[n - 1 - k][n - 1 - i], matrix[i][k]
        for j in range(n):
            for k in range(n//2):
                    matrix[k][j], matrix[n - 1 - k][j] = matrix[n - 1 - k][j], matrix[k][j]



#Method-5

class Solution:
    def rotate(self, matrix: List[List[int]]) -> None:
        n = len(matrix) - 1
        for i in range(len(matrix)//2):
            gen = ([(i+j,i),(i,(n+i)-j),(n+i,i+j),((n+i)-j,n+i)] for j in range(n))
            for which in gen:
                temp = matrix[which[0][0]][which[0][1]]
                matrix[which[0][0]][which[0][1]] = matrix[which[2][0]][which[2][1]]
                matrix[which[2][0]][which[2][1]] = matrix[which[3][0]][which[3][1]]
                matrix[which[3][0]][which[3][1]] = matrix[which[1][0]][which[1][1]]
                matrix[which[1][0]][which[1][1]] = temp
            n-=2
        return matrix


#Q21 Word Search
'''
Given an m x n grid of characters board and a string word, return true if word exists in the grid.

The word can be constructed from letters of sequentially adjacent cells, where adjacent cells are horizontally or vertically neighboring. The same letter cell may not be used more than once.

 

Example 1:


Input: board = [["A","B","C","E"],["S","F","C","S"],["A","D","E","E"]], word = "ABCCED"
Output: true
Example 2:


Input: board = [["A","B","C","E"],["S","F","C","S"],["A","D","E","E"]], word = "SEE"
Output: true
Example 3:


Input: board = [["A","B","C","E"],["S","F","C","S"],["A","D","E","E"]], word = "ABCB"
Output: false
 

Constraints:

m == board.length
n = board[i].length
1 <= m, n <= 6
1 <= word.length <= 15
board and word consists of only lowercase and uppercase English letters.
 

Follow up: Could you use search pruning to make your solution faster with a larger board?
'''

#Solution 

#Method-1
#index search

class Solution:
    def exist(self, board: List[List[str]], word: str) -> bool:
        m = len(board)
        n = len(board[0])
        
        def check(i, j):
            return 0 <= i < m and 0 <= j < n
        
        def search(i, j, indx):
            if indx == len(word):
                return True
            if not check(i, j) or board[i][j] != word[indx]:
                return
            board[i][j] = "*"
            for nx, ny in [[i+1, j], [i-1, j], [i, j+1], [i, j-1]]:
                if search(nx, ny, indx+1):
                    return True
            board[i][j] = word[indx]
            return False
        
        for i in range(m):
            for j in range(n):  
                if board[i][j] == word[0]:
                    if search(i, j, 0):
                        return True
        return False

    
#Method-2
#DFS solution
# Time Limit Exceeded

class Solution:
    # @param board, a list of lists of 1 length string
    # @param word, a string
    # @return a boolean
    # 3:42
    def exist(self, board, word):
        visited = {}

        for i in range(len(board)):
            for j in range(len(board[0])):
                if self.getWords(board, word, i, j, visited):
                    return True
        
        return False

    def getWords(self, board, word, i, j, visited, pos = 0):
        if pos == len(word):
            return True

        if i < 0 or i == len(board) or j < 0 or j == len(board[0]) or visited.get((i, j)) or word[pos] != board[i][j]:
            return False

        visited[(i, j)] = True
        res = self.getWords(board, word, i, j + 1, visited, pos + 1) \
                or self.getWords(board, word, i, j - 1, visited, pos + 1) \
                or self.getWords(board, word, i + 1, j, visited, pos + 1) \
                or self.getWords(board, word, i - 1, j, visited, pos + 1)
        visited[(i, j)] = False

        return res
    
#Method-3

# Backtracing

class Solution(object):
    def exist(self, board, word):
        if board==[]:
            return 0
        
        for r in range(len(board)):
             for c in range(len(board[0])):
                    if board[r][c]==word[0]:
                        if self.helper(board[:],word[1:],r,c):
                            return True
        return False
        
    def helper(self,board,word,r,c):
        if word=="":
            return True
    
        tmp=board[r][c]
        board[r][c]="#"
        #print r,c,board,word
    
        if r-1>=0 and board[r-1][c]==word[0]:
             if self.helper(board[:],word[1:],r-1,c):
                return True

        if r+1<=len(board)-1 and board[r+1][c]==word[0]:
            if self.helper(board[:],word[1:],r+1,c):
                return True
        
        if c-1>=0 and board[r][c-1]==word[0]:
            if self.helper(board[:],word[1:],r,c-1):
                return True
    
        if c+1<=len(board[0])-1 and board[r][c+1]==word[0]:
             if self.helper(board[:],word[1:],r,c+1):
                return True
    
        board[r][c]=tmp
        return False


#Method-4
#Recursive DFS Solution

class Solution:
    def dfs(self,board,index,recursionStack,word,i,j):
        #we will do dfs from the index i,j in order to complete the word on the board
        if index == len(word)-1:
            return True
        recursionStack.add((i,j))
        result = False
        if i > 0:
            if (i-1,j) not in recursionStack and board[i-1][j] == word[index+1]:
                result = result or self.dfs(board,index+1,recursionStack,word,i-1,j)
        if i < len(board)-1:
            if (i+1,j) not in recursionStack and board[i+1][j] == word[index+1]:
                result = result or self.dfs(board,index+1,recursionStack,word,i+1,j)
        if j > 0:
            if (i,j-1) not in recursionStack and board[i][j-1] == word[index+1]:
                result = result or self.dfs(board,index+1,recursionStack,word,i,j-1)
        if j < len(board[0])-1:
            if (i,j+1) not in recursionStack and board[i][j+1] == word[index+1]:
                result = result or self.dfs(board,index+1,recursionStack,word,i,j+1)
        recursionStack.remove((i,j))
        return result
    def exist(self, board: List[List[str]], word: str) -> bool:
        for i in range(len(board)):
            for j in range(len(board[0])):
                if board[i][j] == word[0]:
                    if self.dfs(board,0,set({}),word,i,j):
                        return True
        return False

#Method-5
#BackTrack
#Time Limit Exceeded
class Solution:
    def exist(self, board: List[List[str]], word: str) -> bool:
        # Solution - backtrack
        # Time - O(M*N*W)
        # Space - O(M*N)
        
        self.diList = [[1, 0], [-1, 0], [0, -1], [0, 1]]
        visited = [[0] * len(board[0]) for i in range(len(board))]
        
        for i in range(len(board)):
            for j in range(len(board[0])):
                if self.backtrack(i, j, 0, board, visited, word):
                    return True
        
        return False
    
    def backtrack(self, i, j, wi, board, visited, word):
        if i < 0 or i >= len(board) or j < 0 or j >= len(board[0]) or visited[i][j] != 0:
            return wi >= len(word) 
        
        if wi >= len(word):
            return True
        
        if board[i][j] != word[wi]:
            return False
        
        visited[i][j] = 1
        for di, dj in self.diList:
            x, y = i + di, j + dj
            
            if self.backtrack(x, y, wi + 1, board, visited, word):
                return True
        
        visited[i][j] = 0
        return False

#Q22  3Sum Closest

'''
Given an integer array nums of length n and an integer target, find three integers in nums such that the sum is closest to target.

Return the sum of the three integers.

You may assume that each input would have exactly one solution.

 

Example 1:

Input: nums = [-1,2,1,-4], target = 1
Output: 2
Explanation: The sum that is closest to the target is 2. (-1 + 2 + 1 = 2).
Example 2:

Input: nums = [0,0,0], target = 1
Output: 0
 

Constraints:

3 <= nums.length <= 1000
-1000 <= nums[i] <= 1000
-104 <= target <= 104

'''

#Method-1

class Solution:
    def threeSumClosest(self, nums: List[int], target: int) -> int:
        def partition(a ,low,high):
            i = low-1
            piv = a[high]
            for j in range(low,high):
                if a[j] < piv:
                    i+=1
                    a[i],a[j] = a[j] , a[i]
                    
            a[high],a[i+1] = a[i+1], a[high]
        
            return i +1
        
        def quicksort(a, low, high):
            if low <high:
                pivInd = partition(a,low,high)
                quicksort(a,low, pivInd-1)
                quicksort(a,pivInd+1, high)
                
        
        quicksort(nums, 0, len(nums)-1)
        print(nums)
        
        min_dist = 999999
        minsum = 0
        for i in range(len(nums)-2):
            sub = nums[i+1:]
            
            low = 0
            high = len(sub) - 1
            
            
            
            while low <high:
                summ = nums[i] + sub[low] + sub[high]
                if summ > target:
                    if summ - target < min_dist:
                        min_dist = summ-target
                        minsum = summ
                    high-=1
                    
                elif summ < target:
                    
                    if target - summ < min_dist:
                        min_dist = target-summ
                        minsum = summ
                
                    low +=1
                    
                else:
                    return summ
                
        return minsum

    
#Method-2
#Modified Kth Sum

# This solution is a modification of kth sum solution found here.

# Solution:
# Start by sorting nums. Then, recursively pick a number until you picked k-2 numbers and only if the result isn't equal to the target yet. To avoid duplication, you can only pick from subsequent numbers after the previously picked number.

# We will use the two pointers technique to picks the last two numbers. Initialize the left pointers to the index of the last picked number adding 1 and the right pointers to the end of nums. If the sum of all values including at both pointers are less than the target, increment the left pointer by 1. Else, if the sum of all values including at both pointers are greater than the taget, decrement the right pointer by 1. Else, we have found the cloest sum to the target and thus, we return.

# Complexity:
# Time: O(n**k)
# Space: O(1)

from math import inf

class Solution:
    def threeSumClosest(self, nums: list[int], target: int) -> int:

        # Initialize the result
        res = inf

        # Sort nums so it is easier to avoid duplication
        nums = sorted(nums)

        # k-sum backtracking
        def backtrack(k=3, start=0, partialTotal=0):
            nonlocal res

            # While k hasn't reach 2
            if k != 2:

                # Pick a number from nums starting from the index of the previously picked number plus 1
                for i in range(start, len(nums)):

                    # If result is equal to target, we can stop the search
                    if res == target:
                        return

                    # To avoid duplication, we skip any number that is the same as the previous number
                    if i > start and nums[i] == nums[i - 1]:
                        continue

                    # Pick a number recursively
                    backtrack(k - 1, i + 1, partialTotal + nums[i])

                return

            # Once we have picked k - 2 numbers
            # Initialize the left and right pointers
            l, r = start, len(nums) - 1

            # Iterate until both pointers crossed
            while l < r:

                # Add all values including at both pointers together
                total = partialTotal + nums[l] + nums[r]

                # The current sum is closer to the target than the previous sum, save it
                res = total if abs(target - total) < abs(target - res) else res

                # If the current sum is greater than the target, decrement the right pointer
                if total > target:
                    r -= 1

                # If the current sum is lesser than the target, increment the left pointer
                elif total < target:
                    l += 1

                # Else, we have the cloest possible sum
                else:
                    return

        backtrack()

        return res
    
#Method-3

class Solution:
    def threeSumClosest(self, nums: List[int], target: int) -> int:
        nums.sort()
        ans = 100000
        n = len(nums)
        for i in range(n-2):
            x = nums[i] + nums[-2] + nums[-1]
            if x < target:
                if abs(x-target) < abs(ans-target):
                    ans = x
                continue
            y = nums[i] + nums[i+1] + nums[i+2]
            if y > target:
                if abs(y-target) < abs(ans-target):
                    ans = y
                break
            a=nums[i]
            k = i+1
            e = n-1
            while k < e:
                s = nums[k] + nums[e]
                if s==target-a:
                    return target
                if abs(s+a-target)<abs(ans-target):
                    ans=s+a
                if s < target-a:
                    k += 1
                else:
                    e -= 1
        return ans

    
#Method-4
#Two Pointers, use bisect.
#Use binary search to initialize lo. (low of the two pointers).

class Solution(object):
    def threeSumClosest(self, nums, target):
        f = lambda x: abs(x - target)
        ans, n, nums = float('inf'), len(nums), sorted(nums)
        for i in range(n-2):
            if nums[i] >= target + abs(ans-target): 
                break
            hi, x =  n - 1, target - nums[i] - nums[n-1]
            lo = bisect.bisect_left(nums, x, i + 1, hi) - 1 #binary search
            lo += (lo == i)
            while lo < hi :
                sum = nums[i] + nums[lo] + nums[hi]
                if sum == target:  
                    return sum
                ans = min(ans, sum, key = f)
                hi -= sum > target
                lo += sum < target
        return ans

    
#Method-5    
#Two pointers and min heap
#Time Limit Exceeded
import heapq
class Solution:
    def threeSumClosest(self, nums: List[int], target: int) -> int:
        heap = []
        nums = sorted(nums)
        for i in range(len(nums)):
            j, k = i + 1 ,len(nums) - 1

            if i > 0 and nums[i] == nums[i - 1]: continue

            while j < k:
                if k < len(nums) - 1 and nums[k] == nums[k + 1]:
                    k -= 1
                    continue

                # Insert into heap: O(log n) for each item
                sigma = nums[i] + nums[j] + nums[k]
                diff = abs(target - sigma)
                heapq.heappush(heap, (diff, sigma))

                if sigma > target:
                    k -= 1
                elif sigma < target:
                    j += 1
                else:
                    j += 1
                    k -= 1

        return heapq.heappop(heap)[1]

    
#Method-5
#Time Limit Exceeded
class Solution:
    def threeSumClosest(self, nums: List[int], target: int) -> int:
        ans = float('inf')
        nums.sort()
        for x in range(len(nums)-2):
            y, z = x+1, len(nums)-1
            while z>y:
                sum3 = nums[x]+nums[y]+nums[z]
                if sum3 == target:
                    return target
                if abs(ans-target)>abs(sum3-target):
                    ans = sum3
                if sum3 < target:
                    y+=1
                else:
                    z-=1
        return ans

#Q23  Game of Life

'''
According to Wikipedia's article: "The Game of Life, also known simply as Life, is a cellular automaton devised by the British mathematician John Horton Conway in 1970."

The board is made up of an m x n grid of cells, where each cell has an initial state: live (represented by a 1) or dead (represented by a 0). Each cell interacts with its eight neighbors (horizontal, vertical, diagonal) using the following four rules (taken from the above Wikipedia article):

Any live cell with fewer than two live neighbors dies as if caused by under-population.
Any live cell with two or three live neighbors lives on to the next generation.
Any live cell with more than three live neighbors dies, as if by over-population.
Any dead cell with exactly three live neighbors becomes a live cell, as if by reproduction.
The next state is created by applying the above rules simultaneously to every cell in the current state, where births and deaths occur simultaneously. Given the current state of the m x n grid board, return the next state.

 

Example 1:


Input: board = [[0,1,0],[0,0,1],[1,1,1],[0,0,0]]
Output: [[0,0,0],[1,0,1],[0,1,1],[0,1,0]]
Example 2:


Input: board = [[1,1],[1,0]]
Output: [[1,1],[1,1]]
 

Constraints:

m == board.length
n == board[i].length
1 <= m, n <= 25
board[i][j] is 0 or 1.
 

Follow up:

Could you solve it in-place? Remember that the board needs to be updated simultaneously: You cannot update some cells first and then use their updated values to update other cells.
In this question, we represent the board using a 2D array. In principle, the board is infinite, which would cause problems when the active area encroaches upon the border of the array (i.e., live cells reach the border). How would you address these problems?

'''

# Solution

#Method-1
# use positive int and negative int to distinguish live and dead
# The absolute value is the count of neighbors live cells
# Time O(n)
# Space O(1)

class Solution:
    def gameOfLife(self, board: List[List[int]]) -> None:
        """
        Do not return anything, modify board in-place instead.
        """
        n, m = len(board), len(board[0])
        def check(i:int, j:int) -> int:
            if i < 0 or i >= n or j < 0 or j >= m:
                return 0
            if board[i][j] > 0:
                return 1
            return 0
        def count(i:int, j:int) -> None:
            cnt = sum([check(ii,jj) for ii,jj in 
                       [
                           (i-1,j-1),(i-1,j),(i,j-1),(i-1,j+1),
                           (i+1,j+1),(i+1,j),(i,j+1),(i+1,j-1),
                       ]
                      ])
            if board[i][j] > 0:
                board[i][j] = max(cnt,1)#key: keep live cell with 0 neighbor still live in a moment
            else:
                board[i][j] = -cnt
        def update(i:int, j:int) -> None:
            live_neighbors = abs(board[i][j])
            if board[i][j] > 0:# live cell
                if live_neighbors < 2 or live_neighbors > 3:
                    board[i][j] = 0
                else:
                    board[i][j] = 1
            else:# dead cell
                if live_neighbors == 3:
                    board[i][j] = 1
                else:
                    board[i][j] = 0
        for i in range(n):
            for j in range(m):
                count(i,j)
        for i in range(n):
            for j in range(m):
                update(i,j)
                
#Method-2

class Solution:
    def gameOfLife(self, board: List[List[int]]) -> None:
        """
        Do not return anything, modify board in-place instead.
        """
        dire = [(0,1),(0,-1),(1,0),(-1,0),(1,1),(1,-1),(-1,1),(-1,-1)]
        m = len(board)
        n = len(board[0])
        state = [[0]*n for i in range(m)]

        def invalid(i,j):
            return i < 0 or j <0 or i == m or j == n

        def neigh(i,j):
            for dx,dy in dire:
                if not invalid(i+dx,j+dy) and board[i+dx][j+dy]:
                    state[i][j] += 1

        for i in range(m):
            for j in range(n):
                neigh(i,j)

        for i in range(m):
            for j in range(n):
                if board[i][j] == 1 and state[i][j] < 2:
                    board[i][j] = 0
                if board[i][j] == 1 and  state[i][j] > 3:
                    board[i][j] = 0
                if board[i][j] == 0 and state[i][j] == 3:
                    board[i][j] = 1
                    
                    
#Method-3                   
class Solution:
    def gameOfLife(self, board):
        changeList = set()
                
        def judge(x, y):
            live = 0
            for spot in [(0,1),(0,-1),(1,0),(-1,0),(1,1),(1,-1),(-1,1),(-1,-1)]:
                newx, newy = x+spot[0], y+spot[1]
                if newx < 0 or newx >= len(board) or newy < 0 or newy >= len(board[0]): continue
                if board[newx][newy] == 1: live += 1
            if live < 2:
                if board[x][y] == 1: changeList.add((x,y))
            elif live == 3:
                if board[x][y] == 0: changeList.add((x,y))
            elif live > 3:
                if board[x][y] == 1: changeList.add((x,y))
  
        for i in range(len(board)):
            for j in range(len(board[0])):
                judge(i,j)
        
        for pair in changeList:
            x, y = pair[0], pair[1]
            board[x][y] = 1 if board[x][y] == 0 else 0
            
#Method-4
# For O(1) space, the idea is to use 2 and 3 to represent changed states for each board element, and use modulo to test for original state value when getting live neighbor counts. Then do a final pass over the board to change 2 to 1 and 3 to 0.

def gameOfLife(self, board):
    """
    :type board: List[List[int]]
    :rtype: void Do not return anything, modify board in-place instead.
    """
    ############################################
    # 0, 1 = unchanged, 2 = 0 to 1, 3 = 1 to 0 #
    ############################################
    if not any(board):
        return
    m = len(board)
    n = len(board[0])

    for i in range(m):
        for j in range(n):
            count = self.getNeighbors(board, i, j, m, n)
            if board[i][j] == 1:
                if count < 2 or count > 3:
                    board[i][j] = 3
            else:
                if count == 3:
                    board[i][j] = 2

    for i in range(m):
        for j in range(n):
            if board[i][j] == 2:
                board[i][j] = 1
            if board[i][j] == 3:
                board[i][j] = 0

def getNeighbors(self, board, i, j, m, n):
    count = 0
    if i > 0:
        if j > 0:
            count += 1 if board[i-1][j-1] & 1 else 0
        count += 1 if board[i-1][j] & 1 else 0
        if j < n-1:
            count += 1 if board[i-1][j+1] & 1 else 0
    if i < m-1:
        if j > 0:
            count += 1 if board[i+1][j-1] & 1 else 0
        count += 1 if board[i+1][j] & 1 else 0
        if j < n-1:
            count += 1 if board[i+1][j+1] & 1 else 0
    if j > 0:
        count += 1 if board[i][j-1] & 1 else 0
    if j < n-1:
        count += 1 if board[i][j+1] & 1 else 0
    return count


            
#Method-5
#Using DFS technique

class Solution(object):
    def gameOfLife(self, board):
        """
        :type board: List[List[int]]
        :rtype: None Do not return anything, modify board in-place instead.
        """
        row=len(board) # length of row
        col=len(board[0]) # length of column
        def dfs(x,y):
            # The dx and dy list combine to make all possible moves for an index (x,y)
            dx=[-1,0,1,0,-1,1,-1,1] 
            dy=[0,-1,0,1,-1,1,1,-1]
            count=0
            for i in range(len(dx)):
                p=x+dx[i]
                q=y+dy[i]
                if not (p<0 or p>=row or q<0 or q>=col):
                    if board[p][q]==1: 
                        count+=1
            return count
        
        l=[]
        for i in range(row):
            for j in range(col):
                c=dfs(i,j)
                if c<2:
                    l.append([i,j,0])
                elif (c==2 or c==3) and board[i][j]==1:
                    l.append([i,j,1])
                elif c>3:
                    l.append([i,j,0])
                elif c==3:
                    l.append([i,j,1])
        
        for i in range(len(l)):
            x=l[i][0]
            y=l[i][1]
            v=l[i][2]
            board[x][y]=v
            
            
            
#Method-6

class Solution(object):
    def gameOfLife(self, board):
        """
        :type board: List[List[int]]
        :rtype: None Do not return anything, modify board in-place instead.
        """
        
        m, n = len(board), len(board[0])
        if m == 0 or n==0:
            return
        
        grid = [[0 for _ in range(n)] for _ in range(m)]
        
        directions = [ [1, 0], [0, 1], [-1, 0], [0, -1], 
                      [1, 1], [1, -1], [-1, 1], [-1, -1] ]
        
        for x in range(m):
            for y in range(n):
                grid[x][y] = board[x][y]
        
        def next_state(x, y, neighbours):
            element = grid[x][y]
            
            if element == 0:
                if neighbours == 3:
                    return 1
                else:
                    return 0
            
            else:
                if neighbours < 2:
                    return 0
                elif neighbours == 2 or neighbours == 3:
                    return 1
                elif neighbours > 3:
                    return 0
        
        def valid(x, y):
            return (0 <= x < m) and (0 <= y < n)
        
        def helper(x, y):
            curr = grid[x][y]
            neighbours = 0
            
            for dx, dy in directions:
                nx, ny = x + dx, y + dy
                if valid(nx, ny):
                    neighbours += grid[nx][ny]
            
            board[x][y] = next_state(x, y, neighbours)
                
        
        for x in range(m):
            for y in range(n):
                helper(x, y)
                

#Q24 Pairs of Songs With Total Durations Divisible by 60

'''
You are given a list of songs where the ith song has a duration of time[i] seconds.

Return the number of pairs of songs for which their total duration in seconds is divisible by 60. Formally, we want the number of indices i, j such that i < j with (time[i] + time[j]) % 60 == 0.

 

Example 1:

Input: time = [30,20,150,100,40]
Output: 3
Explanation: Three pairs have a total duration divisible by 60:
(time[0] = 30, time[2] = 150): total duration 180
(time[1] = 20, time[3] = 100): total duration 120
(time[1] = 20, time[4] = 40): total duration 60
Example 2:

Input: time = [60,60,60]
Output: 3
Explanation: All three pairs have a total duration of 120, which is divisible by 60.
 

Constraints:

1 <= time.length <= 6 * 104
1 <= time[i] <= 500

'''
# Solution


# Method-1
# modular arithmetic again

class Solution:
    # (time[i] + time[j]) % 60 == 0 -> time[i] % 60 = 60 - time[j] % 60
    # practically a hash table + two sum problem
    # if key[i] + key[j] = 60
    # Possible pairs:
    # if key[i] != key[j]: contribution = hash_table[key[i]]*hash_table[key[j]]
    # else: contribution = hash_table[key[i]]*(hash_table[key[i]] - 1) // 2
    def numPairsDivisibleBy60(self, time: List[int]) -> int:
        count, result = [0]*60, 0
        for t in time:
            count[t % 60] += 1
        for i in range(31):
            if i == 0 or i == 30:
                result += count[i]*(count[i]-1)//2
            else:
                result += count[i]*count[60-i]
        return result
    
#Method-2
#dictionary

class Solution:
    def numPairsDivisibleBy60(self, time: List[int]) -> int:
        time = [t % 60 for t in time]
        dic = defaultdict(int)
        for t in time : 
            dic[t] +=1
            
        counter = (dic[0] * (dic[0]-1)) //2 +(dic[30] * (dic[30]-1)) //2
        for i in range(1,30):
            counter += dic[i] * dic[60-i]
        return counter

#Method-3    
#Simple Hashmap

class Solution:
    def numPairsDivisibleBy60(self, time):
        dict1, total = Counter([i%60 for i in time]), 0
        for i in range(31):
            if i == 0 or i == 30:
                total += dict1[i]*(dict1[i] - 1)//2
            else:
                total += dict1[i]*dict1[60-i]
    
        return total
    

#Method-4       
#Using HashSet

class Solution:
    def numPairsDivisibleBy60(self, time: List[int]) -> int:
        hmap = collections.Counter(t % 60 for t in time)
        result = (hmap.get(0, 0) * (hmap.get(0, 0) - 1)) // 2  + (hmap.get(30, 0) * (hmap.get(30, 0) - 1)) // 2
        
        visited = set([30, 0])
        for time, count in hmap.items():
            if time not in visited:
                result += hmap.get(time, 0) * hmap.get(60 - time, 0)
                visited.add(time)
                visited.add(60 - time)
        return result

#Method-5 
#O(n) time, O(n) space

class Solution:
    # Return the greatest number which is a multiple of 60 which is closest to n
    def numClosestTo60(self, n):
        # n + 1 is used to handle cases when n is itself a multiple of 60
        # for that we simply return the next number which is a multiple of 60
        return math.ceil((n+1)/60)*60
    
    def numPairsDivisibleBy60(self, time: List[int]) -> int:
        count = 0
        n = len(time)
        
        hsh = dict()
        
        for t in time:
            N = self.numClosestTo60(t)
            
            # N is guaranteed to be a multiple of 60
            for k in range(N,1001,60):
                P = abs(k - t)
                # Check if the difference exists in the input list
                if P in hsh:
                    if (P + t)%60 == 0:
                        count += hsh[P]
            
            # Add the value to the hash map
            hsh[t] = hsh.get(t,0) + 1
            
        return count

#Method-6    
#Save Count of Pair

class Solution:
    def numPairsDivisibleBy60(self, time: List[int]) -> int:
        res = 0
        arr = [0 for _ in range(60)]
        for dur in (dur % 60 for dur in time):
            pair = 0 if dur == 0 else 60 - dur
            res += arr[pair]
            arr[dur] += 1
        return res

#Q24 4Sum

'''
Given an array nums of n integers, return an array of all the unique quadruplets [nums[a], nums[b], nums[c], nums[d]] such that:

0 <= a, b, c, d < n
a, b, c, and d are distinct.
nums[a] + nums[b] + nums[c] + nums[d] == target
You may return the answer in any order.

 

Example 1:

Input: nums = [1,0,-1,0,-2,2], target = 0
Output: [[-2,-1,1,2],[-2,0,0,2],[-1,0,0,1]]
Example 2:

Input: nums = [2,2,2,2,2], target = 8
Output: [[2,2,2,2]]
 

Constraints:

1 <= nums.length <= 200
-109 <= nums[i] <= 109
-109 <= target <= 109

'''

# Solution 
#Method-1
#Using Two-Pointer approach

class Solution:
    def fourSum(self, nums: List[int], target: int) -> List[List[int]]:
        nums.sort()
        ll=[]
        for i in range(len(nums)):
            if i>0 and nums[i]==nums[i-1]:
                continue
            for j in range(i+1,len(nums)):
                if j>i+1 and nums[j]==nums[j-1]:
                    continue
                f=j+1
                l=len(nums)-1
                sum=0
                
                while f<l:
                    sum=nums[i]+nums[j]+nums[f]+nums[l]                
                    if sum>target:
                        l=l-1
                    elif sum<target:
                        f=f+1
                    else:
                        ll.append([nums[i],nums[j],nums[f],nums[l]])
                        val=nums[f]
                        while f<l and nums[f]==val:
                            f=f+1
                        val=nums[l]
                        while f<l and nums[l]==val:
                            l=l-1
        return ll
    

#Method-2
#hash and sets. 

class Solution:
    def fourSum(self, nums: List[int], target: int) -> List[List[int]]:
        # brute force is by creating 4 for loops and using a set to store result.
        
        size = len(nums)
        
        # we need to apply the same logic we used in two Sum
        
        # pro-gamer anti time complexity attack
        magic = nums[0]
        for i in range(size):
            if magic != nums[i] or size < 4:
                break
            if i == size -1:
                if magic * 4 == target:
                    return [[magic, magic, magic, magic]]
        
        # we need to sort to handle the output better (1,3,2,5) is the same as (1,2,5,3)
        # this even applies for creating pairs. Sorting is super important for this problem
        nums.sort()
        
        # we will create all possible pairs.
        pairs = {}
        
        for i in range(size):
            for j in range(i, size):
                if i == j:
                    continue
                key = nums[i] + nums[j]
                if key not in pairs:
                    pairs[key] = [(i, j)]
                else:
                    pairs[key] = pairs[key] + [(i, j)]
        
        # a time complexity attack could be found by exploiting your results set, LOL O(N⁴), literally this is leetcode being leetcode. WOw, my solution was perfect. 
        
        results = {}
        
        for i in range(size):
            for j in range(i, size):
                if i == j: continue
                number = target - (nums[i] + nums[j])
                if number in pairs:
                    for pair in pairs[number]:
                        if pair[0] > j:
                            results[((nums[i], nums[j], nums[pair[0]], nums[pair[1]]))] = True

        return results.keys()
    
    
#Method-3
#Two pointer like 3 Sum ||| O(n3)

class Solution:
    def fourSum(self, nums: List[int], target: int) -> List[List[int]]:
        ans = []
        nums.sort()
        for i in range(len(nums)):
            if i and nums[i] == nums[i-1]:
                continue
            for j in range(i+1 , len(nums)):
                if j != i+1 and nums[j] == nums[j-1]:
                    continue
                p = target - nums[i]-nums[j]
                l = j+1
                r = len(nums)-1
                while l<r:
                    if nums[l]+nums[r] == p:
                        k = [nums[i] , nums[j] , nums[l] , nums[r]]
                        ans.append(k)
                        l+=1
                        while l<len(nums) and  nums[l] == nums[l-1] :
                            l+=1
                        r-=1
                        while r>-1 and  nums[r] == nums[r+1]:
                            r-=1
                    elif nums[l]+nums[r] < p:
                        l+=1
                        while l < len(nums) and nums[l] == nums[l-1]:
                            l+=1
                    else:
                        r-=1
                        while r>-1and  nums[r] == nums[r+1]:
                            r-=1
        return ans
    
#Method-4
# First sort the array, loop over the first two indices i & j, and the problem reduces to the 2Sum problem, i.e., finding two indices k & l such that nums[k]+nums[l] == target - nums[i] - nums[j], which takes O(N) time. The total time complexity is then O(N^3).

class Solution(object):
    def fourSum(self, nums, target):
        """
        :type nums: List[int]
        :type target: int
        :rtype: List[List[int]]
        """
        N = len(nums)
        if N < 4:
            return []
        res = []
        nums = sorted(nums)
        i = 0
        for i in range(N-3):
            if 0 < i < N-3 and nums[i] == nums[i-1]:
                continue        
            for j in range(i+1,N-2):
                if i+1 < j < N-2 and nums[j] == nums[j-1]:
                    continue
                k = j+1
                l = N-1
                while k < l:
                    summ = nums[i]+nums[j]+nums[k]+nums[l]
                    if summ == target:
                        res.append([nums[i],nums[j],nums[k],nums[l]])
                        while k < N-1 and nums[k] == nums[k+1]:
                            k += 1
                        while l > 0 and nums[l] == nums[l-1]:
                            l -= 1
                        k += 1
                        l -= 1
                    elif summ < target:
                        k += 1
                    else:
                        l -= 1
        return res

    
#Method-5    
# simple like 3sum

class Solution:
    def fourSum(self, nums: List[int], target: int) -> List[List[int]]:
        result = set()
        nums.sort()
        for i in range(len(nums)):
            for j in range(i+1,len(nums)):
                k , l= j+1 , len(nums)-1
                while k < l:
                    if(nums[i]+nums[j]+nums[k]+nums[l] == target):
                        result.add((nums[i],nums[j],nums[k],nums[l]))
                    if(nums[i]+nums[j]+nums[k]+nums[l] > target):
                        l-=1 
                    else:
                        k+=1 

        return list(result)
    
#Method-6
# Two pointer appraoch
class Solution:
    def fourSum(self, nums: List[int], target: int) -> List[List[int]]:
        nums.sort()
        s=set()
        for i in range(len(nums)-3):
            for j in range(i+1,len(nums)-2):
                k=j+1
                l=len(nums)-1
                while k<l:
                    total=nums[i]+nums[j]+nums[k]+nums[l]
                    if total<target:
                        k+=1
                    elif total>target:
                        l-=1
                    else:
                        s.add((nums[i],nums[j],nums[k],nums[l]))
                        k+=1
                        l-=1
                        
        return s
                        
#Q25 Find the Duplicate Number

'''
Given an array of integers nums containing n + 1 integers where each integer is in the range [1, n] inclusive.

There is only one repeated number in nums, return this repeated number.

You must solve the problem without modifying the array nums and uses only constant extra space.

 

Example 1:

Input: nums = [1,3,4,2,2]
Output: 2
Example 2:

Input: nums = [3,1,3,4,2]
Output: 3
 

Constraints:

1 <= n <= 105
nums.length == n + 1
1 <= nums[i] <= n
All the integers in nums appear only once except for precisely one integer which appears two or more times.
 

Follow up:

How can we prove that at least one duplicate number must exist in nums?
Can you solve the problem in linear runtime complexity?

''' 

# Solution 

# Method-1
# Using dict

class Solution:
    def findDuplicate(self, nums: List[int]) -> int:
        dic = {}
        for i in range(len(nums)):
            num = dic.setdefault(nums[i], 0)
            if num == 1:
                return nums[i]
            else:
                dic[nums[i]] = 1 
# # Method-2                
#Counter
class Solution:
    def findDuplicate(self, nums: List[int]) -> int:
        c = Counter(nums)
        for i,j in c.items():
            if j > 1:
                return i

# Method-3              
# O(n) time and O(1) space

class Solution(object):
    def findDuplicate(self, nums):
        """
        :type nums: List[int]
        :rtype: int
        """
        count = 0
        l = len(nums)
        while count < l:
            while nums[count] != count:
                temp =  nums[count]
                if temp == nums[temp]:
                    return temp
                else:
                    nums[count] = nums[temp]
                    nums[temp] = temp
            count += 1

            
# Method-4 
# Using  hashing concept 

class Solution:
    def findDuplicate(self, nums: List[int]) -> int:
        le=len(nums)
        for i in range(le):
            x=nums[i]%le
            nums[x]=nums[x]+le
            if nums[x]>=(le*2):
                return x
        return -1
            
# Method-5

# XOR approach | O(N) | O(N) |

# Explanation:
# input: [0, 1, 2, 2, 3]

# Steps:
# Create a list e.g. z_nums of length n that has values 0, where n is the length of the input.
# e.g. [0, 0, 0, 0, 0].
# Now if you do num ^ z_nums[num-1], for the first occurence it will be num as 0 ^ num = num and you assigned the value to z_nums[num-1]; however, if it occurs again then num ^ z_nums[num-1] will be zero and num ^ num = 0 and thus we can return num.
# Note: We are using z_nums[n-1] not z_nums[n] as the array contains values > 0.

class Solution:
    def findDuplicate(self, nums: List[int]) -> int:
        z_nums = [0]*len(nums)
        
        for num in nums:
            if (n:= num ^ z_nums[num-1]) == 0:
                return num
            else:
                z_nums[num-1] = n

#Q26 Combination Sum

'''
Given an array of distinct integers candidates and a target integer target, return a list of all unique combinations of candidates where the chosen numbers sum to target. You may return the combinations in any order.

The same number may be chosen from candidates an unlimited number of times. Two combinations are unique if the frequency of at least one of the chosen numbers is different.

It is guaranteed that the number of unique combinations that sum up to target is less than 150 combinations for the given input.

 

Example 1:

Input: candidates = [2,3,6,7], target = 7
Output: [[2,2,3],[7]]
Explanation:
2 and 3 are candidates, and 2 + 2 + 3 = 7. Note that 2 can be used multiple times.
7 is a candidate, and 7 = 7.
These are the only two combinations.
Example 2:

Input: candidates = [2,3,5], target = 8
Output: [[2,2,2,2],[2,3,3],[3,5]]
Example 3:

Input: candidates = [2], target = 1
Output: []
 

Constraints:

1 <= candidates.length <= 30
1 <= candidates[i] <= 200
All elements of candidates are distinct.
1 <= target <= 500

'''

# Solution 


# Method-1
class Solution:
    # @param {integer[]} candidates
    # @param {integer} target
    # @return {integer[][]}
    def combinationSum(self, candidates, target):
        candidates.sort()
        ans = []
        self.help(candidates, target, [], 0, ans)
        return ans

    def help(self, a, target, cur, s, ans):
        if target == 0:
            ans.append(cur[:])
        if target < 0 or a[s] > target:
            return
        while s < len(a):
            cur.append(a[s])
            r = self.help(a, target - a[s], cur, s, ans)
            cur.pop()
            if target - a[s] < 0:
                break
            s += 1


            

# Method-2            
# Recursive -> Backtracking 
class Solution:
    def combinationSum(self, candidates: List[int], target: int) -> List[List[int]]:
        res=[]
        def rec_backtrack(i,curr,total):
            if total==target:
                res.append(curr.copy())
                return
            if i>=len(candidates) or total>target:
                return
            curr.append(candidates[i])
            rec_backtrack(i,curr,total+candidates[i])
            curr.pop()
            rec_backtrack(i+1,curr,total)
        rec_backtrack(0,[],0)
        return res
    
    
# Method-3

# DP 

class Solution:
    def combinationSum(self, candidates: List[int], target: int) -> List[List[int]]:
        min_el = min(candidates)
        @cache
        def dp(target):
            if target < min_el:
                return []
            res = [[cand] + x for cand in candidates if cand<=target \
                for x in dp(target-cand) if len(x)>0 and x[0]>= cand]
            if target in candidates:
                res.append([target])
            return res
        return dp(target)
    
# Method-4    
#Dynamic Programming Solution

class Solution:
    def combinationSum(self, nums: List[int], target: int) -> List[List[int]]:
        dp = [[] for i in range(target+1)]
        dp[0] = [[]]
        for num in nums:
            for i in range(num,target+1):
                dp[i] += [x + [num] for x in dp[i-num]]
        return dp[-1] 

    
# Method-5    
#Recursive
class Solution:
    def combinationSum(self, candidates, target):
        candidates.sort()
        return self._combinationSum(candidates, target, [])
    
    
    def _combinationSum(self, candidates, target, item):
        if not candidates:
            return []
    
        c = candidates[0]
        if c > target:
            return []
        if c == target:
            return [item+[c]]
    
        return self._combinationSum(candidates[1:], target, item)+self._combinationSum(candidates, target-c, item+[c])

#Q27 Jump Game II

'''
Given an array of non-negative integers nums, you are initially positioned at the first index of the array.

Each element in the array represents your maximum jump length at that position.

Your goal is to reach the last index in the minimum number of jumps.

You can assume that you can always reach the last index.

 

Example 1:

Input: nums = [2,3,1,1,4]
Output: 2
Explanation: The minimum number of jumps to reach the last index is 2. Jump 1 step from index 0 to 1, then 3 steps to the last index.
Example 2:

Input: nums = [2,3,0,1,4]
Output: 2
 

Constraints:

1 <= nums.length <= 104
0 <= nums[i] <= 1000

'''

# Solution 

# Method-1
# Dp 

class Solution:
    def jump(self, nums: List[int]) -> int:
        l = len(nums)
        stack = [0] + [9999] * (l - 2)
        for i in range(l - 1):
            for j in range(i + 1, i + nums[i] + 1):
                if i + nums[i] >= l - 1:
                    return stack[i] + 1
                stack[j] = min(stack[j], stack[i] + 1)
        return stack[l - 2]

# Method-2

class Solution:
    def jump(self, nums):
        output = 0
        idx = 0
        if len(nums) == 1: return 0
        while True:
            currentNum = nums[idx]
            currentMax, currentIdx = 0, 0
            for t in range(1, currentNum + 1):
                if idx + t >= len(nums) - 1: return output + 1
                if idx + t + nums[idx+t] >= currentMax + currentIdx:
                    currentMax = nums[idx+t]
                    currentIdx = idx + t
            idx = currentIdx
            output += 1

# Method-3
#Greedy | BFS

class Solution:
    def jump(self, nums: List[int]) -> int:
        res=0
        l,r=0,0
        while r<len(nums)-1:
            long=0
            for i in range(l,r+1):
                long=max(long,i+nums[i])
            l=r+1
            r=long
            res+=1
        return res

    
# Method-4
#greedy - O(1) memory

class Solution:
    def jump(self, nums):
        """
        :type nums: List[int]
        :rtype: int
        """
        pos = 0
        step = 0
        L = len(nums)
        if L < 2:
            return (0)
        else:
            while L-pos-1 > nums[pos]:
                step = step + 1
                val = 0
                tmpPos = 0
                for i in range(1, nums[pos]+1):
                    if nums[pos + i] + i > val:
                        val = nums[pos+i] + i
                        tmpPos = pos + i
                pos = tmpPos
            step += 1
            return (step)

# Method-4        
#solution using stack

class Solution:
    def jump(self, nums: List[int]) -> int:
        if(len(nums)==1):
            return 0
        stack=[0,0]
        jumpdic={}
        mi=10**10
        while(stack):
            times=stack.pop()
            index=stack.pop()
            count=nums[index]
            while(count):
                if(count+index>=len(nums)-1):
                    mi=min(times+1,mi)
                    count=len(nums)-1-index-1
                    continue;
                if(index+count in jumpdic and jumpdic[index+count]<=times+1):
                    break;
                jumpdic[index+count]=times+1
                stack.append(index+count)
                stack.append(times+1)
                count-=1
        return mi
 
# Method-5
# We are keeping track of 3 variables :-

# minJumps :- For storing minimum jumps required
# steps :- Keeps the track of total maximum steps we can move at each index
# maxReachableIndex :- Stores the maximum index which can be reached from the current index.
# We initialize the steps and maxReachableIndex with the first value of jumps array. For each index of the given jump array starting from 1, we compute the maximum reachable index and keep decreasing the value of steps. When steps reaches to 0 that means now we can make a jump to reach the farthest index possible, so we increment jumps and update the value of steps.

# Time Complexity :- O(N)
# Space Complexity :- O(1)
class Solution:
    def jump(self, nums: List[int]) -> int:
        n = len(nums)
        if n <= 1:
            return 0
        steps = nums[0]
        maxReachableIndex = nums[0]
        minJumps = 1
        for i in range(1, n):
            if i == n-1:
                return minJumps
            maxReachableIndex = max(maxReachableIndex, i+nums[i])
            steps -= 1
            if steps == 0:
                minJumps += 1
                steps = maxReachableIndex - i


#Q28 Maximum Points You Can Obtain from Cards
'''
There are several cards arranged in a row, and each card has an associated number of points. The points are given in the integer array cardPoints.

In one step, you can take one card from the beginning or from the end of the row. You have to take exactly k cards.

Your score is the sum of the points of the cards you have taken.

Given the integer array cardPoints and the integer k, return the maximum score you can obtain.

 

Example 1:

Input: cardPoints = [1,2,3,4,5,6,1], k = 3
Output: 12
Explanation: After the first step, your score will always be 1. However, choosing the rightmost card first will maximize your total score. The optimal strategy is to take the three cards on the right, giving a final score of 1 + 6 + 5 = 12.
Example 2:

Input: cardPoints = [2,2,2], k = 2
Output: 4
Explanation: Regardless of which two cards you take, your score will always be 4.
Example 3:

Input: cardPoints = [9,7,7,9,7,7,9], k = 7
Output: 55
Explanation: You have to take all the cards. Your score is the sum of points of all cards.
 

Constraints:

1 <= cardPoints.length <= 105
1 <= cardPoints[i] <= 104
1 <= k <= cardPoints.length

'''
# Solution 


#Method-1
# find min (n - k) window.
# sliiding window

class Solution:
    def maxScore(self, cardPoints: List[int], k: int) -> int:
        total = sum(cardPoints)

        n = len(cardPoints)
        l, r = 0, n - k - 1
        window = sum(cardPoints[l: r + 1])
        smallest_window = window
        for r in range(r + 1, n):
            window -= cardPoints[l]
            window += cardPoints[r]
            smallest_window = min(smallest_window, window)
            l += 1
        return total - smallest_window

#Method-2
#Simple, Short and Fast Solution || O(n) Time || Sliding Window

class Solution:
    def maxScore(self, cards: List[int], k: int) -> int:
        n = len(cards)
        c = s = sum(cards[:n-k])
        for i in range(n-k, n):
            c = c + cards[i] - cards[i-n+k]
            s = min(s, c)
        return sum(cards) - s
    
    
#Method-3    
# Most Optimized Solution || O(N)->TC || O(1)->SC

# Intuition : remove min sum subarray such that sum of remaining elements will be max.

class Solution:
    def maxScore(self, cardPoints: List[int], k: int) -> int:
        n = len(cardPoints)
        res = 10**9
        total = 0
        l = 0

        for r in range(n):
            total += cardPoints[r]
            if r-l+1 > n-k: # we exceeded the limit window hence pop from back
                total -= cardPoints[l]
                l += 1
            if r-l+1 == n-k: # subarray of length (n-k)
                res = min(res, total)

        return sum(cardPoints) - res
    
#Method-4
#Sliding-Window


class Solution:
    def maxScore(self, card_points: List[int], k: int) -> int:
        
        # Sliding window approach from K elements at start to K elements at end
        
        # Sum of first k elements
        sum = 0
        for i in range(0, k):
            sum += card_points[i]
        
        ans = sum
        if(len(card_points) == k):
            return sum
        end = len(card_points) -1
        for i in range(k-1, -1, -1):
            sum = sum - card_points[i] + card_points[end]
            end -= 1
            ans = max(ans, sum)
        return ans
    
#Method-5   
#DP solution O(n)
from collections import deque
class Solution:
    def maxScore(self, cardPoints: List[int], k: int) -> int:
        dpL = [0] * len(cardPoints)
        dpR = [0] * len(cardPoints)
        n = len(cardPoints)
        dpL[0] = cardPoints[0]
        dpR[n-1] = cardPoints[n-1]
        for i in range(1, k):
            dpL[i] = dpL[i-1] + cardPoints[i]
            dpR[n-1-i] = dpR[n-1-i+1] + cardPoints[n-1-i]
        res = 0
        for i in range(k+1):
            lscore = dpL[i-1] if i>0 else 0
            rscore = dpR[n-k+i] if (n-k+i) < n else 0
            res = max(lscore+rscore, res)
        return res

    
    
#Method-6  
# we need to find the maximum of point of take X cards from left + point of take Y card from the right where X + Y = k

# For example:
# suppose you have 4 cards [1,79,80, 1] and take k = 2,
# you can only one of these choice:

# take 0 from left and take 2 from right
# take 1 from left and take 1 from right
# take 0 from left and take 2 from right
# and the result is max of (1. 2. 3.)
# let:
# take_from_left[X] = point we can get if we take X cards from left
# take_from_left[X] = point we can get if we take X cards from right

# variable take_from_left is [0, 1, 80] and take_from_right is [0, 1, 81] in this case.
# we let both array[0] = 0 because obviously when we take 0 card from one side, we get 0 point.
# then the result is MAX_OF(
# take_from_left[0] + take_from_right[2],
# take_from_left[1] + take_from_right[1],
# take_from_left[2] + take_from_right[0]
# )

class Solution:
    def maxScore(self, cardPoints: List[int], k: int) -> int:
        take_from_left = [0] + [*itertools.accumulate(cardPoints[:k])]
        take_from_right = [0] + [*itertools.accumulate(reversed(cardPoints[-k:]))]
        return max(take_from_left[i] + take_from_right[k - i] for i in range(k + 1))
 

#Method-7
#understand with PrefixSum O(n)

# Calculate the prefix sum of cardPoints, add 0 to the beginning of the prefix sum array. If you choose i cards from the left, the sum of left side points is prefixSum[i]. The points of the right side is prefixSum[-1] - prefixSum[n-k+i].

class Solution:
    def maxScore(self, cardPoints: List[int], k: int) -> int:
        n = len(cardPoints)
        res = float('-inf')
        prefixSum = [cardPoints[0]]
        for i in range(1, n):
            prefixSum.append(prefixSum[i-1] + cardPoints[i])
        prefixSum = [0] + prefixSum
        for i in range(k+1):
            temp = prefixSum[i] + prefixSum[-1] - prefixSum[n - k + i]
            res = max(res, temp)
        return res
    
 #Method-8   
class Solution:
    def maxScore(self, cardPoints: List[int], k: int) -> int:
        n = len(cardPoints)
        tot = sum(cardPoints)
        n -= k
        for i in range(1,len(cardPoints)):
            cardPoints[i] += cardPoints[i-1]
        cardPoints  = [0] + cardPoints
        ans = -math.inf
        for i in range(n,len(cardPoints)):
            ans = max(ans, tot - (cardPoints[i] - cardPoints[i-n]))
        return ans

#Q29 Maximum Area of a Piece of Cake After Horizontal and Vertical Cuts

'''
You are given a rectangular cake of size h x w and two arrays of integers horizontalCuts and verticalCuts where:

horizontalCuts[i] is the distance from the top of the rectangular cake to the ith horizontal cut and similarly, and
verticalCuts[j] is the distance from the left of the rectangular cake to the jth vertical cut.
Return the maximum area of a piece of cake after you cut at each horizontal and vertical position provided in the arrays horizontalCuts and verticalCuts. Since the answer can be a large number, return this modulo 109 + 7.

 

Example 1:


Input: h = 5, w = 4, horizontalCuts = [1,2,4], verticalCuts = [1,3]
Output: 4 
Explanation: The figure above represents the given rectangular cake. Red lines are the horizontal and vertical cuts. After you cut the cake, the green piece of cake has the maximum area.
Example 2:


Input: h = 5, w = 4, horizontalCuts = [3,1], verticalCuts = [1]
Output: 6
Explanation: The figure above represents the given rectangular cake. Red lines are the horizontal and vertical cuts. After you cut the cake, the green and yellow pieces of cake have the maximum area.
Example 3:

Input: h = 5, w = 4, horizontalCuts = [3], verticalCuts = [3]
Output: 9
 

Constraints:

2 <= h, w <= 109
1 <= horizontalCuts.length <= min(h - 1, 105)
1 <= verticalCuts.length <= min(w - 1, 105)
1 <= horizontalCuts[i] < h
1 <= verticalCuts[i] < w
All the elements in horizontalCuts are distinct.
All the elements in verticalCuts are distinct.

'''

# Solution 

#Method-1
#sorting + finding max

class Solution:
    def maxArea(self, h: int, w: int, horizontalCuts: List[int], verticalCuts: List[int]) -> int:
        horizontalCuts = sorted([0] + horizontalCuts + [h])
        verticalCuts = sorted([0] + verticalCuts + [w])
        hor_dims = [horizontalCuts[i]-horizontalCuts[i-1] for i in range(1, len(horizontalCuts))]
        ver_dims = [verticalCuts[i]-verticalCuts[i-1] for i in range(1, len(verticalCuts))]
        return max(hor_dims)*max(ver_dims)%1000000007
        
        
#Method-2
#Sorting

class Solution:
    def maxArea(self, h: int, w: int, hc: List[int], vc: List[int]) -> int:
        # to handle edge cases add [0] and [dimension]
        hc = [0] + sorted(hc) + [h]
        vc = [0] + sorted(vc) + [w]
        
        # now store diff in appropriate array and pop last element as it will be not contain difference
        for i in range(len(hc)-1):
            hc[i] = hc[i+1] - hc[i]
        hc.pop()

        for i in range(len(vc)-1):
            vc[i] = vc[i+1] - vc[i]
        vc.pop()
        
        # now to find maximum product of two numbers in two different array, sort them and then multiply their last numbers with each other
        # NOTE : sorting here wont affect Time Complexity as we have already used it earlier
        hc.sort()
        vc.sort()

        return (hc[-1] * vc[-1]) % (10**9 + 7)

    
#Method-3 
# Identify maximum gap between cuts 
# greedy
# sorting

        # sort the horizontal cuts and vertical cuts
        # add 0 and height to start and end of horizontal cuts list
        # add 0 and width to the start and end of vertical cuts list
        # take the difference of consecutive elements in both list
        # identify the max element in both the cases 
        # return the product of the max of each element in both the list

class Solution:
    def maxArea(self, h: int, w: int, horizontalCuts: List[int], verticalCuts: List[int]) -> int:
        horizontalCuts.sort()
        verticalCuts.sort()
        horizontalCuts = [0] + horizontalCuts + [h]
        verticalCuts = [0] + verticalCuts + [w]
        h_diff = [horizontalCuts[i] - horizontalCuts[i-1] for i in range(1, len(horizontalCuts))]
        v_diff = [verticalCuts[i] - verticalCuts[i-1] for i in range(1, len(verticalCuts))]
        return (max(h_diff) * max(v_diff)) % (10**9 + 7)


    
#Method-4   
class Solution:
    def maxArea(self, h: int, w: int, horizontalCuts: List[int], verticalCuts: List[int]) -> int:
        horizontalCuts.extend([0, h])
        horizontalCuts.sort()
        verticalCuts.extend([0, w])
        verticalCuts.sort()
        
        h_diff = [a-b for b, a in zip(horizontalCuts, horizontalCuts[1:])]
        v_diff = [a-b for b, a in zip(verticalCuts, verticalCuts[1:])]
        
        return (max(h_diff)*max(v_diff))%(10**9 + 7)
 
#Method-5  
#SORTING AND MAX GAP PYTHON

class Solution:
    def maxArea(self, h: int, w: int, ho: List[int], ve: List[int]) -> int:
        ho.sort()
        ve.sort()
       
        ho=[0]+ho
        ho.append(h)
        ve=[0]+ve
        ve.append(w)
        ans=0
        hd=0
        vd=0
        for i in range(1,len(ho)):
            hd=max(hd,ho[i]-ho[i-1])
        for i in range(1,len(ve)):
            vd=max(vd,ve[i]-ve[i-1])
        return (hd*vd)%(10**9+7)

    
#Method-6      
# 3 lines python

class Solution:
    def maxArea(self, h: int, w: int, horizontalCuts: List[int], verticalCuts: List[int]) -> int:
        hs = [0] + sorted(horizontalCuts) + [h]
        ws = [0] + sorted(verticalCuts) + [w]
        return max(hs[i]-hs[i-1] for i in range(1,len(hs)))*max(ws[i]-ws[i-1] for i in range(1,len(ws)))%(10**9+7)
    


#Q30 Max Area of Island

'''
You are given an m x n binary matrix grid. An island is a group of 1's (representing land) connected 4-directionally (horizontal or vertical.) You may assume all four edges of the grid are surrounded by water.

The area of an island is the number of cells with a value 1 in the island.

Return the maximum area of an island in grid. If there is no island, return 0.

 

Example 1:


Input: grid = [[0,0,1,0,0,0,0,1,0,0,0,0,0],[0,0,0,0,0,0,0,1,1,1,0,0,0],[0,1,1,0,1,0,0,0,0,0,0,0,0],[0,1,0,0,1,1,0,0,1,0,1,0,0],[0,1,0,0,1,1,0,0,1,1,1,0,0],[0,0,0,0,0,0,0,0,0,0,1,0,0],[0,0,0,0,0,0,0,1,1,1,0,0,0],[0,0,0,0,0,0,0,1,1,0,0,0,0]]
Output: 6
Explanation: The answer is not 11, because the island must be connected 4-directionally.
Example 2:

Input: grid = [[0,0,0,0,0,0,0,0]]
Output: 0
 

Constraints:

m == grid.length
n == grid[i].length
1 <= m, n <= 50
grid[i][j] is either 0 or 1.


'''
  
#Solution 


#Method-1
#Elegant & Short | In-place | DFS

class Solution:
    """
    Time:   O(n^2)
    Memory: O(1)
    """

    WATER = 0
    LAND = 1

    def maxAreaOfIsland(self, grid: List[List[int]]) -> int:
        n, m = len(grid), len(grid[0])
        return max(self.island_area(i, j, grid) for i in range(n) for j in range(m))

    @classmethod
    def island_area(cls, row: int, col: int, grid: List[List[int]]) -> int:
        if grid[row][col] != cls.LAND:
            return 0

        grid[row][col] = cls.WATER
        area = 1

        if row > 0:
            area += cls.island_area(row - 1, col, grid)

        if row + 1 < len(grid):
            area += cls.island_area(row + 1, col, grid)

        if col > 0:
            area += cls.island_area(row, col - 1, grid)

        if col + 1 < len(grid[0]):
            area += cls.island_area(row, col + 1, grid)

        return area
 

#Method-2   
#python simple dfs

class Solution:
    def maxAreaOfIsland(self, grid: List[List[int]]) -> int:
        maxArea = 0
        for row in range(len(grid)):
            for col in range(len(grid[row])):
                if grid[row][col] == 1:
                    area = [1]
                    self.dfs(grid, row, col, area, {(row, col)})
                    maxArea = max(maxArea, area[0])
        
        return maxArea
    
    def dfs(self, grid, row, col, area, visited):
        grid[row][col] = 0
        
        if row < len(grid) - 1:
            if grid[row + 1][col] == 1:
                if (row + 1, col) not in visited:
                    area[0] += 1
                    visited.add((row + 1, col))
                    self.dfs(grid, row + 1, col, area, visited)
        if row > 0:
            if grid[row - 1][col] == 1:
                if (row - 1, col) not in visited:
                    area[0] += 1
                    visited.add((row - 1, col))
                    self.dfs(grid, row - 1, col, area, visited)
        if col < len(grid[row]) - 1:
            if grid[row][col + 1] == 1:
                if (row, col + 1) not in visited:
                    area[0] += 1
                    visited.add((row, col + 1))
                    self.dfs(grid, row, col + 1, area, visited)
        if col > 0:
            if grid[row][col - 1] == 1:
                if (row, col - 1) not in visited:
                    area[0] += 1
                    visited.add((row, col - 1))
                    self.dfs(grid, row, col - 1, area, visited)
                    
#Method-3
# Uses DFS with recursion

class Solution:
    def maxAreaOfIsland(self, grid) -> int:
        lock = 0
        grid[:] = [[0] * (len(grid[0]) + 1)] + [[0] + line + [0] for line in grid] + [[0] * (len(grid[0]) + 1)]

        def DFS(r, c):
            if not grid[r][c]: return self.area
            self.area += 1; grid[r][c] = 0
            return max(DFS(r + 1, c), DFS(r, c + 1), DFS(r - 1, c), DFS(r, c - 1))

        for r, col in enumerate(grid[1 : -1], start = 1):
            for c, num in enumerate(col[1 : -1], start = 1):
                self.area = 0
                if num == 1:
                    temp = DFS(r, c)
                    if lock < temp: lock = temp

        return lock


#Method-4  
#iterative solution

class Solution:
    def maxAreaOfIsland(self, grid):
        """
        :type grid: List[List[int]]
        :rtype: int
        """
        max_y = len(grid)
        max_x = len(grid[0])
        result = 0
        for y in range(max_y):
            for x in range(max_x):
                if grid[y][x] == 1:
                    queue = [(y, x)]
                    local_max = 0
                    while queue:
                        point = queue.pop()
                        if 0 <= point[0] < max_y and 0 <= point[1] < max_x and grid[point[0]][point[1]] == 1:
                            grid[point[0]][point[1]] = 0
                            local_max += 1
                            queue.append((point[0] + 1, point[1]))
                            queue.append((point[0] - 1, point[1]))
                            queue.append((point[0], point[1] + 1))
                            queue.append((point[0], point[1] - 1))
                    result = max(result, local_max)
        return result
    
#Method-5
 # DFS    
def dfs(i,j,grid):
    
    if i < 0 or j < 0 or i >= len(grid) or j >= len(grid[i]) or grid[i][j] == 0:
        return 0
    
    grid[i][j] = 0
    
    up = dfs(i,j+1,grid)
    down = dfs(i,j-1,grid)
    left = dfs(i-1,j,grid)
    right = dfs(i+1,j,grid)
    
    return up + down + left + right + 1

class Solution(object):
    def maxAreaOfIsland(self, grid):
        """
        :type grid: List[List[int]]
        :rtype: int
        """
        count = 0
        
        for i in range(len(grid)):
            for j in range(len(grid[i])):
                
                if grid[i][j] == 1:
                    count = max(dfs(i,j,grid), count)
                    
        return count

#Q 31 Find All Duplicates in an Array

'''
Given an integer array nums of length n where all the integers of nums are in the range [1, n] and each integer appears once or twice, return an array of all the integers that appears twice.

You must write an algorithm that runs in O(n) time and uses only constant extra space.

 

Example 1:

Input: nums = [4,3,2,7,8,2,3,1]
Output: [2,3]
Example 2:

Input: nums = [1,1,2]
Output: [1]
Example 3:

Input: nums = [1]
Output: []
 

Constraints:

n == nums.length
1 <= n <= 105
1 <= nums[i] <= n
Each element in nums appears once or twice.

'''

# Solution 

#Method-1
class Solution:
    def findDuplicates(self, nums: List[int]) -> List[int]:
        ansList = []
        for i in range(len(nums)):
            index = abs(nums[i])-1
            if nums[index] < 0:
                ansList.append(index+1)
            else:
                nums[index] = -1 * nums[index]
        return ansList
    

#Method-2   
#Using hashmap 

class Solution:
    def findDuplicates(self, nums: List[int]) -> List[int]:
        d = {1:set(),2:set()}
        for i in range(len(nums)):
            if nums[i] in d[1]:
                d[2].add(nums[i])
            else:
                d[1].add(nums[i])
        return list(d[2])
    
#Method-3
class Solution:
    def findDuplicates(self, nums: List[int]) -> List[int]:
        count = Counter(nums)
        ans = []
        for i in count:
            if count[i] == 2:
                ans.append(i)
        return ans
    
    
#Method-4
#Using Counter
class Solution:
    def findDuplicates(self, nums):
        c = Counter(nums)
        return ([key for key in c.keys() if c.get(key) == 2])
    
    

#Method-5
# using hashmap and dicctionary

class Solution:
    def findDuplicates(self, nums):
        d={}
        res=[]
        for i in nums:
            if i not in d:
                d[i]=1
            else:
                d[i]+=1
        for j in d:
            if d[j]>=2:
                res.append(j)
        return res



#Q 31 K-diff Pairs in an Array
'''
Given an array of integers nums and an integer k, return the number of unique k-diff pairs in the array.

A k-diff pair is an integer pair (nums[i], nums[j]), where the following are true:

0 <= i, j < nums.length
i != j
nums[i] - nums[j] == k
Notice that |val| denotes the absolute value of val.

 

Example 1:

Input: nums = [3,1,4,1,5], k = 2
Output: 2
Explanation: There are two 2-diff pairs in the array, (1, 3) and (3, 5).
Although we have two 1s in the input, we should only return the number of unique pairs.
Example 2:

Input: nums = [1,2,3,4,5], k = 1
Output: 4
Explanation: There are four 1-diff pairs in the array, (1, 2), (2, 3), (3, 4) and (4, 5).
Example 3:

Input: nums = [1,3,1,5,4], k = 0
Output: 1
Explanation: There is one 0-diff pair in the array, (1, 1).
 

Constraints:

1 <= nums.length <= 104
-107 <= nums[i] <= 107
0 <= k <= 107 
'''
# Sloution 

#Method-1
#USING HASHMAP
class Solution:
    def findPairs(self, nums: List[int], k: int) -> int:
        hash = {}
        arr = []
        nums.sort()
        for i in range(len(nums)):
            if nums[i] - k not in hash:
                hash[nums[i]] = i
            else:
                if [nums[i] , nums[i] - k] not in arr:
                    arr.append([nums[i] , nums[i] - k])
                hash[nums[i]] = i
        return len(arr)               
                
#Time Limit Exceeded        
#         # O(N^2) --> TLE
#         nums.sort()
#         arr = []
#         for i in range(len(nums)):
#             for j in range(i+1,len(nums)):
#                 if abs(nums[i] - nums[j]) == k:
#                     if sorted([nums[i] , nums[j] ]) not in arr:
#                         arr.append( sorted([nums[i] , nums[j]]))
#         print(arr)
#         return len(arr)
    
#Method-2
#Using dictionary

class Solution(object):
    def findPairs(self, nums, k):
        """
        :type nums: List[int]
        :type k: int
        :rtype: int
        """
        nums.sort()
        count = []
        dict = {}
        for i in range(len(nums)):
            if nums[i] in dict:
                count.append((dict[nums[i]],nums[i]))
            dict[nums[i]+k] = nums[i]
        return len(set(count))
    
    
#Method-3
#Counter
class Solution:
    def findPairs(self, nums, k):
        """
        :type nums: List[int]
        :type k: int
        :rtype: int
        """
        c = collections.Counter(nums)
        count = 0
        if k < 0:
            return 0
        if k == 0:
            for item in c.keys():
                if c[item] > 1:
                    count +=1
            return count
        else:
            for item in c.keys():
                if item + k in c:
                    count += 1
            return count
#Method-4
#use dictionary and set

class Solution:
    def findPairs(self, nums, k):
        if k < 0 or len(nums)==0: return 0
        count_dict, count = {}, 0
        
        for num in nums:
            count_dict[num] = count_dict.get(num,0) + 1
                        
        for key in count_dict:
            if k:
                if key + k in count_dict: count += 1
            else:
                if count_dict[key] >= 2: count += 1
        return count
    
#Method-5

# 1️⃣ Approach 1: Two Pointer O(n^2)
# We first sort the array and using two pointer left and right to iterate through whole num.

# We use hashmap to return the number of unique k-diff pairs

# Left: Iterate through nums
# Right: Once nums[right] - nums[left] > k, break the nested loop and move on to next left
# If nums[right] - nums[left] == k, we store leftHash[leftNum] = rightNum
# Finally count number of keys in the hashMap

# Complexity Analysis
# Time: O(n^2) : Let n be length of nums
# Space: O(n) : We using extra space sotre leftHash
# Two Pointer Code
# # O(n^2)| O(n)


class Solution:
    def findPairs(self, nums: List[int], k: int) -> int:
        nums.sort()
        leftHash = {}
        
        for left in range(len(nums) - 1):
            right = left + 1
            while right < len(nums) and nums[right] - nums[left] <= k:
                if nums[right] - nums[left] == k:
                    if nums[left] not in leftHash:
                        leftHash[nums[left]] = nums[right]
                right += 1
                
        res = 0
        for left in leftHash:
            res += 1
        return res
    
    
# 2️⃣ Approach 2: 2 Sum Solution | O(n log n)
# We first sort the array and using 2 Sum's like method to iterate through the array

# Step 1. Sort the array
# Step 2. Using hashMap and iterate through nums once found target res += 1 and set numHash[target] = False (To prevent duplicate counts)

# Complexity Analysis
# Time: O(n log n) : Let n be length of nums. Since we sort the array it takes (n log n)
# Space: O(n) : We using extra space sotre leftHash
# Sort and HashMap Code
# O(n log n)| O(n)


class Solution:
    def findPairs(self, nums: List[int], k: int) -> int:
        nums.sort()
        numHash = {}
        res = 0
        
        for num in nums:
            target = num - k
            if target in numHash and numHash[target]:
                res += 1
                numHash[target] = False
            if num not in numHash:
                numHash[num] = True
        return res
    
    
# 3️⃣ Approach 3: Count the Numbers O(n) Optimal 🦞
# Step 1. Count the numbers in num using hashMap. =>O(n)
# Step 2. Iterate through nums,

# If k == 0 => find numsCount > 1
# If k > 0 => find key + k in numsCount

# Complexity Analysis
# Time: O(n) : Let n be length of nums. We iterate through nums twice => O(2N) => O(N)
# Space: O(n) : We using extra space sotre leftHash
# Counter Code
# # O(n)| O(n)


class Solution:
    def findPairs(self, nums: List[int], k: int) -> int:
        numsCount = {}
        
        for num in nums:
            numsCount[num] = numsCount.get(num, 0) + 1
        res = 0
        
        for key in numsCount:
            if k == 0 and numsCount[key] > 1:
                res += 1
            elif k > 0 and key + k in numsCount:
                res += 1
 
       return res



#Q 32 Subsets

'''
Given an integer array nums of unique elements, return all possible subsets (the power set).

The solution set must not contain duplicate subsets. Return the solution in any order.

 

Example 1:

Input: nums = [1,2,3]
Output: [[],[1],[2],[1,2],[3],[1,3],[2,3],[1,2,3]]
Example 2:

Input: nums = [0]
Output: [[],[0]]
 

Constraints:

1 <= nums.length <= 10
-10 <= nums[i] <= 10
All the numbers of nums are unique.

'''

# Solution 


#Method-1
class Solution:
    def subsets(self, nums: List[int]) -> List[List[int]]:
        ans=[]
        for i in range(len(nums)+1):
            ans.extend(combinations(nums,i))
        return ans
    
    

#Method-2    
# Time and space complexity O(2^n)
class Solution:
    def subsets(self, nums: List[int]) -> List[List[int]]:
        subset=[[]]
        for number in nums:
            n=len(subset)
            for i in range(n):
                newSet=list(subset[i])
                newSet.append(number)
                subset.append(newSet)
        return subset

#Method-3        
#Using itertools
import itertools    
class Solution:
    # @param S, a list of integer
    # @return a list of lists of integer
    def subsets(self, S):
        return_list = []
        S = sorted(S)
        for i in range(len(S)+1):
            return_list.extend (list(x) for x in itertools.combinations(S,i))
        return return_list
    
    
#Method-4
#Recursive and Loop

class Solution:
    """
    @param S: The set of numbers.
    @return: A list of lists. See example.
    """
    def subsets(self, S):
        n=len(S)
        if n==0:
            return []
        elif n==1:
            return [[],[S[0]]]
        S.sort()
        re=[[],[S[0]]]
        for i in range(1,n):
            re=[x+[S[i]] for x in re]+re
        return re

    
    
class Solution:
    def subsets(self, S):
        n=len(S)
        if n==0:
            return [[]]
        elif n==1:
            return [[],S]
        S.sort()
        re=[]
        for x in self.subsets(S[:n-1]):
            re.append(x)
            re.append(x+[S[n-1]])
        return re

    
#Method-5    
#Backtracking solution

class Solution(object):
    def subsets(self, nums):
        """
        :type nums: List[int]
        :rtype: List[List[int]]
        """
        nums.sort()
        ans,stack,x,n=[[]],[],0,len(nums)
        while True:
            if x<n:
                stack+=[(x,nums[x])]
                ans=ans+[zip(*stack)[1]]
                x+=1
            elif stack:
                x=stack.pop()[0]+1
            else:
                return ans
            
            
#one liner using bit manipulation

class Solution(object):
    def subsets(self, nums):
        """
        :type nums: List[int]
        :rtype: List[List[int]]
        """
        return [[nums[j] for j in range(len(nums)) if i>>j&1] for i in range(2**len(nums))]



#Q32 Invalid Transactions

'''
A transaction is possibly invalid if:

the amount exceeds $1000, or;
if it occurs within (and including) 60 minutes of another transaction with the same name in a different city.
You are given an array of strings transaction where transactions[i] consists of comma-separated values representing the name, time (in minutes), amount, and city of the transaction.

Return a list of transactions that are possibly invalid. You may return the answer in any order.

 

Example 1:

Input: transactions = ["alice,20,800,mtv","alice,50,100,beijing"]
Output: ["alice,20,800,mtv","alice,50,100,beijing"]
Explanation: The first transaction is invalid because the second transaction occurs within a difference of 60 minutes, have the same name and is in a different city. Similarly the second one is invalid too.
Example 2:

Input: transactions = ["alice,20,800,mtv","alice,50,1200,mtv"]
Output: ["alice,50,1200,mtv"]
Example 3:

Input: transactions = ["alice,20,800,mtv","bob,50,1200,mtv"]
Output: ["bob,50,1200,mtv"]
 

Constraints:

transactions.length <= 1000
Each transactions[i] takes the form "{name},{time},{amount},{city}"
Each {name} and {city} consist of lowercase English letters, and have lengths between 1 and 10.
Each {time} consist of digits, and represent an integer between 0 and 1000.
Each {amount} consist of digits, and represent an integer between 0 and 2000.

'''

# Solution 
#Method-1
#sliding window, straightforward, but heavy, O(nlog(n)) for sorting, with comments

# This looks like a kind of heavy implementation task rather than an algorithmic one. The only algorithm is comparably simple - a sliding window. It is easier because you dont have to solve a puzzle, but heavy in implementation and more prone to errors. I think, they may want to assess a carefull possibly object oriented implementation for such kinds of tasks.

class Transaction:
    def __init__(self, id, str):
        parts = str.split(',')
        self.Id = id
        self.Name = parts[0]
        self.Time = int(parts[1])
        self.Amount = int(parts[2])
        self.City = parts[3]
    
class Solution:
    def invalidTransactions(self, transactions: List[str]) -> List[str]:
        
        invalid = set()
        
        people = defaultdict(list)
        
        # parse transaction and check the first > 1000 rule
        # group by people
        for i in range(len(transactions)):
            tran = Transaction(i, transactions[i])                        
            if tran.Amount > 1000:
                invalid.add(tran.Id)                
            people[tran.Name].append(tran)
            
        # check per each person
        for name in people:
            trans = people[name]
            # sort by time
            trans.sort(key = lambda x: x.Time)            
            
            # use a sliding window
            wnd_cities = defaultdict(int) # cities to check dups within the window
            wnd_start_idx = 0 # sliding window start            
            last_checked_idx = 0 # optimization - the last added to invalid index in trans
            
            for i, tran in enumerate(trans):                
                wnd_cities[tran.City] += 1                
                # clean up the sliding window to contain only 60 min away trans
                while tran.Time - trans[wnd_start_idx].Time > 60:
                    start_city = trans[wnd_start_idx].City
                    wnd_cities[start_city] -= 1
                    if wnd_cities[start_city] == 0:
                        del wnd_cities[start_city]
                        
                    wnd_start_idx += 1
                                        
                # the sliding window is adjusted, if there are more than 2 diff cities, add to res 
                if len(wnd_cities) > 1:          
                    # just speed up a bit by tracking last added index in last_checked_idx
                    for j in range(max(last_checked_idx, wnd_start_idx), i + 1):                        
                        invalid.add(trans[j].Id)   
                    last_checked_idx = i + 1
        
        return [transactions[i] for i in invalid]
    
    
    
    
    
    
    
    
    
    
# method-2


class Solution:
    def invalidTransactions(self, transactions: List[str]) -> List[str]:
        trans = sorted([t.split(',') for t in transactions], key=lambda t: (t[0],int(t[1])))
        invalid = [False]*len(trans)
        for i in range(len(trans)):
            if int(trans[i][2]) > 1000:
                invalid[i] = True
            j = i + 1
            while j < len(trans) and trans[j][0] == trans[i][0] and int(trans[j][1]) - int(trans[i][1]) <= 60:
                if trans[j][3] != trans[i][3]:
                    invalid[i] = True
                    invalid[j] = True
                j += 1   
        return [','.join(trans[i]) for i in range(len(trans)) if invalid[i]]
    
    
    
    
     
# method-3

class Solution:
    def invalidTransactions(self, transactions: List[str]) -> List[str]:
        n = len(transactions)
        for i in range(n):
            transactions[i] = transactions[i].split(',')
        transactions.sort(key = lambda x: int(x[1]))
        ans = []
        failed = [False for i in range(n)]
        for i in range(n):
            if int(transactions[i][2]) > 1000 : failed[i] = True
            for j in range(i+1,n):
                if int(transactions[j][1]) - int(transactions[i][1]) > 60: break
                if transactions[j][0] == transactions[i][0] and\
                transactions[j][-1] != transactions[i][-1]:
                    failed[i] = failed[j] = True
            if failed[i] == True:
                ans.append(','.join(transactions[i]))
        return ans
 



# method-4
#  O(N + KlogK) Time Straightforward Python Solutions,  beats 100%

# Time: O(N + KlogK), N = len(transactions) and K = max count of anyone's transaction data; worst case happens when K == N, which we only have transaction data for a person.

# Space: O(N)

class Solution:
    def invalidTransactions(self, transactions: List[str]) -> List[str]:
        N = len(transactions)
        
        # parse strings in transactions for later references
        data = [(n, int(t), int(m), c) for n, t, m, c in map(lambda s: s.split(','), transactions)]
        get_name = lambda i: data[i][0]
        get_time = lambda i: data[i][1]
        get_money = lambda i: data[i][2]
        get_city = lambda i: data[i][3]
        
        # O(K), k is the max length of indices
        def collect_city_conflicts(indices, invalids):
            t1 = t2 = float('inf')
            c1 = c2 = ''
            for i in indices:
                city, time = get_city(i), get_time(i)
                if city == c1:
                    if abs(time - t2) <= 60:
                        invalids.add(i)
                    t1 = time
                else:
                    if abs(time - t1) <= 60:
                        invalids.add(i)
                    t2, c2 = t1, c1
                    t1, c1 = time, city
        
        # O(KlogK)
        def get_invalids(indices, invalids):
            # O(KlogK)
            indices.sort(key = lambda i: get_time(i))
            
            # O(K), from past to future to see any conflict happens before cur time
            collect_city_conflicts(indices, invalids)
            
            # O(K), from future to past to see any conflict happens after cur time
            collect_city_conflicts(indices[::-1], invalids)
            
            # O(K) find any index of the invalid transactions whose amount > 1000
            invalids |= {i for i in indices if get_money(i) > 1000}

        # O(N), K = max(map(len, data_by_person.values()))
        data_by_person = collections.defaultdict(list)
        for i in range(N):
            data_by_person[get_name(i)].append(i)
        
        # O(N)
        invalids = set()
        for indices in data_by_person.values():
            get_invalids(indices, invalids)
        
        return [transactions[i] for i in invalids]
    
    
# method-5    
# O(nlogn) solution

# It becomes efficient only for very large test cases (there aren't in this question), but it may be helpful to someone.
# Keep a map with a sorted list for each name.
# When we encounter a transaction, insert it in the sorted list in nlogn, then iterate from there both up and down updating the solution.
# Return all the elements that are not invalid

from sortedcontainers import SortedKeyList

class Solution:
    def invalidTransactions(self, transactions: List[str]) -> List[str]:
        
        cmp = lambda y: int(y[0])
        people = defaultdict(lambda: SortedKeyList(key=cmp))
        invalid = [0] * len(transactions)
        
        for i, transaction in enumerate(transactions):
            name, time, amount, city = transaction.split(',')
            
            if int(amount) >= 1000:
                invalid[i] = 1
            
            people[name].add((time, city, i))
            idx = people[name].index((time, city, i))
            
            tmp = idx + 1
            while tmp < len(people[name]):
                ctime, ccity, cidx = people[name][tmp]
                if int(ctime) - int(time) <= 60 and ccity != city:
                    invalid[cidx] = 1
                    invalid[i] = 1
                elif int(time) - int(ctime) > 60:
                    break
                tmp += 1
            
            tmp = idx - 1
            while tmp >= 0:
                ctime, ccity, cidx = people[name][tmp]
                if int(time) - int(ctime) <= 60 and ccity != city:
                    invalid[cidx] = 1
                    invalid[i] = 1
                elif int(time) - int(ctime) > 60:
                    break
                tmp -= 1
        
        return [trans for i, trans in enumerate(transactions) if invalid[i]]

#Q33 Jump Game I

'''
You are given an integer array nums. You are initially positioned at the array's first index, and each element in the array represents your maximum jump length at that position.

Return true if you can reach the last index, or false otherwise.

 

Example 1:

Input: nums = [2,3,1,1,4]
Output: true
Explanation: Jump 1 step from index 0 to 1, then 3 steps to the last index.
Example 2:

Input: nums = [3,2,1,0,4]
Output: false
Explanation: You will always arrive at index 3 no matter what. Its maximum jump length is 0, which makes it impossible to reach the last index.
 

Constraints:

1 <= nums.length <= 104
0 <= nums[i] <= 105

'''

#Solution 

#Method-1

class Solution:
    def canJump(self, nums: List[int]) -> bool:
        lnth = len(nums)
        i, j = lnth - 2, lnth - 1
        
        while i >= 0:
            if nums[i] >= j-i:
                j = i
            i -= 1
        
        return j == 0
    
#Method-2
class Solution:
    def canJump(self, nums: List[int]) -> bool:
        l = len(nums)
        curr = l - 1
        for i in range(l - 2, -1, -1):
            if nums[i] >= curr - i:
                curr = i  
        return curr == 0
    
 #Method-3   
class Solution:
    def canJump(self, nums):
        """
        :type nums: List[int]
        :rtype: bool
        """
        n = len(nums)
        h = []
        for i in range(n):
            h.append(i+nums[i])
        i = 0
        r = nums[0]
        while r < n:
            m = max(h[i:r+1])
            if m > r:
                i = r+1
                r = m
            else:
                break
        if r >= n-1:
            return True
        return False

    

#Method-4   
#Using greedy approach in O(n) time

class Solution:
    def canJump(self, nums: List[int]) -> bool:
        goal = len(nums) -1 
        for i in range(len(nums)-1,-1,-1) :
            if i+nums[i]>=goal:
                goal=i
        if goal == 0 :
            return True
        return False
    

#Method-5   
# Priority queue method

# In this method, we maintain a queue that store all the index we can reach and a border variable that records the longest index we can get.
# We firstly put index '0' into queue. Then check the first element in the queue and find how far we can reach through the head of the queue. If the path we can reach is greater than border, then we put all the index behind border but before the longest index into queue (because the path is continuous, if we can reach index n, we must reach n - 1).
# We keep traversing the queue until we can find target that is the end of the array. If not, return False.

class Solution:
    def canJump(self, nums: List[int]) -> bool:
        ## border = 0
        # cur  longest     border    --     new queue
        # 0       2         0        --       1 2
        # 1       4         2        --      2 3 4
        # we find 4,  loop end
        queue = collections.deque()
        target = len(nums) - 1
        border = 0
        queue.append(0)
        while queue:
            cur = queue.popleft()
            step = nums[cur]
            if cur + step >= target: return True
            if cur + step <= border: continue
            for i in range(border + 1, cur + step + 1):
                queue.append(i)
            border = cur + step
        return False

#Q34 Subarray Sums Divisible by K

'''
Given an integer array nums and an integer k, return the number of non-empty subarrays that have a sum divisible by k.

A subarray is a contiguous part of an array.

 

Example 1:

Input: nums = [4,5,0,-2,-3,1], k = 5
Output: 7
Explanation: There are 7 subarrays with a sum divisible by k = 5:
[4, 5, 0, -2, -3, 1], [5], [5, 0], [5, 0, -2, -3], [0], [0, -2, -3], [-2, -3]
Example 2:

Input: nums = [5], k = 9
Output: 0
 

Constraints:

1 <= nums.length <= 3 * 104
-104 <= nums[i] <= 104
2 <= k <= 104
'''

#Solution 

#Method-1
#prefixSum explanation


class Solution:
    def subarraysDivByK(self, nums: List[int], k: int) -> int:
        
        #the big idea using prefix sum is that:
        # whatever remainder you get from curSum % k,
        # if that same remainder existed in a prefixSum of the array,
        # then the second part of the array not including the prefix sum is perfectly divisable by k
        
        prefixSum = {0: 1}
        curSum = 0
        count = 0
        for num in nums:
            curSum += num 
            if curSum % k in prefixSum: 
                count += prefixSum[curSum % k]
                prefixSum[curSum % k] += 1        
            else:
                prefixSum[curSum % k] = 1
        return count
    
    
#Method-2
#python solution using hash/O(n)/ 90.65% faster than other submissions

class Solution:
    def subarraysDivByK(self, nums: List[int], k: int) -> int:
        prefixsum = {0:1}
        numsum = 0
        count = 0
        for i in range(len(nums)):
            numsum += nums[i]
            if (numsum%k) in prefixsum:
                count += prefixsum[numsum%k]
                prefixsum[numsum%k] += 1
            else:
                prefixsum[numsum%k] = 1

            return count
        
        
        
#Method-3
#Simple Maths

class Solution:
    def subarraysDivByK(self, nums, k):
        dict1, total, running_sum = defaultdict(int), 0, 0
        
        dict1[0] = 1
    
        for i in nums:
            running_sum += i
            total += dict1[running_sum%k]
            dict1[running_sum%k] += 1
        
        return total  
    
#Method-4    
#Dictionary to store index of each remainder, binary search to get index

class Solution:
    def subarraysDivByK(self, A, K):
        ma = {}
        res = 0
        for i in range(K):
            ma[i] = []
        sum = 0
        for i in range(len(A)):
            sum += A[i]
            ma[sum%K].append(i)
        res += len(ma[0])
        sum = 0
        for i in range(len(A)):
            sum += A[i]
            found = bisect.bisect_right(ma[sum%K], i)
            res += len(ma[sum%K]) - found
        return res

    
#Method-5 

#o(n) using prefix sum and dict

from collections import defaultdict
class Solution:
    def subarraysDivByK(self, A, K):
        """
        :type A: List[int]
        :type K: int
        :rtype: int
        """
        prefix_dict = defaultdict(lambda: 0)
        # Don't forget [] as a prefix
        prefix_dict[0] = 1
        prefix = list(A)
        res    = 0
        for i in range(0, len(A)):
            # don't start i from 1!!!
            if i > 0:
                prefix[i] += prefix[i - 1]
            prefix_rem = prefix[i] % K
            res += prefix_dict[prefix_rem]
            #print(prefix_rem, prefix_dict[prefix_rem], res)
            prefix_dict[prefix_rem] += 1
        #print(prefix)
 
        return res

#Q35 First Missing Positive

'''
Given an unsorted integer array nums, return the smallest missing positive integer.

You must implement an algorithm that runs in O(n) time and uses constant extra space.

 

Example 1:

Input: nums = [1,2,0]
Output: 3
Explanation: The numbers in the range [1,2] are all in the array.
Example 2:

Input: nums = [3,4,-1,1]
Output: 2
Explanation: 1 is in the array but 2 is missing.
Example 3:

Input: nums = [7,8,9,11,12]
Output: 1
Explanation: The smallest positive integer 1 is missing.
 

Constraints:

1 <= nums.length <= 105
-231 <= nums[i] <= 231 - 1


'''

# Solution 

#Method-1

class Solution:
    def firstMissingPositive(self, nums: List[int]) -> int:
        nums.sort()
        
        for num in nums:
            if num > 0:
                indx = nums.index(num)
                nums = nums[indx:]
                break
                
        if max(nums) <= 0 or nums[0] > 1: return 1
        
        nums1 = nums[1:] + [nums[0]]
        
        zpobj = zip(nums,nums1)
        
        for x,y in zpobj:
            if (y-x) > 1: return (x+1)
        
        return max(nums)+1
        
#Method-2

class Solution:
    def firstMissingPositive(self, nums: List[int]) -> int:
        poss_val = {}
        for i in range(1, len(nums)+1):
            poss_val[i] = True
    
        for i in nums:
            if i in poss_val:
                del poss_val[i]
    
        if len(poss_val)>0:
            return list(poss_val.keys())[0]
        else:
            return len(nums)+1
        
#Method-3

class Solution:
    def firstMissingPositive(self, nums: List[int]) -> int:
        candidate = 1
        for i in sorted(list(set(nums))):
            if i < 1:
                continue
            elif i == candidate:
                candidate += 1
                continue
            else:
                return candidate
        return candidate
    
    
    
#Method-4    

# Sorting solution

# Another simple solution lies in sorting the array and iterating through it until we reach the last non-positive number and further checking that every positive number is present in the sorted array.


class Solution:
    def firstMissingPositive(self, nums: List[int]) -> int:

        # sort nums
        nums.sort()
        cur = 0
        
        for idx, val in enumerate(nums):
            # skip the negatives
            if val <= 0:
                continue

            # check that next value in sorted nums contains
            # number that immeadiately follows it or is equal to it
            # set current lowest positive to one that we checked
            elif val == cur or val == cur + 1:
                cur = val
           
           # break cycle if there is a gap of more than 1 between two
           # neighbouring values in sorted nums
            else:
                break

        return cur + 1
    
    
# Complexity analysis
# Let N be the length of the nums array.

# Time Complexity: O(N * logN)
# Quicksort is generally considered the fastest among the usual sorting algorithms since its time complexity is O(N * logN) on average for a randomly sampled array. However, most programming languages use some sort of hybrid, heavily optimized algorithm as their native sort. Usually, the native sorting algorithms are the fastest, but their average time complexity is O(N * logN).
# For each in nums[i], we check whether the value is positive and equal to the previous or bigger by one.

# In total we have O(N * logN + N * M) = O(N * logN + N) = O(N * logN)

# Space Complexity: O(1)
# We use constant extra space to store a fixed number of variables to account for the current number we search for. Quicksort is an in-place sorting algorithm, meaning that it uses no extra space.

# However, if you use native to your preferred language sorting algorithm, it may use a linear extra space in a worst-case scenario.



#Method-5

# Hash-Table solution

# The pros of using a hash table are that hash tables are implemented in such a way that adding, searching for, and deleting a value is done within average and amortized O(1) time. The solution lies in iterating through nums and adding every positive integer to the hash table, and then checking for the presence in the hash table of every positive integer in ascending order.




class Solution:
    def firstMissingPositive(self, nums: List[int]) -> int:

        # create hash table
        present_values = set()

        # add every value from nums to hash table
        for v in nums:
            if v > 0:
                present_values.add(v)
        
        # searching for lowest missing value, starting with 1
        cur = 1
        
        while cur in present_values:
            cur += 1

        return cur
    
    
# Complexity analysis
# Let N be the length of the nums array, and O(M) be the time complexity of finding whether a certain positive number is present in the hash table.

# Time Complexity: O(N)
# For each nums[i], we add its value to the hash table in O(1) time. For values in the range [1, …, N], we check whether they are present in the hash table in O(M) time.

# In total we have O(N * 1 + N * M) = O(N + N * 1) = O(N)
# Space Complexity: O(N)
# We use linear extra space to store the hash table (some of the values in nums are stored in the hash table). Not knowing the exact number of positive integers in nums, in the worst-case scenario, all values in nums will be positive), and thus hash table stores a certain percentage P of values in nums.

# Note that O(P / 100 * N) = O(N)




#Method-6

# Final solution

# There are a couple of constraints to the problem, which will help us find the right solution:

# We need to store somehow information about the existence of a certain positive number
# According to the problem’s formulation, we can not use additional space to store this information.
# We can not sort the nums array to store information in an intuitive ascending way because of the time complexity constraints which do not allow for sorting.
# The only way to store all necessary information is in the nums array itself, and here is how we will do it.

# We could use the cell at the index that corresponds to a specific value v to store information about the value v so that nums[v], which contains some value k, will represent the existence of v, yet still containing information about the k value.

# Since we only care about the positive numbers, upon reaching value v, we could make the value in nums[v] a negative value of the same power, nums[v] = -nums[v]. But you can already see some flaws in this approach:

# In case nums[v] = 0, then -nums[v] = 0 as well, not reflecting the existence of v.
# Negative integers could already be present in nums, confusing the algorithm, such as in the following case, say there is no value v in nums, but nums[i] = -2, then the algorithm would think that v was present in nums.
# Large values greater than the highest index in nums can also be present in nums, calling for runtime errors.
# Let us try to fix these issues:

# In case nums[v] = 0: Since zero is not a positive integer, we do not care about its existence. We can replace it with any number that we know exists in nums, as adding a number already present in nums will not reflect on the lowest missing integer. The number that surely is the number v that we are processing at the moment nums[v] = 0 => nums[v] = -v.
# Since the presence of negative values is irrelevant to us (we are looking for the lowest positive integer), we can replace all negatives with zeroes, especially since we have already solved the ‘zero’ problem.
# As explained in the brute-force approach, missing values is in the range [1, …, N + 1] thus, we can ignore all values greater than N (if all values in [1, …, N] are present in nums, then N + 1 is the lowest missing, thus no need to store information about N + 1), or perhaps more conveniently replace them with zeroes
# And lastly, for convenience, to avoid messing with indices, we will add another zero value at the end of the array to represent the existence of value N; consequently, nums[N] will not present us with a runtime error.


class Solution:
    def firstMissingPositive(self, nums: List[int]) -> int:
        # add zero value to the end to avoid messing with indices
        nums.append(0)

        # nums preprocessing
        for idx, num in enumerate(nums):
            if nums[idx] <= 0 or nums[idx] >= len(nums):
                nums[idx] = 0

        # getting nums to store information about the existence of processed positive integer
        for idx, num in enumerate(nums):
            i = abs(num)

            if nums[i] == 0:
                nums[i] = -i
            else:
                nums[i] = -abs(nums[i])

        idx = 1

        # finding lowest positive integer that is missing from nums
        while idx < len(nums) and nums[idx] < 0:
            idx += 1

        return idx


# Complexity analysis
# Let N be the length of the nums array.

# Time Complexity: O(N * logN)
# For each nums[i], we check whether it is negative or larger than N and replace it with zero if the condition is true in O(N) time. For each nums[i] = v we set nums[|v|] = -|v| in O(N) time. For each nums[i] = v, we check whether v is larger than zero, meaning that v was not present in nums, consequently v being the first missing positive in O(N) time

# In total we have O(N + N + N) = O(N)

# Space Complexity: O(1)
# We use constant extra space to store a fixed number of variables to account for the current number/index.





#Q36 Largest Rectangle in Histogram
'''

Given an array of integers heights representing the histogram's bar height where the width of each bar is 1, return the area of the largest rectangle in the histogram.

 

Example 1:


Input: heights = [2,1,5,6,2,3]
Output: 10
Explanation: The above is a histogram where width of each bar is 1.
The largest rectangle is shown in the red area, which has an area = 10 units.
Example 2:


Input: heights = [2,4]
Output: 4
 

Constraints:

1 <= heights.length <= 105
0 <= heights[i] <= 104

'''

#Solution


 # Method-1
#Stack Solution 

class Solution:
    def largestRectangleArea(self, heights: List[int]) -> int:
        stack = [] # pair (starting index, height)
        max_area = 0
        
        for i, height in enumerate(heights):
            if not stack:
                stack.append((i, height))
                continue
                
            if height > stack[-1][1]:
                stack.append((i, height))
                continue
                
            start_i = stack[-1][0]
                
            while stack and height <= stack[-1][1]:
                start_i, h = stack.pop()
                max_area = max(max_area, (i - start_i) * h)
                
            stack.append((start_i, height))
            
        while stack:
            start_i, h = stack.pop()
            max_area = max(max_area, (len(heights) - start_i) * h) 
        
        return max_area


# Method-2


"""
 For each height, if the it is lower than the previous one, it means that the previous are not able to extend anymore. So we calculate its area.

If the previous area, is larger than the current one, it means that the current one are able to extand backward.
"""


class Solution:
    def largestRectangleArea(self, heights: List[int]) -> int:
        maxArea = 0
        stack = []
        
        heights.append(0) #dummy for the ending
        
        for i, h in enumerate(heights):
            start = i
            while stack and h<stack[-1][1]: #[0]
                j, h2 = stack.pop()
                maxArea = max(maxArea, h2*(i-j))
                start = j
            stack.append((start, h)) #[1]
        
        return maxArea
"""
For interview preparation, similar problems, check out my GitHub.
It took me a lots of time to make the solution. Becuase I want to help others like me.
Please give me a star if you like it. Means a lot to me.
https://github.com/wuduhren/leetcode-python
"""


# Method-3

class Solution:
    def largestRectangleArea(self, heights: List[int]) -> int:
        n = len(heights)
        left = [1]*n
        right = [1]*n
        
        for i in range(1,n):
            j = i - 1
            while j>=0 and heights[j] >= heights[i]:
                j -= left[j]
            left[i] = i - j
             
        for i in range(n-2,-1,-1):
            j = i + 1
            while j < len(heights) and heights[i] <= heights[j]:
                j += right[j] 
            right[i] = j - i
            
        res = 0
        for i in range(n):
            res = max(res,heights[i]*(left[i]+right[i]-1))
                
        return res
    
    

# Method-4

# stack solution with detailed comments


class Solution(object):
    def largestRectangleArea(self, heights):
        """
        :type heights: List[int]
        :rtype: int
        """
        # idea is that we iterate thru all heights, and add them to a stack
        # stack invariant is that top items are higher than bottom items.
        # if a new height H is being added to the stack that violates the invariant, we keep popping
        # from the stack (call popped height H') until H > H'. We then know that a rectangle of height H' started from
        # the x coordinate of H` and ended at the x coordinate of H.
        
        # Example we have heights = [2,1,2]
        # 1. add 2 to stack. stack: [(x=0,h=2)]
        # 2. trying to add 1 to stack, pop off 2. Rectangle of height 2 started at x=0 and ended at x=1, max_area = 2
        #    stack: [(x=0,h=1)]
        # 3. add 2 to stack. stack: [(x=0,h=1),(x=2,h=2)]
        # Now we have finished iterating, process leftover rectangles.
        # 4. pop (x=2,h=2), max_area still = 2
        # 5. pop (x=0,h=1), max area is now (3-0)*1 = 3
        max_area = 0
        if not heights:
            return 0
        stack = [(0, heights[0])] # tuple of x_coord, height
        for j, height in enumerate(heights[1:]):
            i = j + 1
            left_x = i
            while stack and height < stack[-1][1]: # if rectangle to be added is smaller than top of stack keep popping
                left_x, left_height = stack.pop()
                max_area = max(max_area, (i - left_x) * left_height)
            stack.append((left_x,height)) 
            # smaller block starts from coordinate of larger one
            # so if we popped something, we use the x_coordinate of the popped thing as the new x_coord to store in the stack
            # otherwise if we didnt pop anything the new rectangle starts from this x_coord.
        total_len = len(heights)
        
        # Process any leftover rectangles after iterating thru all heights
        while stack:
            left_x, left_height = stack.pop()
            max_area = max(max_area, (total_len - left_x) * left_height)
        return max_area




# Method-5
# one pass monotonic stack algorithm, O(n) / O(n), 


class Solution:
    def largestRectangleArea(self, heights: List[int]) -> int:
        # for each element we just find previous and next element less than that, ple and nle
        # the rectangle candidate area would be the element height multiplied by the index range
        stack = [-1] # previous less element has the virtual index -1
        n = len(heights)
        max_rect = -math.inf        
        for i in range(n + 1): # we go one more step as if there is n+1's element with zero height
            # increasing monotonic stack - standard algorithm to find previous and next less element
            while len(stack) > 1 and (i == n or heights[stack[-1]] >= heights[i]):                
                mid_idx = stack.pop()              
                # for the element higher than current, the current one would be nle
                # the previous in stack would ple
                max_rect = max(max_rect, heights[mid_idx] * (i - stack[-1] - 1))
            # add index to the monotonicaly increasing stack
            stack.append(i)                    
        return max_rect



#Q37  Insert Delete GetRandom O(1) - Duplicates allowed

'''
RandomizedCollection is a data structure that contains a collection of numbers, possibly duplicates (i.e., a multiset). It should support inserting and removing specific elements and also removing a random element.

Implement the RandomizedCollection class:

RandomizedCollection() Initializes the empty RandomizedCollection object.
bool insert(int val) Inserts an item val into the multiset, even if the item is already present. Returns true if the item is not present, false otherwise.
bool remove(int val) Removes an item val from the multiset if present. Returns true if the item is present, false otherwise. Note that if val has multiple occurrences in the multiset, we only remove one of them.
int getRandom() Returns a random element from the current multiset of elements. The probability of each element being returned is linearly related to the number of same values the multiset contains.
You must implement the functions of the class such that each function works on average O(1) time complexity.

Note: The test cases are generated such that getRandom will only be called if there is at least one item in the RandomizedCollection.

 

Example 1:

Input
["RandomizedCollection", "insert", "insert", "insert", "getRandom", "remove", "getRandom"]
[[], [1], [1], [2], [], [1], []]
Output
[null, true, false, true, 2, true, 1]

Explanation
RandomizedCollection randomizedCollection = new RandomizedCollection();
randomizedCollection.insert(1);   // return true since the collection does not contain 1.
                                  // Inserts 1 into the collection.
randomizedCollection.insert(1);   // return false since the collection contains 1.
                                  // Inserts another 1 into the collection. Collection now contains [1,1].
randomizedCollection.insert(2);   // return true since the collection does not contain 2.
                                  // Inserts 2 into the collection. Collection now contains [1,1,2].
randomizedCollection.getRandom(); // getRandom should:
                                  // - return 1 with probability 2/3, or
                                  // - return 2 with probability 1/3.
randomizedCollection.remove(1);   // return true since the collection contains 1.
                                  // Removes 1 from the collection. Collection now contains [1,2].
randomizedCollection.getRandom(); // getRandom should return 1 or 2, both equally likely.
 

Constraints:

-231 <= val <= 231 - 1
At most 2 * 105 calls in total will be made to insert, remove, and getRandom.
There will be at least one element in the data structure when getRandom is called.

'''

# Solution 



# Method-1

from collections import defaultdict
class RandomizedCollection:

    def __init__(self):
        # previously in 380, we have a dict with elem (val: val's idx)
        # now since duplicate allowed, for the same value, it could have many indices
        # so now the elem is like (val: (val's idx1, idx2, ... ))
        # we can make it as a set
        self.nums = []
        self.pos = defaultdict(set)
        
    def insert(self, val: int) -> bool:
        '''
        # too repetitive:
        if val not in self.pos:
            self.nums.append(val)
            self.pos[val].add(len(self.nums)-1)
            return True
        else:
            self.nums.append(val)
            self.pos[val].add(len(self.nums)-1)
            return False
        '''
        self.nums.append(val)
        self.pos[val].add(len(self.nums)-1)
        return len(self.pos[val])==1
        # if the length of idx set is 1, then it is the first idx for this val
        # so we should return True

    def remove(self, val: int) -> bool:
        if len(self.pos[val])==0:
            return False
        # to remove a val, we can pop out one of the index in that index set
        remove_idx = self.pos[val].pop()
        last = self.nums[-1]
        self.nums[remove_idx] = last # we replace val to remove with last number
        # update the last number 's index
        # we should always do add first, in case that the to remove val is also the last number
        self.pos[last].add(remove_idx) 
        self.pos[last].discard(len(self.nums)-1)

        self.nums.pop() # pop out the value as O(1) remove operation
        return True
        

    def getRandom(self) -> int:
        return random.choice(self.nums)



# Method-2

class RandomizedCollection:

    def __init__(self):
        self.items = []

    def insert(self, val: int) -> bool:
        self.items.append(val)
        if self.items.count(val) > 1:
            return False
        else:
            return True

    def remove(self, val: int) -> bool:
        if val in self.items:
            flag = True
            self.items.remove(val)
        else:
            flag = False
        
        return flag

    def getRandom(self) -> int:
        return choice(self.items)
            

# Method-3

#Python - different - O(log N) for updates - sorted list + counter


from random import choice

from sortedcontainers import SortedList

class RandomizedCollection:

    def __init__(self):
        self.list = SortedList()
        self.count = Counter()
        
    def insert(self, val: int) -> bool:
        self.count[val] += 1        
        self.list.add(val)        
        return self.count[val] == 1
                
    def remove(self, val: int) -> bool:
        if self.count[val] < 1: return False
        self.count[val] -= 1                
        self.list.pop(self.list.index(val))        
        return True
        
    def getRandom(self) -> int:
        return choice(self.list)
    
    
    
    
# Method-4 

class RandomizedCollection(object):

    def __init__(self):
        self.vals, self.indexs = [], collections.defaultdict(set)

    def insert(self, val):
        self.vals.append(val)
        self.indexs[val].add(len(self.vals)-1)
        return len(self.indexs[val]) == 1

    def remove(self, val):
        if not self.indexs[val]:
            return False
        x = self.indexs[val].pop()
        self.vals[x] = None
        return True

    def getRandom(self):
        x = None
        while x is None:
            x = random.choice(self.vals)
        return x
    

    
# Method-5

class RandomizedCollection(object):
    def __init__(self):
        """
        Initialize your data structure here.
        """
        self.dOfd = collections.defaultdict(dict)
        self.d = collections.defaultdict(list)
        self.a = []

    def insert(self, val):
        """
        Inserts a value to the collection. Returns true if the collection did not already contain the specified element.
        :type val: int
        :rtype: bool
        """
        self.d[val].append(len(self.a))
        self.dOfd[val][len(self.a)] = len(self.d[val]) - 1
        self.a.append(val)
        return len(self.d[val]) == 1

    def remove(self, val):
        """
        Removes a value from the collection. Returns true if the collection contained the specified element.
        :type val: int
        :rtype: bool
        """
        dd = self.dOfd
        a = self.a
        d = self.d
        if not d[val]:
            return False
        idx = d[val][-1]
        a[idx] = a[-1]
        idxInDForLast = dd[a[-1]][len(a) - 1]
        d[a[-1]][idxInDForLast] = idx
        dd[a[-1]][idx] = idxInDForLast

        # del dd[val][idx]
        del dd[a[-1]][len(a) - 1]
        d[val].pop()
        a.pop()
        return True

    def getRandom(self):
        """
        Get a random element from the collection.
        :rtype: int
        """
        return self.a[random.randrange(0, len(self.a))]
    
    

# Your RandomizedCollection object will be instantiated and called as such:
# obj = RandomizedCollection()
# param_1 = obj.insert(val)
# param_2 = obj.remove(val)
# param_3 = obj.getRandom()





#Q38 Best Time to Buy and Sell Stock III

'''
You are given an array prices where prices[i] is the price of a given stock on the ith day.

Find the maximum profit you can achieve. You may complete at most two transactions.

Note: You may not engage in multiple transactions simultaneously (i.e., you must sell the stock before you buy again).

 

Example 1:

Input: prices = [3,3,5,0,0,3,1,4]
Output: 6
Explanation: Buy on day 4 (price = 0) and sell on day 6 (price = 3), profit = 3-0 = 3.
Then buy on day 7 (price = 1) and sell on day 8 (price = 4), profit = 4-1 = 3.
Example 2:

Input: prices = [1,2,3,4,5]
Output: 4
Explanation: Buy on day 1 (price = 1) and sell on day 5 (price = 5), profit = 5-1 = 4.
Note that you cannot buy on day 1, buy on day 2 and sell them later, as you are engaging multiple transactions at the same time. You must sell before buying again.
Example 3:

Input: prices = [7,6,4,3,1]
Output: 0
Explanation: In this case, no transaction is done, i.e. max profit = 0.
 

Constraints:

1 <= prices.length <= 105
0 <= prices[i] <= 105

'''

# Solution

# # Method-1

# # divide and conquer solution 


class Solution:
    def maxProfit(self, prices: List[int]) -> int:
        # use divide and conquer method:
        # use left and right to track the maximum profits that can be obtained in the corresponding path
        # left[i] = max(left[i-1],prices[i]-leftMin)
        # right[i] = max(right[i+1],rightMax-prices[i])
        # keep track of the min of the left part from left to right, and update it if meet a smaller value
        # keep track of the max of the right part from right to left, and update if if meet a bigger value
        
        n = len(prices)
        
        left = [0]*n
        right = [0]*n
        
        leftMin = prices[0]
        for i in range(1,n):
            left[i] = max(left[i-1],prices[i]-leftMin)
            if prices[i] < leftMin:
                leftMin = prices[i]
                
        rightMax = prices[-1]
        for i in range(n-2,-1,-1):
            right[i] = max(right[i+1],rightMax - prices[i])
            if prices[i] > rightMax:
                rightMax = prices[i]
                
        # find max(leftpart+rightpart)
        profits = 0
        for i in range(n):
            curr = right[i]+(left[i-1] if i>0 else 0)
            if curr > profits:
                profits = curr
                
        return profits
    
#Method-2

class Solution(object):
    def maxProfit(self, prices):
        if not prices: 
            return 0
        n, ans = len(prices), 0
        left, buy = [0] * n, prices[0]
        for i in range(1, n):
            left[i] = max(left[i - 1], prices[i] - buy)
            buy = min(buy, prices[i])
    
        right, sell = [0] * n, prices[-1]
        for i in range(n - 2, -1, -1):
            right[i] = max(right[i + 1], sell - prices[i])
            sell = max(sell, prices[i])
            ans = max(ans ,left[i] + right[i])
        return ans
    

    
 #Method-3   

# Linear Solution

# Consider day i. Say we know maximum profit possible from day 0 to day i. Say we also know the maximum profit from day i+1 to day N-1. Let us call day[i] = forward[i] + backward[i+1]. Backward[i+1] will give us the maximum profit from day i+1 to N-1.
# Clearly then, the solution will be max(day[i]).
# Now forward[i] is Best Stock 1 problem.
# Backward[j[ can also be modelled as the forward[i] problem from j = i+1 to N-1. However this will make it an O(N^2) operation. Can we do it in O(N)?
# How about we start from last index and move to 0? Backward[i] is now the reverse problem - start from end, update the highest value as sell value as you move left, and keep updating maximum profit.
# Now we will find the cumulative max of both array in respective direction.
# Array: [1,2,4,2,5,7,2,4,9,0]
# forward: [0, 1, 3, 3, 4, 6, 6, 6, 8, 8]
# reverse: [8, 7, 7, 7, 7, 7, 7, 5, 0, 0]

           
class Solution(object):
    def maxProfit(self, prices):
        """
        :type prices: List[int]
        :rtype: int
        """
        if prices == []:
            return 0
        N = len(prices)
        forward, backward = [0]*N, [0]*N

        max_so_far, buy = 0, prices[0]
        for i in range(N):
            forward[i] = max(max_so_far, prices[i]-buy)
            max_so_far = max(max_so_far, forward[i])
            buy = min(buy, prices[i])
        
        max_so_far, sell = 0, prices[-1]
        for i in range(N-1, -1,-1):
            backward[i] = max(max_so_far, sell-prices[i])
            max_so_far = max(max_so_far, backward[i])
            sell = max(sell, prices[i])        
        
        max_profit = 0
        for i in range(N):
            max_profit_day_i = forward[i]+backward[i+1] if i < N-1 else forward[i]
            max_profit = max(max_profit, max_profit_day_i)
            
        return max_profit
    
    
# Recursive DP Memoization Solution

# f[k, i] represents the max profit up until prices[i] (Note: NOT ending with prices[i]) using at most k transactions.
# f[k, i] = max(f[k, i-1], price[i]-price[j] + f[k-1, j-1]) (j in the range of 0 to i-1)
# f[k, i] = max(f[k, i-1], price[i] + max( f[k-1, j-1]--price[j])) (j in the range of 0 to i-1)
# f[0,i] = 0 (0 times transaction makes 0 profit)
# f[k,0] = 0 (if there is only one price data point you can't make any money no matter how many times you can trade)
            

    
#Method-4  
                       
class Solution(object):
    def maxProfit(self, prices):
        """
        :type prices: List[int]
        :rtype: int
        """
        if not prices:
            return 0
        N, K = len(prices), 2
        max_profit = -1
        dp = [[0]*N for _ in range(K+1)]
        for k in range(1, K+1):
            tmpMax = dp[k-1][0] - prices[0]
            for i in range(1, N):
                dp[k][i] = max(dp[k][i-1], prices[i] + tmpMax)
                tmpMax = max(tmpMax, dp[k-1][i] - prices[i])
                max_profit = max(max_profit, dp[k][i])
        return dp[K][N-1]
    
    
    
# Up to multiple max transactions O(n) space O(kn) time
#Method-5

class Solution(object):
    def maxProfit(self, prices):
        return self.maxProfitMultiple(prices, 2)
        
    def maxProfitMultiple(self, prices, max_transations):
        days = len(prices)
        if days < 2:return 0
        dp, times = [0] * days, max_transations
        for i in range(times):
            min_buyin = prices[0]
            for j in range(1, days):
                dp[j], min_buyin = max(dp[j-1], prices[j] - min_buyin), min(min_buyin, prices[j]-dp[j])    
        return dp[-1]



#Q39 Max Value of Equation

'''
You are given an array points containing the coordinates of points on a 2D plane, sorted by the x-values, where points[i] = [xi, yi] such that xi < xj for all 1 <= i < j <= points.length. You are also given an integer k.

Return the maximum value of the equation yi + yj + |xi - xj| where |xi - xj| <= k and 1 <= i < j <= points.length.

It is guaranteed that there exists at least one pair of points that satisfy the constraint |xi - xj| <= k.

 

Example 1:

Input: points = [[1,3],[2,0],[5,10],[6,-10]], k = 1
Output: 4
Explanation: The first two points satisfy the condition |xi - xj| <= 1 and if we calculate the equation we get 3 + 0 + |1 - 2| = 4. Third and fourth points also satisfy the condition and give a value of 10 + -10 + |5 - 6| = 1.
No other pairs satisfy the condition, so we return the max of 4 and 1.
Example 2:

Input: points = [[0,0],[3,0],[9,2]], k = 3
Output: 3
Explanation: Only the first two points have an absolute difference of 3 or less in the x-values, and give the value of 0 + 0 + |0 - 3| = 3.
 

Constraints:

2 <= points.length <= 105
points[i].length == 2
-108 <= xi, yi <= 108
0 <= k <= 2 * 108
xi < xj for all 1 <= i < j <= points.length
xi form a strictly increasing sequence.

'''

# Solution

# Method-1

#Monotonic queue...

class Solution:
    def findMaxValueOfEquation(self, x: List[List[int]], k: int) -> int:
        ans=-inf
        q=[]
        j=1
        l=len(x)
        for i in range(l-1):
            j=max(i+1,j)
            while q and q[0]<=i:
                q.pop(0)
            while j<l and x[j][0]-x[i][0]<=k: 
                while q and sum(x[q[-1]])<=sum(x[j]):
                    q.pop(-1)
                q.append(j)
                j+=1
            if not q:continue
            ans=max(ans,x[i][1]-x[i][0]+sum(x[q[0]]))
        return ans
    

# Method-2    
#sliding window + decreasing queue

# basic idea is sliding window by |Xj - Xi|, and keep a decreasing queue, each element in queue is (Yi - Xi, i). Because the equation is Yj + Xj + Yi - Xi actually, so we always need keep track of maximum Yi - Xi within the sliding window. The idea coming from max value of k size sliding window.

class Solution:
    def findMaxValueOfEquation(self, points: List[List[int]], k: int) -> int:
        res = float('-inf')
        q = collections.deque()
        
        i, j = 0, 0
        while j < len(points):
            while q and points[j][0] - points[i][0] > k:
                if q[0][1] == i:
                    q.popleft()
                i += 1
                
            if q:
                res = max(res, q[0][0] + points[j][0] + points[j][1])
                
            while q and q[-1][0] < points[j][1] - points[j][0]:
                q.pop()
            q.append((points[j][1] - points[j][0], j))
            
            j += 1
                
        return res
 


# Method-3

#Two Pointer, Max Heap, O(nlogn)


class Solution:
    def findMaxValueOfEquation(self, points: List[List[int]], k: int) -> int:
        n = len(points)
        heap = []
        i,j=0,0
        removed = set()
        ans = -999999999
        while i<n:
            if j<n and points[j][0]-points[i][0] <= k:
                heapq.heappush(heap,(-(points[j][1]+points[j][0]),j))
                j += 1
            else:
                while heap and (heap[0][1] in removed or heap[0][1] == i):
                    heapq.heappop(heap)
                if not heap:
                    i += 1
                    continue
                val,idx = heap[0]
                ans = max(ans,-val-points[i][0] + points[i][1])
                removed.add(i)
                i += 1
        return ans



# Method-4

class Solution:
    def findMaxValueOfEquation(self, points, k):
        res, pq, i = -float('inf'), [], 0
        for j in range(len(points)):
            while pq and points[j][0] - pq[0][1] > k: heapq.heappop(pq)
            if pq: res = max(res, -pq[0][0] + points[j][1] + points[j][0])
            heapq.heappush(pq, (points[j][0] - points[j][1], points[j][0]))
        return res
                

    
    
    
# Method-5  
#Monotonic Queue & Heap


class Solution:
    def findMaxValueOfEquation(self, points: List[List[int]], k: int) -> int:
        # bottom line here is to use decreaseing queue/heap to maintain
        # maximum (yi-xi) and xi to be able to calculate the 
        # max equation => yi+yj-xi+xj == (yi-xi)+yj+xj
        # Time O(n) Space O(n)

        decre_q = deque()
        result = -sys.maxsize

        for x,y in points:
            # while xi - xj <= k, i.e. xi miust be greater than xj-k
            while decre_q and decre_q[0][1] < x - k:
                decre_q.popleft()

            if decre_q:
                result = max(result, decre_q[0][0]+x+y)

            # maintain maximum (yi-xi) in decreasing queue
            while decre_q and decre_q[-1][0] <= y-x:
                decre_q.pop()

            decre_q.append((y-x, x))

        return result

        # use heap Time O(logn), Space O(n)
        hp = []
        result = -sys.maxsize
        for x,y in points:
            # while xi - xj <= k, i.e. xi miust be greater than xj-k
            while hp and hp[0][1] < x - k:
                heappop(hp)

            if hp:
                result = max(result, -hp[0][0]+x+y)

            heappush(hp, (-(y-x), x))

        return result
    
    
    
# Method-6    
# Monotonic Stack Approach
#TC O(n)

class Solution:
    def findMaxValueOfEquation(self, points: List[List[int]], k: int) -> int:
        stack = collections.deque()
        ans = float('-inf')

        for x, y in points:
            while stack and abs(stack[0][0]-x)>k:
                stack.popleft()
            if stack:
                ans = max(ans, x+y+stack[0][1])
            while stack and stack[-1][1]<=y-x:
                stack.pop()
            stack.append((x, y-x))
        return ans



# # Method-7    

# #O(n log n) solution with alternate backward formulation


# I can see many people used the forward formulation, but for me it was easier to think in the backwards one. If you are moving from right to left, and at each iteration you name your reference x1, y1; then the best guy you can pair with is on the right (no need to check left side due symmetry), and it is the one giving you maximum
# y1 + y2 + abs(x1 - x2).

# If we split the function above in two pieces, y1 + y2 and abs(x1 - x2), and remember that x1 and y1 are constants for current iteration; we realize that both are increasing functions respect to their respective parameters y2 and x2. Hence we want to pick the maximum value of both variables together, which I think would be simply the max of their sum (aka y2 + x2), over all the elements on the right of current reference (x1, y1).

# Above may allow a more formal proof, but if you buy it, then we can apply the usual trick of finding such best guy (x2, y2) on each iteration with a max-heap; yielding the O(n log n) solution that many other got with the forward-thinking approach.


class Solution:
    def findMaxValueOfEquation(self, points: List[List[int]], k: int) -> int:
        n = len(points)
        heap = []
        ans = -inf
        for i in reversed(range(n)):
            x1, y1 = points[i]
            while heap:
                _, j = heappop(heap)
                x2, y2 = points[j]
                dx = abs(x1 - x2)
                if dx <= k:
                    ans = max(ans, y1 + y2 + dx)
                    heappush(heap, (-(x2 + y2), j))
                    break
            heappush(heap, (-(x1 + y1), i))
        return ans  


    