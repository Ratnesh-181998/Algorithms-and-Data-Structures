
#Trie

#Q1. 

https://leetcode.com/explore/learn/card/trie

'''
Trie, also called prefix tree, is a special form of a Nary tree.

In this card, we will go deep into the implementation of Trie and talk about how to use this data structure to solve problems.

After completing this card, you should be able to:

Understand the concept of Trie;
Do insertion and search operations in a Trie;
Understand how Trie helps in practical application;
Solve practical problems using Trie.


'''

#Q2. K Divisible Elements Subarrays
'''

Given an integer array nums and two integers k and p, return the number of distinct subarrays which have at most k elements divisible by p.

Two arrays nums1 and nums2 are said to be distinct if:

They are of different lengths, or
There exists at least one index i where nums1[i] != nums2[i].
A subarray is defined as a non-empty contiguous sequence of elements in an array.

 

Example 1:

Input: nums = [2,3,3,2,2], k = 2, p = 2
Output: 11
Explanation:
The elements at indices 0, 3, and 4 are divisible by p = 2.
The 11 distinct subarrays which have at most k = 2 elements divisible by 2 are:
[2], [2,3], [2,3,3], [2,3,3,2], [3], [3,3], [3,3,2], [3,3,2,2], [3,2], [3,2,2], and [2,2].
Note that the subarrays [2] and [3] occur more than once in nums, but they should each be counted only once.
The subarray [2,3,3,2,2] should not be counted because it has 3 elements that are divisible by 2.
Example 2:

Input: nums = [1,2,3,4], k = 4, p = 1
Output: 10
Explanation:
All element of nums are divisible by p = 1.
Also, every subarray of nums will have at most 4 elements that are divisible by 1.
Since all subarrays are distinct, the total number of subarrays satisfying all the constraints is 10.
 

Constraints:

1 <= nums.length <= 200
1 <= nums[i], p <= 200
1 <= k <= nums.length
 

Follow up:

Can you solve this problem in O(n2) time complexity?

'''
#Solution 

#Approach-1

# O(n **2)
# set
# sliding window

class Solution:
    def countDistinct(self, nums: List[int], k: int, p: int) -> int:
        subArrays = set()
        n = len(nums)
        count = 0
        for i in range(n):
            for j in range(i, n):
                if count == k and nums[j] % p == 0:
                    break
                if nums[j] % p == 0:
                    count += 1
                subArrays.add(str(nums[i:j+1]))
            count = 0
        return len(subArrays)

#Approach-2: O(N^2) presum+trie

class Node:
    def __init__(self):
        self.children = dict()
class Solution:
    def countDistinct(self, nums: List[int], k: int, p: int) -> int:
        pre_num = [0]
        for n in nums:
            if n % p == 0:
                pre_num.append(pre_num[-1] + 1)
            else:
                pre_num.append(pre_num[-1])
        trees = {}
        res = 0
        for i in range(len(nums)):
            if nums[i] not in trees:
                trees[nums[i]] = Node()
            cur = trees[nums[i]]
            for j in range(i, len(nums)):
                c = 0 if nums[j] % p != 0 else 1
                if c + pre_num[j] - pre_num[i] > k:
                    break
                if nums[j] not in cur.children:
                    res += 1
                    cur.children[nums[j]] = Node()
                cur = cur.children[nums[j]]
        return res
    
    

#Approach-3: DIRECT solution

class Solution:
    def countDistinct(self, nums: List[int], k: int, p: int) -> int:
        
        LENGTH = len( nums )
        
        #Will hold all subarrays
        all_subarrays = set()
        
        #Go through each index as a starting point
        for start in range( LENGTH ):
            
            #Each iteration reset the current subarray and divisible count
            current_subarray = []
            div_count = 0
            
            #Go to the end
            for j in range( start, LENGTH ):
                #Look at an element
                element = nums[ j ]
                
                #If it is divisible by p
                is_div_by_p = ( element % p ) == 0
                
                #We add it to our div count
                if is_div_by_p:
                    div_count += 1
                    
                #And if we have more than k, we break out of the loop
                if div_count > k:
                    break
                
                #We can then append the element
                current_subarray.append( element )
                
                #And hash the subarray into our set
                all_subarrays.add( str( current_subarray ) )
        
        #Lastly, we return however many there are
        return len( all_subarrays )
    
#Approach-4:Simple Count all combinations

# T = O(N^3)
# S = O(N^2)

class Solution:
    def countDistinct(self, nums: List[int], k: int, p: int) -> int:
        n = len(nums)                        
        sub_arrays = set()
        
		# generate all combinations of subarray
        for start in range(n):
            cnt = 0
            temp = ''
            for i in range(start, n):
                if nums[i]%p == 0:
                    cnt+=1                 
                temp+=str(nums[i]) + ',' # build the sequence subarray in CSV format          
                if cnt>k: # check for termination 
                    break
                sub_arrays.add(temp)                                    
                
        return len(sub_arrays)

