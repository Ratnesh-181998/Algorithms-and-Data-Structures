
#GRAPH

#Q1. Employee Importance

'''
You have a data structure of employee information, including the employee's unique ID, importance value, and direct subordinates' IDs.

You are given an array of employees employees where:

employees[i].id is the ID of the ith employee.
employees[i].importance is the importance value of the ith employee.
employees[i].subordinates is a list of the IDs of the direct subordinates of the ith employee.
Given an integer id that represents an employee's ID, return the total importance value of this employee and all their direct and indirect subordinates.

 

Example 1:


Input: employees = [[1,5,[2,3]],[2,3,[]],[3,3,[]]], id = 1
Output: 11
Explanation: Employee 1 has an importance value of 5 and has two direct subordinates: employee 2 and employee 3.
They both have an importance value of 3.
Thus, the total importance value of employee 1 is 5 + 3 + 3 = 11.
Example 2:


Input: employees = [[1,2,[5]],[5,-3,[]]], id = 5
Output: -3
Explanation: Employee 5 has an importance value of -3 and has no direct subordinates.
Thus, the total importance value of employee 5 is -3.
 

Constraints:

1 <= employees.length <= 2000
1 <= employees[i].id <= 2000
All employees[i].id are unique.
-100 <= employees[i].importance <= 100
One employee has at most one direct leader and may have several subordinates.
The IDs in employees[i].subordinates are valid IDs.

'''

#Solution 


"""
# Definition for Employee.
class Employee:
    def __init__(self, id: int, importance: int, subordinates: List[int]):
        self.id = id
        self.importance = importance
        self.subordinates = subordinates
"""

# class Solution:
#     def getImportance(self, employees: List['Employee'], id: int) -> int:


#Approach-1: Depth-First Search

# Intuition and Algorithm

# Let's use a hashmap emap = {employee.id -> employee} to query employees quickly.

# Now to find the total importance of an employee, it will be the importance of that employee, plus the total importance of each of that employee's subordinates. This is a straightforward depth-first search.

# Time Complexity: O(N)O(N), where NN is the number of employees. We might query each employee in dfs.

# Space Complexity: O(N)O(N), the size of the implicit call stack when evaluating dfs.


class Solution(object):
    def getImportance(self, employees, query_id):
        emap = {e.id: e for e in employees}
        def dfs(eid):
            employee = emap[eid]
            return (employee.importance +
                    sum(dfs(eid) for eid in employee.subordinates))
        return dfs(query_id)
    
    
 
#Approach-2:

class Solution(object):
    def getImportance(self, employees, id):
        """
        :type employees: Employee
        :type id: int
        :rtype: int
        """ 
        emap = {e.id: e for e in employees}
        employee = emap[id]
        total_importance = employee.importance    
        
        for id in employee.subordinates:
            total_importance += self.getImportance(employees, id)
            
        return total_importance
    
    
#Approach-3:BFS + Hashing solution
# hashmap
# bfs + hash

class Solution:
    def getImportance(self, employees: List['Employee'], id: int) -> int:
        count, hashMap = 0, {}
        for employee in employees:
            hashMap[employee.id] = employee
        queue, visited = [], defaultdict(lambda: False)
        queue.append(hashMap[id])
        visited[hashMap[id]] = True
        while len(queue):
            curr = queue.pop(0)
            count += curr.importance
            for subordinate in curr.subordinates:
                if not visited[hashMap[subordinate]]:
                    visited[hashMap[subordinate]] = True
                    queue.append(hashMap[subordinate])
        return count

#Approach-4:DFS no recursion (using a queue) 


class Solution:
    def getImportance(self, employees: List['Employee'], id: int) -> int:
        emp = {e.id: e for e in employees}
        q: Deque['Employee'] = deque()
        q.append(emp[id])

        importance = 0

        while q:
            employee = q.popleft()
            importance += employee.importance
            for sub in employee.subordinates:
                q.append(emp[sub])
            
        return importance

#Approach-5:

# BFS || Dictionary || Queue || Easy
# bfs
# queue
# dictionary
# hashmap


class Solution(object):
    def getImportance(self, employees, id):
        """
        :type employees: List[Employee]
        :type id: int
        :rtype: int
        """
        map_emp = {}
        visited = {}
        for e in employees:
            map_emp[e.id] = e
            visited[e.id] = False
        
        imp = 0
        queue = []
        queue += [map_emp[id]]
        visited[id] = True
        
        while(len(queue) != 0):
            emp = queue[0]
            queue = queue[1:]
            
            imp += emp.importance
            subl = emp.subordinates
            
            for i in subl:
                if not visited[i]:
                    queue += [map_emp[i]]

        
        return imp


#Approach-6:recursive and iterative solution


# recursive:

class Solution:
    def getImportance(self, employees, id):
        table = {emp.id: emp for emp in employees}

        def dfs(emp):
            if emp.subordinates == []:  # base case
                return emp.importance
            else:  # recursive case
                value = emp.importance
                for sub in emp.subordinates:
                    value += dfs(table[sub])
                return value
                # or just:
                # return emp.importance + sum(dfs(table[sub]) for sub in emp.subordinates)

        return dfs(table[id])
    
    
# iterative:

class Solution:
    def getImportance(self, employees, id):
        value = 0
        table = {}
        for emp in employees:
            table[emp.id] = emp

        stack = [table[id]]

        while stack:
            emp = stack.pop()
            for sub in emp.subordinates:
                stack.append(table[sub])
            value += emp.importance

        return value


#Q2.Find the Town Judge

'''

In a town, there are n people labeled from 1 to n. There is a rumor that one of these people is secretly the town judge.

If the town judge exists, then:

The town judge trusts nobody.
Everybody (except for the town judge) trusts the town judge.
There is exactly one person that satisfies properties 1 and 2.
You are given an array trust where trust[i] = [ai, bi] representing that the person labeled ai trusts the person labeled bi.

Return the label of the town judge if the town judge exists and can be identified, or return -1 otherwise.

 

Example 1:

Input: n = 2, trust = [[1,2]]
Output: 2
Example 2:

Input: n = 3, trust = [[1,3],[2,3]]
Output: 3
Example 3:

Input: n = 3, trust = [[1,3],[2,3],[3,1]]
Output: -1
 

Constraints:

1 <= n <= 1000
0 <= trust.length <= 104
trust[i].length == 2
All the pairs of trust are unique.
ai != bi
1 <= ai, bi <= n  

'''

#Solution 

#Approach-1

class Solution:
    def findJudge(self, n: int, trust: List[List[int]]) -> int:
        if len(trust) == 0 and n == 1:
            return 1
        # If theres a cycle in our graph then town judge does not exist
        adj = defaultdict(list)
        nodeVisits = [0] * (n + 1)
        # init adj
        # O(P) where P is the size of trust list
        for u, v in trust:
            adj[u].append(v)

        # O(N + E) N are nodes, E are edges
        for _, trust_list in adj.items():
            for vertex in trust_list:
                nodeVisits[vertex] += 1

        # Now we need to find a node who have a nodeVisit value of (n - 1)
        # and check they dont trust anyone else, this will be the candidate for the judge
        for node, nodeCount in enumerate(nodeVisits):
            if (nodeCount == n - 1) and (not adj[node]):
                return node
        return -1
    
#Approach-2

class Solution:
    def findJudge(self, n: int, trust: List[List[int]]) -> int:
        
        if not len(trust) and n==1:
            return 1
        
        trusted_by = {val: [] for pair in trust for val in pair}
        
        for pair in trust:
            if pair[1] in trusted_by.keys():
                trusted_by[pair[1]].append(pair[0])
            else:
                trusted_by.update({pair[1]: [pair[0]]})
        
        keys = sorted(list(trusted_by.keys()))
        values = [val for person in trusted_by for val in trusted_by[person]]
        
        for person in trusted_by:
            if sorted(trusted_by[person]) == [k for k in keys if k!=person] and person not in values:
                return person
            
        return -1
    
#Approach-3

# GoLang Solution | HashMap 
# hashmap
# golang

class Solution:
    def findJudge(self, n: int, trust: List[List[int]]) -> int:
        score = Counter()
        
        for a, b in trust:
            score[a] -= 1
            score[b] += 1
        
        for person in range(1, n+1):
            if score[person] == n-1:
                return person
        
        return -1
    
    
#Approach-4

from collections import defaultdict

class Solution:
    def findJudge(self, N: int, trust: List[List[int]]) -> int:
        trustsDict = defaultdict(set)
        trustedByDict = defaultdict(set)
        for i in range(N):
            trustsDict[i+1] = set()
            trustedByDict[i+1] = set()
        for truster, trustee in trust:
            trustsDict[truster].add(trustee)
            trustedByDict[trustee].add(truster)
        potentialJudges = []
        for person, trustedBySet in trustedByDict.items():
            if len(trustedBySet) == N-1 and person not in trustedBySet and len(trustsDict[person]) == 0:
                potentialJudges.append(person)
        return potentialJudges[0] if len(potentialJudges) == 1 else -1

#Approach-5

class Solution:
    def findJudge(self, n: int, trust: List[List[int]]) -> int:
        if len(trust) == 0:
            return n if n == 1 else -1
        vis1 = []
        vis2 = []
        for i in range(len(trust)):
            vis1.append(trust[i][1])
            vis2.append(trust[i][0])
            
        filt = set(vis1)
        for i in filt:
            if i not in vis2:
                if vis1.count(i) == n-1:
                    return i
                
        return -1 


#Q2.Find the Town Judge
'''

In a town, there are n people labeled from 1 to n. There is a rumor that one of these people is secretly the town judge.

If the town judge exists, then:

The town judge trusts nobody.
Everybody (except for the town judge) trusts the town judge.
There is exactly one person that satisfies properties 1 and 2.
You are given an array trust where trust[i] = [ai, bi] representing that the person labeled ai trusts the person labeled bi.

Return the label of the town judge if the town judge exists and can be identified, or return -1 otherwise.

 

Example 1:

Input: n = 2, trust = [[1,2]]
Output: 2
Example 2:

Input: n = 3, trust = [[1,3],[2,3]]
Output: 3
Example 3:

Input: n = 3, trust = [[1,3],[2,3],[3,1]]
Output: -1
 

Constraints:

1 <= n <= 1000
0 <= trust.length <= 104
trust[i].length == 2
All the pairs of trust are unique.
ai != bi
1 <= ai, bi <= n

'''

#Solution 

#Approach-1

class Solution:
    def findJudge(self, n: int, trust: List[List[int]]) -> int:
        if len(trust) == 0 and n == 1:
            return 1
        # If theres a cycle in our graph then town judge does not exist
        adj = defaultdict(list)
        nodeVisits = [0] * (n + 1)
        # init adj
        # O(P) where P is the size of trust list
        for u, v in trust:
            adj[u].append(v)

        # O(N + E) N are nodes, E are edges
        for _, trust_list in adj.items():
            for vertex in trust_list:
                nodeVisits[vertex] += 1

        # Now we need to find a node who have a nodeVisit value of (n - 1)
        # and check they dont trust anyone else, this will be the candidate for the judge
        for node, nodeCount in enumerate(nodeVisits):
            if (nodeCount == n - 1) and (not adj[node]):
                return node
        return -1
    
#Approach-2

class Solution:
    def findJudge(self, n: int, trust: List[List[int]]) -> int:
        
        if not len(trust) and n==1:
            return 1
        
        trusted_by = {val: [] for pair in trust for val in pair}
        
        for pair in trust:
            if pair[1] in trusted_by.keys():
                trusted_by[pair[1]].append(pair[0])
            else:
                trusted_by.update({pair[1]: [pair[0]]})
        
        keys = sorted(list(trusted_by.keys()))
        values = [val for person in trusted_by for val in trusted_by[person]]
        
        for person in trusted_by:
            if sorted(trusted_by[person]) == [k for k in keys if k!=person] and person not in values:
                return person
            
        return -1
    
#Approach-3

# GoLang Solution | HashMap 
# hashmap
# golang

class Solution:
    def findJudge(self, n: int, trust: List[List[int]]) -> int:
        score = Counter()
        
        for a, b in trust:
            score[a] -= 1
            score[b] += 1
        
        for person in range(1, n+1):
            if score[person] == n-1:
                return person
        
        return -1
    
    
#Approach-4

from collections import defaultdict

class Solution:
    def findJudge(self, N: int, trust: List[List[int]]) -> int:
        trustsDict = defaultdict(set)
        trustedByDict = defaultdict(set)
        for i in range(N):
            trustsDict[i+1] = set()
            trustedByDict[i+1] = set()
        for truster, trustee in trust:
            trustsDict[truster].add(trustee)
            trustedByDict[trustee].add(truster)
        potentialJudges = []
        for person, trustedBySet in trustedByDict.items():
            if len(trustedBySet) == N-1 and person not in trustedBySet and len(trustsDict[person]) == 0:
                potentialJudges.append(person)
        return potentialJudges[0] if len(potentialJudges) == 1 else -1

#Approach-5

class Solution:
    def findJudge(self, n: int, trust: List[List[int]]) -> int:
        if len(trust) == 0:
            return n if n == 1 else -1
        vis1 = []
        vis2 = []
        for i in range(len(trust)):
            vis1.append(trust[i][1])
            vis2.append(trust[i][0])
            
        filt = set(vis1)
        for i in filt:
            if i not in vis2:
                if vis1.count(i) == n-1:
                    return i
                
        return -1
 

#Approach-6

# Solution O(1) Memory

# For trust[i] = [ai, bi], we call ai as truster and bi as trustee

# Time Complexity = O(nlogn)
# Space Complexity = O(1)

class Solution:
    def findJudge(self, n: int, trust: List[List[int]]) -> int:
        
        trust = list(sorted(trust, key=lambda x: x[1])) # Sort list based on the trustee
        
        if n == 1: # Only one person condition
            return 1
        
        if not trust:
            return -1
        
        potential_judge = trust[0][1] # Assign the potential_judge to the first trustee
        trust_count = 1               # Initialize the trust count to 1
        
        for _, trustee in trust[1:]:
            if potential_judge == trustee: # Increase the trust_count if trustee is the potential_judge 
                trust_count += 1
                
            elif trust_count == n-1: 
                break
                
            else:
                potential_judge = trustee # Assign the potential_judge to the new trustee
                trust_count = 1           # Initialize the trust count to 1
                
        for truster, _ in trust: 
            if truster == potential_judge: # If the potential_judge is a truster return -1
                return -1
             
        return potential_judge if trust_count == n-1 else -1 # If trust_count == n-1 then return the judge found else -1
 
#Q3. Evaluate Division

'''

You are given an array of variable pairs equations and an array of real numbers values, where equations[i] = [Ai, Bi] and values[i] represent the equation Ai / Bi = values[i]. Each Ai or Bi is a string that represents a single variable.

You are also given some queries, where queries[j] = [Cj, Dj] represents the jth query where you must find the answer for Cj / Dj = ?.

Return the answers to all queries. If a single answer cannot be determined, return -1.0.

Note: The input is always valid. You may assume that evaluating the queries will not result in division by zero and that there is no contradiction.

 

Example 1:

Input: equations = [["a","b"],["b","c"]], values = [2.0,3.0], queries = [["a","c"],["b","a"],["a","e"],["a","a"],["x","x"]]
Output: [6.00000,0.50000,-1.00000,1.00000,-1.00000]
Explanation: 
Given: a / b = 2.0, b / c = 3.0
queries are: a / c = ?, b / a = ?, a / e = ?, a / a = ?, x / x = ?
return: [6.0, 0.5, -1.0, 1.0, -1.0 ]
Example 2:

Input: equations = [["a","b"],["b","c"],["bc","cd"]], values = [1.5,2.5,5.0], queries = [["a","c"],["c","b"],["bc","cd"],["cd","bc"]]
Output: [3.75000,0.40000,5.00000,0.20000]
Example 3:

Input: equations = [["a","b"]], values = [0.5], queries = [["a","b"],["b","a"],["a","c"],["x","y"]]
Output: [0.50000,2.00000,-1.00000,-1.00000]
 

Constraints:

1 <= equations.length <= 20
equations[i].length == 2
1 <= Ai.length, Bi.length <= 5
values.length == equations.length
0.0 < values[i] <= 20.0
1 <= queries.length <= 20
queries[i].length == 2
1 <= Cj.length, Dj.length <= 5
Ai, Bi, Cj, Dj consist of lower case English letters and digits.

'''
#Solution 


#Apprach-1: DFS

# zayne-siew has kindly provided an explanation for the bone-headed error I made and has provided a BFS implementation of the solution to this problem.
# If you have any questions, feel free to ask; I will try to answer in the best manner possible.
# I hate to say this, but the only reason I took the reciprocal of the answer produced by the DFS (as seen in the second-to-last line before the return statement in calcEquation) is because I first tried the actual value itself, and I noticed the values coming out were the reciprocal values of the right answer, and it just came out all correct when I took the reciprocal.

class Solution:
    
    def answer(self, current, end, scalar):
        if current==end: return scalar
        self.visited.add(current)
        if current in self.graph:
            for i in self.graph[current]:
                if i[0] not in self.visited:
                    a=self.answer(i[0],end,scalar*i[1])
                    if a!=-1: return a
        return -1
    def calcEquation(self, equations: List[List[str]], values: List[float], queries: List[List[str]]) -> List[float]:
        self.graph,self.visited={},set()
        for i in range(len(equations)):
            if equations[i][0] not in self.graph:
                self.graph[equations[i][0]]=[]
            if equations[i][1] not in self.graph:
                self.graph[equations[i][1]]=[]
            self.graph[equations[i][0]].append((equations[i][1],1/values[i]))
            self.graph[equations[i][1]].append((equations[i][0],values[i]))
        v=[]
        for i in queries:
            self.visited=set()
            if i[0] not in self.graph or i[1] not in self.graph:
                v.append(-1)
                continue
            v.append(1/self.answer(i[0],i[1],1) if i[0]!=i[1] else 1)
        return v



# class Solution:
#     def calcEquation(self, equations: List[List[str]], values: List[float], queries: List[List[str]]) -> List[float]:
        
    
#Apprach-1: DFS Solution

# graph
# dfs
# The problem requires us to follow the path in queries[i] so we can end up with some value[j] OR a new value comprised of other values in values. We can see the correct path given some equations[i][0] -> equations[j][1]. Given that there are paths we have to take to get an answer, it is obvious that this is a graph problem and we can model equations and values to be graph G.

# In this scenario, G is of type dict[List[tuple]] with the tuple being (either the corresponding numerator or denominator, quotient). This way we have all the info we'll need to form an answer or lead us to where the next path is. Also note that G is a bidirectional graph so that we can store the inverse of the quotients for the numerator and denominator. There are various ways one could make G however.

# We start by getting queries[i] and if both are valid nodes in G, we can start doing dfs. We have 2 sets because we need a way to (A) Track which letters (or nodes) we've already seen and (B) Check if we've already seen the equation. We keep updating value by multiplying it with our quotient. If we reach our target node >>> return value. Else: return -1.


class Solution:
    
    def dfs(self, node: str, graph: dict[List[tuple]], value: float, target: str, tuples_seen: set, letters_seen: set) -> float:
        
        '''
        dfs check path from curr node to target node
        for e.g. our starting node is 'a' and target is 'c'
        if we follow path a -> b -> c we'll get ret
        
        otherwise if we end up in a -> ... -> d
        then 'd' is not in G and we return -1
        '''
        if node not in graph:
            return float(-1)
        
        if node == target:
            return value
        
        ret = float(-1)
        for child in graph[node]:

            if child in tuples_seen: continue
            l2, quot = child
            if l2 in letters_seen: continue
                
            # use 2 different sets
            # we need to see every node already seen
            # we also need to treat every pair as separate
            
            tuples_seen.add(child)
            letters_seen.add(node)
            
            ret = self.dfs(l2, graph, value * quot, target, tuples_seen, letters_seen)
            if ret != float(-1): return ret

        return ret
        
    def calcEquation(self, equations: List[List[str]], values: List[float], queries: List[List[str]]) -> List[float]:
        
        n = len(equations)
        m = len(queries)
        out = [float(-1) for x in queries]

        
        # a dict of lists containing tuples
        G = defaultdict(list)
        for i, eq in enumerate(equations):
            x, y = eq
            
            # add to graph G the numerator
            G[x].append((y, values[i]))
            
            # and the denominator with respective values
            G[y].append((x, 1/values[i]))
        
        
        for i in range(m):
            l1, l2 = queries[i]
            if l1 in G and l2 in G:
                
                # find eq
                # case 1: 1 eq only
                # case 2: 2 or more combo of eqs needed
                
                ans = float(1)
                seenA = set() # for the tuples seen 
                seenB = set() # for the letters (nodes) seen thru out dfs
                ans = self.dfs(l1, G, ans, l2, seenA, seenB)
                out[i] = ans
                
        return out
    

#Apprach-2:

# using graph and recursion
# graph

class Solution:
    def calcEquation(self, equations: List[List[str]], values: List[float], queries: List[List[str]]) -> List[float]:
	
        graph = defaultdict(set) # construct a graph to store all connectivities
        quotient_dic = {}       # quotient_dic to store all quotients
        
        for [i, j], quotient in zip(equations, values):
            graph[i].add(j)
            graph[j].add(i)
            quotient_dic[(i, j)] = quotient
            quotient_dic[(j, i)] = 1 / quotient 

        all_nums = list(graph.keys())
        groups = {} # {num1: (group_id1, weight1), ....}
        group_id = 0

        while all_nums: # place all the numbers into groups
            group_id += 1
            def dp(val, weight):   # dp should reach all nodes in the graph if they are connected 
                groups[val] = (group_id, weight)
                all_nums.remove(val)
                for neib in list(graph[val]): # check all neighbours
                    if neib not in groups:
                        quotient = quotient_dic[(neib, val)]
                        dp(neib, quotient * weight)
            dp(all_nums[0], 1) # initial weight is chosen as 1, can be any other number

        out = []
        for x, y in queries:
            if x not in groups or y not in groups:
                out.append(-1)
                continue
            g1, val1 = groups[x]
            g2, val2 = groups[y]
            if g1 != g2:
                out.append(-1)
            else:
                out.append(val1/val2)

        return out

#Apprach-3:

# using directed graph dfs search

# I didn't finish my solution when doing the contest since time is up. I came up with the undirected graph firstly, but it occurs lots of issues. I rewrite my coding after the contesting. The main idea is that:

# building directed graph based on the input.
# building hashmap for the values.
# search the path in the graph
# if not directly path, search the reverse path again.
# The following code is not optimalized.

class Solution(object):
    def dfsquery(self,graph,vals,start,end,visited):
        if start==end and start in graph:
            return 1.0
        if (start,end) in vals:
            return vals[(start,end)]
        # dfs query
        if start in graph:
            for subnode in graph[start]:
                if subnode in visited:
                    continue
                visited.add(subnode)
                ressub=self.dfsquery(graph,vals,subnode,end,visited)
                if ressub!=-1.0:
                    return vals[(start,subnode)]*ressub
                else:
                    visited.discard(subnode)
                    return -1.0
        return -1.0
        
        
    def calcEquation(self, equations, values, queries):
        """
        :type equations: List[List[str]]
        :type values: List[float]
        :type query: List[List[str]]
        :rtype: List[float]
        """
        vals,graph={},{}
        n=len(equations)
        
        # building directed graph
        for i in range(n):
            a,b=equations[i][0],equations[i][1]
            graph[a]=graph.get(a,[])+[b]
            graph[b]=graph.get(b,[])+[a]
            vals[(a,b)]=values[i]
            vals[(b,a)]=1.0/values[i]
            
        qlen=len(queries)
        res=[0.0]*(qlen)
        for i in range(qlen):
            # check a-->b has the path
            res1=self.dfsquery(graph,vals,queries[i][0],queries[i][1],{queries[i][0]})
            if res1==-1.0:
                # if not check path b--->a
                res[i]=1.0/self.dfsquery(graph,vals,queries[i][1],queries[i][0],{queries[i][1]})
            else:
                res[i]=res1
        return res


#Apprach-4:

 # DFS / Iterative 


from collections import defaultdict
# from fractions import Fraction

class Solution(object):
    def calcEquation(self, equations, values, queries):
        """
        :type equations: List[List[str]]
        :type values: List[float]
        :type queries: List[List[str]]
        :rtype: List[float]
        """
        dic_next = collections.defaultdict(dict)
        for i in range(len(values)):
            lis = equations[i]
            dic_next[lis[0]][lis[1]] = values[i]
            dic_next[lis[1]][lis[0]] = 1.0/values[i]
        
        r_lis = []
        for q_lis in queries:
            if (q_lis[0] not in dic_next) or (q_lis[1] not in dic_next): # if not even find the element
                r_lis.append(-1.0)
            else:  # DFS search
                begin, goal =  q_lis[0], q_lis[1]
                stack_lis = [(begin, begin, 1.0)]
                visited, reached_goal = set([begin]), None
                while stack_lis:
                    start, end, frac = stack_lis.pop()
                    if end==goal:
                        reached_goal = frac
                        break
                    for k in dic_next[end]:
                        if k not in visited:
                            stack_lis.append((start, k, frac*dic_next[end][k]))
                            visited.add(k)
                
                if reached_goal:
                    r_lis.append(reached_goal)
                else:
                    r_lis.append(-1.0)
                
        return r_lis

    
#Apprach-5: graph + dfs search


from collections import defaultdict

class Solution(object):

    def calcEquation(self, equations, values, queries):
        """
        :type equations: List[List[str]]
        :type values: List[float]
        :type queries: List[List[str]]
        :rtype: List[float]
        """
        # adjacency list graph G, G[v1] --> [(v2, w12), (v3, w13)...]
        # where w12 is the weight for a directed edge v1->v2, where v1 / v2 = w12
        G = defaultdict(list)
        for (v1, v2), val in zip(equations, values):
            # v1 / v2 = val
            G[v1].append((v2, val))
            G[v2].append((v1, 1 / val))

        # for each query v1 / v2, check whether there is a path from v1 to v2
        # if so, the result of v1 / v2 is given by the accumulated product of 
        # all weights on the path
        results = []
        for v1, v2 in queries:
            if v1 in G and v2 in G:
                results.append(self.check_path(G, v1, v2))
            else:   # if either of v1 and v2 doesn't exist in the graph
                results.append(-1.0)
        return results

    def check_path(self, G, v1, v2):
        visited = set()
        weight_path = []

        def backtrack(v):   # dfs with backtracking to find a path v --> v2
            if v == v2:
                return True
            for x, w in G[v]:
                if x not in visited:
                    visited.add(x)
                    weight_path.append(w)
                    if backtrack(x):
                        return True
                    del weight_path[-1]  # elimination to restore the original path
            return False

        if backtrack(v1):
            r = 1.0
            for w in weight_path:
                r *= w
            return r
        return -1.0


#Q4. Accounts Merge
'''
Given a list of accounts where each element accounts[i] is a list of strings, where the first element accounts[i][0] is a name, and the rest of the elements are emails representing emails of the account.

Now, we would like to merge these accounts. Two accounts definitely belong to the same person if there is some common email to both accounts. Note that even if two accounts have the same name, they may belong to different people as people could have the same name. A person can have any number of accounts initially, but all of their accounts definitely have the same name.

After merging the accounts, return the accounts in the following format: the first element of each account is the name, and the rest of the elements are emails in sorted order. The accounts themselves can be returned in any order.

 

Example 1:

Input: accounts = [["John","johnsmith@mail.com","john_newyork@mail.com"],["John","johnsmith@mail.com","john00@mail.com"],["Mary","mary@mail.com"],["John","johnnybravo@mail.com"]]
Output: [["John","john00@mail.com","john_newyork@mail.com","johnsmith@mail.com"],["Mary","mary@mail.com"],["John","johnnybravo@mail.com"]]
Explanation:
The first and second John's are the same person as they have the common email "johnsmith@mail.com".
The third John and Mary are different people as none of their email addresses are used by other accounts.
We could return these lists in any order, for example the answer [['Mary', 'mary@mail.com'], ['John', 'johnnybravo@mail.com'], 
['John', 'john00@mail.com', 'john_newyork@mail.com', 'johnsmith@mail.com']] would still be accepted.
Example 2:

Input: accounts = [["Gabe","Gabe0@m.co","Gabe3@m.co","Gabe1@m.co"],["Kevin","Kevin3@m.co","Kevin5@m.co","Kevin0@m.co"],["Ethan","Ethan5@m.co","Ethan4@m.co","Ethan0@m.co"],["Hanzo","Hanzo3@m.co","Hanzo1@m.co","Hanzo0@m.co"],["Fern","Fern5@m.co","Fern1@m.co","Fern0@m.co"]]
Output: [["Ethan","Ethan0@m.co","Ethan4@m.co","Ethan5@m.co"],["Gabe","Gabe0@m.co","Gabe1@m.co","Gabe3@m.co"],["Hanzo","Hanzo0@m.co","Hanzo1@m.co","Hanzo3@m.co"],["Kevin","Kevin0@m.co","Kevin3@m.co","Kevin5@m.co"],["Fern","Fern0@m.co","Fern1@m.co","Fern5@m.co"]]
 

Constraints:

1 <= accounts.length <= 1000
2 <= accounts[i].length <= 10
1 <= accounts[i][j].length <= 30
accounts[i][0] consists of English letters.
accounts[i][j] (for j > 0) is a valid email. 

'''

#Solution 

#Approach-1:Queue and Set Simple Solution

# set
# queue implementation

'''
We first create a list from each account entry where list[0] = name | list[1] = set(emails)
Push all such lists into a queue for processing
Pop element and traverse queue
a. If no element in q is mergeable with the poped element then add it to result
b. If some elements are mergeable merge them into the poped element and set their name to * to aviod processing them later on. Also append the current poped element back into queue so that it can be processed again after the merge update
Once the queue is empty process the results into the expected output format

'''

from collections import deque

class Solution:
    def accountsMerge(self, accounts: List[List[str]]) -> List[List[str]]:
        h_map = {}
        
        q = deque([])
        
        for a in accounts:
            q.append([a[0], set(a[1:])])
        
        res = []
        
        while q:
                
            curr = q.popleft()
            is_merged = False
            if curr[0] == '*':
                continue
    
            for item in q:
                if not curr[1].isdisjoint(item[1]):
                    is_merged = True
                    curr[1] |= item[1]
                    item[0] = '*'
            
            if is_merged:
                q.append(curr)
            else:
                res.append(curr)
        
        ans = []
        
        for r in res:
            temp = [r[0]]
            x = list(r[1])
            x.sort()
            temp+=x
            ans.append(temp)
        return ans 

#Approach-2:

# Construct Graph and DFS 
# dfs
# dfs with recursion

class Solution:
    def accountsMerge(self, accounts: List[List[str]]) -> List[List[str]]:
        adj = defaultdict(list)
        # Build an adjacency list - graph
        for emails in accounts:
            for i in range(2,len(emails)):
                adj[emails[i]].append(emails[i-1])
                adj[emails[i-1]].append(emails[i])
        
        def dfs(email):
            seen.add(email)
            res = [email]
            small = []
            for u in adj[email]:
                if u not in seen:
                    small += dfs(u)
            return res + small
        
        seen = set()
        ans = []
        # Traverse through the components of graph and combine result
        for emails in accounts:
            if emails[1] not in seen:
                ans.append([emails[0]] + sorted(dfs(emails[1])))
        return ans

    
#Approach-3:using Union-Find

# Two versions of solution have been provided:

# Using Union Find
# Using Undirected Graph and DFS

# 1) Union Find Version

class Solution:
    def accountsMerge(self, accounts: List[List[str]]) -> List[List[str]]:
        # we will use union-find data-structure to handle this problem
        root = {email: email for name, *emails in accounts for email in emails}
        rank = {email: 1 for email in root}
        
        # define find function to retrieve the root of a set
        def find(x):
            res = x
            while res != root[res]:
                res = root[res]
            root[x] = res
            return res
        
        # define the union function
        def union(x, y):
            p, q = find(x), find(y)
            if p == q: return 0
            
            if rank[p] > rank[q]:
                root[q] = p
                rank[p] += rank[q]
            elif rank[q] >= rank[p]:
                root[p] = q
                rank[q] += rank[p]
            
            return 1
        
        # perform the union operation
        for name, firstEmail, *otherEmails in accounts:
            for email in otherEmails:
                union(firstEmail, email)
        
        # perform a mapping between name and disjoint set
        emailToName = {}
        for name, firstEmail, *rest in accounts:
            emailToName[find(firstEmail)] = name
        
        # collect the results
        output = {}
        for email in root:
            output.setdefault(find(email), list()).append(email)
        
        
        # now sort them and append name
        result = []
        for email, emails in output.items():
            result.append([emailToName[email]] + sorted(emails))
            
        return result
  

#Approach-4: Undirected Graph + DFS version 

class Solution:
    def accountsMerge(self, accounts: List[List[str]]) -> List[List[str]]:
        # graph builder
        graph = {}
        emailName = {}
        for name, *emails in accounts:
            firstEmail = emails[0]
            for email in emails:
                graph.setdefault(email, set()).add(firstEmail)
                graph.setdefault(firstEmail, set()).add(email)
                emailName[firstEmail] = name
        
        # DFS algorithim to explore all the
        # connected edges
        def DFS(node, graph, visited, nodes):
            if node in visited: return
            visited.add(node)
            nodes.append(node)
            for nei in graph[node]:
                if nei not in visited:
                    DFS(nei, graph, visited, nodes)
            
            
        # run DFS if needed
        visited = set()
        output = []
        for email, name in emailName.items():
            if email in visited: continue
            nodes = []
            DFS(email, graph, visited, nodes)
            output.append([name] + sorted(nodes))
            
        
        return output
    
    
#Approach-5: DFS:

class Solution(object):
    def accountsMerge(self, accounts):
        """
        :type accounts: List[List[str]]
        :rtype: List[List[str]]
        """
        neighbor_dic = collections.defaultdict(set)
        name_dic = {}
        for lst in accounts:
            name = lst[0]
            for email in lst[1:]:
                neighbor_dic[email].add(lst[1])
                neighbor_dic[lst[1]].add(email)
                name_dic[email] = name
                   
        res = []
        seen = set()
        for key in neighbor_dic.keys():
            if key not in seen:
                seen.add(key)
                stack = [key]
                tmp = [key]
                while stack:
                    u = stack.pop()
                    for n in neighbor_dic[u]:
                        if n not in seen:
                            seen.add(n)
                            tmp.append(n)
                            stack.append(n)
                res.append([name_dic[key]]+sorted(tmp))
        return res 

#Q5.  Network Delay Time

'''

You are given a network of n nodes, labeled from 1 to n. You are also given times, a list of travel times as directed edges times[i] = (ui, vi, wi), where ui is the source node, vi is the target node, and wi is the time it takes for a signal to travel from source to target.

We will send a signal from a given node k. Return the minimum time it takes for all the n nodes to receive the signal. If it is impossible for all the n nodes to receive the signal, return -1.

 

Example 1:


Input: times = [[2,1,1],[2,3,1],[3,4,1]], n = 4, k = 2
Output: 2
Example 2:

Input: times = [[1,2,1]], n = 2, k = 1
Output: 1
Example 3:

Input: times = [[1,2,1]], n = 2, k = 2
Output: -1
 

Constraints:

1 <= k <= n <= 100
1 <= times.length <= 6000
times[i].length == 3
1 <= ui, vi <= n
ui != vi
0 <= wi <= 100
All the pairs (ui, vi) are unique. (i.e., no multiple edges.) 

'''

#Solution 

# class Solution:
#     def networkDelayTime(self, times: List[List[int]], n: int, k: int) -> int:
        
    
#Approach-1:  O(V + ElogV), O(V + E)

# bfs
# djkastra

class Solution:
    def networkDelayTime(self, times: List[List[int]], n: int, k: int) -> int:
        adjList = defaultdict(list)
        for src, dst, w in times:
            adjList[src].append((w, dst))
        
        queue, seen, result = [(0, k)], set(), 0     
        
        while queue:
            w1, n1 = heapq.heappop(queue)
            if n1 in seen: continue
            seen.add(n1)
            result = max(result, w1)
            for w2, n2 in adjList[n1]:
                heapq.heappush(queue, (w1 + w2, n2))
        
        return result if len(seen) == n else -1

#Approach-2:BFS with heap

from heapq import *
class Solution:
    def networkDelayTime(self, times, N, K):
        graph = collections.defaultdict(list)
        for source,dest,weight in times:
            graph[source].append([dest,weight])
        time = {}
        heap = []
        heappush(heap, [0,K])
        # in heap put distance as key otherwise wont sort it 
        
        while heap:
            dist, node = heappop(heap)
            if node not in time:
                time[node] = dist
                for child, wei in graph[node]:
                    if child not in time:
                        heappush(heap,[wei+dist,child])
        return max(time.values()) if len(time) == N else -1

#Approach-3: Dijkstra algorithm


class Solution:
    def networkDelayTime(self, times, N, K):
        """
        :type times: List[List[int]]
        :type N: int
        :type K: int
        :rtype: int
        """
        G = collections.defaultdict(dict)
        for (u, v, w) in times:
            G[u-1][v-1] = w

        """Dijkstra Algorithm: dist, todo, done"""
        d = [math.inf] * N
        d[K-1] = 0
        
        todo, done = set(range(N)), set()
        while todo:
            # u = argmin(d, todo)
            u = None
            for n in todo:
                if u == None or d[n] < d[u]:
                    u = n
            
            if d[u] == math.inf: return -1 # unreachable node
            todo.remove(u)
            done.add(u)
            
            for v in G[u]:
                if v in todo:
                    d[v] = min(d[v], d[u]+G[u][v])
        return max(d)
    
#Approach-4:Dijkstra 

# priority queue
# dijkstra algorithm

class Solution:
    def networkDelayTime(self, times: List[List[int]], n: int, k: int) -> int:
        network={}
        for u,v,time in times:
            if u not in network:
                network[u]=[]
            network[u].append((time,v))
        
        import heapq as hp
        
        visited=set()
        summits_delay=[(0,k)]
        max_delay=0
        
        while summits_delay:
            curr_delay,curr_summit=hp.heappop(summits_delay)
            if curr_summit in visited:
                continue
                
            visited.add(curr_summit)
            max_delay=curr_delay
            
            if curr_summit in network:
                for time,next_summit in network[curr_summit]:
                    if next_summit in visited:
                        continue
                    hp.heappush(summits_delay,(curr_delay+time,next_summit))
                    
        return max_delay if len(visited)==n else -1

#Approach-5: Bellman Ford 

class Solution:
    def networkDelayTime(self, times, n, k):
        """
        :type times: List[List[int]]
        :type n: int
        :type k: int
        :rtype: int
        """
        delay_list = {}
        for i in range(1, n + 1):
            delay_list[i] = float('inf')

        # Initialize kth to 0
        delay_list[k] = 0

        # Iterate over n-1 times
        for i in range (0, n - 1):
            count = 0
            for j in range(len(times)):
                src = times[j][0]
                dst = times[j][1]
                time = times[j][2]
                if delay_list[src] + time < delay_list[dst]:
                    delay_list[dst] = delay_list[src] + time
                    count += 1
            if count == 0:
                # No more change, so break
                break
        max_value = max(delay_list.values())
        if max_value == float('inf'):
            return -1
        return max_value


sol = Solution()
n = 5
k = 1
nodes = [1, 2, 3, 4, 5]
times = [[1, 2, 9], [1, 4, 2], [2, 5, 1], [4, 2, 4], [4, 5, 6], [3, 2, 3], [5, 3, 7], [3, 1, 5]]
print(sol.networkDelayTime(times, n, k))




# Approach 6: Dijkstras Algo 

from collections import defaultdict
import heapq


class Solution:
    def networkDelayTime(self, times, n, k):
        """
        :type times: List[List[int]]
        :type n: int
        :type k: int
        :rtype: int
        """
        delay_list = {}
        done_list = set()
        graph = defaultdict(list)
        for src, dst, time in times:
            graph[src].append((dst, time))
        for i in range(1, n + 1):
            delay_list[i] = float('inf')
        heap = []
        # Use a min-heap to take min timed value among the next set of nodes
        heapq.heappush(heap, (0, k))
        # Once we are done with exploring all the nodes, add it to done_list.
        done_list.add(k)
        while heap:
            time, next_node = heapq.heappop(heap)
            # Check if we have visited this node with lower time already, then do not
            # Overwrite, else update the value
            if delay_list[next_node] > time:
                delay_list[next_node] = time
            if next_node not in graph:
                continue
            adj_list = graph[next_node]
            for adj_node, adj_node_time in adj_list:
                # If the node is already in done_list,
                # then do not add it again.
                if adj_node not in done_list:
                    heapq.heappush(heap, (time + adj_node_time, adj_node))
            done_list.add(next_node)
        max_value = max(delay_list.values())
        if max_value == float('inf'):
            return -1
        return max_value



sol = Solution()
n = 5
k = 1
nodes = [1, 2, 3, 4, 5]
times = [[1, 2, 9], [1, 4, 2], [2, 5, 1], [4, 2, 4], [4, 5, 6], [3, 2, 3], [5, 3, 7], [3, 1, 5]]
print(sol.networkDelayTime(times, n, k))


# Approach :7 BFS 

from collections import defaultdict

class Solution(object):
    def networkDelayTime(self, times, n, k):
        """
        :type times: List[List[int]]
        :type n: int
        :type k: int
        :rtype: int
        """
        graph = defaultdict(list)
        for u, v, w in times:
            graph[u].append((w, v))
        visited = {}
        queue = [(k, 0)]

        while queue:
            u, w = queue.pop(0)
            if u not in visited or w < visited[u]:
                # w < visited[u] if we got a new lesser value to reach u
                visited[u] = w
                for t, v in graph[u]:
                    queue.append((v, t + w))
        if len(visited) < n:
            # We could not visit all
            return -1
        return max(visited.values())

times = [[2,1,1],[2,3,1],[3,4,1]]
n = 4
k = 2
sol = Solution()
print(sol.networkDelayTime(times, n, k))


#Q6.Find Eventual Safe States
'''
There is a directed graph of n nodes with each node labeled from 0 to n - 1. The graph is represented by a 0-indexed 2D integer array graph where graph[i] is an integer array of nodes adjacent to node i, meaning there is an edge from node i to each node in graph[i].

A node is a terminal node if there are no outgoing edges. A node is a safe node if every possible path starting from that node leads to a terminal node (or another safe node).

Return an array containing all the safe nodes of the graph. The answer should be sorted in ascending order.

 

Example 1:

Illustration of graph
Input: graph = [[1,2],[2,3],[5],[0],[5],[],[]]
Output: [2,4,5,6]
Explanation: The given graph is shown above.
Nodes 5 and 6 are terminal nodes as there are no outgoing edges from either of them.
Every path starting at nodes 2, 4, 5, and 6 all lead to either node 5 or 6.
Example 2:

Input: graph = [[1,2,3,4],[1,2],[3,4],[0,4],[]]
Output: [4]
Explanation:
Only node 4 is a terminal node, and every path starting at node 4 leads to node 4.
 

Constraints:

n == graph.length
1 <= n <= 104
0 <= graph[i].length <= n
0 <= graph[i][j] <= n - 1
graph[i] is sorted in a strictly increasing order.
The graph may contain self-loops.
The number of edges in the graph will be in the range [1, 4 * 104]. 

'''
#Solution 

  # class Solution:
#     def eventualSafeNodes(self, graph: List[List[int]]) -> List[int]:
        
# Approach 1: Reverse Edges

# Algorithm
# We'll keep track of graph, a way to know for some node i, what the outgoing edges (i, j) are. We'll also keep track of rgraph, a way to know for some node j, what the incoming edges (i, j) are.

# Now for every node j which was declared eventually safe, we'll process them in a queue. We'll look at all parents i = rgraph[j] and remove the edge (i, j) from the graph (from graph). If this causes the graph to have no outgoing edges graph[i], then we'll declare it eventually safe and add it to our queue.

# Also, we'll keep track of everything we ever added to the queue, so we can read off the answer in sorted order later.

# Let NN be the number of nodes in the given graph, and EE be the number of edges.

# Time Complexity: O(N + E)O(N+E). We initialize the indegrees of all nodes in O(N)O(N) and determine the safe state value of the in-degree of each node, for which we iterate through all the edges of the graph in O(E)O(E).

# Space Complexity: O(N + E)O(N+E). We need O(N + E)O(N+E) space to stpre the reverse-graph, and O(N)O(N) space to store the queue.

#Solution 

class Solution:
    def eventualSafeNodes(self, graph: List[List[int]]) -> List[int]:
        N = len(graph)
        safe = [False] * N

        graph = [set(neighbors) for neighbors in graph]
        rgraph = [set() for _ in range(N)]
        q = collections.deque()

        for i, js in enumerate(graph):
            if not js:
                q.append(i)
            for j in js:
                rgraph[j].add(i)

        while q:
            j = q.popleft()
            safe[j] = True
            for i in rgraph[j]:
                graph[i].remove(j)
                if len(graph[i]) == 0:
                    q.append(i)

        return [i for i, is_safe in enumerate(safe) if is_safe]
    
    
# Approach 2: Depth-First Search

# Algorithm
# We can improve this approach, by noticing that we don't need to clear the colors between each search.

# When we visit a node, the only possibilities are that we've marked the entire subtree black (which must be eventually safe), or it has a cycle and we have only marked the members of that cycle gray. So indeed, the invariant that gray nodes are always part of a cycle, and black nodes are always eventually safe is maintained.

# In order to exit our search quickly when we find a cycle (and not paint other nodes erroneously), we'll say the result of visiting a node is true if it is eventually safe, otherwise false. This allows information that we've reached a cycle to propagate up the call stack so that we can terminate our search early.

# Let NN be the number of nodes in the given graph, and EE be the number of edges.

# Time Complexity: O(N + E)O(N+E). In this approach, we traverse all nodes and edges, which needs O(N+E)O(N+E).

# Space Complexity: O(N)O(N). O(N)O(N) space is required to store the nodes' colors and the recursion stack when calling dfs.


class Solution:
    def eventualSafeNodes(self, graph: List[List[int]]) -> List[int]:
        WHITE, GRAY, BLACK = 0, 1, 2
        color = collections.defaultdict(int)

        def dfs(node):
            if color[node] != WHITE:
                return color[node] == BLACK

            color[node] = GRAY
            for nei in graph[node]:
                if color[nei] == BLACK:
                    continue
                if color[nei] == GRAY or not dfs(nei):
                    return False
            color[node] = BLACK
            return True

        return filter(dfs, range(len(graph)))

    
# Approach 3:DFS on Graphs
# dfs with recursion

class Solution:
    def eventualSafeNodes(self, g: List[List[int]]) -> List[int]:
        
        def dfs(v):
            if v in vis:
                return v in res
            
            vis.add(v)
            for u in g[v]:
                if not dfs(u):
                    return False
            res.add(v)
            return True
        
        vis = set()
        res = set()
        for i in range(len(g)):
            dfs(i)
            
        return sorted(res)

# Approach 4:
# Elegant & Short | O(V + E) | Three-color DFS
# dfs
# short
# elegant
# three-color-dfs

class Solution:
	"""
	Time:   O(V + E)
	Memory: O(V)
	"""

	WHITE = 0
	GRAY = 1
	BLACK = 2

	def eventualSafeNodes(self, graph: List[List[int]]) -> List[int]:
		def dfs(u: int) -> bool:
			if color[u] == self.GRAY:
				return True

			if color[u] == self.BLACK:
				return False

			color[u] = self.GRAY
			for v in graph[u]:
				if dfs(v):
					return True

			color[u] = self.BLACK
			return False

		color = [self.WHITE] * len(graph)
		return [node for node in range(len(graph)) if not dfs(node)]

    
# Approach 5: DFS
# The idea is to assume that a node is not safe. If there is a cycle, that would mean that the DFS will return false for all the nodes in the cycle.
# This way, we can ensure that a node is marked safe only if all the children of that node are safe. Because of the initialization of safe[u] as False, this handles cycles as well as self-loops.


class Solution:
    def eventualSafeNodes(self, graph: List[List[int]]) -> List[int]:
        def dfs(u):
            if u in safe:
                return safe[u]
            safe[u] = False
            
            safe[u] = all(dfs(v) for v in graph[u])
            return safe[u]
            
        safe = dict()
        return [u for u in range(len(graph)) if dfs(u)]

#Q7.. Keys and Rooms
'''

There are n rooms labeled from 0 to n - 1 and all the rooms are locked except for room 0. Your goal is to visit all the rooms. However, you cannot enter a locked room without having its key.

When you visit a room, you may find a set of distinct keys in it. Each key has a number on it, denoting which room it unlocks, and you can take all of them with you to unlock the other rooms.

Given an array rooms where rooms[i] is the set of keys that you can obtain if you visited room i, return true if you can visit all the rooms, or false otherwise.

 

Example 1:

Input: rooms = [[1],[2],[3],[]]
Output: true
Explanation: 
We visit room 0 and pick up key 1.
We then visit room 1 and pick up key 2.
We then visit room 2 and pick up key 3.
We then visit room 3.
Since we were able to visit every room, we return true.
Example 2:

Input: rooms = [[1,3],[3,0,1],[2],[0]]
Output: false
Explanation: We can not enter room number 2 since the only key that unlocks it is in that room.
 

Constraints:

n == rooms.length
2 <= n <= 1000
0 <= rooms[i].length <= 1000
1 <= sum(rooms[i].length) <= 3000
0 <= rooms[i][j] < n
All the values of rooms[i] are unique.

'''
#Solution 

# class Solution:
#     def canVisitAllRooms(self, rooms: List[List[int]]) -> bool:
   
    
# Approach #1: Depth-First Search [Accepted]

# Algorithm

# When visiting a room for the first time, look at all the keys in that room. For any key that hasn't been used yet, add it to the todo list (stack) for it to be used.

# Time Complexity: O(N + E)O(N+E), where NN is the number of rooms, and EE is the total number of keys.

# Space Complexity: O(N)O(N) in additional space complexity, to store stack and seen.

class Solution(object):
    def canVisitAllRooms(self, rooms):
        seen = [False] * len(rooms)
        seen[0] = True
        stack = [0]
        #At the beginning, we have a todo list "stack" of keys to use.
        #'seen' represents at some point we have entered this room.
        while stack:  #While we have keys...
            node = stack.pop() # get the next key 'node'
            for nei in rooms[node]: # For every key in room # 'node'...
                if not seen[nei]: # ... that hasn't been used yet
                    seen[nei] = True # mark that we've entered the room
                    stack.append(nei) # add the key to the todo list
        return all(seen) # Return true iff we've visited every room
    
    
# Approach 2:BFS

class Solution:
    def canVisitAllRooms(self, rooms: List[List[int]]) -> bool:
        q, visited = deque([0]), {0}
        while q:
            cur = q.pop()
            for nxt in rooms[cur]:
                if nxt not in visited:
                    visited.add(nxt)
                    q.appendleft(nxt)
        return len(visited) == len(rooms)
    
# Approach 3:

# using deque

import collections;
class Solution:
    def canVisitAllRooms(self, rooms):
        """
        :type rooms: List[List[int]]
        :rtype: bool
        """
       
        tempList = rooms[0];
        queue = collections.deque();
        queue.append(tempList)
        roomList = [0];
        
        while(queue):
            curRoom = queue.pop();
            for cur in curRoom: 
                if cur not in roomList:
                    roomList.append(cur);
                    queue.append(rooms[cur]);
        
        return len(roomList) == len(rooms)

    
# Approach 4: DFS with stack

class Solution(object):
    def canVisitAllRooms(self, rooms):
        """
        :type rooms: List[List[int]]
        :rtype: bool
        """
        if not rooms:
            return False
        
        # dictionary to hold all the visited rooms
        visited = {}
        
        # set first room to visited
        visited[0] = True
        
        # maintain a stack to hold all the rooms to be visited
        stack = []
        stack.append(0)
        
        while stack:
            curr = stack.pop()
            # for each key in a room, append in stack if that room is not already visited
            for i in rooms[curr]:
                if i not in visited:
                    visited[i] = True
                    stack.append(i)
        return len(visited) == len(rooms)

# Approach 5:

# using BFS + Queue
# bfs
# queue
# directed unweighted graph

class Solution:
    #Time-Complexity: O(n + n^2) -> O(n^2)
    #Space-Complexity: O(n + n + n) -> O(n)
    def canVisitAllRooms(self, rooms: List[List[int]]) -> bool:
        
        q = collections.deque()
        number_of_rooms = len(rooms)
        #if we visited every room, our visited set will match wanted_set!
        wanted_set = set()
        for i in range(number_of_rooms):
            wanted_set.add(i)
        #visited will keep track of all distinct visited rooms which will be updated as bfs traversal                   progresess!
        visited = set()
        
        #before initiating bfs, we append to queue room 0 and mark room 0 as visited!
        visited.add(0)
        q.append(0)
        
        #as long as queue is non-emtpy, continue bfs!
        #all elements of queue are waited to be processed and are not already visited!
        #in worst case, our queue have to process all n rooms if we can simply hop from ith room to i+1th room
        #until we visit every single room!
        while q:
            cur_room = q.popleft()
            set_of_keys = rooms[cur_room]
            #For each room our current room can lead to, check that it is not already visited to avoid
            #revisiting node(stuck in cycle) and make sure it's not a self loop!
            #this inner for loop in worst case runs n-1 times, cause ith room may provide keys to 
            #all other rooms!
            for key in set_of_keys:
                if(key not in visited and key != cur_room):
                    q.append(key)
                    visited.add(key)
        #once our queue ends, see if visited == wanted_set
        if(visited == wanted_set):
            return True
        return False


#Q8.Possible Bipartition
'''
We want to split a group of n people (labeled from 1 to n) into two groups of any size. Each person may dislike some other people, and they should not go into the same group.

Given the integer n and the array dislikes where dislikes[i] = [ai, bi] indicates that the person labeled ai does not like the person labeled bi, return true if it is possible to split everyone into two groups in this way.

 

Example 1:

Input: n = 4, dislikes = [[1,2],[1,3],[2,4]]
Output: true
Explanation: group1 [1,4] and group2 [2,3].
Example 2:

Input: n = 3, dislikes = [[1,2],[1,3],[2,3]]
Output: false
Example 3:

Input: n = 5, dislikes = [[1,2],[2,3],[3,4],[4,5],[1,5]]
Output: false
 

Constraints:

1 <= n <= 2000
0 <= dislikes.length <= 104
dislikes[i].length == 2
1 <= dislikes[i][j] <= n
ai < bi
All the pairs of dislikes are unique. 

'''

#Solution 

# class Solution:
#     def possibleBipartition(self, n: int, dislikes: List[List[int]]) -> bool:
        
#Approach-1:DFS

# Analysis Problem step by step


# Requirement analysis:

# we need to split a group of n people into two groups. Key is two groups, it means that we have two states of group. If a person is not in group A, he/she must be in the remain group (group B).
# we have the relationships [a,b] means a dislikes b and b dislike a. If we have [a,b], [a,c] we can have the conclusion that b and c must be in a same group.
# Approach 1: using BFS/DFS

# First step, we need to build a graph from dislike relationship. graph: {person_id: [dislike_person_id]}
# Traverse graph with start each node, then color the dislike_person_id with another color. E.g [a,b] => a is RED color while b is BLUE color. We record the colors in a map. seen = {}
# If a person is already colored in seen map and need to color with a different color => conflict => return False
# return True if there is no conflict.
# Time: O(N)
# build the graph takes O(N)
# for each node we need to traverse one time (verify in the map seen)
# Space: O(N)
# store the graph takes O(N)


class Solution:
    def possibleBipartition(self, n: int, dislikes: List[List[int]]) -> bool:
        
        graph = collections.defaultdict(list)
        for dl in dislikes:
            graph[dl[0]].append(dl[1])
            graph[dl[1]].append(dl[0])
            
        seen = {}
        def helper(person_id, color):
            if person_id in seen:
                if seen[person_id] != color:
                    return False
                return True
            
            seen[person_id] = color
            
            for nei in graph[person_id]:
                if not helper(nei, -color):
                    return False
            return True
        
        for pid in range(1,n+1):
            if pid not in seen:
                if not helper(pid, 1):
                    return False
        return True

#Approach-2:BFS

class Solution:
    def possibleBipartition(self, n: int, dislikes: List[List[int]]) -> bool:
        
        graph = collections.defaultdict(list)
        for dl in dislikes:
            graph[dl[0]].append(dl[1])
            graph[dl[1]].append(dl[0])                        
        
        seen = {}
        def bfs(person_id, color, seen):
            queue = deque([(person_id, color)])
            while queue:
                q_i,q_color = queue.popleft()
                if q_i in seen:
                    if seen[q_i] != q_color:
                        return False
                    continue
                
                seen[q_i] = q_color
            
                for dislike_i in graph[q_i]:      
                    queue.append((dislike_i,-q_color))
            return True
        
        seen = {}
        for pid in range(1,n+1):
            if pid not in seen:
                if not bfs(pid, 1, seen):
                    return False
        return True
            
#Approach- 3: using Union-Find

# the idea of union-find is for each person, we can union all dislike person. E.g [a,b] and [a,c] => we union b and c together. Each union step, if we check a and (b or c) in a same group => conflict => return False.
# Time complexity:
# For regular union and find, each operation takes O(logn) in average, and O(n) in worst case.
# For union by rank, it takes at most O(logn) time since the height of tree-like structure is restricted in O(logn).
# For path compression, the time complexity is reduced to O({\alpha}(n)) where alpha(n) is inverse Ackermann function

class UnionFind:
    def __init__(self, n):
        self.p = {}
        self.size = {}
        for i in range(n+1):
            self.p[i] = i
            self.size[i] = 1
            
    def find(self, i):
        if i != self.p[i]:
            self.p[i] = self.find(self.p[i])
        return self.p[i]
    
    
    def union(self, i, j):
        p_i = self.find(i)
        p_j = self.find(j)
        if p_i == p_j:
            return
        if self.size[p_i] < self.size[p_j]:
            self.size[p_j] += self.size[p_i]
            self.p[p_i] = p_j
        else:
            self.size[p_i] += self.size[p_j]
            self.p[p_j] = p_i                
    
class Solution:
    def possibleBipartition(self, n: int, dislikes: List[List[int]]) -> bool:
        
        graph = collections.defaultdict(list)
        for dl in dislikes:
            graph[dl[0]].append(dl[1])
            graph[dl[1]].append(dl[0])
            
        uf = UnionFind(n)
        for i in range(1,n+1):
            parent_i = uf.find(i)
            if parent_i in graph:
                dislike_i = graph[i][0]
                for dis_j in graph[i][1:]:
                    uf.union(dis_j, dislike_i)
                    if uf.find(dis_j) == parent_i:    # dislike and i are in same group
                        return False
        return True  
    
#Approach- 4:Bipartite Graph using DFS
# bipartite graph concept
# dfs with recursion

class Solution:
    def possibleBipartition(self, n: int, disl: List[List[int]]) -> bool:
        g = defaultdict(set)
        for u,v in disl:
            g[u].add(v)
            g[v].add(u)
            
        done = defaultdict(int)
        def dfs(v, p):
            
            for u in g[v]:
                if u in done:
                    if done[u] == done[v]:
                        return False
                elif u != p:
                    done[u] = ~done[v]
                    dfs(u, v)
            return True
        
        for i in g.keys():
            if not dfs(i,0):
                return False
            
        return True

    
#Approach- 5:dfs,bipartite

# Time: O(E + V), Space: O(E + V)
# Time: O(E + V)
# Space: O(E + V) for the adjList, the colors list and the call stack

class Solution:
    def possibleBipartition(self, n: int, dislikes: List[List[int]]) -> bool:
        adjList = defaultdict(list)
        for a, b in dislikes:
            adjList[a - 1].append(b - 1)
            adjList[b - 1].append(a - 1)

        BLACK = 1
        RED = -1
        colors = [0] * n
        
        def dfs(node, prevCol=BLACK):
            currColor = -prevCol
            colors[node] = currColor
            for nextNode in adjList[node]:
                if colors[nextNode] != 0 and colors[node] == colors[nextNode]:
                    return False
                if colors[nextNode] == 0 and not dfs(nextNode, currColor):
                    return False
            return True
        
        for node in range(n):
            if colors[node] == 0 and not dfs(node):
                return False
        return True

#Q9.Most Stones Removed with Same Row or Column

'''

On a 2D plane, we place n stones at some integer coordinate points. Each coordinate point may have at most one stone.

A stone can be removed if it shares either the same row or the same column as another stone that has not been removed.

Given an array stones of length n where stones[i] = [xi, yi] represents the location of the ith stone, return the largest possible number of stones that can be removed.

 

Example 1:

Input: stones = [[0,0],[0,1],[1,0],[1,2],[2,1],[2,2]]
Output: 5
Explanation: One way to remove 5 stones is as follows:
1. Remove stone [2,2] because it shares the same row as [2,1].
2. Remove stone [2,1] because it shares the same column as [0,1].
3. Remove stone [1,2] because it shares the same row as [1,0].
4. Remove stone [1,0] because it shares the same column as [0,0].
5. Remove stone [0,1] because it shares the same row as [0,0].
Stone [0,0] cannot be removed since it does not share a row/column with another stone still on the plane.
Example 2:

Input: stones = [[0,0],[0,2],[1,1],[2,0],[2,2]]
Output: 3
Explanation: One way to make 3 moves is as follows:
1. Remove stone [2,2] because it shares the same row as [2,0].
2. Remove stone [2,0] because it shares the same column as [0,0].
3. Remove stone [0,2] because it shares the same row as [0,0].
Stones [0,0] and [1,1] cannot be removed since they do not share a row/column with another stone still on the plane.
Example 3:

Input: stones = [[0,0]]
Output: 0
Explanation: [0,0] is the only stone on the plane, so you cannot remove it.
 

Constraints:

1 <= stones.length <= 1000
0 <= xi, yi <= 104
No two stones are at the same coordinate point. 

'''
#Solution 

# class Solution:
#     def removeStones(self, stones: List[List[int]]) -> int:
        
        
#Approach-1:using stack and dictionary

class Solution:
    def removeStones(self, stones: List[List[int]]) -> int:
        maps = defaultdict(list)
    
        for x,y in stones:
            maps[x].append([x,y])
            maps[20000+y].append([x,y])
        
        visited,groups = set(),0
    
        for x,y in stones:
            if (x,y) not in visited:
                visited.add((x,y))
                groups+=1
                stack = [[x,y]]
                while stack:
                    x,y = stack.pop()
                    for nx,ny in maps[x]:
                        if (nx,ny) not in visited:
                            visited.add((nx,ny))
                            stack.append([nx,ny])
                    for nx,ny in maps[20000+y]:
                        if (nx,ny) not in visited:
                            visited.add((nx,ny))
                            stack.append([nx,ny])   
    
        return len(stones)-groups

#Approach-2:
# DFS | O(n) time and space
# graph
# dfs

class Solution:
    def removeStones(self, stones: List[List[int]]) -> int:
        #build the graph O(n) time and space
        adj_list = defaultdict(set)
        for stone in stones:
            x, y = stone
            adj_list[(x,'x')].add(tuple(stone))
            adj_list[(y,'y')].add(tuple(stone))
            
        #DFS to connect the graph/islands O(n) time
        def dfs(stone):
            x, y = stone
            visited.add(stone)
            neighbors = adj_list[(x, 'x')].union(adj_list[(y, 'y')])
            for nei in neighbors-visited:
                dfs(nei)
                
        #iterate every stone and DFS to get the connected components
        visited = set()
        ans = len(stones)
        for stone in stones:
            if tuple(stone) not in visited:
                dfs(tuple(stone))
                ans -= 1
        #every component needs atleast one node, so subtracting it from total stones is the answer
        return ans

 
#Approach- 3:

# Build the adjacency matrix. Then, just follow the problem statement. For every row, earmark first stone (do not remove it). Mark all the columns with stones in this row for deletion. Similarly, while deleting all stones in these columns, mark all the rows with stones in this column for deletion. Keep toggling between removing rows and columns till there are no more stones to remove. Go on to next row and repeat.

class Solution:
    def removeStones(self, stones: List[List[int]]) -> int:
        rowStones=defaultdict(set)
        colStones=defaultdict(set)
        
        for (r,c) in stones:
            rowStones[r].add(c)
            colStones[c].add(r)
            
        stonesDeleted=0
        
        for row in rowStones:
            if not rowStones[row]:
                continue
            #Earmark the first stone. Do not remove this stone
            doNotRemoveCol=rowStones[row].pop()
            rowStones[row].add(doNotRemoveCol)
            
            doNotRemove=(row,doNotRemoveCol)
            removeCols=rowStones[row].copy()
            removeRows=set()

            while removeCols:
                while removeCols:
                    c=removeCols.pop()
                    currentRows=colStones[c].copy()
                    for r in currentRows:
                        
                        if (r,c)==doNotRemove:
                            continue
                        removeRows.add(r)
                        stonesDeleted+=1
                        colStones[c].remove(r)
                        rowStones[r].remove(c)

                while removeRows:
                    r=removeRows.pop()
                    currentCols=rowStones[r].copy()
                    for c in currentCols:
                        
                        if (r,c)==doNotRemove:
                            continue
                        removeCols.add(c)
                        stonesDeleted+=1
                        rowStones[r].remove(c)
                        colStones[c].remove(r)
                        
        return stonesDeleted
    
#Approach-4:

# UnionFind

class Solution(object):
    def removeStones(self, stones):
        uf = unionfind()
        row, line = {}, {}
        stones = set(map(tuple, stones))
        x = len(stones)
        
        for stone in stones:
            uf.Create(stone[0], stone[1])
            if stone[0] in row:
                uf.Union(stone[0], stone[1], row[stone[0]][0], row[stone[0]][1])
            else:
                row[stone[0]] = stone
            
            if stone[1] in line:
                uf.Union(stone[0], stone[1], line[stone[1]][0], line[stone[1]][1])
            else:
                line[stone[1]] = stone
        
        #print uf.Print()
        return x - uf.Count()
            
            
        

class unionfind(object):
    def __init__(self):
        self.d = {}
    
    def Print(self):
        return self.d
    
    def Create(self, x, y):
        self.d[(x, y)] = (x, y)
        return
    
    def Find(self, x, y):
        if self.d[(x, y)] == (x, y):
            return (x, y)
        self.d[(x, y)] = self.Find(self.d[(x, y)][0], self.d[(x, y)][1])
        return self.d[(x, y)]
    
    def Union(self, x1, y1, x2, y2):
        x1, y1 = self.Find(x1, y1)
        x2, y2 = self.Find(x2, y2)
        if (x1, y1) == (x2, y2):
            return
        else:
            self.d[(x1, y1)] = (x2, y2)
            return
        
    def Count(self):
        A = set()
        for item in self.d:
            A.add(self.Find(item[0], item[1]))
        return len(A)
 

#Approach-5:Union Find

class UnionFind:
    def __init__(self,n):
        self.parent = list(range(n))
        self.size = [1]*n
        self.groups = n
        
    def find(self, node):
        # recursively search
        if self.parent[node] != node:
            self.parent[node] = self.find(self.parent[node])
        return self.parent[node]
    def union(self, nodeA, nodeB):
        A = self.find(nodeA)
        B = self.find(nodeB)
        if A==B: return
        
        if self.size[A] > self.size[B]:
            self.size[A] += self.size[B]
            self.parent[B] = A
        else:
            self.size[B] += self.size[A]
            self.parent[A] = B
            
        self.groups -=1
        return


#Q10. Regions Cut By Slashes
'''

An n x n grid is composed of 1 x 1 squares where each 1 x 1 square consists of a '/', '\', or blank space ' '. These characters divide the square into contiguous regions.

Given the grid grid represented as a string array, return the number of regions.

Note that backslash characters are escaped, so a '\' is represented as '\\'.

 

Example 1:


Input: grid = [" /","/ "]
Output: 2
Example 2:


Input: grid = [" /","  "]
Output: 1
Example 3:


Input: grid = ["/\\","\\/"]
Output: 5
Explanation: Recall that because \ characters are escaped, "\\/" refers to \/, and "/\\" refers to /\.
 

Constraints:

n == grid.length == grid[i].length
1 <= n <= 30
grid[i][j] is either '/', '\', or ' '. 

'''
#Solution 

# class Solution:
#     def regionsBySlashes(self, grid: List[str]) -> int:
        
#Approach-1
# DFS without upscaled (Idea from Eulearian Path)
# dfs
# eulerian path


# The idea was inspired from Eulearian Path.

# Each slash atmost add two new nodes to the graph.
# Assume we walked pass the outmost square boundary first.
# We backtrack the bounary and see if any node forms new regions, which is determinated by either
# forms a circle in the graph
# touching the boundary again
# Visited Edges and nodes are removed.
# For the remaining edges, see if any inner regions are formed.


class Solution:
    def regionsBySlashes(self, grid: List[str]) -> int:
        graph = defaultdict(set)
        n = len(grid)
        #Build the graph
        for i in range(n):
            for j in range(n):
                if grid[i][j] == '/':
                    graph[(i,j+1)].add((i+1,j))
                    graph[(i+1,j)].add((i,j+1))
                elif grid[i][j] == '\\':
                    graph[(i,j)].add((i+1,j+1))
                    graph[(i+1,j+1)].add((i,j))
        
        def dfs(i,j, count, visited):
            visited.add((i,j))
            while graph[(i,j)]:
                x,y = graph[(i,j)].pop()
                if (x,y) in visited or x == 0 or y == 0 or x == n or y == n:
                    count += 1
                graph[(x,y)].remove((i,j))
                count = dfs(x,y,count, visited)
            del graph[(i,j)]
            return count
        
        def dfsKeys(keys, count):
            while keys:
                key = keys.pop()
                if key in graph:
                    i,j = key
                    count = dfs(i,j, count, set())
            return count

        count = 1
        #Count for regions touching the outer boundary 
        keys = [k for k in graph.keys() if (k[0] ==0 or k[0] == n or k[1] == 0 or k[1] == n)] 
        count = dfsKeys(keys, count)
        #Count for remaining inner circle regions
        keys = [k for k,v in graph.items() if len(v) >1] 
        count = dfsKeys(keys, count)
        return count

#Approach-2

# Ugly DFS

# This is the ugliest solution I ever wrote, but it was straight from my head, and kinda want to share how complicated things can become if not decomposing the problem in a better way, it would be enormerous situations and conditions to cover.

# This is DFS, tries to visit all areas, each visit counts as 1 division of the graph, the same idea as to solve island problem.

# Spliting each cell to 4 parts in other threads is pretty clever, however I only thought of spliting into 2 parts, then I have to consider directions approaching each cell.

class Solution:
    def regionsBySlashes(self, grid: List[str]) -> int:
        FULL, UP, DOWN, LEFT, RIGHT, YET = range(6)
        M, N = len(grid), len(grid[0])
        visited = [[YET] * N for _ in range(M)]
        
        def dfs(i, j, di):
            if i < 0 or j < 0 or i > M-1 or j > N-1:
                return
            
            if di == LEFT or (di == UP and grid[i][j] == '/') or (di == DOWN and grid[i][j] == '\\'):
                di = LEFT
            else:
                di = RIGHT
                
            if visited[i][j] == FULL or visited[i][j] == di:
                return
            
            if grid[i][j] == ' ':
                visited[i][j] = FULL
                dfs(i-1, j, DOWN)
                dfs(i+1, j, UP)
                dfs(i, j-1, RIGHT)
                dfs(i, j+1, LEFT)
            elif grid[i][j] == '/':
                if di == LEFT:
                    visited[i][j] = FULL if visited[i][j] == RIGHT else LEFT
                    dfs(i-1, j, DOWN)
                    dfs(i, j-1, RIGHT)
                else:
                    visited[i][j] = FULL if visited[i][j] == LEFT else RIGHT
                    dfs(i, j+1, LEFT)
                    dfs(i+1, j, UP)
            else:
                if di == LEFT:
                    visited[i][j] = FULL if visited[i][j] == RIGHT else LEFT
                    dfs(i+1, j, UP)
                    dfs(i, j-1, RIGHT)
                else:
                    visited[i][j] = FULL if visited[i][j] == LEFT else RIGHT
                    dfs(i, j+1, LEFT)
                    dfs(i-1, j, DOWN)
        res = 0
        for i in range(M):
            for j in range(N):
                for di in [LEFT, RIGHT]:
                    if visited[i][j] == FULL or visited[i][j] == di:
                        continue
                    dfs(i, j, di)
                    res += 1
        return res
    
#Approach-3

class DSU:
    def __init__(self):
        self.parents = {}
        
    def find(self, x):
        self.parents.setdefault(x, x)
        if self.parents[x] != x:
            self.parents[x] = self.find(self.parents[x])
        return self.parents[x]
    
    def union(self, x, y):
        self.parents[self.find(y)] = self.find(x)


class Solution:
    def regionsBySlashes(self, grid):
        """
        :type grid: List[str]
        :rtype: int
        """
        N = len(grid)
        dsu = DSU()
        
        for r, row in enumerate(grid):
            for c, val in enumerate(row):
                
                root = 4 * (r * N + c)
                
                if val != '\\':
                    dsu.union(root + 0, root + 1)
                    dsu.union(root + 2, root + 3)
                    
                if val != '/':
                    dsu.union(root + 0, root + 2)
                    dsu.union(root + 1, root + 3)
                
                if r-1 >= 0:
                    dsu.union(root + 0, (root-4*N) + 3)
                
                if c-1 >= 0: 
                    dsu.union(root + 1, (root-4) + 2)
                    
        return sum(dsu.find(x) == x for x in dsu.parents)
                
        
#Approach-4

# O(N^2) by increasing resolution


class Solution:
    def regionsBySlashes(self, grid: List[str]) -> int:
        
        def mark(row,col):
            if 0<=row<n and 0<=col<n and g[row][col]==0:
                g[row][col]=1
                mark(row,col+1),mark(row+1,col),mark(row-1,col),mark(row,col-1)
                
        n=3*len(grid)
        g = [[0]*n for i in range(n)]
        for row in range(0,n,3):
            for col in range(0,n,3):
                el=grid[row//3][col//3]
                if el=="\\": g[row][col],g[row+1][col+1],g[row+2][col+2]=1,1,1
                elif el=="/": g[row+2][col],g[row+1][col+1],g[row][col+2]=1,1,1
        
        total=0
        for row in range(n):
            for col in range(n):
                if g[row][col]==0:
                    total+=1
                    mark(row,col)
        return total
    
#Approach-5

# readable DFS on upscaled grid

# Transform every '/' or '\' into an upscaled 1:3 grid. I set the slash boundaries to "False" and the open regions to "True". Then, I used a DFS algorithm to traverse through the entire big grid. Every time the algorithm comes across a "True" that hasn't been seen yet, it will iteratively add all neighboring "Trues" to the "seen" set.

class Solution:
    def regionsBySlashes(self, grid: List[str]) -> int:
        n = len(grid) * 3
        big_grid = [[True for j in range(n)] for i in range(n)]
        
        for i, row in enumerate(grid):
            for j, char in enumerate(row):
                if char == '/':
                    big_grid[3 * i][(3 * j) + 2] = False
                    big_grid[(3 * i) + 1][(3 * j) + 1] = False
                    big_grid[(3 * i) + 2][3 * j] = False
                elif char == '\\':
                    big_grid[3 * i][3 * j] = False
                    big_grid[(3 * i) + 1][(3 * j) + 1] = False
                    big_grid[(3 * i) + 2][(3 * j) + 2] = False
                
        seen = set()
        regions_count = 0
        
        for i, row in enumerate(big_grid):
            for j, is_char in enumerate(row):
                if is_char and (i, j) not in seen:
                    regions_count += 1
                    stack = [(i, j)]
                    while stack:
                        a, b = stack.pop()
                        seen.add((a, b))
                        if a > 0 and big_grid[a - 1][b] and (a - 1, b) not in seen:
                            stack.append((a - 1, b))
                        if a < n - 1 and big_grid[a + 1][b] and (a + 1, b) not in seen:
                            stack.append((a + 1, b))
                        if b > 0 and big_grid[a][b - 1] and (a, b - 1) not in seen:
                            stack.append((a, b - 1))
                        if b < n - 1 and big_grid[a][b + 1] and (a, b + 1) not in seen:
                            stack.append((a, b + 1))
                
        return regions_count
        

#Q11.Satisfiability of Equality Equations

'''

You are given an array of strings equations that represent relationships between variables where each string equations[i] is of length 4 and takes one of two different forms: "xi==yi" or "xi!=yi".Here, xi and yi are lowercase letters (not necessarily different) that represent one-letter variable names.

Return true if it is possible to assign integers to variable names so as to satisfy all the given equations, or false otherwise.

 

Example 1:

Input: equations = ["a==b","b!=a"]
Output: false
Explanation: If we assign say, a = 1 and b = 1, then the first equation is satisfied, but not the second.
There is no way to assign the variables to satisfy both equations.
Example 2:

Input: equations = ["b==a","a==b"]
Output: true
Explanation: We could assign a = 1 and b = 1 to satisfy both equations.
 

Constraints:

1 <= equations.length <= 500
equations[i].length == 4
equations[i][0] is a lowercase letter.
equations[i][1] is either '=' or '!'.
equations[i][2] is '='.
equations[i][3] is a lowercase letter. 

'''

#Solution 

#Approach-1:Union-Find Solution with Intuition

# union-find
# dsu

class Solution:
    def equationsPossible(self, equations: List[str]) -> bool:
        parent = [x for x in range(26)]
        
        def find(x):
            if parent[x] == x: return x
            parent[x] = find(parent[x])
            return parent[x]
        
        def union(a,b):
            p1 = find(ord(a)-ord("a"))
            p2 = find(ord(b)-ord("a"))
            
            if p1 == p2: return
            else: parent[p2] = p1
        
        # Union Step for equality equations
        for eq in equations:
            if eq[1:-1] == "==":
                union(eq[0], eq[-1])
        
        for eq in equations:
            if eq[1:-1] == "!=":
                a,b = ord(eq[0])-ord("a"), ord(eq[-1])-ord("a")
                if find(a) == find(b):
                    return False
        return True
    
    
#Approach-2:UnionFind solution with comments


# The idea is to connect all variables which are equal into a single connected compont at the first pass and check than no unequal variables belong to the same equality connected component on the second. Pretty intuitive

# standard UnionFind implementation with path compression and rank
# find, union O(a(N)) where a() is inverse Ackerman's function ~ const

class UnionFind:
    def __init__(self, size):        
        self.root = [x for x in range(size)]        
        self.rank = [1] * size
        
    def find(self, x):
        if x == self.root[x]:
            return x
        self.root[x] = self.find(self.root[x])
        return self.root[x]
        
    def union(self, x, y):
        rootx = self.find(x)
        rooty = self.find(y)
        
        if rootx == rooty:
            return False
            
        if self.rank[rootx] > self.rank[rooty]:
            self.root[rooty] = rootx
        elif self.rank[rootx] < self.rank[rooty]:
            self.root[rootx] = rooty
        else:
            self.root[rooty] = rootx
            self.rank[rootx] += 1
        
        return True
                 
    def connected(self, x, y):
        return self.find(x) == self.find(y)    
    
class Solution:
    def equationsPossible(self, equations: List[str]) -> bool:
        # time: O(n*a(n)) ~ O(n)
        # space O(n)
        uf = UnionFind(26) # up to 26 different letters
        unequals = [] # all unequal relations to check later
        for eq in equations:
            mc = re.match("(\w+)(==|!=)(\w+)", eq)
            if mc:
                groups = mc.groups()               
                x = ord(groups[0]) - ord('a')
                y = ord(groups[2]) - ord('a')
                if groups[1] == "==":
                    # all equal variables are gathered into a 
                    # single connected components
                    uf.union(x, y)
                else:
                    # all unequal relations are stored to later check
                    unequals.append((x, y))    
        
        # check all unequality relations
        for x, y in unequals:
            # if the variables were connected before as equal return False
            if uf.connected(x, y):                
                return False
            
        return True
        

#Approach-3: dfs


# This question is insanely similar to the problem 737, which can also be solved by bfs, dfs (find a target / coloring graph) or union find).

# https://leetcode.com/problems/sentence-similarity-ii/discuss/413478/python-bfsdfsunion-find-complexity-analysis

# DFS (find equavlent expression):

class Solution:
    def equationsPossible(self, equations: List[str]) -> bool:
        def dfs(u, visited, target):
            if u == target: return True
            visited.add(u)
            for v in neighbors[u]:
                if v in visited: continue
                if dfs(v, visited, target):
                    return True
            return False
        
        check = []
        neighbors = collections.defaultdict(set)
        for eq in equations:
            if eq[1] == '!':
                check.append((eq[0], eq[3]))
                continue
            neighbors[eq[0]].add(eq[3])
            neighbors[eq[3]].add(eq[0])
        
        for u, v in check:
            if dfs(u, set(), v):
                return False
        return True
        
#Approach-4: DFS (find target) (version 2):

class Solution:
    def equationsPossible(self, equations: List[str]) -> bool:
        graph = collections.defaultdict(set)

        def dfs(u, v, vis):
            if u in graph[v]: return True
            for i in graph[v]:
                if i not in vis:
                    vis.append(v)
                    if dfs(u, i, vis):
                        return True
            return False

        for eq in equations:
            if eq[1] == '=':
                graph[eq[0]].add(eq[3])
                graph[eq[3]].add(eq[0])

        for eq in equations:
		   # you can remove the following 2 lines if you change
		   # the first line in dfs into if u = v: return True
            if eq[1] == '!':
                if i[0] == i[3]:   #
                    return False
                if dfs(i[0], i[3], []):
                    return False
        return True

#Approach-5:dfs (coloring connect components):
# complexity analysis:

# Time: dfs is O(N^2). We do dfs number of inequalities times. In worest case, they are N inequalities ( N is length of input). The overall complexity is O(N^3).
# Space: O(N).

class Solution:
    def equationsPossible(self, equations: List[str]) -> bool:
        graph = collections.defaultdict(set)
        for eq in equations:
            if eq[1] == "=":
                graph[eq[0]].add(eq[3])
                graph[eq[3]].add(eq[0])

        colored = {}
        def dfs(node, color):
            if node not in colored:
                colored[node] = color
                for nei in graph[node]:
                    dfs(nei, color)

        color = 0
        for node in graph:
            if node not in colored:
                dfs(node, color)
                color += 1

        for eq in equations:
            if eq[1] == "!":
                if eq[0] == eq[3]: return False
                if colored.get(eq[0], eq[0]) == colored.get(eq[3], eq[3]): return False
        return True

#Approach-6:BFS:

# complexity analysis:

# Time: bfs is O(N^2). We do number of inequalities times bfs. In worest case, they are N inequalities ( N is length of input). The overall complexity is O(N^3).
# Space: O(N).


class Solution:
    def equationsPossible(self, equations: List[str]) -> bool:
        graph = collections.defaultdict(set)
        check = []
        '''
        def dfs(u, target, visited):
            if u == target: return True
            visited.add(u)
            for v in graph[u]:
                if v in visited: continue
                return dfs(v, target, visited):
        '''
        def bfs(u, target):
            Q = collections.deque([u])
            visited = set([u])
            while Q:
                u = Q.popleft()
                if u == target: return True
                for v in graph[u]:
                    if v not in visited:
                        visited.add(v)
                        Q.append(v)
            return False

        for eq in equations:
            if eq[1:3] == '!=':
                a, b = eq.split('!=')
                check.append((a, b))
                continue
            u, v = eq.split('==')
            graph[u].add(v)
            graph[v].add(u)

        for u, v in check:
            if bfs(u, v):
                return False
        return True

    
#Approach-7: Union Find:

# for each equation,
# if it is an inquality,
# then add it to 'check' (a list that we use to check the validility of the input later)
# else:
# union the two expression
# After we find all connnected components, we can simply check if the lhs and rhs of each inequality in 'check' is in the same connected components.

# If they are, then they must be equal and therefore the inequality should not hold, so we return 'False'.
# complexity analysis:

# time: O(N) where is the length of the input
# space: O(1) since we only store 26 characters in the parent dictionary.
# class Solution:

    def equationsPossible(self, equations: List[str]) -> bool:
        if not equations: return True
        parent = {i:i for i in string.ascii_lowercase}
        def find(x):
            if parent[x] != x:
                parent[x] = find(parent[x])
            return parent[x]
        def union(x, y):
            rx, ry = find(x), find(y)
            if rx != ry:
                parent[ry] = rx
        checks = []
        for eq in equations:
            if eq[1] == '!':
                checks.append(eq)
                continue
            union(eq[0], eq[3])
        
        for chk in checks:
            if find(chk[0]) == find(chk[3]):
                return False
        return True

#Q12.As Far from Land as Possible

'''

Given an n x n grid containing only values 0 and 1, where 0 represents water and 1 represents land, find a water cell such that its distance to the nearest land cell is maximized, and return the distance. If no land or water exists in the grid, return -1.

The distance used in this problem is the Manhattan distance: the distance between two cells (x0, y0) and (x1, y1) is |x0 - x1| + |y0 - y1|.

 

Example 1:


Input: grid = [[1,0,1],[0,0,0],[1,0,1]]
Output: 2
Explanation: The cell (1, 1) is as far as possible from all the land with distance 2.
Example 2:


Input: grid = [[1,0,0],[0,0,0],[0,0,0]]
Output: 4
Explanation: The cell (2, 2) is as far as possible from all the land with distance 4.
 

Constraints:

n == grid.length
n == grid[i].length
1 <= n <= 100
grid[i][j] is 0 or 1
'''
#Solution 
# class Solution:
#     def maxDistance(self, grid: List[List[int]]) -> int:
        
#Approach-1:breath-first-search


class Solution:
    def maxDistance(self, grid: List[List[int]]) -> int:
        ROWS,COLS = len(grid),len(grid[0])
        visit = set()
        q =[]
        for r in range(ROWS):
            for c in range(COLS):
                if grid[r][c] == 1:
                    q.append([r,c])
                    visit.add((r,c))
        if len(visit) == 0 or len(visit)==ROWS*COLS:
            return -1

        def addRooms(r,c):
            if r < 0 or c < 0 or r >= ROWS or c >= COLS or (r,c) in visit:
                return

            visit.add((r,c))
            q.append([r,c])

        dist = 0
        while q:
            for _ in range(len(q)):
                r,c = q.pop(0)
                grid[r][c] = dist
                addRooms(r + 1,c)
                addRooms(r - 1,c)
                addRooms(r,c + 1)
                addRooms(r,c -1 )
            dist += 1
        maxVal = 0
        for x in grid:
            maxVal = max(maxVal,max(x))
        return maxVal

#Approach-2:EXPLAINED WITH INTUTION | FAST | BFS | WELL WRITTEN |
# bfs
# easy
# breadth first search
# fast

# explained

# reaper

# EXPLANATION
# There can be two ways to solve the question :
# 1. Forward way : Find the nearest 1 for each 0s
# 2. Backward way : Start from 1 and find the 0s 

# Using First Approach we will get TLE

# Using Second Approach : we can solve the problem

# USE BFS :
# initially queue is all cell with value = 1 and the distance is 0
# Now we traverse the grid and if any 0 occur we update its distance to nearest 1 and once a 
# cell is visited we do not need to visit it again


class Solution:
    def maxDistance(self, grid: List[List[int]]) -> int:
        n = len(grid)
        queue = []
        vist = [[False for i in range(n)] for j in range(n)] 
        for i in range(n):
            for j in range(n):
                if grid[i][j] == 1:
                    queue.append((i,j,0))
                    vist[i][j] = True
        ans = 0
        while queue:
            r,c,d = queue.pop(0)
            if grid[r][c] == 0 :ans = max(ans,d)
            for x,y in ((r+1,c),(r-1,c),(r,c+1),(r,c-1)):
                if 0 <= x < n and 0 <= y < n and vist[x][y] == False:
                    vist[x][y] = True
                    queue.append((x,y,d+1))
        return ans if ans != 0 else -1

#Approach-2:BFS O(n*m)

class Solution:
	def maxDistance(self, grid: List[List[int]]) -> int:
		# Similar to rotten Oranges
		# Time and Space O(rows*cols)
		dirs = [(1,0), (-1, 0), (0, 1), (0, -1)]
		seen = set()
		rows,cols = len(grid), len(grid[0])
		q = deque()
		level = 0
		water = 0

		for r in range(rows):
			for c in range(cols):
				if grid[r][c] == 0:
					water += 1
				if grid[r][c] == 1:
					q.append((r,c)) 
					seen.add((r,c))

		# keep track of level -> a level represent distance to nearest land
		while q and water:
			q_len = len(q)
			for _ in range(q_len):
				r,c = q.popleft()
				for x,y in dirs:
					dr,dc = x+r, c+y
					if dr >= 0 and dr < rows and dc >= 0 and dc < cols \
					and grid[dr][dc] == 0 and (dr,dc) not in seen:
						q.append((dr,dc))
						seen.add((dr,dc))
						grid[dr][dc] == 1
						water -= 1
			level += 1

		return level or -1
    
    
#Approach-3:Short BFS with Logic 
# Logic
# What we want is the biggest distance from 1 to 0.
# So start from any 1(level 0), and the adjacent nodes from it means next level(distance + 1 = level1)
# Then add them to queue
# BFS repeats , on level 0 again....
# When it finish, it means all 0s turned into 1(visited) and the last distance is the farthest 0 from any 1

class Solution:
    def maxDistance(self, grid: List[List[int]]) -> int:

        n = len(grid)
        q = collections.deque()
        d = 0
        
        if sum([sum(row) for row in grid]) == 0 or sum([sum(row) for row in grid]) == n*n:
            return -1
        
        for i in range(n):
            for j in range(n):
                if grid[i][j] == 1:
                    q.append((i, j, d))
                    
        dirs = [(-1, 0), (1, 0), (0, -1), (0, 1)]
        while q:
            x, y, d = q.popleft()
            for dx, dy in dirs:
                nx, ny = x+dx, y+dy
                if 0<=nx<n and 0<=ny<n and grid[nx][ny]==0:
                    grid[nx][ny] = 1
                    q.append((nx, ny, d+1))
    
        return d

#Q13.  Number of Closed Islands

'''

Given a 2D grid consists of 0s (land) and 1s (water).  An island is a maximal 4-directionally connected group of 0s and a closed island is an island totally (all left, top, right, bottom) surrounded by 1s.

Return the number of closed islands.

 

Example 1:



Input: grid = [[1,1,1,1,1,1,1,0],[1,0,0,0,0,1,1,0],[1,0,1,0,1,1,1,0],[1,0,0,0,0,1,0,1],[1,1,1,1,1,1,1,0]]
Output: 2
Explanation: 
Islands in gray are closed because they are completely surrounded by water (group of 1s).
Example 2:



Input: grid = [[0,0,1,0,0],[0,1,0,1,0],[0,1,1,1,0]]
Output: 1
Example 3:

Input: grid = [[1,1,1,1,1,1,1],
               [1,0,0,0,0,0,1],
               [1,0,1,1,1,0,1],
               [1,0,1,0,1,0,1],
               [1,0,1,1,1,0,1],
               [1,0,0,0,0,0,1],
               [1,1,1,1,1,1,1]]
Output: 2
 

Constraints:

1 <= grid.length, grid[0].length <= 100
0 <= grid[i][j] <=1

'''
#Solution 

#Approach-1:dfs solution 


# & does not support short-circut, so A & B & C and A and B and C will be excuted once even if expression has a True.
# the idea is if the island is closed, it doesn't extend to the border, so use dfs to traverse the every island, and check whether traversed path of the island will extend to the border or not.
# if use and, the island may not be fully traversed because of short-circut, this will make one island be counted two or more, so we should use & instead of and
# every element in the grid will be accessed at most twice
# tc is O(2*len(grid)*len(grid[0])), sc is O(1)

class Solution:
    def closedIsland(self, grid: List[List[int]]) -> int:
        count, numRow, numCol = 0, len(grid), len(grid[0])
        def dfs(i, j):
            nonlocal grid
            if i < 0 or j < 0 or i >= numRow or j >= numCol: return False
            if grid[i][j] == 1: return True
            grid[i][j] = 1
            return dfs(i, j+1) & dfs(i+1, j) & dfs(i-1, j) & dfs(i, j-1) # work
            # return dfs(i, j+1) and dfs(i+1, j) and dfs(i-1, j) and dfs(i, j-1) # not work

        for i in range(numRow):
            for j in range(numCol):
                if grid[i][j] == 0 and dfs(i ,j):
                    count+=1

        return count
    
#Approach-2:dfs

class Solution:
    def closedIsland(self, grid: List[List[int]]) -> int:
        count, numRow, numCol = 0, len(grid), len(grid[0])
        def dfs(i, j):
            if i < 0 or j < 0 or i >= numRow or j >= numCol: return False
            nonlocal grid
            if grid[i][j] == 1: return True
            grid[i][j] = 1
            res = dfs(i, j+1)
            res1 = dfs(i+1, j)
            res = res and res1
            res1 = dfs(i-1, j)
            res = res and res1
            res1 = dfs(i, j-1)
            res = res and res1
            return  res
        for i in range(numRow):
            for j in range(numCol):
                if grid[i][j] == 0 and dfs(i ,j):
                    count+=1

        return count  
    
#Approach-3:
# We want to traverse a island, and then "flood" them( change them into water, in case they are traversed again). We can use DFS to do that. This question asks the closed islands, so we have to first "flood" all the islands that are not closed

class Solution:
    def closedIsland(self, grid: List[List[int]]) -> int:
        def dfs(grid, i , j):
            if i < 0 or j < 0 or i >= m or j >=n:
                return
            if grid[i][j] == 1:
                return
            
            grid[i][j] = 1
            dfs(grid, i-1, j)
            dfs(grid, i+1, j)
            dfs(grid, i, j-1)
            dfs(grid, i, j+1)
        
        m = len(grid)
        n = len(grid[0])
        for i in range(m):
            dfs(grid, i, 0)
            dfs(grid, i, n-1)
        for j in range(n):
            dfs(grid, 0, j)
            dfs(grid, m-1, j)
        
        res = 0
        for i in range(m):
            for j in range(n):
                if grid[i][j] == 0:
                    dfs(grid, i, j)
                    res += 1
        return res

##Approach-4: Graph coloring + Set

class Solution:
    def closedIsland(self, grid: List[List[int]]) -> int:
        m = len(grid)
        if m <= 0:
            return 0
        n = len(grid[0])
        
        seen = [[0]*n for _ in range(m)]
        
        def dfs(i, j, color):
            dirs = [[0, 1], [1, 0], [0, -1], [-1, 0]]
            grid[i][j] = color
            seen[i][j] = 1
            for d in dirs:
                x, y = i + d[0], j + d[1]
                if x < 0 or x >= m or y < 0 or y >= n:
                    continue
                if grid[x][y] == 0 and not seen[x][y]:
                    dfs(x, y, color)
        
        color = 0
        ans = 0
        for i in range(m):
            for j in range(n):
                if grid[i][j] == 0 and i != 0 and j != 0 and i != m-1 and j != n-1 and not seen[i][j]:
                    color -= 1
                    dfs(i, j, color)
        # print(grid)
        # print(color)
        s = set()
        for i in range(m):
            if grid[i][0] != 0 and grid[i][0] != 1:
                s.add(grid[i][0])
            if grid[i][n-1] != 0 and grid[i][n-1] != 1:
                s.add(grid[i][n-1])
        for j in range(n):
            if grid[0][j] != 0 and grid[0][j] != 1:
                s.add(grid[0][j])
            if grid[m-1][j] != 0 and grid[m-1][j] != 1:
                s.add(grid[m-1][j])
        # print(s)
        return -color - len(s)
    
#Approach-5:depth-first search marking boundary

# Loop through grid.
# For a 0, depth-first search all 0s connecting to it and mark them to 1. If the 0 isn't connected to boundary, add 1 to the result.

from itertools import product 

class Solution:
    def closedIsland(self, grid: List[List[int]]) -> int:
        m, n = len(grid), len(grid[0])
        
        def dfs(i, j): 
            grid[i][j] = 1 #mark as visited 
            closed = 0 < i < m-1 and 0 < j < n-1 #True for closed island
            for ii, jj in ((i+1, j), (i-1, j), (i, j+1), (i, j-1)):
                if 0 <= ii < m and 0 <= jj < n and grid[ii][jj] == 0: closed = dfs(ii, jj) and closed #order matters
            return closed 
        
        return sum(dfs(i, j) for i, j in product(range(m), range(n)) if grid[i][j] == 0)


#Q14.Number of Operations to Make Network Connected
'''

There are n computers numbered from 0 to n - 1 connected by ethernet cables connections forming a network where connections[i] = [ai, bi] represents a connection between computers ai and bi. Any computer can reach any other computer directly or indirectly through the network.

You are given an initial computer network connections. You can extract certain cables between two directly connected computers, and place them between any pair of disconnected computers to make them directly connected.

Return the minimum number of times you need to do this in order to make all the computers connected. If it is not possible, return -1.

 

Example 1:


Input: n = 4, connections = [[0,1],[0,2],[1,2]]
Output: 1
Explanation: Remove cable between computer 1 and 2 and place between computers 1 and 3.
Example 2:


Input: n = 6, connections = [[0,1],[0,2],[0,3],[1,2],[1,3]]
Output: 2
Example 3:

Input: n = 6, connections = [[0,1],[0,2],[0,3],[1,2]]
Output: -1
Explanation: There are not enough cables.
 

Constraints:

1 <= n <= 105
1 <= connections.length <= min(n * (n - 1) / 2, 105)
connections[i].length == 2
0 <= ai, bi < n
ai != bi
There are no repeated connections.
No two computers are connected by more than one cable.

'''
#Solution 

#Approach-1

class Solution:
    def makeConnected(self, n: int, connections: List[List[int]]) -> int:
        if len(connections) < n - 1:
            return -1
        d = defaultdict(set)
        for a, b in connections:
            d[a].add(b)
            d[b].add(a)
        res = n - len(d)
        while d:
            cur = list(d.keys())[:1]
            while cur:
                tmp = []
                for i in cur:
                    for j in d[i]:
                        d[j].remove(i)
                        tmp.append(j)
                    del d[i]
                cur = tmp
            res += 1
        return res - 1
    
#Approach-2

class Solution:
    def makeConnected(self, n: int, connections: List[List[int]]) -> int:
        
        def dfs(i):
            if i in seen:
                return 0
            seen.add(i)
            for j in d[i]:
                dfs(j)
            return 1
        
        if len(connections) < n - 1:
            return -1
        d, seen = defaultdict(set), set()
        for a, b in connections:
            d[a].add(b)
            d[b].add(a)
        
        return sum(dfs(i) for i in range(n)) - 1
    
#Approach-3

# Union-Find Fast Solution


class Solution(object):
    def __init__(self):
        self.parents = []
        self.count = []
        
    def makeConnected(self, n, connections):
        """
        :type n: int
        :type connections: List[List[int]]
        :rtype: int
        """
        if len(connections) < n-1:
            return -1  
        self.parents = [i for i in range(n)]
        self.count = [1 for _ in range(n)]
        for connection in connections:
            a, b = connection[0], connection[1]
            self.union(a, b)
        return len({self.find(i) for i in range(n)}) - 1
            
    def find(self, node):
        """
        :type node: int
        :rtype: int
        """
        while(node != self.parents[node]):
            node = self.parents[node];
        return node
    
    def union(self, a, b):
        """
        :type a: int
        :type b: int
        :rtype: None
        """
        a_parent, b_parent = self.find(a), self.find(b)
        a_size, b_size = self.count[a_parent], self.count[b_parent]
        
        if a_parent != b_parent:
            if a_size < b_size:
                self.parents[a_parent] = b_parent
                self.count[b_parent] += a_size
            else:
                self.parents[b_parent] = a_parent
                self.count[a_parent] += b_size
                
#Approach-4

# DFS, count the number of disjoint sets.


class Solution:
    def dfs(self, u):
        self.visited[u] = 1
        for v in self.AdjList[u]:
            if self.visited[v] == 0:
                self.dfs(v)
    
    def makeConnected(self, n: int, connections: List[List[int]]) -> int:
        if len(connections) < n-1:
            return -1
        self.AdjList = [[] for _ in range(n)]
        for connection in connections:
            u, v = connection
            self.AdjList[u].append(v)
            self.AdjList[v].append(u)
        self.visited = [0]*n
        res = 0
        for i in range(n):
            if self.visited[i] == 0:
                res += 1
                self.dfs(i)
        
        return res-1
    
#Approach-5: dfs solution counting number of groups


import collections
class Solution:
    def makeConnected(self, n: int, connections: List[List[int]]) -> int:
        if len(connections)<n-1:
            return -1
        graph=collections.defaultdict(list)
        for i,j in connections:
            graph[i].append(j)
            graph[j].append(i)  
        def dfs(i):
            if not visited[i]:
                visited[i]=1
                for nexti in graph[i]:
                    dfs(nexti)
            
        visited=[0]*n
        res=0
        for i in range(n):
            if not visited[i]:
                dfs(i)
                res+=1                
        return res-1       

#Q15. Find the City With the Smallest Number of Neighbors at a Threshold Distance

'''
There are n cities numbered from 0 to n-1. Given the array edges where edges[i] = [fromi, toi, weighti] represents a bidirectional and weighted edge between cities fromi and toi, and given the integer distanceThreshold.

Return the city with the smallest number of cities that are reachable through some path and whose distance is at most distanceThreshold, If there are multiple such cities, return the city with the greatest number.

Notice that the distance of a path connecting cities i and j is equal to the sum of the edges' weights along that path.

 

Example 1:


Input: n = 4, edges = [[0,1,3],[1,2,1],[1,3,4],[2,3,1]], distanceThreshold = 4
Output: 3
Explanation: The figure above describes the graph. 
The neighboring cities at a distanceThreshold = 4 for each city are:
City 0 -> [City 1, City 2] 
City 1 -> [City 0, City 2, City 3] 
City 2 -> [City 0, City 1, City 3] 
City 3 -> [City 1, City 2] 
Cities 0 and 3 have 2 neighboring cities at a distanceThreshold = 4, but we have to return city 3 since it has the greatest number.
Example 2:


Input: n = 5, edges = [[0,1,2],[0,4,8],[1,2,3],[1,4,2],[2,3,1],[3,4,1]], distanceThreshold = 2
Output: 0
Explanation: The figure above describes the graph. 
The neighboring cities at a distanceThreshold = 2 for each city are:
City 0 -> [City 1] 
City 1 -> [City 0, City 4] 
City 2 -> [City 3, City 4] 
City 3 -> [City 2, City 4]
City 4 -> [City 1, City 2, City 3] 
The city 0 has 1 neighboring city at a distanceThreshold = 2.
 

Constraints:

2 <= n <= 100
1 <= edges.length <= n * (n - 1) / 2
edges[i].length == 3
0 <= fromi < toi < n
1 <= weighti, distanceThreshold <= 10^4
All pairs (fromi, toi) are distinct.

'''
#Solution 

#Approach-1
# using Flyod Warshall
# flyod warshall

class Solution:
    def findTheCity(self, n: int, edges: List[List[int]], k: int) -> int:
        def floyd(n):
            dp = defaultdict(lambda:defaultdict(lambda:inf))
            for u,v,d in edges:
                dp[u][v] = d
                dp[v][u] = d
            for i in range(n):
                dp[i][i] = 0
                
            for k in range(n):
                for i in range(n):
                    for j in range(n):
                        dp[i][j] = min(dp[i][j], dp[i][k]+dp[k][j])
            return dp
            
        dp = floyd(n)
        res = defaultdict(set)
        for i in range(n):
            c = 0
            for j in dp[i]:
                if dp[i][j] <= k and i!=j:
                    c += 1
            res[c].add(i)
        
        return max(res[min(res.keys())])

#Approach-2:

# Floyd Warshall

# Idea: Use Floyd Warshall's Algorithm to find smallest distance between two nodes
# Count number of nodes reachable form every node with distance less than limit
# find minimum of the count (if same count take bigger node)
# Floyd Warshall Algorithm idea:
# create a matrix of size nxn where each cell i,j represent the minimum distance to reach i from j
# so every i,i pair will be zero initialize it to zero
# Now at step 1 we will find the least distance to reach each node without any nodes in between , So this will be the weight of each edge. That is if and edge from i to j exist with weight w in first iteration dist[i][j] = w.
# in second iteration we take one common node which is 0th node and claculate min distance. This will be equal to dist[i][0] + dist[0][j]. if this is less than original dist[i][j], then change it to this.
# In next iteration we use two nodes 0,1 do the same calculation. continue this to get min distance to all nodes

class Solution:
	def findTheCity(self, n: int, edges: List[List[int]], distanceThreshold: int) -> int:
		dist = [[math.inf]*n for i in range(n)]

		for i in range(n):
			dist[i][i] = 0

		for i,j,w in edges:
			dist[i][j] = w
			dist[j][i] = w

		for k in range(n):
			for i in range(n):
				for j in range(n):
					dist[i][j] = min(dist[i][j],dist[i][k]+dist[k][j])

		ans = []

		for i in range(n):
			o = 0
			for j in range(n):
				if i == j:
					continue
				if dist[i][j] <= distanceThreshold:
					o+=1
			ans.append((o,i))

		return min(ans,key =lambda x: (x[0],-x[1]))[1]
    
    
#Approach-3: straightforward Floyd-Warshall algorithm

class Solution:
    def findTheCity(self, n: int, edges: List[List[int]], distanceThreshold: int) -> int:
        # time: O(n^3)        
        # space: O(n^2)        
        # create the dp array, which on the first step is simply an adjacency matrix
        dp = [[math.inf] * n for _ in range(n)]
        # distance from a city to itself is zero
        for i in range(n): 
            dp[i][i] = 0
        # create the adjecency matrix, in both directions since undirectional graph
        for i, j, w in edges: 
            dp[i][j] = w
            dp[j][i] = w
        # Floyd Warshall algorithm, shortest paths between each pair of nodes
        for k in range(n):
            for i in range(n):
                for j in range(n):                    
                   dp[i][j] = min(dp[i][j], dp[i][k] + dp[k][j])             
        # just get the last city with minimum connected cities with the distance limit     
        res = -1
        min_cnt = math.inf
        for i in range(n):                        
            cnt = sum(1 for x in dp[i] if x <= distanceThreshold)
            if cnt <= min_cnt:
                min_cnt = cnt
                res = i                 
        return res
    
#Approach-4:

# Brute-Force Floyd Warshall algorithm

from collections import defaultdict
class Solution(object):
    def findTheCity(self, n, edges, distanceThreshold):

        # make graph
        dist = [[float('inf')] * n for _ in range(n)]
        for edge in edges:
            dist[edge[0]][edge[1]] = edge[2]
            dist[edge[1]][edge[0]] = edge[2]
        
        # use Floyd–Warshall algorithm to find the minimum distance between any pair of nodes
        for k in range(n):
            for i in range(n):
                for j in range(n):
                    if i == j:    # in case there is a cycle, keep dist[i][i] as inf
                        continue
                    dist[i][j] = min(dist[i][k] + dist[k][j], dist[i][j])
        
        # for all starting node, find their neighboring cities, and return the one having fewest neighboring cities
        mn = n + 1
        res = None
        for start in range(n):
            count = len([d for d in dist[start] if d <= distanceThreshold])
            if count <= mn:
                mn = count
                res = start
        return res
    
#Approach-5:

# using Dijkstra's algorithm


class Solution:
    class Graph(): 
        def __init__(self, vertices): 
            self.V = vertices 
            self.graph = [[0 for column in range(vertices)]  
                        for row in range(vertices)] 

        # A utility function to find the vertex with  
        # minimum distance value, from the set of vertices  
        # not yet included in shortest path tree 
        def minDistance(self, dist, sptSet): 

            # Initilaize minimum distance for next node 
            min = 10**10

            min_index = None
            # Search not nearest vertex not in the  
            # shortest path tree 
            for v in range(self.V): 
                if dist[v] < min and sptSet[v] == False: 
                    min = dist[v] 
                    min_index = v 

            return min_index 

        # Funtion that implements Dijkstra's single source  
        # shortest path algorithm for a graph represented  
        # using adjacency matrix representation 
        def dijkstra(self, src: int, distanceThreshold: int) -> int: 

            dist = [10**10] * self.V 
            dist[src] = 0
            sptSet = [False] * self.V 

            for cout in range(self.V): 

                # Pick the minimum distance vertex from  
                # the set of vertices not yet processed.  
                # u is always equal to src in first iteration 
                u = self.minDistance(dist, sptSet) 
                if u is None:
                    break

                # Put the minimum distance vertex in the  
                # shotest path tree 
                sptSet[u] = True

                # Update dist value of the adjacent vertices  
                # of the picked vertex only if the current  
                # distance is greater than new distance and 
                # the vertex in not in the shotest path tree 
                for v in range(self.V): 
                    if self.graph[u][v] != 0 and \
                         sptSet[v] == False and \
                         dist[v] > dist[u] + self.graph[u][v]: 
                        dist[v] = dist[u] + self.graph[u][v] 
            
            ct = 0
            for dis in dist:
                if dis <= distanceThreshold:
                    ct += 1
            return ct

                        
    def findTheCity(self, n: int, edges: List[List[int]], distanceThreshold: int) -> int:
        g = self.Graph(n)
        mat = [[0 for x in range(n)] for y in range(n)]
        for (one, two, weight) in edges:
            mat[one][two] = weight
            mat[two][one] = weight
        g.graph = mat
        city = 0
        minCount = 10**10
        for i in range(n):
            ct = g.dijkstra(i, distanceThreshold)
            if ct <= minCount:
                minCount = ct
                city = i
        return city


#Q16.Time Needed to Inform All Employees

'''

A company has n employees with a unique ID for each employee from 0 to n - 1. The head of the company is the one with headID.

Each employee has one direct manager given in the manager array where manager[i] is the direct manager of the i-th employee, manager[headID] = -1. Also, it is guaranteed that the subordination relationships have a tree structure.

The head of the company wants to inform all the company employees of an urgent piece of news. He will inform his direct subordinates, and they will inform their subordinates, and so on until all employees know about the urgent news.

The i-th employee needs informTime[i] minutes to inform all of his direct subordinates (i.e., After informTime[i] minutes, all his direct subordinates can start spreading the news).

Return the number of minutes needed to inform all the employees about the urgent news.

 

Example 1:

Input: n = 1, headID = 0, manager = [-1], informTime = [0]
Output: 0
Explanation: The head of the company is the only employee in the company.
Example 2:


Input: n = 6, headID = 2, manager = [2,2,-1,2,2,2], informTime = [0,0,1,0,0,0]
Output: 1
Explanation: The head of the company with id = 2 is the direct manager of all the employees in the company and needs 1 minute to inform them all.
The tree structure of the employees in the company is shown.
 

Constraints:

1 <= n <= 105
0 <= headID < n
manager.length == n
0 <= manager[i] < n
manager[headID] == -1
informTime.length == n
0 <= informTime[i] <= 1000
informTime[i] == 0 if employee i has no subordinates.
It is guaranteed that all the employees can be informed.  

'''
#Solution 

#Approach-1:Bottom-up

# Solution:
# Doing top-down approach by calculating the maximum cost starting from the head of the company requires us to build an adjacency list which cost O(n). Let avoid doing this by working from the bottom-up.

# The cost to inform an employee is the cost for his manager to inform him + the cost to inform his manager. If an employee doesn't have a manager, return 0 as the cost to inform him.

# Iterate through all employees and return the higest cost. Since we are starting from each employee up to the head of the company, use caching to avoid repeated works.

# Complexity:
# Time: O(n)
# Space: O(n)

from functools import lru_cache

class Solution:
    def numOfMinutes(
        self, n: int, headID: int, manager: list[int], informTime: list[int]
    ) -> int:

        # Recursively calculate the cost to inform an employee
        @lru_cache(None)
        def cost(employee):
            # If an employee doesn't have a manager, return 0 as the cost to inform such employee
            if manager[employee] == -1:
                return 0

            # Else, calculate the cost to inform such employee as the cost for his manager to inform him + the cost to inform his manager
            return informTime[manager[employee]] + cost(manager[employee])

        # Return the largest cost
        return max(cost(i) for i in range(n))
    
#Approach-2:

# Graph DFS: Find the farthest node from root


class Solution:
    def numOfMinutes(self, n: int, headID: int, manager: List[int], informTime: List[int]) -> int:
        graph = [[] for _ in range(n)]
        for i in range(len(manager)):
            if manager[i] == -1: continue
            graph[manager[i]].append(i)
        visited = [False for _ in range(n)]
        
        def dfs(u, c=0):
            visited[u] = True
            if not graph[u]:
                yield c + informTime[u]
            else:
                for v in graph[u]:
                    if not visited[v]:
                        yield from dfs(v, c + informTime[u])
        
        return max(i for i in dfs(headID))
    
    
#Approach-3:

# 2 line DP

# dynamic programming
# dfs
# dp

# DFS for each person in the company, but also cache the time.

class Solution:
    def numOfMinutes(self, n: int, headID: int, manager: List[int], informTime: List[int]) -> int:
        @cache
        def time(i):
            return informTime[i] if manager[i] == -1 else informTime[i] + time(manager[i])
        
        return max(time(i) for i in range(len(manager)))


#Approach-4:

# DFS
# depth first search
# easy to underatnd
# dfs

from collections import defaultdict
class Solution:
    def numOfMinutes(self, n: int, he: int, ma: List[int], ie: List[int]) -> int:
        adj = defaultdict(list)
        for i in range(n):
            adj[ma[i]].append(i)
        def dfs(d):
            t = ie[d]
            if adj.get(d):
                t1 = 0
                for val in adj[d]:
                    t1 = max(t1,dfs(val))
                t += t1
            else:
                return 0
            return t
        return dfs(he)

#Approach-5:Graph DFS: Find the farthest node from root

class Solution:
    def numOfMinutes(self, n: int, headID: int, manager: List[int], informTime: List[int]) -> int:
        graph = [[] for _ in range(n)]
        for i in range(len(manager)):
            if manager[i] == -1: continue
            graph[manager[i]].append(i)
        visited = [False for _ in range(n)]
        
        def dfs(u, c=0):
            visited[u] = True
            if not graph[u]:
                yield c + informTime[u]
            else:
                for v in graph[u]:
                    if not visited[v]:
                        yield from dfs(v, c + informTime[u])
        
        return max(i for i in dfs(headID))

