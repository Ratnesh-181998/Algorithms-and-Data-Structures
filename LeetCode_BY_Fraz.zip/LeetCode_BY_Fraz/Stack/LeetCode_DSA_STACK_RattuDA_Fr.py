
#STACK

#Q1.Min Stack

'''

Design a stack that supports push, pop, top, and retrieving the minimum element in constant time.

Implement the MinStack class:

MinStack() initializes the stack object.
void push(int val) pushes the element val onto the stack.
void pop() removes the element on the top of the stack.
int top() gets the top element of the stack.
int getMin() retrieves the minimum element in the stack.
You must implement a solution with O(1) time complexity for each function.

 

Example 1:

Input
["MinStack","push","push","push","getMin","pop","top","getMin"]
[[],[-2],[0],[-3],[],[],[],[]]

Output
[null,null,null,null,-3,null,0,-2]

Explanation
MinStack minStack = new MinStack();
minStack.push(-2);
minStack.push(0);
minStack.push(-3);
minStack.getMin(); // return -3
minStack.pop();
minStack.top();    // return 0
minStack.getMin(); // return -2
 

Constraints:

-231 <= val <= 231 - 1
Methods pop, top and getMin operations will always be called on non-empty stacks.
At most 3 * 104 calls will be made to push, pop, top, and getMin. 

'''
#Solution

# class MinStack:

#     def __init__(self):
        

#     def push(self, val: int) -> None:
        

#     def pop(self) -> None:
        

#     def top(self) -> int:
        

#     def getMin(self) -> int:
        


# # Your MinStack object will be instantiated and called as such:
# # obj = MinStack()
# # obj.push(val)
# # obj.pop()
# # param_3 = obj.top()
# # param_4 = obj.getMin()


#Approach-1

# Min Max Stack Construction - Interview Question | With comments
# minMaxStack keeps track of minValue and maxValue at a particular instance.

"""
For example,
	- push 2 to stack
		stack - [2]
		minMaxStack - [[2, 2]]
	- push 3 to stack
		stack - [2, 3]
		minMaxStack - [[2, 2], [2, 3]]
	- push 1 to stack
		stack - [2, 3, 1]
		minMaxStack - [[2, 2], [2, 3], [1, 3]]
"""

# So whenever we pop an element from stack, the min & max value is not lost
"""
For example,
	stack - [2, 3, 1]
	minMaxStack - [[2, 2], [2, 3], [1, 3]]
	- pop() from stack
		stack - [2, 3]
		minMaxStack - [[2, 2], [2, 3]] # In this case the minVal 1 is popped and 2 becomes new minVal.
	- pop() from stack
		stack - [2]
		minMaxStack - [[2, 2]] # In this case the maxVal 3 is popped and 2 becomes new maxVal.
"""

class MinStack(object):
	
    def __init__(self):
        self.stack = []
        self.minMaxStack = []
		
    def push(self, val):
        """
        :type val: int
        :rtype: None
        """
        self.stack.append(val)
        if len(self.minMaxStack) == 0:
            self.minMaxStack.append([val, val])
        elif self.minMaxStack[-1][0] > val:
            self.minMaxStack.append([val, self.minMaxStack[-1][1]])
        elif self.minMaxStack[-1][0] < val:
            self.minMaxStack.append([self.minMaxStack[-1][0], val])
        else:
            self.minMaxStack.append(self.minMaxStack[-1])
        
    def pop(self):
        """
        :rtype: None
        """
        if len(self.stack):
            self.stack.pop()
            self.minMaxStack.pop()

    def top(self):
        """
        :rtype: int
        """
        if len(self.stack):
            return self.stack[-1]

    def getMin(self):
        """
        :rtype: int
        """
        if len(self.minMaxStack):
            return self.minMaxStack[-1][0]
        
#Approach-2

class MinStack:

    def __init__(self):
        # Add extra O(N) space complexity
        self._minStack = []
        self._stack = []

    def push(self, val: int) -> None:
        self._stack.append(val)
        if (not self._minStack) or (val <= self.getMin()):
            self.pushToMinStack(val)

    def pop(self) -> None:
        if self._stack.pop() == self._minStack[-1]:
            self._minStack.pop()

    def top(self) -> int:
        return self._stack[-1]
        

    def getMin(self) -> int:
        if self._minStack:
            return self._minStack[-1]

    def pushToMinStack(self, val) -> None:
        self._minStack.append(val)
        
#Approach-3

class MinStack:
    def __init__(self):
        self.stack = []
        self.min_val = []

    def push(self, val: int) -> None:
        self.stack.append(val)
        if not self.min_val: self.min_val.append(val)
        elif val <= self.min_val[-1]: self.min_val.append(val)

    def pop(self) -> None:
        if self.min_val[-1] == self.stack.pop(): self.min_val.pop()

    def top(self) -> int:
        return self.stack[-1]

    def getMin(self) -> int:
        return self.min_val[-1]
 
#Approach-4
# Time: O(1) for all methods of the class


class MinStack:

    def __init__(self):
        self.stack = []

    def push(self, val: int) -> None:
        minn = min(val, self.stack[-1][1]) if self.stack else val
        self.stack.append((val, minn))
        # Time: O(1)
        # Space: O(1)
        
    def pop(self) -> None:
        self.stack.pop()
        # Time: O(1)
        # Space: O(1)

    def top(self) -> int:
        return self.stack and self.stack[-1][0]
        # Time: O(1)
        # Space: O(1)

    def getMin(self) -> int:
        return self.stack and self.stack[-1][1]
        # Time: O(1)
        # Space: O(1)
        

#Approach-5        
# min-stack
# stack

class MinStack:
    def __init__(self):
        self.data = []
    
    #O(1) time complexity
    def push(self, val: int) -> None:
        if not self.data:
            self.data.append([val, val])
        else:
            self.data.append([val, min(self.data[-1][1], val)])
    
    #O(1) time complexity
    def pop(self) -> None:
        self.data.pop()
        
    #O(1) time complexity
    def top(self) -> int:
        return self.data[-1][0]
    
    #O(1) time complexity
    def getMin(self) -> int:
        return self.data[-1][1]


 #Q2. Next Greater Element I

'''

The next greater element of some element x in an array is the first greater element that is to the right of x in the same array.

You are given two distinct 0-indexed integer arrays nums1 and nums2, where nums1 is a subset of nums2.

For each 0 <= i < nums1.length, find the index j such that nums1[i] == nums2[j] and determine the next greater element of nums2[j] in nums2. If there is no next greater element, then the answer for this query is -1.

Return an array ans of length nums1.length such that ans[i] is the next greater element as described above.

 

Example 1:

Input: nums1 = [4,1,2], nums2 = [1,3,4,2]
Output: [-1,3,-1]
Explanation: The next greater element for each value of nums1 is as follows:
- 4 is underlined in nums2 = [1,3,4,2]. There is no next greater element, so the answer is -1.
- 1 is underlined in nums2 = [1,3,4,2]. The next greater element is 3.
- 2 is underlined in nums2 = [1,3,4,2]. There is no next greater element, so the answer is -1.
Example 2:

Input: nums1 = [2,4], nums2 = [1,2,3,4]
Output: [3,-1]
Explanation: The next greater element for each value of nums1 is as follows:
- 2 is underlined in nums2 = [1,2,3,4]. The next greater element is 3.
- 4 is underlined in nums2 = [1,2,3,4]. There is no next greater element, so the answer is -1.
 

Constraints:

1 <= nums1.length <= nums2.length <= 1000
0 <= nums1[i], nums2[i] <= 104
All integers in nums1 and nums2 are unique.
All the integers of nums1 also appear in nums2.
 

Follow up: Could you find an O(nums1.length + nums2.length) solution?

'''

#Solution 

#Approach-1

class Solution:
    def nextGreaterElement(self, nums1: List[int], nums2: List[int]) -> List[int]:
        s = []
        r = [-1]* len(nums1)
        m = {n:i for i , n in enumerate(nums1)}
        for i in nums2[::-1]:
            while s and  i > s[-1]: s.pop()
            if s and i in m: r[m[i]] = s[-1]
            s.append(i)
        return r
    
#Approach-2
# Monotonic Stack

# Standard monotonic stack solution

class Solution:
    def nextGreaterElement(self, nums1: List[int], nums2: List[int]) -> List[int]:
        
        n2 = len(nums2)
        stack = []
        res2 = {}
        
        for i in range(n2-1, -1, -1):
            while stack and stack[-1] < nums2[i]:
                stack.pop()
            
            res2[nums2[i]] = stack[-1] if stack else -1
            
            stack.append(nums2[i])
            
        res = []
        for n1 in nums1:
            res.append(res2[n1])
            
        return res
    
#Approach-3

# Only using For Loop

class Solution:
    def nextGreaterElement(self, nums1: List[int], nums2: List[int]) -> List[int]:
        l=[]
        Flag=True           #Flag status
        for i in nums1:
            ind=nums2.index(i)      #found the index of number in nums2
            
            for j in range(ind, len(nums2)):
                if nums2[j]>i:
                    Flag=False        #Flag changed to false, if greater element found in nums2  
                    l.append(nums2[j])  
                    break               #inner loop ended
            
            if Flag==True:           
                l.append(-1)
                
            Flag=True        #setting flag value to True, to check the next number
            
        return l

#Q3.Backspace String Compare
'''

Given two strings s and t, return true if they are equal when both are typed into empty text editors. '#' means a backspace character.

Note that after backspacing an empty text, the text will continue empty.

 

Example 1:

Input: s = "ab#c", t = "ad#c"
Output: true
Explanation: Both s and t become "ac".
Example 2:

Input: s = "ab##", t = "c#d#"
Output: true
Explanation: Both s and t become "".
Example 3:

Input: s = "a#c", t = "b"
Output: false
Explanation: s becomes "c" while t becomes "b".
 

Constraints:

1 <= s.length, t.length <= 200
s and t only contain lowercase letters and '#' characters.
 
Follow up: Can you solve it in O(n) time and O(1) space?

'''

#Solution 

#Approach-1

# Stack Simplest Solution With Explanation | Beg to adv | Stack

class Solution:
    def backspaceCompare(self, s: str, t: str) -> bool:
        stack1 = [] # taking empty stack
        stack2 = [] # taking another empty stack
        
        for i in range(len(s)): # traversing through string s.
            if s[i] is not "#": # if the elem is not #
                stack1.append(s[i]) # will push it to the stack1
            else: # if it is "#" and there is some elem in stack1 then we`ll pop it else we`ll pass.
                if len(stack1)>0: 
                    stack1.pop()
                else:
                    pass
                
        for i in range(len(t)): # traversing through string t.       
            if t[i] is not "#": # if the elem is not #
                stack2.append(t[i]) # will push it to the stack2
            else: # if it is "#" and there is some elem in stack2 then we`ll pop it else we`ll pass.
                if len(stack2)>0:
                    stack2.pop()
                else:
                    pass
                
        return stack1 == stack2 # returning if they are equal when both are typed into empty text editors
           

#Approach-2

# 0-pointers simple solution || O(n) time, O(1) space

# You do not need 2 (or any count of) pointers if you have generators!

from itertools import zip_longest

def back_char_gen(st):
    bp_count = 0
    for char in reversed(st):
        if char == '#':
            bp_count += 1
        elif bp_count > 0:
            bp_count -= 1
        else:
            yield char


class Solution:
    def backspaceCompare(self, s: str, t: str) -> bool:
        for s_char, t_char in zip_longest(back_char_gen(s), back_char_gen(t)):
            if s_char != t_char:
                return False
        return True
    
 
# Approach-3

class Solution:
    def backspaceCompare(self, S, T):
        """
        :type S: str
        :type T: str
        :rtype: bool
        """
        return self.backspaceStr(S) == self.backspaceStr(T)
        
    def backspaceStr(self, S):
        index = 0
        res = ""
        for i in range(len(S)):
            if S[i] != '#':
                index += 1
                res += S[i]
            else:
                if index > 0:
                    index -= 1
                    res = res[:index]
        return res
  


# Approach-4

class Solution:
    def backspaceCompare(self, s: str, t: str) -> bool:
        def preprocess(s):
            s1 = []
            for c in s:
                if c == '#' :
                    if s1 != []:
                        s1.pop()
                else:
                    s1.append(c)
            return s1
            
        return preprocess(s) == preprocess(t)

# Approach-5

class Solution:
    def backspaceCompare(self, S, T):
        """
        :type S: str
        :type T: str
        :rtype: bool
        """
        return self.backspaceStr(S) == self.backspaceStr(T)
        
    def backspaceStr(self, S):
        index = 0
        res = ""
        for i in range(len(S)):
            if S[i] != '#':
                index += 1
                res += S[i]
            else:
                if index > 0:
                    index -= 1
                    res = res[:index]
        return res


#Q4. Implement Queue using Stacks

'''

Implement a first in first out (FIFO) queue using only two stacks. The implemented queue should support all the functions of a normal queue (push, peek, pop, and empty).

Implement the MyQueue class:

void push(int x) Pushes element x to the back of the queue.
int pop() Removes the element from the front of the queue and returns it.
int peek() Returns the element at the front of the queue.
boolean empty() Returns true if the queue is empty, false otherwise.
Notes:

You must use only standard operations of a stack, which means only push to top, peek/pop from top, size, and is empty operations are valid.
Depending on your language, the stack may not be supported natively. You may simulate a stack using a list or deque (double-ended queue) as long as you use only a stack's standard operations.
 

Example 1:

Input
["MyQueue", "push", "push", "peek", "pop", "empty"]
[[], [1], [2], [], [], []]
Output
[null, null, null, 1, 1, false]

Explanation
MyQueue myQueue = new MyQueue();
myQueue.push(1); // queue is: [1]
myQueue.push(2); // queue is: [1, 2] (leftmost is front of the queue)
myQueue.peek(); // return 1
myQueue.pop(); // return 1, queue is [2]
myQueue.empty(); // return false
 

Constraints:

1 <= x <= 9
At most 100 calls will be made to push, pop, peek, and empty.
All the calls to pop and peek are valid.
 

Follow-up: Can you implement the queue such that each operation is amortized O(1) time complexity? In other words, performing n operations will take overall O(n) time even if one of those operations may take longer.

'''

#Solution 

# class MyQueue:

#     def __init__(self):
        

#     def push(self, x: int) -> None:
        

#     def pop(self) -> int:
        

#     def peek(self) -> int:
        

#     def empty(self) -> bool:
        


# # Your MyQueue object will be instantiated and called as such:
# # obj = MyQueue()
# # obj.push(x)
# # param_2 = obj.pop()
# # param_3 = obj.peek()
# # param_4 = obj.empty()

#Approach-1

class MyQueue:

    def __init__(self):
        self.s1=[]
        self.s2=[]

    def push(self, x: int) -> None:
        while self.s1 :
            self.s2.append(self.s1.pop())
        self.s1.append(x)
        while self.s2 :
            self.s1.append(self.s2.pop())

    def pop(self) -> int:
        return self.s1.pop()

    def peek(self) -> int:
        return self.s1[-1]

    def empty(self) -> bool:
        return not self.s1
    
#Approach-2

# using two stacks


class MyQueue:
    """
    constraints
    Q: Do the queue methods we have to implement need to perform at the same complexity of a real queue?
    No, but they should be as performant as possible. amortized O(1) time complexity
    
    1 <= x <= 9
    at most 100 calls made to push, pop, peek, and empty
    all the calls to pop and peek are valid
    
    test case
    ["MyQueue", "push", "push", "peek", "pop", "empty"]
    [[], [1], [2], [], [], []]
    
    output -> [null, null, null, 1, 1, false]
    
    solution
    diff between queue and stack
    insertion
    stack [1,2,3,4,5]
    queue [1,2,3,4,5]
    
    removing twice
    stack [1,2,3]
    queue [3,4,5]
    -> order of elements getting popped is different
    
    aha! have another stack in reversed order
    
    then how do we reverse the stack?
    pop the values from stack1 and populate stack2 then pop
    stack1 = []
    stack2 = [5,4,3,2,1]
    pop
    pop
    stack1 = []
    stack2 = [5,4,3]
    insert 6
    insert 7
    
	now stack1 is empty so populate stack1 then insert
    stack1 = [3,4,5,6,7]
    stack2 = []
    
    peek
    which ever is not empty return [0]
    
    empty check if both are empty
    
    """

    def __init__(self):
        self.push_stack = []
        self.pop_stack = []
        

    def push(self, x: int) -> None:
        if self.pop_stack:
            while self.pop_stack:
                self.push_stack.append(self.pop_stack.pop())
        self.push_stack.append(x)

    def pop(self) -> int:
        if self.push_stack:
            while self.push_stack:
                self.pop_stack.append(self.push_stack.pop())
        return self.pop_stack.pop() if self.pop_stack else None
        
    def peek(self) -> int:
        if self.push_stack:
            return self.push_stack[0]
        if self.pop_stack:
            return self.pop_stack[-1]
        
    def empty(self) -> bool:
        return not (self.push_stack or self.pop_stack)
    
    
    
#Approach-3    
# O(n) Push

class MyQueue:

    def __init__(self):
        """
        Intialize the variables 
        """
        self.stack = []
        self.stack_two = []

    def push(self, x: int) -> None:
        """
        Push element x to the back of queue.
        """
      
        while self.stack:
            top = self.stack.pop()
            self.stack_two.append(top)
            
            
        self.stack.append(x)
        
        while self.stack_two:
            top = self.stack_two.pop()
            self.stack.append(top)
        
        

    def pop(self) -> int:
        """
        Removes the element from in front of queue and returns that element.
        """
        
        return self.stack.pop()
        
       

    def peek(self) -> int:
        """
        Get the front element.
        """
        
        return self.stack[-1]
        
    
    def empty(self) -> bool:
        """
        Returns whether the queue is empty.
        """
        return not self.stack 
    
    
    
#Approach-4     
    
class MyQueue:

    def __init__(self):
        self.stac = []
        self.stac2 =[]

    def push(self, x: int) -> None:
        self.stac.append(x)

    def pop(self) -> int:
        while len(self.stac) != 1:
            self. stac2.append(self.stac.pop())
        ans = self.stac[0]
        self. stac.pop()
        while len(self.stac2) != 0:
            self.stac.append(self.stac2.pop())
        return ans
    def peek(self) -> int:
        return self.stac[0]
    
        
        

    def empty(self) -> bool:
        return len(self.stac) ==0
        

#Approach-5

class MyQueue:
    def __init__(self):
        """
        Initialize your data structure here.
        """
        self.item=[]
    

    def push(self, x):
        """
        Push element x to the back of queue.
        :type x: int
        :rtype: void
        """
        self.item.append(x)

    def pop(self):
        """
        Removes the element from in front of queue and returns that element.
        :rtype: int
        """
        return self.item.pop(0)

    def peek(self):
        """
        Get the front element.
        :rtype: int
        """
        return self.item[0]

    def empty(self):
        """
        Returns whether the queue is empty.
        :rtype: bool
        """
        return self.item==[]


#Q5.Implement Stack using Queues

'''
Implement a last-in-first-out (LIFO) stack using only two queues. The implemented stack should support all the functions of a normal stack (push, top, pop, and empty).

Implement the MyStack class:

void push(int x) Pushes element x to the top of the stack.
int pop() Removes the element on the top of the stack and returns it.
int top() Returns the element on the top of the stack.
boolean empty() Returns true if the stack is empty, false otherwise.
Notes:

You must use only standard operations of a queue, which means that only push to back, peek/pop from front, size and is empty operations are valid.
Depending on your language, the queue may not be supported natively. You may simulate a queue using a list or deque (double-ended queue) as long as you use only a queue's standard operations.
 

Example 1:

Input
["MyStack", "push", "push", "top", "pop", "empty"]
[[], [1], [2], [], [], []]
Output
[null, null, null, 2, 2, false]

Explanation
MyStack myStack = new MyStack();
myStack.push(1);
myStack.push(2);
myStack.top(); // return 2
myStack.pop(); // return 2
myStack.empty(); // return False
 

Constraints:

1 <= x <= 9
At most 100 calls will be made to push, pop, top, and empty.
All the calls to pop and top are valid.

'''
#Solution 

# class MyStack:

#     def __init__(self):
        

#     def push(self, x: int) -> None:
        

#     def pop(self) -> int:
        

#     def top(self) -> int:
        

#     def empty(self) -> bool:
        


# # Your MyStack object will be instantiated and called as such:
# # obj = MyStack()
# # obj.push(x)
# # param_2 = obj.pop()
# # param_3 = obj.top()
# # param_4 = obj.empty()


#Approach-1
# Using only 1 deque


class MyStack:
    def __init__(self):
        self.Q = deque()

    def push(self, x: int) -> None:
        self.Q.append(x)

    def pop(self) -> int:
        return self.Q.pop()

    def top(self) -> int:
        return self.Q[-1]

    def empty(self) -> bool:
        return len(self.Q) == 0

#Approach-2

class MyStack(object):

    def __init__(self):
        self.stack=[]

    def push(self, x):
        self.stack.append(x)
        return None
        
    def pop(self):
        return self.stack.pop(-1)
        

    def top(self):
        return self.stack[-1]

    def empty(self):
        if self.stack==[]:
            return True
        return False
  
#Approach-3

import queue
class MyStack:

    def __init__(self):
        self.q1 = queue.Queue()
        self.ans = None
        
    def push(self, x: int) -> None:
        self.q1.put(x)
        self.ans = x
        return
        

    def pop(self) -> int:
        size = self.q1.qsize()
        while size > 1:
            popped = self.q1.get()
            self.ans = popped
            self.q1.put(popped)
            size -= 1
        ans = self.q1.get()
        return ans
        
    def top(self) -> int:
        return self.ans

    def empty(self) -> bool:
        return self.q1.empty()
        



#Q6. Daily Temperatures
'''

Given an array of integers temperatures represents the daily temperatures, return an array answer such that answer[i] is the number of days you have to wait after the ith day to get a warmer temperature. If there is no future day for which this is possible, keep answer[i] == 0 instead.

 

Example 1:

Input: temperatures = [73,74,75,71,69,72,76,73]
Output: [1,1,4,2,1,1,0,0]
Example 2:

Input: temperatures = [30,40,50,60]
Output: [1,1,1,0]
Example 3:

Input: temperatures = [30,60,90]
Output: [1,1,0]
 

Constraints:

1 <= temperatures.length <= 105
30 <= temperatures[i] <= 100

'''
#Solution 



#Approach-1

#  Basic idea is store the current temp and index in a stact and if current temp is greater than the temp at the top of stack pop the temp and index and in ans array at same index as that of top store the diff of current index and top temp index


class Solution:
    def dailyTemperatures(self, temperatures: List[int]) -> List[int]:
        
        # array to store the answer
        ans = [0] * len(temperatures)
        
        # a stack to store a pair of temperature and its index
        stack = list()
        
        # iterate over the temperature array
        for idx, temp in enumerate(temperatures):
            # while stack is not empty and current temp is greater than the top temp of stack
            # pop the top element temp and index and in ans array at top stack index point
            # store the diff between current index and top stack index
            while stack and temp > stack[-1][0]:
                stackTemp, stackIdx = stack.pop()
                ans[stackIdx] = (idx - stackIdx)
            
            # once all possible element are popped from the stact add current temp and index to stack
            stack.append([temp,idx])
            
        # once done return the ans array
        return ans
   
#Approach-2

# ndex Table + Upper Bound Binary Search

# This solutions works, it is just too slow on large cases but still worth knowing or understanding.

# Since the temperature values are small range [30,100], we could make a table and add the indexes where each element appears to the specific temperature index in the table.
# Since we iterate left to right, the indexes will always be monotonic -- increasing order.
# That means, we could apply binary search to find the best index...

# Idea with binary search:
# Find the upper bound -- meaning the next greatest element at the minimal index to the current temperature.

# For example, if we are at index 20, we only want to consider table entries from [21,100]
# Therefore, we can check if they have at least one element.
# To cut down on unnecessary binary searches -- check if the last element is greater than the current day, x.

# That way we know we can have a possibility of an answer.

# Then do this throughout all of the remaining temps ahead, and each time we take a the minimum of the upperbound index found such that it is greater than the current Day.

# Then if we did not find an answer, add 0 to answer array, else answer.

# Was not too familiar with monotonic stacks, however I was able to come up with a working but slow solution that leverages the monotonic nature.

class Solution:
    def dailyTemperatures(self, temperatures: List[int]) -> List[int]:
        table = [[] for x in range(101)];
        ans = [];
        
        for x in range(len(temperatures)):
            table[temperatures[x]].append(x);

        def upperbound(items, target):
            l,r=0,len(items)-1;
            
            ans=10000000000;
            while l<=r:
                m=(l+r)>>1;
                
                if target >= items[m]:
                    l=m+1;
                else:
                    ans = min(ans, items[m]);
                    r=m-1;

            return (ans, ans != 10000000000);
        
        for x,temp in enumerate(temperatures):
            best = 10000000000;
            for nextTemp in range(temp+1,101):
                if len(table[nextTemp]) > 0 and table[nextTemp][-1] > x:
                    upperBound, hasUpperBound = upperbound(table[nextTemp], x);
                    if hasUpperBound:
                        best = min(best, upperBound);
            
            ans.append(best-x if best != 10000000000 else 0);
        
        return ans
    

#Approach-3

# Optimal Time Solution using Monotonic Stack


class Solution:
    def dailyTemperatures(self, temperatures: List[int]) -> List[int]:

        # Monotonic Stack T.C: O(n)
        stack = deque()
        answer = [0] * len(temperatures)
        
        for i,t in enumerate(temperatures):
            while stack and t > stack[-1][0]:
                temp, index = stack.pop()
                answer[index] = i-index
            stack.append((t,i))
        return answer
    
    
#Approach-4

class Solution:
    def dailyTemperatures(self, temperatures: List[int]) -> List[int]:
        # monotonically decreasing stack
        stack = []
        result = [0] * len(temperatures)

        for i, t in enumerate(temperatures):
            if not stack or (t <= stack[-1][0]):
                # append if stack empty
                # or new temp is lower than top of stack
                stack.append((t, i))
            else:
                # need to pop back until we find a value
                # thats greater than t
                while stack and (t > stack[-1][0]):
                    prevTemp = stack.pop()
                    # Calculate the days apart
                    result[prevTemp[1]] = i - prevTemp[1]
                # append new high to stack
                stack.append((t, i))
        return result
 


#Approach-5

class Solution(object):
    def dailyTemperatures(self, temperatures):
        """
        :type temperatures: List[int]
        :rtype: List[int]
        """
        lt = len(temperatures)
        if lt ==1:
            return [0]
        res = [0]*lt
        record = [0]*101
        for t in range(temperatures[-1]):
            record[t] = lt-1
        for i in range(lt-2, -1, -1):
            tpt= temperatures[i]      
            res[i]=max(record[tpt]-i,0)
            for j in range(tpt):
                record[j]=i
        return res


# Q7. Flatten Nested List Iterator

'''

You are given a nested list of integers nestedList. Each element is either an integer or a list whose elements may also be integers or other lists. Implement an iterator to flatten it.

Implement the NestedIterator class:

NestedIterator(List<NestedInteger> nestedList) Initializes the iterator with the nested list nestedList.
int next() Returns the next integer in the nested list.
boolean hasNext() Returns true if there are still some integers in the nested list and false otherwise.
Your code will be tested with the following pseudocode:

initialize iterator with nestedList
res = []
while iterator.hasNext()
    append iterator.next() to the end of res
return res
If res matches the expected flattened list, then your code will be judged as correct.

 

Example 1:

Input: nestedList = [[1,1],2,[1,1]]
Output: [1,1,2,1,1]
Explanation: By calling next repeatedly until hasNext returns false, the order of elements returned by next should be: [1,1,2,1,1].
Example 2:

Input: nestedList = [1,[4,[6]]]
Output: [1,4,6]
Explanation: By calling next repeatedly until hasNext returns false, the order of elements returned by next should be: [1,4,6].
 

Constraints:

1 <= nestedList.length <= 500
The values of the integers in the nested list is in the range [-106, 106].

'''

#Solution

# """
# This is the interface that allows for creating nested lists.
# You should not implement it, or speculate about its implementation
# """
#class NestedInteger:
#    def isInteger(self) -> bool:
#        """
#        @return True if this NestedInteger holds a single integer, rather than a nested list.
#        """
#
#    def getInteger(self) -> int:
#        """
#        @return the single integer that this NestedInteger holds, if it holds a single integer
#        Return None if this NestedInteger holds a nested list
#        """
#
#    def getList(self) -> [NestedInteger]:
#        """
#        @return the nested list that this NestedInteger holds, if it holds a nested list
#        Return None if this NestedInteger holds a single integer
#        """

# class NestedIterator:
#     def __init__(self, nestedList: [NestedInteger]):
        
    
#     def next(self) -> int:
        
    
#     def hasNext(self) -> bool:
         

# Your NestedIterator object will be instantiated and called as such:
# i, v = NestedIterator(nestedList), []
# while i.hasNext(): v.append(i.next())



#Approach-1

class NestedIterator:
    def __init__(self, nestedList: [NestedInteger]):
        self.flattedList = []
        for i in range(len(nestedList)):
            nestedArray = self.flat(nestedList[i])
            self.flattedList.extend(nestedArray)
        print(self.flattedList)
        self.currentIndex = 0
    
    def flat(self, nestedInteger: NestedInteger) -> list:
        array = []
        if nestedInteger.isInteger():
            array.append(nestedInteger.getInteger())
        else:
            nestedIntegerList = nestedInteger.getList()
            for nestedInteger in nestedIntegerList:
                tmpArray = self.flat(nestedInteger)
                array.extend(tmpArray)
        return array
    
    def next(self) -> int:
        if self.currentIndex > len(self.flattedList) - 1:
            return self.flattedList[self.currentIndex]
        else:
            result = self.flattedList[self.currentIndex]
            self.currentIndex += 1                
            return result
        
    
    def hasNext(self) -> bool:
        if self.currentIndex > len(self.flattedList) - 1:
            return False
        return True
    
    
#Approach-2

# recursive solution

class NestedIterator:
    def __init__(self, nestedList: [NestedInteger]):
        self.ls = []
        self.ind = 0
        
        def flatten(ar):
            if len(ar) == 0:
                return
            
            for i in ar:
                if i.isInteger() == False:
                    flatten(i.getList())
                else:
                    self.ls.append(i.getInteger())
                    
        flatten(nestedList)
        
    def next(self) -> int:
        val = self.ls[self.ind]
        self.ind += 1
        return val
        
    
    def hasNext(self) -> bool:
        if len(self.ls) == self.ind:
            return False
        else:
            return True
        
#Approach-3
# iterator

class NestedIterator:
    def __init__(self, nestedList: [NestedInteger]):
        self.global_stack = []
        self.global_stack.append(iter(nestedList))
        self.next_element = nestedList
    def next(self) -> int:
        return self.next_element
    
    def hasNext(self) -> bool:
            count = 0
            while self.global_stack :
                try:
                    temp = next(self.global_stack[-1])
                    if temp.isInteger():
                        self.next_element = temp.getInteger()
                        return True
                    else:
                        self.global_stack.append(iter(temp.getList()))
                except Exception as e: 
                    self.global_stack.pop()
            return False


#Approach-4
class NestedIterator:
    def __init__(self, nestedList: [NestedInteger]):
        #Using a stack of [list, index] pairs. index is the pointer of the current elem in one nested list
        self.stack = [[nestedList,0]]
        
    
    def next(self) -> int:
        self.hasNext()
        # we read in the current nestedlist and its current index
        nested_list, i = self.stack[-1]
        # now that we will return the current value in this list, we move index forward.
        self.stack[-1][1] += 1
        return nested_list[i].getInteger()
        
    
    def hasNext(self) -> bool:
        s =self.stack # just for being easy to read
        while s:
            # while we still have list to check, return the current nest and its current index
            nested_list, i = s[-1]
            # if this happens, it means the index has already go through every elem in the current nestlist, so we pop this list out, then try to see if we have a next nestedlist (go back to while)
            if i == len(nested_list):
                s.pop()
            # if the index is not in the end of list, we extract what index points at to x, and check if x is a pure value of another list. If it is int, it means we have next value for iteration, so hasNext returns True
            #if x is another list, then we firstly move the index forward, because we have checked the current element, and we push a new nestedlist into stack, we will check it from 0 index, until we see a int value and return True.
            else:
                x = nested_list[i]
                if x.isInteger():
                    return True
                s[-1][1] += 1
                s.append([x.getList(),0])
        # if stack is empty, we reach the end of entire nestedlist, so we return False
        return False
    
    
#Approach-5    
# Simple recursion | Stack

# Store the integers in a list then pop elements when next is called.

class NestedIterator:
    def __init__(self, nestedList: [NestedInteger]):
        self.arr=[]
        self.itr(nestedList)
        self.arr=self.arr[::-1]
        
    def itr(self,nl):
        if(type(nl)==list):
            for i in nl:
                self.itr(i)
        else:
            if(nl.isInteger()):
                self.arr.append(nl.getInteger())
            res=nl.getList()
            if(res):
                self.itr(res)
        
    def next(self) -> int:
        return self.arr.pop()
    
    def hasNext(self) -> bool:
        return len(self.arr)>0



#Q8. Online Stock Span

'''
Design an algorithm that collects daily price quotes for some stock and returns the span of that stock's price for the current day.

The span of the stock's price today is defined as the maximum number of consecutive days (starting from today and going backward) for which the stock price was less than or equal to today's price.

For example, if the price of a stock over the next 7 days were [100,80,60,70,60,75,85], then the stock spans would be [1,1,1,2,1,4,6].
Implement the StockSpanner class:

StockSpanner() Initializes the object of the class.
int next(int price) Returns the span of the stock's price given that today's price is price.
 

Example 1:

Input
["StockSpanner", "next", "next", "next", "next", "next", "next", "next"]
[[], [100], [80], [60], [70], [60], [75], [85]]
Output
[null, 1, 1, 1, 2, 1, 4, 6]

Explanation
StockSpanner stockSpanner = new StockSpanner();
stockSpanner.next(100); // return 1
stockSpanner.next(80);  // return 1
stockSpanner.next(60);  // return 1
stockSpanner.next(70);  // return 2
stockSpanner.next(60);  // return 1
stockSpanner.next(75);  // return 4, because the last 4 prices (including today's price of 75) were less than or equal to today's price.
stockSpanner.next(85);  // return 6
 

Constraints:

1 <= price <= 105
At most 104 calls will be made to next.  

'''

#Solution 

# class StockSpanner:

#     def __init__(self):
        

#     def next(self, price: int) -> int:
        


# Your StockSpanner object will be instantiated and called as such:
# obj = StockSpanner()
# param_1 = obj.next(price)



#Approach-1

# using Stack || Easy to understand

class StockSpanner:

    def __init__(self):
        self.stack=[]
        self.arr=[]
        

    def next(self, price: int) -> int:
        if len(self.arr)==0:
            self.stack.append(0)
            self.arr.append(price)
            
            return 1
        
        else:
            while len(self.stack)>0 and price >= self.arr[self.stack[-1]]:
                self.stack.pop()
    
            ans=0
            if len(self.stack) ==0:
                
                ans=len(self.arr)+1
            else:
                ans=(len(self.arr))-self.stack[-1]
            
            self.stack.append(len(self.arr))
            self.arr.append(price)
            
            return ans
        
        
#Approach-2

 # monotonic decreasing stack

class StockSpanner:
    # Use a monotonic decreasing stack to achieve the goal
    def __init__(self):
        self.stack = [[100001, -1]]
        self.count = 0

    def next(self, price: int) -> int:
        if not self.stack or price < self.stack[-1][0]:
            ans = 1
        else:
            while self.stack and price >= self.stack[-1][0]:
                self.stack.pop()
            ans = self.count - self.stack[-1][1]
        self.stack.append([price, self.count])
        self.count += 1
        return ans                   


# Your StockSpanner object will be instantiated and called as such:
# obj = StockSpanner()
# param_1 = obj.next(price)


#Approach-3

# Using Stack and Memoization


class StockSpanner:

    def __init__(self):
        self.currentId = 0
        self.stocks = []
        self.has_stops = []
        self.top = None

    def next(self, price: int) -> int:
        self.stocks.append(price)
        self.top = price
        self.currentId += 1
        stock_span = self.stock_span_problem(self.stocks)
        return stock_span
    
    def stock_span_problem(self, stocks: list[int]):
        cur_id = self.currentId - 1
        stack = stocks[0:cur_id]
        has_stop_stack : list = self.has_stops[0:cur_id]
        stock = self.top
        streak = 0
        while len(stack) > 0:
            top = stack.pop()
            has_stop = has_stop_stack.pop()
            if stock >= top:
                streak += cur_id - has_stop
                stack = stack[0: has_stop]
                has_stop_stack = has_stop_stack[0:has_stop]
                cur_id = has_stop
                continue
            break
        self.has_stops.append(cur_id)
        return streak + 1
    
    
#Approach-4

class StockSpanner:

    def __init__(self):
        self.stack = []
        

    def next(self, price: int) -> int:
        res = 1
        while self.stack and self.stack[-1][1] <= price: res += self.stack.pop()[0]
        self.stack.append((res, price))
        return res
    
    
#Approach-5

# Linked List solution


class ListNode:
    def __init__(self, val=0, less=0, pre=None):
        self.val = val
        self.less = less
        self.pre = pre

class StockSpanner:
    def __init__(self):
        self.tail = ListNode(val=10 ** 6)

    def next(self, price):
        total, cur = 1, self.tail
        while cur and cur.val <= price:
            total += cur.less
            cur = cur.pre
        self.tail = ListNode(price, total, cur)        
        return total

#Q9. Minimum Cost Tree From Leaf Values

'''

Given an array arr of positive integers, consider all binary trees such that:

Each node has either 0 or 2 children;
The values of arr correspond to the values of each leaf in an in-order traversal of the tree.
The value of each non-leaf node is equal to the product of the largest leaf value in its left and right subtree, respectively.
Among all possible binary trees considered, return the smallest possible sum of the values of each non-leaf node. It is guaranteed this sum fits into a 32-bit integer.

A node is a leaf if and only if it has zero children.

 

Example 1:


Input: arr = [6,2,4]
Output: 32
Explanation: There are two possible trees shown.
The first has a non-leaf node sum 36, and the second has non-leaf node sum 32.
Example 2:


Input: arr = [4,11]
Output: 44
 

Constraints:

2 <= arr.length <= 40
1 <= arr[i] <= 15

'''
#Solution 

#Approach-1


# DP and stack: array problem disguised as a tree problem

# I don't know who think of the tree representation in the question, which complicates the understanding.

# DP approach
class Solution:
    # We cut arr into two pieces and harvest the product, until we reaches the leaves
    # dp[i][j] = smallest possible sum of the values of each non-leaf nodes for arr[i:j+1]
    # dp[i][j] = max(dp[i][k] + dp[k+1][j] + arr[i]*arr[i+1]*...*arr[j])
    def mctFromLeafValues(self, arr: List[int]) -> int:
        n = len(arr)
        dp = [[0 for i in range(n)] for j in range(n)]
        for j in range(n):
            for i in range(j-1, -1, -1):
                dp[i][j] = float('inf')
                for k in range(i,j):
                    dp[i][j] = min(dp[i][j], max(arr[i:k+1])*max(arr[k+1:j+1]) + dp[i][k] + dp[k+1][j])
        return dp[0][n-1]

    
    
#Approach-2

# Monotonic stack greedy approach
class Solution:
    # We should notice that in Example 1, the number 2 is only used once in the lower subtrees, in both cases.
    # The problem can be reinterpreted as: given arr, if we group two neighbours arr[i] and arr[i+1] to make it max(arr[i], arr[i+1]) and will incur a cost of arr[i]*arr[i+1], what is the minimum cost until we get to only one element?
    # That means in this problem, we can significantly cut down the complexities by taking a Greedy approach.
    # We maintain a monotonic decreasing stack to hold potential multiplication pairs
    # For example, let's consider Example 1:
    # arr = [6,2,4]
    # We can maintain a monotonic decreasing array up till [6,2]
    # When 4 comes in, we know we have remove 2, which one should I include in calculation of the cost?
    # The answer is minimum between the new element 4 and the stack top 6. -> 4*2 = 8, and we append 4 to the stack
    # When all the elements are exhausted we clear up the stack and add up pairwise products from the stack top
    
    def mctFromLeafValues(self, arr: List[int]) -> int:
        stack, result = [float('inf')], 0
        for num in arr:
            while stack and stack[-1] <= num:
                item = stack.pop()
                result += item*min(stack[-1],num)
            stack.append(num)
        while len(stack) > 2:
            result += stack.pop() *stack[-1]
        return result
 

#Approach-3

class Solution:
	def mctFromLeafValues(self, arr: List[int]) -> int:
		ans = 0

		while len(arr) > 1:
			i = arr.index(min(arr))
			l = math.inf
			r = math.inf

			if i-1 >=0:
				l = arr[i-1]
			if i+1 < len(arr):
				r = arr[i+1]

			ans+= min(l,r)*arr.pop(i)
		return ans

    
#Approach-4

# DP Based | O(N^3)

class Solution(object):
    def mctFromLeafValues(self, arr):
        """
        :type arr: List[int]
        :rtype: int
        """
        
        N = len(arr)
        dp = [[0 for _ in range(N)] for _ in range(N)]
        max_dp = [[0 for _ in range(N)] for _ in range(N)]
        
        for i in range(N):
            max_val = arr[i]
            for j in range(i, N):
                max_val = max(max_val, arr[j])
                max_dp[i][j] = max_val
                
        for gap in range(1, N):
            for i in range(N-gap):
                j = i + gap
                dp[i][j] = float("inf")
                for k in range(i, j):
                    dp[i][j] = min(dp[i][j], \
                                (dp[i][k]+dp[k+1][j])+max_dp[i][k]*max_dp[k+1][j])
                    
        
        return dp[0][N-1]
    
    
#Approach-5

# Huffman tree'-like, O(n^2)

# Somehow when reading this question's description, I came up with Huffman coding and the construction process of a Huffman tree. Though I don't know how this problem is related to building a Huffman tree, but anyway the code works (like any greedy solutions)...

# This idea is to repeatedly find a pair of two adjacent elements in the array with the smallest product, record the smallest product, and then replace these two elements with the greater one among these two, until there is only one element in the array.

class Solution:
    def mctFromLeafValues(self, arr: List[int]) -> int:
        res = [] # to record the smallest product of each iteration

        while len(arr) >= 2: # until reaching root node
            smallestProduct = float("inf") # smallest product met in this iteration
            smallestProductPosition = -1 # position of the two adjacent elements that makes the smallest product
            bigger = -1 # greater one among these two elements

            for i in range(len(arr) - 1): # iterate over the array
                a = arr[i] # element1
                b = arr[i + 1] # element2
                if a * b <= smallestProduct: # smaller pair product found
                    smallestProduct = a * b
                    smallestProductPosition = i
                    bigger = max(a, b)

            res.append(smallestProduct) # record the smallest product
            arr[smallestProductPosition: smallestProductPosition + 2] = [bigger] # replace the two adjacent elements with the greater one after iteration
        return sum(res)


#Q10. Sum of Subarray Minimums

'''

Given an array of integers arr, find the sum of min(b), where b ranges over every (contiguous) subarray of arr. Since the answer may be large, return the answer modulo 109 + 7.

 

Example 1:

Input: arr = [3,1,2,4]
Output: 17
Explanation: 
Subarrays are [3], [1], [2], [4], [3,1], [1,2], [2,4], [3,1,2], [1,2,4], [3,1,2,4]. 
Minimums are 3, 1, 2, 4, 1, 1, 2, 1, 1, 1.
Sum is 17.
Example 2:

Input: arr = [11,81,94,43,3]
Output: 444
 

Constraints:

1 <= arr.length <= 3 * 104
1 <= arr[i] <= 3 * 104 

'''

#Solution 

#Approach-1 :monotonic stack

# The adjustment to this exercise is that you have to notice that at index i you need to multiply the number of bigger numbers at his right (including itself) to the number of bigger numbers to the left (including itself) and that is the number of times you need to sum the num arr[i]

class Solution:
	def sumSubarrayMins(self, arr: List[int]) -> int:

		rightSmallest = [i for i in range(len(arr))]
		leftSmallest = [i for i in range(len(arr))]
		mono_stack = deque()
		ans, mod = 0, 10 ** 9 + 7

		for i, num in enumerate(arr):

			while len(mono_stack) > 0 and num < arr[mono_stack[-1]]:
				rightSmallest[mono_stack.pop()] = i - 1

			if len(mono_stack) == 0:
				leftSmallest[i] = 0
			else:
				leftSmallest[i] = mono_stack[-1] + 1

			mono_stack.append(i)

		while len(mono_stack) > 0:
			rightSmallest[mono_stack.pop()] = len(arr) - 1

		for i in range(len(arr)):
			ans += arr[i] * ((rightSmallest[i] - i + 1) * (i - leftSmallest[i] + 1))

		return ans % mod

#Approach-2 :

# Stack + DP

class Solution:
    def sumSubarrayMins(self, arr: List[int]) -> int:
        # sum[i] means the sum when ending at i-th element
        # sum[i] = sum[j] + (i-j)*arr[i] when j < i and arr[j] <= arr[i]
        sums = [0] * len(arr)
        stack = []
        for i in range(len(arr)):
            while stack and arr[stack[-1]] > arr[i]:
                stack.pop()
            if stack:
                j = stack[-1]
                sums[i] = sums[j] + (i-j)*arr[i]
            else:
                sums[i] = (i+1)*arr[i]
            stack.append(i)
            
        return sum(sums) % (10**9 + 7)
    
#Approach-3 :

class Solution:
    def sumSubarrayMins(self, arr: List[int]) -> int:
        res = 0
        stack = [-1]                                        # We are adopting increasing stack to solve this problem.
        arr += [0]                                          # The trick is as same as problem 84,
                                                            # put 0 in the last of arr, also keeping stack[0] always the smallest element without affecting res.
            
            
        for i in range(len(arr)):                           
            while arr[i] < arr[stack[-1]]:                  
                mid = stack.pop()                           # mid is the idx of "num" which is the smallest element in current interval.  
                num = arr[mid]
                right = i                                   # "right" is the right first element smaller than "num"
                left = stack[-1]                            # "left" is the left first element smaller than "num"
                res += num * (right-mid) * (mid-left)
            stack.append(i)
        
        return res % (10**9 + 7)
    
    

    
#Approach-4 :increasing stack


class Solution:
    # Time On
    # Space On
    # 3 1 2 2 4
    # 3: [3-3]
    # 1: [3-1][3-2][3-4] [1-1][1-2][1-2][1-4]
    # 2: [2-2] [2-2][2-4]
    # 2: [2-2][2-2] [2-4]
    # 4: [4-4]
    def sumSubarrayMins2(self, A: List[int]) -> int:
        MOD,n = 10**9 + 7,len(A)
        left,right,s1,s2 = [0]*n,[0]*n,[],[]
        
        # increasing stack
        # remember the first minum num and the num bigger than it
        # 3     s1 = (3,1)
        # 3 1   s1 = (1,2)
        # 3 1 2 s1 = (1,2) (2,1)
        for i,a in enumerate(A):
            count = 1
            print(s1)
            while s1 and s1[-1][0] > a:
                count += s1.pop()[1]
            print(s1)
            left[i] = count
            s1.append((a,count))
        for i in range(n-1,-1,-1):
            count = 1
            while s2 and s2[-1][0] >= A[i]:
                count += s2.pop()[1]
            right[i] = count
            s2.append((A[i],count))
            print(s2)
        print(left,right)
        
        return sum(a * l * r for a, l, r in zip(A, left, right)) % MOD
    
    # increasing stack s
    # when i is smaller than the top of stack
    # pop the top
    # left[top] = top - stack[-1] (i is the smallest in A(stack[-1]:i])
    # right[top] = i - top (i is the smallest in A[top:i))
    # top * left[top] * right[top]
    def sumSubarrayMins(self, A):
        res = 0
        s = []
        A = [0] + A + [0]
        for i, x in enumerate(A):
            print(s)
            while s and A[s[-1]] > x:
                j = s.pop()
                k = s[-1]
                print(A[j],i,j,k)
                res += A[j] * (i - j) * (j - k)
            print(s)
            s.append(i)
        return res % (10**9 + 7)

#Approach- 5 :

# stack

class Solution:
    def sumSubarrayMins(self, A: List[int]) -> int:
        if len(A) == 1:
            return A[0]
        
        ans = 0
        stack = [0]
        for ind in range(1, len(A)):
            if A[ind] > A[ind-1]:
                stack.append(ind)
            else:
                while stack and A[stack[-1]] >= A[ind]:
                    p = stack.pop()
                    p_l = stack[-1] if len(stack) != 0 else -1
                    ans = (ans+(ind-p)*(p-p_l)*A[p])%1000000007
                stack.append(ind)
        while stack:
            p = stack.pop()
            p_l = stack[-1] if stack else -1
            ans = (ans+(len(A)-p)*(p-p_l)*A[p])%1000000007
        
        return ans
    
    

#Approach- 6 :monotonic stack

MOD = 1000000007
class Solution:
    def sumSubarrayMins(self, arr: List[int]) -> int:
        stack = []
        ret = 0
        for idx, n in enumerate(arr):
            while len(stack) != 0 and n < stack[-1][-1]:
                v_prev = stack.pop(-1)
                if len(stack) == 0:
                    prev_idx = -1
                else:
                    prev_idx = stack[-1][0]
                ret += ((idx - v_prev[0]) % MOD * (v_prev[0] - prev_idx) % MOD * v_prev[1] % MOD) % MOD
                ret = ret % MOD
            stack.append((idx, n))
            
        idx = len(arr)
        while len(stack) != 0:
            v_prev = stack.pop(-1)
            if len(stack) == 0:
                prev_idx = -1
            else:
                prev_idx = stack[-1][0]
            ret += ((idx - v_prev[0]) % MOD * (v_prev[0] - prev_idx) % MOD * v_prev[1] % MOD) % MOD
            ret = ret % MOD
        return ret % MOD


#Q11. Evaluate Reverse Polish Notation

'''

Evaluate the value of an arithmetic expression in Reverse Polish Notation.

Valid operators are +, -, *, and /. Each operand may be an integer or another expression.

Note that division between two integers should truncate toward zero.

It is guaranteed that the given RPN expression is always valid. That means the expression would always evaluate to a result, and there will not be any division by zero operation.

 

Example 1:

Input: tokens = ["2","1","+","3","*"]
Output: 9
Explanation: ((2 + 1) * 3) = 9
Example 2:

Input: tokens = ["4","13","5","/","+"]
Output: 6
Explanation: (4 + (13 / 5)) = 6
Example 3:

Input: tokens = ["10","6","9","3","+","-11","*","/","*","17","+","5","+"]
Output: 22
Explanation: ((10 * (6 / ((9 + 3) * -11))) + 17) + 5
= ((10 * (6 / (12 * -11))) + 17) + 5
= ((10 * (6 / -132)) + 17) + 5
= ((10 * 0) + 17) + 5
= (0 + 17) + 5
= 17 + 5
= 22
 

Constraints:

1 <= tokens.length <= 104
tokens[i] is either an operator: "+", "-", "*", or "/", or an integer in the range [-200, 200].

'''
#Solution 

#Approach-1

# Stack

class Solution:
    def evalRPN(self, tokens: List[str]) -> int:
        # Use a stack to evaluate the expression.
        
        stack = []
        add = lambda m, n : m + n
        subtract = lambda m, n : m - n
        multiply = lambda m, n : m * n
        
        operation = {'+': add, '-': subtract, '*': multiply, '/': self.divide}
        
        for tok in tokens:
            if tok in operation:
                n = int(stack.pop())
                m = int(stack.pop())
                stack.append (operation[tok] (m, n))
            else:
                stack.append (tok)
                
        return stack.pop()
    
    # This divide function does integer division that truncates toward zero.
    def divide (self, m: int, n: int) -> int:
        q = m // n
        if q < 0 and n*q != m:
            q += 1
            
        return q
    
#Approach-2

class Solution:
    def evalRPN(self, tokens: List[str]) -> int:
        stack = []
        def makeOp(op,num1,num2):
            res = 0
            if op == '+' :
                res = num2 + num1
            elif op == '-' :
                res = num2 - num1
            elif op == '*' :
                res = num2 * num1
            else : 
                res = int(num2 / num1)
            return res
        
        for op in tokens :
            if op in ['+','-','*','/'] :
                val1 = stack.pop()
                val2 = stack.pop()
                stack.append(makeOp(op,val1,val2))
            else :
                stack.append(int(op))

        return stack[-1]
    
#Approach-3

class Solution:
    def evalRPN(self, tokens: List[str]) -> int:
        stack = []
        for c in tokens:
            if c == "+":
                stack.append(stack.pop()+stack.pop())
            elif c == "-":
                a,b = stack.pop(), stack.pop()
                stack.append(b-a)
            elif c == "*":
                stack.append(stack.pop()*stack.pop())
            elif c == "/":
                a,b = stack.pop(), stack.pop()
                stack.append(int(b/a))
            else:
                stack.append(int(c))
            
        return stack[-1]

#Approach-4

class Solution(object):
    def evalRPN(self, tokens):
        """
        :type tokens: List[str]
        :rtype: int
        """
        stack = []
        for token in tokens:
            if token != "+" and token != "-" and token != "*" and token != "/":
                stack.append(int(token))
            else:
                a = stack.pop()
                b = stack.pop()
                if token == "+":
                    stack.append(a + b)
                elif token == "-":
                    stack.append(b - a)
                elif token == "*":
                    stack.append(a * b)
                elif token == "/":
                    if a*b < 0:
                        stack.append(-(abs(b)//abs(a)))
                    else:
                        stack.append(b // a)
            
        return stack[-1]
    
#Approach-5 :

class Solution:
    def evalRPN(self, tokens: List[str]) -> int:
        stack = []
        for token in tokens:
            if token not in ["+", "-", "*", "/"]:
                stack.append(int(token))
            else:
                x, y = stack.pop(), stack.pop()
                match token:
                    case "/":
                        stack.append(int(y / x))
                    case "+":
                        stack.append(y + x)
                    case "-":
                        stack.append(y - x)
                    case "*":
                        stack.append(y * x)
        return stack[0]




