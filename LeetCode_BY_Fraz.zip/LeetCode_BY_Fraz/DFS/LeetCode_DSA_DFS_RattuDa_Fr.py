#DFS

#Q1. Letter Combinations of a Phone Number ( Doubt)

'''
Given a string containing digits from 2-9 inclusive, return all possible letter combinations that the number could represent. Return the answer in any order.

A mapping of digits to letters (just like on the telephone buttons) is given below. Note that 1 does not map to any letters.


 

Example 1:

Input: digits = "23"
Output: ["ad","ae","af","bd","be","bf","cd","ce","cf"]
Example 2:

Input: digits = ""
Output: []
Example 3:

Input: digits = "2"
Output: ["a","b","c"]
 

Constraints:

0 <= digits.length <= 4
digits[i] is a digit in the range ['2', '9'].

'''

#Solution 
# Method-1
# DFS

class Solution:
    def letterCombinations(self, digits: str) -> List[str]:
        if not digits:
            return []
        number_to_letter = {"2": "abc", "3": "def", "4": "ghi", "5": "jkl",
                            "6": "mno", "7": "pqrs", "8": "tuv", "9": "wxyz"}
        result = []

        def dfs(comb: str, idx: int):
            if idx == len(digits):
                result.append(comb)
            else:
                number_letter_str = number_to_letter[digits[idx]]
                for i in range(len(number_letter_str)):
                    dfs(comb+number_letter_str[i], idx+1)

        dfs(comb="", idx=0)
        return result
    
#Method-2
# Python and itertools
# cartesian-product

from itertools import product

class Solution:
    def letterCombinations(self, digits: str) -> List[str]:
        if not digits:
            return []
        letters_by_digits = {
            "2": "abc",
            "3": "def",
            "4": "ghi",
            "5": "jkl",
            "6": "mno",
            "7": "pqrs",
            "8": "tuv",
            "9": "wxyz",
        }
        if len(digits) == 1:
            return list(letters_by_digits[digits])
        
        return list("".join(p) for p in product(*(letters_by_digits[digit] for digit in digits)))
    
    
#Method-3

class Solution:
    def letterCombinations(self, digits: str) -> List[str]:
        res = []
        digitsToChar = {
            "2" : "abc" ,
            "3" : "def" ,
            "4" : "ghi" ,
            "5" : "jkl" ,
            "6" : "mno" ,
            "7" : "pqrs" ,
            "8" : "tuv" ,
            "9" : "wxyz"
        }
        
        def backtracking(i , curStr):
            if len(curStr) == len(digits):
                res.append(curStr)
                return
            
            for c in digitsToChar[digits[i]]:
                backtracking(i + 1, curStr + c)
                
        if digits :
                backtracking(0 , "")
                
        return res
    
#Method-4
class Solution:
    def letterCombinations(self, digits: str) -> List[str]:
        hashmap = {'2': ['a', 'b', 'c'],
                  '3': ['d', 'e', 'f'],
                  '4': ['g', 'h', 'i'],
                  '5': ['j', 'k', 'l'],
                  '6': ['m', 'n', 'o'],
                  '7': ['p', 'q', 'r', 's'],
                  '8': ['t', 'u', 'v'],
                  '9': ['w', 'x', 'y', 'z']}
        
        res = []
        
        def helper(s, d):
            if len(s) >= len(digits):
                if s:
                    res.append(s)
                return
            
            for i in range(len(d)):
                chars = hashmap[d[i]]
                
                for curr_char in chars:
                    helper(s + curr_char, d[i + 1:])
        
        helper("", digits)
        return res



#Q2 Course Schedule II

'''

There are a total of numCourses courses you have to take, labeled from 0 to numCourses - 1. You are given an array prerequisites where prerequisites[i] = [ai, bi] indicates that you must take course bi first if you want to take course ai.

For example, the pair [0, 1], indicates that to take course 0 you have to first take course 1.
Return the ordering of courses you should take to finish all courses. If there are many valid answers, return any of them. If it is impossible to finish all courses, return an empty array.

 

Example 1:

Input: numCourses = 2, prerequisites = [[1,0]]
Output: [0,1]
Explanation: There are a total of 2 courses to take. To take course 1 you should have finished course 0. So the correct course order is [0,1].
Example 2:

Input: numCourses = 4, prerequisites = [[1,0],[2,0],[3,1],[3,2]]
Output: [0,2,1,3]
Explanation: There are a total of 4 courses to take. To take course 3 you should have finished both courses 1 and 2. Both courses 1 and 2 should be taken after you finished course 0.
So one correct course order is [0,1,2,3]. Another correct ordering is [0,2,1,3].
Example 3:

Input: numCourses = 1, prerequisites = []
Output: [0]
 

Constraints:

1 <= numCourses <= 2000
0 <= prerequisites.length <= numCourses * (numCourses - 1)
prerequisites[i].length == 2
0 <= ai, bi < numCourses
ai != bi
All the pairs [ai, bi] are distinct.

'''
#Solution 

# Method-1

# DFS Solution with Comments
# dfs with recursion

class Solution:
    def findOrder(self, numCourses: int, prerequisites: List[List[int]]) -> List[int]:
        visited = {} # 0 not visited; -1 currently being visited; 1 finished
        graph = {} # key: the course number; value: prerequisite(s) of that course
        res = []
        for i in range(numCourses):
            graph[i], visited[i] = [], 0 # initialize all courses' prerequisites as empty; initialize all courses as 0, not visited status
        for pair in prerequisites:
            graph[pair[0]].append(pair[1]) # fill in the prerequisites of each course
        for j in range(numCourses):
            if not self.dfs(j, visited, graph, res): # if False, there must be a cycle; terminate by returning an empty list
                return []
        return res
        
    def dfs(self, course, visited, graph, res):
        if visited[course] == 1: # this course had been successfully added into the res
            return True
        if visited[course] == -1: # this course had not been added into the res, but visited again; there is a cycle!
            return False
        visited[course] = -1 # set the current course as currently being visited
        for pre in graph[course]: 
            if not self.dfs(pre, visited, graph, res):
                return False # if there is a cycle detected at any point, terminate!
        res.append(course) # no cycle found, dfs finished, good to add the course into the res
        visited[course] = 1 # this course finished
        return True
    
    
# Method-2

# [Deque] Based on Topological Sort


class Solution:
    def findOrder(self, num: int, prer: List[List[int]]) -> List[int]:
        indegree=[0]*num
        adj=[[] for _ in range(num)]
        for a,b in prer:
            indegree[a]+=1    #count indegree of elements
            adj[b].append(a)     #creating adj list of outgoing edges only
        dq=deque()
        for i,val in enumerate(indegree):
            if not val:
                dq.append(i)    #appending nodes having indgree  0, to start the sorting
        res=[]
        while dq:
            pop=dq.popleft()
            res.append(pop)     
            for val in adj[pop]:     #once element is popped, we decrease indegree for all outgoing elements from popped node
                indegree[val]-=1
                if indegree[val]==0:   #if indegree reduces to zero, append it to deque
                    dq.append(val)
        if len(res)!=num: return []    #if there is any cycle then elements will always be less than total
        return res

    
# Method-3
# O(E+V)
# indegree
# outdegree


class Solution:
    def findOrder(self, numCourses: int, prerequisites: List[List[int]]) -> List[int]:
        # indegree, outdegree
        # prereq_course -> course
        # out           -> in
        indegree = collections.defaultdict(set)
        outdegree = collections.defaultdict(list)
        
        for pre in prerequisites:
            # [1, 0] -> target, req
            # req -> target
            # out -> in
            target, req = pre
            
            indegree[target].add(req)
            outdegree[req].append(target)
            
        ans = []
        queue = []
        
        # find the course which has no any indegree
        # it means there is no prerequisit
        for c in range(numCourses):
            if c not in indegree:
                queue.append(c)
                
        while queue:
            c = queue.pop()
            ans.append(c)
            
            # if we take this course, it means we finish an prerequisit for
            # several courses
            for other_course in outdegree[c]:
                indegree[other_course].remove(c)
                
                # there is no more prerequisit
                # add it to the queue
                if len(indegree[other_course]) == 0:
                    queue.append(other_course)
        
        return ans if len(ans) == numCourses else []

 

# Method-4


# Topological Sort O(N + P) Template

# Do DFS on all the nodes.
# 2 sets, 1 for visit and 1 to detect cycle
# inside the DFS , first check if cycle is there, if yes, return False rightaway
# Then, check if node is already visited, if yes return True to add to the output again.
# perform dfs on its neighbors, go deep inside the graph and add the nodes from end to start
# Exact Same template for 269. Alien Dictionary
# Solution for 269: Template


class Solution:
    def findOrder(self, numCourses: int, prerequisites: List[List[int]]) -> List[int]:
        d = {i:[] for i in range(numCourses)}
        
        for crs, prereq in prerequisites:
            d[crs].append(prereq)
         
        visit, cycle = set(), set()
        output = []
        def dfs(crs):
            if crs in cycle:
                return False
            if crs in visit:
                return True
            
            cycle.add(crs)
            for nei in d[crs]:
                if not dfs(nei):
                    return False
            cycle.remove(crs)
            visit.add(crs)
            output.append(crs)
            return True
        
        for crs in range(numCourses):
            if not dfs(crs):
                return []
        return output
            
# Method-5

class Solution(object):
    def findOrder(self, numCourses, prerequisites):
        """
        :type numCourses: int
        :type prerequisites: List[List[int]]
        :rtype: List[int]
        """
        n = numCourses; indegree = [0]*n; childs = [[] for i in range(n)] 
        for e in prerequisites:
            indegree[e[0]] += 1
            childs[e[1]].append(e[0])
            
        k = 0; stack = []
        for i in range(n):
            if indegree[i] == 0:
                stack.append(i)
        ans = []
        while stack:
            tmp = stack.pop()
            k += 1
            if tmp not in ans:
                ans.append(tmp)
            for ee in childs[tmp]:
                indegree[ee] -= 1
                if indegree[ee] == 0:
                    stack.append(ee)
                    
        return [[],ans][k==n]

#Q3 Decode String
'''
Given an encoded string, return its decoded string.

The encoding rule is: k[encoded_string], where the encoded_string inside the square brackets is being repeated exactly k times. Note that k is guaranteed to be a positive integer.

You may assume that the input string is always valid; there are no extra white spaces, square brackets are well-formed, etc. Furthermore, you may assume that the original data does not contain any digits and that digits are only for those repeat numbers, k. For example, there will not be input like 3a or 2[4].

The test cases are generated so that the length of the output will never exceed 105.

 

Example 1:

Input: s = "3[a]2[bc]"
Output: "aaabcbc"
Example 2:

Input: s = "3[a2[c]]"
Output: "accaccacc"
Example 3:

Input: s = "2[abc]3[cd]ef"
Output: "abcabccdcdcdef"
 

Constraints:

1 <= s.length <= 30
s consists of lowercase English letters, digits, and square brackets '[]'.
s is guaranteed to be a valid input.
All the integers in s are in the range [1, 300].

'''
#Solution 

#Method-1

class Solution:
    def decodeString(self, s: str) -> str:
        stk = []
        
        for i in range(len(s)):
            
            if s[i] != ']':
                stk.append(s[i])  
            else:
                strr = ''
                while stk[-1] != '[':
                    strr = stk.pop() + strr
                stk.pop()
                
                num = ''
                while stk and stk[-1].isdigit():
                    num = stk.pop() + num
                    
                stk.append(int(num) * strr)
        
        return ''.join(stk)
                    
#Method-2

class Solution:
    def decodeString(self, s: str) -> str:
        stack = []
        
        for char in s:
            if char != "]":
                stack.append(char)
            else:
                word = ""
                while stack and stack[-1] != "[":
                    word = stack.pop() + word
                
                if stack:
                    stack.pop()
                    num = ""
                    while stack and stack[-1].isdigit():
                        num = stack.pop() + num
                        
                    stack.append(int(num) * word)
                
                    
        return "".join(stack)
    
    
#Method-3
# Solved Using Recursion + Stack

class Solution:
    def decodeString(self, s: str) -> str:
        #base case: single character that's not a number!
        if(len(s) == 1 and s.isdigit() == False and s[0] != '[' and s[0] != ']'):
            return s
        
        #otherwise, we need to intialize the ans variable which we will return at the end!
        ans = ""
        i = 0
        
        current_num = ""
        #iterate through each and every char until it goes out of bounds!
        while i < len(s):
            cur = s[i]
            #append stand alone characters!
            if(cur.isdigit() == False and cur != '[' and cur != ']'):
                ans += cur
                i += 1
                continue
            #otherwise, the other case we have to take account is if
            #current character is number, in which we have to decode
            #in recursive manner!
            if(cur.isdigit()):
                current_num += cur
                i += 1
                continue
            if(cur == '['):
                num = int(current_num)
                #we have to find index positions of all characters
                #between open and closed brackets -> recurse over
                #those characters in substring -> append to ans
                #the result num times!
                
                #to know when we reached the appropriate closing char,
                #we can use a stack!
                
                #push initial opening char!
                stack = ['[']
                #since i assume input is valid, there gaurantees
                #corresponding closing char!
                #start index = i + 2 since i+1th index is bracket char!
                start = i+1
                while stack:
                    if(s[start] == '['):
                        stack.append('[')
                    if(s[start] == ']'):
                        stack.pop()
                    start += 1
                #once we exit, we know range of chars to recurse over!
                #it will go from index i +2 to index start - 2!
                recurse = self.decodeString(s[i+1:start - 1])
                #add to answer num times the rec. call!
                for i in range(num):
                    ans += recurse
                #update i to index start since start points to first char after the closing bracket of
                #current decoded string!
                i = start
                current_num = ""
                continue
                
        return ans
    
#Method-4

# Recursive Solution w/ Explanation and Comments


# For this solution we can break each bracket pair into its own micro-problem, a great candidate for recursion.

# Each Subproblem either is just a character or is contains another subproblem.

# In our first while loop we iterate through the string which will be something like 'a2[ac]'
# If we get a character we simply add that to the output string -> outstring += 'a' and iterate
# We continue along the string until we hit a number. We know that the numbers can be multiple digits, so we keep adding numbers to our runningMultString until
# we hit a non number.
# We then convert that string into an integer
# So now in our example runningMultString = '2' and recurMult = 2
# Next we know we are looking for our internal recursion string
# We can keep a psuedo bracket count to ensure we are capturing the entire string and our brackets are closed when we finally recurse
# So, we scan each character and add 1 if the string is '[' and subtract 1 if ']', then if our count is 0 we know we have a set of closed bracets
# In our example our recurStr and bracketCount would look like this:
# index, character, recurString, bracketCount
# 2, [, [, 1
# 3, a, [a, 1
# 4, c, [ac, 1
# 5, a, [ac], 0
# Finally we can recurse on decode help with our multipler and string decodeHelp(2, '[ac]')
       
       
class Solution:
    def decodeString(self, s: str) -> str:
        return self.decodeHelp(1, f'[{s}]')
        
    def decodeHelp(self, mult, s):
#       remove [...]
        s = s[1:-1]
        outstring = ''
        i = 0
        while i < len(s):
#           if character, simply add and iterate
            if not s[i].isnumeric():
                outstring += s[i]
                i += 1
#           if not character we need to pull multiplier
#           and recursively search interior brackets
            else:
#               get multiplier
                runningMultStr = ''
                while s[i].isnumeric():
                    runningMultStr += s[i]
                    i += 1
                recurMult = int(runningMultStr)
#               get string to recurse
                recurStr = ''
#               add 1 for [ and -1 for ]
#               in order to count when we actually close
                bracketCount = 0
                firstChar = True
                while bracketCount != 0 or firstChar:
                    firstChar = False
                    if s[i] == '[':
                        bracketCount += 1
                    elif s[i] == ']':
                        bracketCount -= 1
            
                    recurStr += s[i]
                    i += 1
                recurResult = self.decodeHelp(recurMult, recurStr)
#               add to out and continue from last character
                outstring += recurResult
            
        return mult*outstring

#Method-5


class Solution(object):
    def decodeString(self, s):
        """
        :type s: str
        :rtype: str
        """
        if len(s) < 2:
            return s
        prefix, suffix = None, None
        for i in range(len(s)):
            if s[i].isdigit():
                prefix, numStart, numEnd = s[:i], i, i 
                while s[numEnd].isdigit():
                    numEnd += 1
                multiplier = int(s[numStart:numEnd])
                bracketStart, bracketEnd, cnt = numEnd, numEnd+1, 1
                while cnt > 0:
                    cnt = cnt + 1 if s[bracketEnd] == '[' else cnt - 1 if s[bracketEnd] == ']' else cnt
                    bracketEnd += 1
                suffix = "" if bracketEnd == len(s) else s[bracketEnd:]
                return prefix + multiplier * self.decodeString(s[bracketStart+1:bracketEnd-1]) + self.decodeString(suffix)
        return s


#Q4  Number of Provinces

'''
There are n cities. Some of them are connected, while some are not. If city a is connected directly with city b, and city b is connected directly with city c, then city a is connected indirectly with city c.

A province is a group of directly or indirectly connected cities and no other cities outside of the group.

You are given an n x n matrix isConnected where isConnected[i][j] = 1 if the ith city and the jth city are directly connected, and isConnected[i][j] = 0 otherwise.

Return the total number of provinces.

 

Example 1:


Input: isConnected = [[1,1,0],[1,1,0],[0,0,1]]
Output: 2
Example 2:


Input: isConnected = [[1,0,0],[0,1,0],[0,0,1]]
Output: 3
 

Constraints:

1 <= n <= 200
n == isConnected.length
n == isConnected[i].length
isConnected[i][j] is 1 or 0.
isConnected[i][i] == 1
isConnected[i][j] == isConnected[j][i]
'''
#Solution 

#Method-1
# DFS

from collections import defaultdict
class Solution:
    def findCircleNum(self, isConnected: List[List[int]]) -> int:
        n = len(isConnected)
        G = defaultdict(list)
        for i in range(n):
            for j in range(n):
                if isConnected[i][j]:
                    G[i].append(j)
        def dfs(v):
            if v in visited: return
            visited.add(v)
            for w in G[v]:
                dfs(w)
        visited = set()
        res =  0
        for v in range(n):
            if v not in visited:
                dfs(v)
                res += 1
        return res
    
    
#Method-2
class Solution:
    def findCircleNum(self, isConnected: List[List[int]]) -> int:
        length=len(isConnected)
        parent={i:i for i in range(length)}
        res = length
        
        def find(x):
            if parent[x]!=x:
                parent[x] = find(parent[x])
            return parent[x]    
    
        def union(x,y):
            r1=find(x)
            r2=find(y)
            if r1!=r2:
                parent[r1]=r2
                return 1
            return 0
        
        for i in range(length-1):
            for j in range(i+1,length):
                if isConnected[i][j]==1:
                    res-=union(i,j)
        return res

#Method-3
# dfs

class Solution:
    def findCircleNum(self, isConnected: List[List[int]]) -> int:
        numProvinces = 0
        visited = set()
        for row in range(len(isConnected)):
            for col in range(len(isConnected[row])):
                if isConnected[row][col] == 1:
                    numProvinces += 1
                    visited.add((row, col))
                    self.dfs(isConnected, row, col, visited)
        
        return numProvinces
    
    def dfs(self, isConnected, row, col, visited):
        # mark city as visited
        isConnected[row][col] = 0
        # visit the inverse city 
        if (col, row) not in visited:
            visited.add((col, row))
            self.dfs(isConnected, col, row, visited)
        
        # since the cities are inversely connected check all the cities in the row
        for c in range(len(isConnected[row])):
            if isConnected[row][c] == 1:
                if (row, c) not in visited:
                    visited.add((row, c))
                    self.dfs(isConnected, row, c, visited)

#Method-4

# using stack

# Each time stack is empty, we go through every student in the current friend cycle, and we increment ans by 1. Keep doing this until we have no student left in left.

class Solution(object):
    def findCircleNum(self, M):
        """
        :type M: List[List[int]]
        :rtype: int
        """
        ans = 0
        left = set(range(len(M)))
        while left:
            seen, stack = set(), [left.pop()]
            while stack:
                x = stack.pop()
                seen.add(x)
                stack.extend(j for j, c in enumerate(M[x]) if c \
                             and j in left and j not in seen)
            left -= seen
            ans += 1
        return ans

#Method-5

class Solution(object):
    def findCircleNum(self, M):
        p, res = [_ for _ in range(len(M))], len(M)
        def find(x):
            while x != p[x]:
                p[x] = p[p[x]]
                x = p[x]
            return x
        for i in range(len(M) - 1):
            for j in range(i + 1, len(M)):
                if M[i][j]:
                    pi, pj = find(i), find(j)
                    if pi != pj: p[pi], res = p[pj], res - 1
        return res


#Q5  Clone Graph
'''
Given a reference of a node in a connected undirected graph.

Return a deep copy (clone) of the graph.

Each node in the graph contains a value (int) and a list (List[Node]) of its neighbors.

class Node {
    public int val;
    public List<Node> neighbors;
}
 

Test case format:

For simplicity, each node's value is the same as the node's index (1-indexed). For example, the first node with val == 1, the second node with val == 2, and so on. The graph is represented in the test case using an adjacency list.

An adjacency list is a collection of unordered lists used to represent a finite graph. Each list describes the set of neighbors of a node in the graph.

The given node will always be the first node with val = 1. You must return the copy of the given node as a reference to the cloned graph.

 

Example 1:


Input: adjList = [[2,4],[1,3],[2,4],[1,3]]
Output: [[2,4],[1,3],[2,4],[1,3]]
Explanation: There are 4 nodes in the graph.
1st node (val = 1)'s neighbors are 2nd node (val = 2) and 4th node (val = 4).
2nd node (val = 2)'s neighbors are 1st node (val = 1) and 3rd node (val = 3).
3rd node (val = 3)'s neighbors are 2nd node (val = 2) and 4th node (val = 4).
4th node (val = 4)'s neighbors are 1st node (val = 1) and 3rd node (val = 3).
Example 2:


Input: adjList = [[]]
Output: [[]]
Explanation: Note that the input contains one empty list. The graph consists of only one node with val = 1 and it does not have any neighbors.
Example 3:

Input: adjList = []
Output: []
Explanation: This an empty graph, it does not have any nodes.
 

Constraints:

The number of nodes in the graph is in the range [0, 100].
1 <= Node.val <= 100
Node.val is unique for each node.
There are no repeated edges and no self-loops in the graph.
The Graph is connected and all nodes can be visited starting from the given node.
'''

#Solution 

"""
# Definition for a Node.
class Node:
    def __init__(self, val = 0, neighbors = None):
        self.val = val
        self.neighbors = neighbors if neighbors is not None else []
"""
# Method-1
# O(V + E), O(V)
# dfs
# graph-creation

class Solution:
    def cloneGraph(self, node: 'Node') -> 'Node':
        seen = {}
        
        def cloneNode(node):
            if not node:
                return
            
            if node.val in seen:
                return seen[node.val]
            
            seen[node.val] = Node(node.val)
            
            for neighbor in node.neighbors:
                seen[node.val].neighbors.append(cloneNode(neighbor))
            
            return seen[node.val]
        
        return cloneNode(node)

# Method-2

# O(V + E), O(V)
# bfs
# graph-creation

class Solution:
    def cloneGraph(self, node: 'Node') -> 'Node':
        if not node:
            return 
        
        nodes, queue = {node.val: Node(node.val)}, deque([node])

        while queue:
            current = queue.popleft()
            for neighbor in current.neighbors:
                if neighbor.val not in nodes:
                    nodes[neighbor.val] = Node(neighbor.val)
                    queue.append(neighbor)
                nodes[current.val].neighbors.append(nodes[neighbor.val])
        
        return nodes[1]

    
# Method-3
# DFS | using Hashmap

class Solution:
	def cloneGraph(self, node: 'Node') -> 'Node':
		oldToNew = {}

		def dfs(node):
			if node in oldToNew:
				return oldToNew[node]

			copy = Node(node.val)
			oldToNew[node] = copy

			for neigh in node.neighbors:
				copy.neighbors.append(dfs(neigh))
			return copy

		return dfs(node) if node else None
    
# Method-4
# Recursion
class Solution:
    def cloneGraph(self, node: 'Node') -> 'Node':
        mappings = {}
        visited = set()
        if not node:
            return 
        
        def clone(node):
            if not node:
                return
            if mappings.get(node):
                return mappings[node]
            mappings[node] = Node(node.val, [])
            for nei in node.neighbors:
                if mappings.get(nei):
                    mappings[node].neighbors.append(mappings.get(nei))
                else:
                    mappings[node].neighbors.append(clone(nei))
            return mappings[node]
        return clone(node)
    
#Method-5

# dfs + dictionary + visited set

class Solution:
    def cloneGraph(self, node: 'Node') -> 'Node':
        visited = set()
        process = [node]
        mapping = {}
        if not node:
            return node
        while process:
            cur = process.pop()
            visited.add(cur.val)
            mapping[cur] = Node(cur.val)
            for n in cur.neighbors:
                if n.val not in visited:
                    process.append(n)
        for orig in mapping:
            for n in orig.neighbors:
                mapping[orig].neighbors.append(mapping[n])
        return mapping[node]


#Q6 Shortest Bridge

'''
You are given an n x n binary matrix grid where 1 represents land and 0 represents water.

An island is a 4-directionally connected group of 1's not connected to any other 1's. There are exactly two islands in grid.

You may change 0's to 1's to connect the two islands to form one island.

Return the smallest number of 0's you must flip to connect the two islands.

 

Example 1:

Input: grid = [[0,1],[1,0]]
Output: 1
Example 2:

Input: grid = [[0,1,0],[0,0,0],[0,0,1]]
Output: 2
Example 3:

Input: grid = [[1,1,1,1,1],[1,0,0,0,1],[1,0,1,0,1],[1,0,0,0,1],[1,1,1,1,1]]
Output: 1
 

Constraints:

n == grid.length == grid[i].length
2 <= n <= 100
grid[i][j] is either 0 or 1.
There are exactly two islands in grid.


'''
#Solution

#Method-1

# flood fill + multi-source bidirectional BFS
# bfs
# flood-fill
# bidirectional
# multisouce bfs

# The idea is simple, implementation is a bit long as for py:

# As we have 2 islands, mark first found island's cells with 2.
# Prepopulate bfs queue with cells 1 and 2
# Run multi-source bfs and expand island 1 and 2 in parallel. That's why we need MS BFS here
# As soon as you find a cell of type 1 trying to connect to a cell of type 2 -> return calculated dist
# It goes in both directions, so it should be pretty fast

# How MS BFS works you can read in my other post + solve a few other problems with MS BFS.

# Source code: Runs 90%+ in TC and SC:

class Solution:
    def shortestBridge(self, grid: List[List[int]]) -> int:
        """
         [[0,2,0],
          [0,0,0],
          [0,0,1]]
        """
        
        N = len(grid)
        
        queue = deque()

		# mark first island with 2 and push 1/2 cells in bfs queue
        found_two = False
        for r in range(N):
            for c in range(N):
                if grid[r][c] == 1:
                    if not found_two:
                        grid[r][c] = 2
                        queue.append((r,c,2))
                        bfs_queue = deque([(r,c)])

                        while bfs_queue:
                            r,c = bfs_queue.popleft()

                            for dr,dc in [(1,0),(-1,0),(0,1),(0,-1)]:
                                nr, nc = r + dr, c + dc

                                if 0 <= nr < N and 0 <= nc < N and grid[nr][nc] == 1:
                                    bfs_queue.append((nr,nc))
                                    grid[nr][nc] = 2
                                    queue.append((nr,nc,2))
                        found_two = True
                    else:
                        queue.append((r,c,1))

        dist = defaultdict(int)
		# process bfs queue
        while queue:
            r,c,t = queue.popleft()
            
            for dr,dc in [(1,0),(-1,0),(0,1),(0,-1)]:
                nr, nc = r + dr, c + dc

                if 0 <= nr < N and 0 <= nc < N:
					# 0-cell means it was not occupied by 1 or 2
                    if grid[nr][nc] == 0:
                        queue.append((nr,nc,t))
                        grid[nr][nc] = t # now it is
                        dist[nr,nc] = dist[r,c] + 1
					# found connection point between 1 and 2
                    if grid[nr][nc] != t:
                        return dist[r,c] + dist[nr,nc]
        return -1


#Method-2

# dfs + bfs solution 

# bfs
# dfs

# the basic idea is to use bfs to find the shortset path from one island to another island, and use dfs to initialize the queue for bfs, dfs is to find all locations in one of the islands to be start point.

# tc is O(N^2), sc is the same as tc


from collections import deque
class Solution:
    def shortestBridge(self, grid: List[List[int]]) -> int:
        numRow, numCol = len(grid), len(grid[0])
        directions, q, visited = [[1,0], [0,1], [-1,0], [0,-1]], deque(), [[False] * numCol for _ in range(numRow)]
        putIslandToQ = False
        def dfs(i ,j, q, visited):
            q.appendleft([i,j])
            visited[i][j] = True
            for dx, dy in directions:
                nextX, nextY = i+dx, j+dy
                if nextX < 0 or nextY < 0 or nextX >= numRow or nextY >= numCol or grid[nextX][nextY] == 0 or visited[nextX][nextY]: continue
                dfs(nextX, nextY, q, visited)

        def bfs(q, visited):
            step = 0
            while q:
                for _ in range(len(q)):
                    i, j = q.pop()
                    for dx, dy in directions:
                        nextX, nextY = i+dx, j+dy
                        if nextX < 0 or nextY < 0 or nextX >= numRow or nextY >= numCol or visited[nextX][nextY]: continue
                        if grid[nextX][nextY] == 1: return step
                        q.appendleft([nextX, nextY])
                        visited[nextX][nextY] = True
                step += 1
                

        for i in range(numRow):
            if putIslandToQ: break
            for j in range(numCol):
                if grid[i][j] == 1:
                    dfs(i, j, q, visited)
                    putIslandToQ = True
                    break


        return bfs(q, visited)
    
    
#Method-3

# BFS X 2 || two queue approach


class Solution:
    def shortestBridge(self, grid: List[List[int]]) -> int:
        # find all island 1 and mark #
        visited = set()
        start_queue = deque()
        bfs_queue = deque()
        
        n = len(grid)
        
        # Find first node         
        for i, j in product(range(n), repeat=2):
            if grid[i][j] == 1:
                grid[i][j] = '#'
                start_queue.append((i, j))
                bfs_queue.append((0,i, j))
                break
        
        # Expand the first node toisland , and mark as '#' and put in bfs start nodes
        directions = [(0, 1), (1, 0), (-1, 0), (0, -1)]
        while start_queue:
            x, y = start_queue.popleft()
                
            for dx, dy in directions:
                i, j = x + dx, y + dy
                if 0 <= i < n and 0 <= y + dy < n and grid[i][j] == 1:
                    grid[i][j] = '#'
                    start_queue.append((i, j))
                    bfs_queue.append((0, i, j))
                    
        # Find the closest land
        while bfs_queue:
            dist, x, y = bfs_queue.popleft()
            for dx, dy in directions:
                i, j = x + dx, y + dy
                if 0 <= i < n and 0 <= j < n:
                    if grid[i][j] == 1:
                        return dist
                    elif grid[i][j] == 0 and (i, j) not in visited:
                        visited.add((i, j))
                        bfs_queue.append((dist + 1, i, j))
                        
#Method-4

# SPLIT ISLAND METHOD|| logic explained|| Explanation and comments


# Disclaimer: The best way to understand this logic is to copy paste my code and uncomment the portion that i have given. The Output on the console will be enough for you to understand. This post is just the walk through of my logic.

# The logic that I have used is that 1st I have created a dfs function which allows me to mark only one ISLAND. So, all of the 1's of this island are changed to 2.
# Now after this step in the entire grid the only elements are 0,1,2.
# The task is to find the distance between 2 and 1 which are nearest to each other.

# So, for this what i did next is that while making the island i stored the entire address of the island cells in i1 array and kept the distance factor 0. Now i pop the 0th index element and search in 4 directions.

# ........The possibilities are:-

# .........................1. The index doesn't exist-->that case is tackled

# .........................2. if the index does exist, it could either be 0,1,2.
# ...................................a.If it is 1 then that is our answer
# ...................................b.If it is 2 that means the current cell is actually somewhere inside the island and from this cell the distance will never be shortest hence we disregard this.
# ...................................c.If it is 0 then we are somewhere between both the islands, so to avoid comming to this square ever again we mark this as 2 and append this cell to the i1 array but in the distance part we add 1 as this is our distance that we need to travel.

# .........................3. This repeats and whn we finally find 1 we have the distance to that cell in the distance variable, d.

# If you still have doubts then pls ask in the comment section and If you like the explanation and the code pls upvote! as that will encourage me to do more such posts.


class Solution:
    def shortestBridge(self, grid: List[List[int]]) -> int:
        n=len(grid)
        
        #to print the grid current state
        #def printgrid():    
            #for i in range(n):
                #for j in range(n):
                    #print(grid[i][j],end=" ")
                #print()
            #print()
        
        # printgrid()
            
        i1=[]
        #to make a island
        def dfs(i,j):
            #print(i,j)
            if 0<=i<n and 0<=j<n and grid[i][j]==1:
                i1.append((i,j,0))
                grid[i][j]=2
                dfs(i+1,j)
                dfs(i-1,j)
                dfs(i,j+1)
                dfs(i,j-1)
                return
            return
        
        #this finds the 1st 1 and we call the dfs and the island is created
        #breaker is to make sure that we only run the dfs function once
        breaker =False
        for i in range(n):
            for j in range(n):
                if grid[i][j]:
                    dfs(i,j)
                    breaker=True
                    break
            if breaker:
                break
                
        
        # printgrid()
        # print(i1)
        
        dir=[(1,0),(-1,0),(0,1),(0,-1)]
        
        while i1:
            i,j,d=i1.pop(0)
            # print(f"i={i} j={j} d={d}")
            #base condition for the case where we find the ans
            if grid[i][j]==1:
                return d
            for dc,dr in dir:
                p,q=dr+i,dc+j
                if 0<=p<n and 0<=q<n and grid[p][q]!=2:
                    if grid[p][q]==1:
                        return d
                    grid[p][q]=2
                    i1.append((p,q,d+1))
                    # printgrid()
                    
                    
                    
#Method-5

# DFS + BFS find points on island by water


class Solution(object):
    def shortestBridge(self, A):
        """
        :type A: List[List[int]]
        :rtype: int
        """
        startIslandNum, destIslandNum = -2, -1
        coordsToStartFrom = [] #coords in island1 we'll be searching from
        visited = [[999999 for col_ in row_] for row_ in A]
        best = 420
        
        def isWithinBounds(row, col):
            return row >= 0 and col >= 0 and row < len(A) and col < len(A[0])
        
        def isByWater(i, j):
            if isWithinBounds(i + 1, j) and A[i+1][j] == 0:
                return True
            if isWithinBounds(i - 1, j) and A[i-1][j] == 0:
                return True
            if isWithinBounds(i, j+1) and A[i][j+1] == 0:
                return True
            if isWithinBounds(i, j-1) and A[i][j-1] == 0:
                return True
            return False
        
        def dfs(i, j, islandNum):
            if A[i][j] != 1:
                return
            A[i][j] = islandNum
            if islandNum == startIslandNum:
                coordsToStartFrom.append([i, j])
                
            if isWithinBounds(i + 1, j):
                dfs(i + 1, j, islandNum)
            if isWithinBounds(i - 1, j):
                dfs(i - 1, j, islandNum)
            if isWithinBounds(i, j+1):
                dfs(i, j+1, islandNum)
            if isWithinBounds(i, j-1):
                dfs(i, j-1, islandNum)
        
        def visit(row, col, temp, count):
            visited[row][col] = count
            if A[row][col] == destIslandNum:
                return True
            temp.append([row, col])
            
        islandNum = startIslandNum
        for i in range(len(A)): #mark islands
            for j in range(len(A[0])):
                if A[i][j] == 1:
                    dfs(i, j, islandNum)
                    islandNum = destIslandNum
        
            
        while coordsToStartFrom: #find shortest path from island1 to island2
            row, col = coordsToStartFrom.pop()
            if not isByWater(row, col):
                continue
            
            count = 0
            q = [[row, col]]
            while q:
                temp = []
                while q:
                    i, j = q.pop()
                        
                    if isWithinBounds(i + 1, j) and visited[i+1][j] > count and A[i+1][j] != startIslandNum:
                        if visit(i + 1, j, temp, count):
                            best = min(best, count)
                    if isWithinBounds(i - 1, j) and visited[i-1][j] > count and A[i-1][j] != startIslandNum:
                        if visit(i - 1, j, temp, count):
                            best = min(best, count)
                    if isWithinBounds(i, j+1) and visited[i][j+1] > count and A[i][j+1] != startIslandNum:
                        if visit(i, j+1, temp, count):
                            best = min(best, count)
                    if isWithinBounds(i, j-1) and visited[i][j-1] > count and A[i][j-1] != startIslandNum:
                        if visit(i, j-1, temp, count):
                            best = min(best, count)
                count += 1
                if count >= best:
                    break
                q = temp
        
        return best



#Q7 All Paths From Source to Target

'''

Given a directed acyclic graph (DAG) of n nodes labeled from 0 to n - 1, find all possible paths from node 0 to node n - 1 and return them in any order.

The graph is given as follows: graph[i] is a list of all nodes you can visit from node i (i.e., there is a directed edge from node i to node graph[i][j]).

 

Example 1:


Input: graph = [[1,2],[3],[3],[]]
Output: [[0,1,3],[0,2,3]]
Explanation: There are two paths: 0 -> 1 -> 3 and 0 -> 2 -> 3.
Example 2:


Input: graph = [[4,3,1],[3,2,4],[3],[4],[]]
Output: [[0,4],[0,3,4],[0,1,3,4],[0,1,2,3,4],[0,1,4]]
 

Constraints:

n == graph.length
2 <= n <= 15
0 <= graph[i][j] < n
graph[i][j] != i (i.e., there will be no self-loops).
All the elements of graph[i] are unique.
The input graph is guaranteed to be a DAG.

'''
#Solution 

#Method-1
# BFS

class Solution(object):
    def allPathsSourceTarget(self, graph):
        """
        :type graph: List[List[int]]
        :rtype: List[List[int]]
        """
        
        q = deque([[0]])
        n = len(graph)
        dest = n - 1
        results = []
        
        while q:
            path = q.popleft()
            node = path[-1]
            if node == dest:
                results.append(path)
            for i in graph[node]:
                new_path = path[:]
                new_path.append(i)
                q.append(new_path)
        return results
    
#Method-2

# dfs backtracking

# To find all possible ways, we need to use backtracking.
# Refer to backtracking once.

class Solution(object):
    def allPathsSourceTarget(self, graph):
        """
        :type graph: List[List[int]]
        :rtype: List[List[int]]
        """
        res=[]
        sub_paths=[0]
        def dfs(i):
            if i==len(graph)-1:                    #Reached destination
                res.append(sub_paths[:])
                return
            for p in graph[i]:                     #Going through all edges
                sub_paths.append(p)                #Adding vertex to sub paths list
                dfs(p)                             #going into further possibilities
                sub_paths.pop()                    #backtraking
        dfs(0)
        return res
    
#Method-3

# dfs
# cache

class Solution:
    def allPathsSourceTarget(self, graph: List[List[int]]) -> List[List[int]]:
        
        @cache
        def paths(cur):
            if self.firstcall:
                self.firstcall = False
            elif cur == 0:
                return []
            elif cur == self.target:
                return [[self.target]]
            
            res = []
            for nei in graph[cur]:
                for path in paths(nei):
                    res.append([cur] + path)
            return res
        
        self.target, self.firstcall = len(graph) - 1, True
        return paths(0)

#Method-4 
# dfs
# recursion

class Solution:
    def allPathsSourceTarget(self, graph: List[List[int]]) -> List[List[int]]:
        ans = []
        
        def dfs(a, path):
            if a == len(graph)-1:
                ans.append(path)
            for neighbour in graph[a]:
                dfs(neighbour,[*path, neighbour])
        dfs(0, [0])
        return ans

#Method-5
# Backtracking 

class Solution:    
    def allPathsSourceTarget(self, graph):        
        def back_tracker(target_node, this_node, graph, this_path, all_paths):
            if this_node == target_node:
                all_paths.append(this_path)
                return
            if graph[this_node] is None:
                return
            for node in graph[this_node]:
                back_tracker(target_node, node, graph, this_path + [node], all_paths)
        
        this_node, target_node = 0, len(graph)-1
        this_path, all_paths = [0], []
        
        back_tracker(target_node, this_node, graph, this_path, all_paths)
        return all_paths


#Q8. Surrounded Regions

'''
Given an m x n matrix board containing 'X' and 'O', capture all regions that are 4-directionally surrounded by 'X'.

A region is captured by flipping all 'O's into 'X's in that surrounded region.

 

Example 1:


Input: board = [["X","X","X","X"],["X","O","O","X"],["X","X","O","X"],["X","O","X","X"]]
Output: [["X","X","X","X"],["X","X","X","X"],["X","X","X","X"],["X","O","X","X"]]
Explanation: Notice that an 'O' should not be flipped if:
- It is on the border, or
- It is adjacent to an 'O' that should not be flipped.
The bottom 'O' is on the border, so it is not flipped.
The other three 'O' form a surrounded region, so they are flipped.
Example 2:

Input: board = [["X"]]
Output: [["X"]]
 

Constraints:

m == board.length
n == board[i].length
1 <= m, n <= 200
board[i][j] is 'X' or 'O'.

'''
#Solution 

#Method-1

# DFS, SET

class Solution:
    def solve(self, board: List[List[str]]) -> None:
        """
        Do not return anything, modify board in-place instead.
        """
        visit = set()
        def dfs(r, c):
            if r >= 0  and c >= 0 and r < len(board) and c < len(board[0]) and (r, c) not in visit and board[r][c] == "O":
                visit.add((r, c))
                dfs(r + 1, c)
                dfs(r - 1, c)
                dfs(r, c + 1)
                dfs(r, c - 1)
        for r in range(len(board)):
            for c in range(len(board[0])):
                if (r == 0 or c == 0 or r == len(board)-1 or c == len(board[0])-1) and board[r][c] == "O":
                    dfs(r, c)
        for r in range(len(board)):
            for c in range(len(board[0])):
                board[r][c] = "X"
        for r,c in visit:
            board[r][c] = "O"
        return board
    
    
#Method-2

# using both BFS & DFS


class Solution:
    def solve(self, board: List[List[str]]) -> None:
        """
        Do not return anything, modify board in-place instead.
        """
        q = collections.deque()
        
        def BFS(r, c):
            if r in range(rows) and c in range(cols) and board[r][c] == "O":
                q.append((r, c))
            while q:
                qr, qc = q.popleft()
                board[qr][qc] = "T"
                directions = [[0,1], [0, -1], [1, 0], [-1, 0]]
                for (dr, dc) in directions:
                    nr, nc = dr+r, dc+c
                    BFS(nr, nc)
                
        
        def DFS(r, c):
            print (r, c)
            if r not in range(rows) or c not in range(cols) or board[r][c] != "O":
                return             
            board[r][c] = "T"            
            directions = [[0,1], [0, -1], [1, 0], [-1, 0]]
            for (dr, dc) in directions:
                nr, nc = dr+r, dc+c
                DFS(nr, nc)
        
        rows = len(board)
        cols = len(board[0])
        for r in range(rows):
            for c in range(cols):
                if (r in [0, rows-1] or c in [0, cols-1]) and board[r][c] == "O":
                    #DFS(r, c) #BY USING DFS
                    BFS(r, c) #BY USING BFS
        
        for r in range(rows):
            for c in range(cols):
                if board[r][c] == "O":
                    board[r][c] = "X"
                if board[r][c] == "T":
                    board[r][c] = "O"
                    
#Method-3

# DFS Understandable solution

# This Approach starts by checking from edges, after checking for edges they are marked differently and later on it is used to solve the surrounded problem

class Solution:
    def dfs(self,board,i,j):
        board[i][j]='y'
        for a,b in ((i-1,j),(i+1,j),(i,j-1),(i,j+1)):
            if a>=len(board) or b>=len(board[0]) or a<0 or b<0:
                continue
            if board[a][b]=='O':
                self.dfs(board,a,b)
    def solve(self, board: List[List[str]]) -> None:
        """
        Do not return anything, modify board in-place instead.
        """
        for i in range(len(board[0])):
            if board[0][i]=='O':
                self.dfs(board,0,i)
        for i in range(len(board)):
            if board[i][len(board[0])-1]=='O':
                self.dfs(board,i,len(board[0])-1)
        for i in range(len(board[0])):
            if board[len(board)-1][i]=='O':
                self.dfs(board,len(board)-1,i)
        for i in range(len(board)):
            if board[i][0]=='O':
                self.dfs(board,i,0)
        for i in range(len(board)):
            for j in range(len(board[0])):
                if board[i][j]=='O':
                    board[i][j]='X'
                elif board[i][j]=='y':
                    board[i][j]='O'

                    
                    
                    
# Method-4

# BFS O(MN) solution

# Instead of finding the enclosed regions, think the other way around. The non enclosed "O" regions must have an outlet into the borders.
# Start scanning the borders (4 borders). As soon as you find a "O", initiate a BFS and mark the relevant component with a new letter "b". A component here comprises of all connected "O".
# After this scan, all the remainder "O" are infact the surrounded regions.
# Run a loop and mark "O" as "X" and "b" as "O".


class Solution(object):
    def explore_top_bottom(self, board):
        M, N = len(board), len(board[0])
        for i in [0,M-1]:
            for j in range(N):
                if board[i][j] == "O":
                    self.explore(i,j,board)
        return
    
    def explore_left_right(self, board):
        M, N = len(board), len(board[0])
        for i in range(M):
            for j in [0,N-1]:
                if board[i][j] == "O":
                    self.explore(i,j,board)
        return    
    
    def solve(self, board):
        """
        :type board: List[List[str]]
        :rtype: void Do not return anything, modify board in-place instead.
        """
        if board == []:
            return
        M, N = len(board), len(board[0])
        self.explore_top_bottom(board)
        self.explore_left_right(board)
        for i in range(M):
            for j in range(N):
                if board[i][j] == "O":
                    board[i][j] = "X"
                if board[i][j] == "b":
                    board[i][j] = "O"
        return
    
    def explore(self, i, j, board):
        M, N = len(board), len(board[0])
        q = deque()
        q.append((i,j))
        board[i][j] = "b"
        while len(q):
            x,y = q.popleft()
            for a,b in ((x+1,y), (x-1,y), (x,y+1), (x,y-1)):
                if 0<=a<M and 0<=b<N and board[a][b] == "O":
                    board[a][b] = "b"
                    q.append((a,b))
        return
    
    
#Method-5

# save path in a set

# Similar to number of island (200) but except we don't search the most outer layer.

# Note I use path set, but at most, the path size is the board, so space complexity is O(row * col)

class Solution:
    def solve(self, board: List[List[str]]) -> None:
        """
        Do not return anything, modify board in-place instead.
        """
        
        def clean_path(path):
            for row, col in path:
                board[row][col] = 'X'
        
        def dfs(row, col, path):
            if row == 0 or row == len(board)-1 or col == 0 or col == len(board[0]) - 1:
                if board[row][col] == 'O':
                    return False
                else:
                    return True
            
            if board[row][col] == 'X':
                return True
            
            if (row, col) in path:
                return True
            path.add((row, col))
            return dfs(row-1, col, path) and dfs(row+1, col, path) and dfs(row, col+1, path) and dfs(row, col-1, path)
            
        for i in range(1, len(board)-1):
            for j in range(1, len(board[0])-1):
                if board[i][j] == 'O':
                    path = set()
                    if dfs(i, j, path):
                        clean_path(path)
        return board

    
#Q9 House Robber III

'''
The thief has found himself a new place for his thievery again. There is only one entrance to this area, called root.

Besides the root, each house has one and only one parent house. After a tour, the smart thief realized that all houses in this place form a binary tree. It will automatically contact the police if two directly-linked houses were broken into on the same night.

Given the root of the binary tree, return the maximum amount of money the thief can rob without alerting the police.

 

Example 1:


Input: root = [3,2,3,null,3,null,1]
Output: 7
Explanation: Maximum amount of money the thief can rob = 3 + 3 + 1 = 7.
Example 2:


Input: root = [3,4,5,1,3,null,1]
Output: 9
Explanation: Maximum amount of money the thief can rob = 4 + 5 = 9.
 

Constraints:

The number of nodes in the tree is in the range [1, 104].
0 <= Node.val <= 104

'''

#Solution 


# Definition for a binary tree node.
# class TreeNode:
#     def __init__(self, val=0, left=None, right=None):
#         self.val = val
#         self.left = left
#         self.right = right

#Method-1

# (DFS)

class Solution:
    def rob(self, root: Optional[TreeNode]) -> int:
        
        # returns values of pair: [withroot, withoutroot]
        def dfs(root):
            if not root:
                return [0, 0]
            
            left_pair = dfs(root.left)
            right_pair = dfs(root.right)
            
            # if the root value is included then we cannot include next root val
            with_root = root.val + left_pair[1] + right_pair[1]
            without_root = max(left_pair) + max(right_pair)
            
            return [with_root, without_root]
        
        return max(dfs(root))
    
      
#Method-2

# Concise code - LRU_CACHE

# Definition for a binary tree node.
# class TreeNode:
#     def __init__(self, val=0, left=None, right=None):
#         self.val = val
#         self.left = left
#         self.right = right

class Solution:
    def rob(self, root: Optional[TreeNode]) -> int:
        
        @lru_cache(None)
        def rob(node, parent_taken):
            if not node:
                return 0
            if parent_taken:
                return rob(node.left, False) + rob(node.right, False) 
            else:
                return max(
                    rob(node.left, True) + node.val +  rob(node.right, True),
                    rob(node.left, False) + rob(node.right, False) 
                )
                
        return max(rob(root, False), rob(root, True))

#Method-3
# DP

class Solution:
    def rob(self, root: Optional[TreeNode]) -> int:
        mp={}
        def dp(root):
            if root in mp:
                return mp[root]
            if not root:
                return 0
            if not root.left and not root.right:
                return root.val
            res1 = dp(root.left)+dp(root.right)
            res2 = root.val
            if root.left:
                res2+=dp(root.left.left)+dp(root.left.right)
            if root.right:
                res2+=dp(root.right.left)+dp(root.right.right)
            mp[root]=max(res1,res2)
            return mp[root]
        return dp(root)


#Method-4

# Recursion + Memoization 


# Definition for a binary tree node.
# class TreeNode:
#     def __init__(self, val=0, left=None, right=None):
#         self.val = val
#         self.left = left
#         self.right = right
class Solution:
    def rob(self, root: Optional[TreeNode]) -> int:
        def solve(root):
            if not root:
                return 0

            if not root.left and not root.right:
                return root.val
            
            if root in dp:
                return dp[root]
            
            inc = root.val

            if root.left:
                inc+=solve(root.left.left)+solve(root.left.right)

            if root.right:
                inc+=solve(root.right.left) + solve(root.right.right)

            exc = 0

            if root.left:
                exc+=solve(root.left)

            if root.right:
                exc+=solve(root.right)
            
            dp[root] = max(inc, exc)
            
            return dp[root]
        
        dp = defaultdict()
        
        return solve(root)
    
#Method-5

# The idea is very simple and it's my first sharing. For each node, we record the maximum benefits of robbing it or not separately, [not rob, rob]. Consider the current node, if you decide to rob it, you cannot rob its direct children, thus, you can obtain root.val+left[not rob]+right[not rob]; while if you decide not to rob it, it doesn't matter whether you rob or not rob its children, so just find the maximum values from the children, thus you obtain max(left[rob], left[not rob])+max(right[rob], right[not rob]). Finally, return the maximum value. 


class Solution(object):
    def rob(self, root):
        """
        :type root: TreeNode
        :rtype: int
        """
        return max(self.helper(root))
    def helper(self, root):
        if root is None: 
            return (0,0)
        lc=self.helper(root.left)
        rc=self.helper(root.right)
        return (max(lc)+max(rc), root.val+lc[0]+rc[0])


#Q10 Critical Connections in a Network

'''

There are n servers numbered from 0 to n - 1 connected by undirected server-to-server connections forming a network where connections[i] = [ai, bi] represents a connection between servers ai and bi. Any server can reach other servers directly or indirectly through the network.

A critical connection is a connection that, if removed, will make some servers unable to reach some other server.

Return all critical connections in the network in any order.

 

Example 1:


Input: n = 4, connections = [[0,1],[1,2],[2,0],[1,3]]
Output: [[1,3]]
Explanation: [[3,1]] is also accepted.
Example 2:

Input: n = 2, connections = [[0,1]]
Output: [[0,1]]
 

Constraints:

2 <= n <= 105
n - 1 <= connections.length <= 105
0 <= ai, bi <= n - 1
ai != bi
There are no repeated connections.

'''
#Solution 

#Method-1

# DFS bridge finder

class Solution(object):
    def criticalConnections(self, n, nodes):
        graph = defaultdict(list)
        for u,v in nodes:
            graph[u].append(v)
            graph[v].append(u)

        intime = {}
        lowtime = {}
        visited = set()
        timer = 1
        ans = []
        def dfs(graph, node, visited, intime, lowtime, parent,timer):
            intime[node] = timer
            lowtime[node] = timer
            timer+=1
            visited.add(node)
            for child in graph[node]:
                if not child in visited:
                    dfs(graph, child, visited, intime, lowtime, node,timer)
                    ## checking for bridge during backtracking
                    if intime[node] < lowtime[child]:
                        ans.append([node,child])

                    lowtime[node] = min(lowtime[child], lowtime[node])

                else:
                    # update the low time 
                    if child!= parent:
                        lowtime[node] = min(intime[child], lowtime[node])
        dfs(graph, list(graph.keys())[0], visited, intime, lowtime, -1,timer)
        return ans
    

#Method-2

# Tarjan's Bridge Algo 


class Solution:
    def criticalConnections(self, n: int, connections: List[List[int]]) -> List[List[int]]:
        def dfs(node, parent):
            nonlocal timer
            timer+=1
            
            tin[node] = timer
            low[node] = timer
            
            visited.add(node)
            
            for nei in graph[node]:
                if nei == parent:
                    continue
                    
                if nei not in visited:
                    dfs(nei, node)
                    low[node] = min(low[node], low[nei])
                    
                    if low[nei] > tin[node]:
                        res.append([node, nei])
                else:
                    low[node] = min(low[node], tin[nei])
                        
            
        timer = 0
        low = {}
        tin = {}
        
        graph = defaultdict(list)
        
        visited = set()
        res = []
        
        for u,v in connections:
            graph[u].append(v)
            graph[v].append(u)
            
        for i in range(n):
            if i not in visited:
                dfs(i, -1)
                
        return res
    
    
#Method-3

# dfs

class Solution:
    def criticalConnections(self, n: int, connections: List[List[int]]) -> List[List[int]]:
        adj = {i:[] for i in range(n)}
        for u, v in connections:
            adj[u].append(v)
            adj[v].append(u)
        
        tin = [0]*n
        low = [0]*n
        vis = [0]*n
        ans = []
        def dfs(node, parent, timer):
            vis[node] = 1
            tin[node] = low[node] = timer
            
            timer += 1
            
            for neigh in adj[node]:
                if neigh == parent:
                    continue
                if vis[neigh] == 0:
                    dfs(neigh, node, timer)
                    
                    low[node]  = min(low[node], low[neigh])
                    
                    if low[neigh] > tin[node]:
                        ans.append([neigh, node])
                else:
                    low[node] = min(low[node], tin[neigh])
        timer = 0
        for i in range(n):
            if vis[i] == 0:
                dfs(i, -1, timer)
        return ans

#Method-4

from collections import defaultdict

class Solution:
    def criticalConnections(self, n: int, connections: List[List[int]]) -> List[List[int]]:
        self.rank = {}
        self.edges = defaultdict(list)
        for a, b in connections:
            self.edges[a].append(b)
            self.edges[b].append(a)
        
        self.res = []
        self.dfs(0, 0, 0)
        return self.res
        
    def dfs(self, node, prev_node, order):
        self.rank[node] = order
        
        for nxt in self.edges[node]:
            if nxt == prev_node:
                continue
            if nxt not in self.rank:
                self.rank[nxt] = self.rank[node] + 1
                child_rank = self.dfs(nxt, node, order + 1)
            else:
                child_rank = self.rank[nxt]
            
            if child_rank > order:
                self.res.append([node, nxt])
            self.rank[node] = min(self.rank[node], child_rank)
        
        return self.rank[node]

#Method-5

# We know that an articulated edge is an edge that sits outside of a cycle.

# From this, we can create a DFS spanning tree, and we know that whenever a child can reach a higher distance node (or equal) to parent via a backedge, we have a cycle detected.
# Therefore, let's negate that statement, if the lowest node a child can hit is smaller than parent distance node, we couldn't find a cycle on that path. Hence it's a critical connection

# Code:

class Solution:
    def criticalConnections(self, n: int, connections: List[List[int]]) -> List[List[int]]:
        if not connections: return None
        graph = defaultdict(list)
        distances = {}
        visited = set([0])
        critical_connections = list()
        
        def dfs(node, parent, distance):
            cur_distance = distance
            distances[node] = distance
            lowest_reach = distance
            
            for neighbor in graph[node]:
                if neighbor not in visited:
                    visited.add(neighbor)
                    lowest, distance = dfs(neighbor, node, distance + 1)
                    if lowest > cur_distance:
                        critical_connections.append((node, neighbor))
                        
                    lowest_reach = min(lowest_reach, lowest)
                
                elif neighbor != parent:
                    lowest_reach = min(lowest_reach, distances[neighbor])

            return (lowest_reach, distance)
        
        for u, v in connections:
            graph[u].append(v)
            graph[v].append(u)
        
        dfs(0, None, 1)
        return critical_connections

#Q11. Remove Invalid Parentheses

'''
Given a string s that contains parentheses and letters, remove the minimum number of invalid parentheses to make the input string valid.

Return all the possible results. You may return the answer in any order.

 

Example 1:

Input: s = "()())()"
Output: ["(())()","()()()"]
Example 2:

Input: s = "(a)())()"
Output: ["(a())()","(a)()()"]
Example 3:

Input: s = ")("
Output: [""]
 

Constraints:

1 <= s.length <= 25
s consists of lowercase English letters and parentheses '(' and ')'.
There will be at most 20 parentheses in s.

'''

#Solution

#Method-1

# Backtracking

class Solution(object):

    def __init__(self):
        self.valid_expressions = None
        self.min_removed = None

    def reset(self):
        self.valid_expressions = set()
        self.min_removed = float("inf")

    """
        string: The original string we are recursing on.
        index: current index in the original string.
        left: number of left parentheses till now.
        right: number of right parentheses till now.
        ans: the resulting expression in this particular recursion.
        ignored: number of parentheses ignored in this particular recursion.
    """
    def remaining(self, string, index, left_count, right_count, expr, rem_count):
        # If we have reached the end of string.
        if index == len(string):

            # If the current expression is valid. The only scenario where it can be
            # invalid here is if left > right. The other way around we handled early on in the recursion.
            if left_count == right_count:

                if rem_count <= self.min_removed:
                    # This is the resulting expression.
                    # Strings are immutable in Python so we move around a list in the recursion
                    # and eventually join to get the final string.
                    possible_ans = "".join(expr)

                    # If the current count of brackets removed < current minimum, ignore
                    # previous answers and update the current minimum count.
                    if rem_count < self.min_removed:
                        self.valid_expressions = set()
                        self.min_removed = rem_count

                    self.valid_expressions.add(possible_ans)    
        else:        

            current_char = string[index]

            # If the current character is not a parenthesis, just recurse one step ahead.
            if current_char != '(' and  current_char != ')':
                expr.append(current_char)
                self.remaining(string, index + 1, left_count, right_count, expr, rem_count)
                expr.pop()
            else:
                # Else, one recursion is with ignoring the current character.
                # So, we increment the ignored counter and leave the left and right untouched.
                self.remaining(string, index + 1, left_count, right_count, expr, rem_count + 1)

                expr.append(current_char)

                # If the current parenthesis is an opening bracket, we consider it
                # and increment left and  move forward
                if string[index] == '(':
                    self.remaining(string, index + 1, left_count + 1, right_count, expr, rem_count)
                elif right_count < left_count:
                    # If the current parenthesis is a closing bracket, we consider it only if we
                    # have more number of opening brackets and increment right and move forward.
                    self.remaining(string, index + 1, left_count, right_count + 1, expr, rem_count)

                expr.pop()

    def removeInvalidParentheses(self, s):
        """
        :type s: str
        :rtype: List[str]
        """

        # Reset the class level variables that we use for every test case.
        self.reset()

        # Recursive call
        self.remaining(s, 0, 0, 0, [], 0)
        return list(self.valid_expressions)
    
    
#Method-2

class Solution:
    def removeInvalidParentheses(self, s):
        """
        :type s: str
        :rtype: List[str]
        """

        left = 0
        right = 0

        # First, we find out the number of misplaced left and right parentheses.
        for char in s:

            # Simply record the left one.
            if char == '(':
                left += 1
            elif char == ')':
                # If we don't have a matching left, then this is a misplaced right, record it.
                right = right + 1 if left == 0 else right

                # Decrement count of left parentheses because we have found a right
                # which CAN be a matching one for a left.
                left = left - 1 if left > 0 else left

        result = {}
        def recurse(s, index, left_count, right_count, left_rem, right_rem, expr):
            # If we reached the end of the string, just check if the resulting expression is
            # valid or not and also if we have removed the total number of left and right
            # parentheses that we should have removed.
            if index == len(s):
                if left_rem == 0 and right_rem == 0:
                    ans = "".join(expr)
                    result[ans] = 1
            else:

                # The discard case. Note that here we have our pruning condition.
                # We don't recurse if the remaining count for that parenthesis is == 0.
                if (s[index] == '(' and left_rem > 0) or (s[index] == ')' and right_rem > 0):
                    recurse(s, index + 1,
                            left_count,
                            right_count,
                            left_rem - (s[index] == '('),
                            right_rem - (s[index] == ')'), expr)

                expr.append(s[index])    

                # Simply recurse one step further if the current character is not a parenthesis.
                if s[index] != '(' and s[index] != ')':
                    recurse(s, index + 1,
                            left_count,
                            right_count,
                            left_rem,
                            right_rem, expr)
                elif s[index] == '(':
                    # Consider an opening bracket.
                    recurse(s, index + 1,
                            left_count + 1,
                            right_count,
                            left_rem,
                            right_rem, expr)
                elif s[index] == ')' and left_count > right_count:
                    # Consider a closing bracket.
                    recurse(s, index + 1,
                            left_count,
                            right_count + 1,
                            left_rem,
                            right_rem, expr)

                # Pop for backtracking.
                expr.pop()                 

        # Now, the left and right variables tell us the number of misplaced left and
        # right parentheses and that greatly helps pruning the recursion.
        recurse(s, 0, 0, 0, left, right, [])     
        return list(result.keys())
    
    
#Method-3

class Solution:
    def removeInvalidParentheses(self, s: str) -> List[str]:
        if not s: return ['']
        cur_set = set([('', 0, 0)])  #string, counter, removed
        for i, char in enumerate(s):
            new_set = set()
            for cand, count, removed in cur_set:
                if char not in '()':
                    new_set.add((cand+char, count, removed))
                else:
                    new_set.add((cand, count, removed+1)) # remove
                    if (char =='(') and (count+1 < len(s)-i):
                        new_set.add((cand+char, count+1, removed))
                    if char == ')' and count>0:
                        new_set.add((cand+char, count-1, removed))

            if not new_set: return ['']
            cur_set = new_set
            
        # now we have set with some count = 0 but different removed count, pick the best

        ans = []
        min_removed = float('inf')
        for cand, count, removed in cur_set:
            if count > 0: continue
            if removed <= min_removed:
                if removed < min_removed: 
                    min_removed = removed
                    ans = []
                ans.append(cand)

        return ans
    
#Method-4 dfs 
class Solution(object):
    def removeInvalidParentheses(self, s):
        """
        :type s: str
        :rtype: List[str]
        """
        memo = set()
        def dfs(index,left,right,path,res):
            memo.add((path,index))
            if left == right:
                res.append(path)
            if index >= len(s):
                return 
            if left < right:
                return
            for i in range(index+1, len(s)):
                if (path,i) not in memo:
                    if s[i] == '(':
                        dfs(i,left+1,right,path+'(',res)
                    elif s[i] == ')':
                        dfs(i,left,right+1,path+')',res)
                    else:
                        dfs(i,left,right,path+s[i],res)
        index = -1
        left = 0
        right = 0
        path = ''
        res = []
        dfs(index,left,right,path,res)
        ans = set()
        maxl = 0
        for s in res:
            l = len(s)
            if l > maxl:
                ans = {s}
                print(ans)
                maxl = l
            elif l == maxl:
                ans.add(s)
        return list(ans)


#Method-5 

# straightforward DFS

class Solution:
    def removeInvalidParentheses(self, s: str) -> List[str]:
        self.res = set()
        self.min_cost = math.inf
        n = len(s)
        def dfs(i, path, left, cost):
            if cost > self.min_cost:
                return
            if i == n and left > 0:
                return
            elif i == n and left == 0:
                if cost < self.min_cost:
                    self.min_cost = cost
                    self.res = set()
                    self.res.add(str(path))
                    return
                elif cost == self.min_cost:
                    self.res.add(str(path))
                    return
            # i != n cuz left < 0 and i == n would never happen
            c = s[i] 
            
            if c not in ["(", ")"]:
                path = path + c
                dfs(i + 1, path, left, cost)
                path = path[:-1]
            elif c == "(":
                # put in
                path = path + c
                dfs(i + 1, path, left + 1, cost)
                path = path[:-1]
                dfs(i + 1, path, left, cost + 1)
            else:
                if left == 0:
                    dfs(i + 1, path, left, cost + 1)
                else:
                    path = path + c
                    dfs(i + 1, path, left - 1, cost)
                    path = path[:-1]
                    dfs(i + 1, path, left, cost + 1)
        dfs(0, "", 0, 0)
        return list(self.res)


#Q12  Longest Increasing Path in a Matrix

'''
Given an m x n integers matrix, return the length of the longest increasing path in matrix.

From each cell, you can either move in four directions: left, right, up, or down. You may not move diagonally or move outside the boundary (i.e., wrap-around is not allowed).

 

Example 1:


Input: matrix = [[9,9,4],[6,6,8],[2,1,1]]
Output: 4
Explanation: The longest increasing path is [1, 2, 6, 9].
Example 2:


Input: matrix = [[3,4,5],[3,2,6],[2,2,1]]
Output: 4
Explanation: The longest increasing path is [3, 4, 5, 6]. Moving diagonally is not allowed.
Example 3:

Input: matrix = [[1]]
Output: 1
 

Constraints:

m == matrix.length
n == matrix[i].length
1 <= m, n <= 200
0 <= matrix[i][j] <= 231 - 1

'''
#Solution 

# Method-1
# DFS+Memoization 

class Solution:
    def longestIncreasingPath(self, nums: List[List[int]]) -> int:
        def dfs(i,j,x,y):
            if i<0 or i>=M or j<0 or j>=N:
                return 0
            
            if (i,j) in visited:
                return dp[i][j]
            
            visited.add((i,j))
            
            res = 0
            
            for dx, dy in directions:
                if 0<=dx+i<M and 0<=dy+j<N and nums[dx+i][dy+j] > nums[i][j]:
                    res = max(res, dfs(dx+i, dy+j, i, j))
            
            dp[i][j] = max(res+1, dp[i][j])
            
            return dp[i][j]
        
        
        M,N = len(nums), len(nums[0])
        directions = [(-1,0), (1,0), (0,-1), (0,1)]
        visited = set()
        
        res = float("-inf")
        
        dp = [[1 for _ in range(N)] for _ in range(M)]
        
        for i in range(M):
            for j in range(N):
                result = dfs(i,j,i,j)
                
                res = max(res, result)
                
        return res
    
#Method-2
# dynamic programming
# recursion
# memoization
# dp

class Solution:
    def solve(self, i, j, m, n, mat, vis, dp):
        if i >= m or j >= n or i < 0 or j < 0:
            return 0
        
        if dp[i][j] != -1:
            return dp[i][j]
        
        vis[i][j] = True
        down, up, left, right = 0, 0, 0, 0
        if i+1 < m and not vis[i+1][j] and mat[i+1][j] > mat[i][j]:
            down = self.solve(i+1, j, m, n, mat, vis, dp)
            
        if j+1 < n and not vis[i][j+1] and mat[i][j+1] > mat[i][j]:
            right = self.solve(i, j+1, m, n, mat, vis, dp)
            
        if i > 0 and not vis[i-1][j] and mat[i-1][j] > mat[i][j]:
            up = self.solve(i-1, j, m, n, mat, vis, dp)
            
        if j > 0 and not vis[i][j-1] and mat[i][j-1] > mat[i][j]:
            left = self.solve(i, j-1, m, n, mat, vis, dp)
        
        vis[i][j] = False
        
        dp[i][j] = max(up, down, left, right) + 1
        return dp[i][j]
        
        
    def longestIncreasingPath(self, matrix: List[List[int]]) -> int:
        ans = 0
        m, n = len(matrix), len(matrix[0])
        vis = [[False]*n for i in range(m)]
        dp = [[-1]*n for i in range(m)]
        
        for i in range(m):
            for j in range(n):
                ans = max(ans, self.solve(i, j, m, n, matrix, vis, dp))
        
        return ans
        
		
#Method-3

# DFS+memo

# dfs
# toposort
# memoization
# khans algorithm

class Solution:
    def longestIncreasingPath(self, matrix: List[List[int]]) -> int:
        ROWS, COLS = len(matrix), len(matrix[0])
        @cache
        def dfs(r,c):
            max_len = 1
            for dr,dc in [(1,0),(-1,0),(0,1),(0,-1)]:
                nr,nc = r + dr, c + dc

                if 0 <= nr < ROWS and 0 <= nc < COLS and matrix[nr][nc] > matrix[r][c]:
                    max_len = max(max_len, 1 + dfs(nr,nc))
            
            return max_len
        
        max_len = 1
        for r in range(ROWS):
            for c in range(COLS):
                max_len = max(max_len, dfs(r,c))
        
        return max_len

    
#Method-4
# This is DAG.
# Here we construct indegrees for all nodes like [6] -> [9] (in: 0 out: 1), [6] -> [8] and etc
# Push nodes with 0-indegree to a queue.
# Remove 1st nodes layer, then remove the next layer and so on.
# Count removed leyers.

# dfs
# toposort
# memoization
# khans algorithm

class Solution:
    def longestIncreasingPath(self, matrix: List[List[int]]) -> int:
        ROWS, COLS = len(matrix), len(matrix[0])
        
        indegrees = [[0] * COLS for _ in range(ROWS)]

        for r in range(ROWS):
            for c in range(COLS):
                for dr,dc in [(0,1),(0,-1),(1,0),(-1,0)]:
                    nr,nc = r + dr, c + dc
                    if 0 <= nr < ROWS and 0 <= nc < COLS and matrix[r][c] < matrix[nr][nc]:
                        indegrees[r][c] += 1

        leaves = deque()
        for r in range(ROWS):
            for c in range(COLS):
                if indegrees[r][c] == 0:
                    leaves.append((r,c))
        
        height = 0
        while leaves:
            for _ in range(len(leaves)):
                r,c = leaves.popleft()
                for dr,dc in [(0,1),(0,-1),(1,0),(-1,0)]:
                    nr,nc = r + dr, c + dc
                    if 0 <= nr < ROWS and 0 <= nc < COLS and matrix[r][c] > matrix[nr][nc]:
                        indegrees[nr][nc] -= 1
                        if indegrees[nr][nc] == 0:
                            leaves.append((nr,nc))
            height += 1
        
        return height


#Method-5

# dfs
# cache
# dp

class Solution:
	def longestIncreasingPath(self, matrix: List[List[int]]) -> int:
		ans = 0
		m = len(matrix)
		n = len(matrix[0])

		def invalid(i,j):
			return i <0 or j<0 or i==m or j == n
		@lru_cache(None)
		def dfs(i,j,p):
			if invalid(i,j):
				return 0
			if matrix[i][j] <= p:
				return 0
			c = matrix[i][j]
			return 1+ max(dfs(i+1,j,c),dfs(i-1,j,c),dfs(i,j+1,c),dfs(i,j-1,c))


		visited = set()
		heap = []
		for i in range(m):
			for j in range(n):
				heap.append([i,j])
		heap = sorted(heap, key=lambda x: matrix[x[0]][x[1]])

		for i,j in heap:
			if (i,j) not in visited:
				ans = max(ans,dfs(i,j,-math.inf))

		return ans

#Q13. Concatenated Words

'''

Given an array of strings words (without duplicates), return all the concatenated words in the given list of words.

A concatenated word is defined as a string that is comprised entirely of at least two shorter words in the given array.

 

Example 1:

Input: words = ["cat","cats","catsdogcats","dog","dogcatsdog","hippopotamuses","rat","ratcatdogcat"]
Output: ["catsdogcats","dogcatsdog","ratcatdogcat"]
Explanation: "catsdogcats" can be concatenated by "cats", "dog" and "cats"; 
"dogcatsdog" can be concatenated by "dog", "cats" and "dog"; 
"ratcatdogcat" can be concatenated by "rat", "cat", "dog" and "cat".
Example 2:

Input: words = ["cat","dog","catdog"]
Output: ["catdog"]
 

Constraints:

1 <= words.length <= 104
1 <= words[i].length <= 30
words[i] consists of only lowercase English letters.
All the strings of words are unique.
1 <= sum(words[i].length) <= 105

'''
#Solution

#Method-1

# top-down dp
# dfs
# dynamic prpgramming

# Let N be the maximum length of a single word, M be the length of words list (total number of words)
# Time complexity O(M * N^3) where N is the maximum length of a single word. Space complexity: maximum recursion depth O(N), we need a memo for each word, so total space complexity O(N + MN) = O(MN)

class Solution:
    def findAllConcatenatedWordsInADict(self, words: List[str]) -> List[str]:
        hashset = set(words)
        
        # dp[i] represents whether word can be constructed from words (at least two)
        def dp(word, i, memo):
            nonlocal hashset
            if i == len(word):
                return True
            if memo[i] != 'Unknown':
                return memo[i]
            
            for j in range(i, len(word)):
                # Check whether the prefix word[i:j+1] is in the words list
                if word[i:j+1] in hashset and (i, j+1) != (0, len(word)):
                    # A common prefix is found, check memo
                    if dp(word, j+1, memo):
                        memo[i] = True
                        return memo[i]
                    # Otherwise check the next word
                    
            memo[i] = False
            return memo[i]
        
        res = []
        # Construct a memo for each word
        for word in words:
            memo = ['Unknown'] * len(word)
            if dp(word, 0, memo):
                res.append(word)
        return res

#Method-2
# wordbreak

class Solution:
     def findAllConcatenatedWordsInADict(self, words: List[str]) -> List[str]:
        
        visited_set = set()
        
        count = 0
        
        for w in words:
            visited_set.add(w)
        
        
    
        def find_word(s, word, words, count, ans):
            
            if s == "":
                if count > 1:
                    ans.append(word)
                return True
            
            flag = False
            
            for i in range(len(s)):
                
                if s[0:i+1] in words:
                    flag |= find_word(s[i+1:], word, words, count+1, ans)
            
            return flag
        
        
        ans = []
        
        for word in words:
            isfound = find_word(word, word, visited_set, count, ans)

        return set(ans)


#Method-3
# dfs
# trie

# Brute force solution to this problem: For each word in the word list, we check if it is a concatenated word or not.
# Say we have words = ["abcd", "ab", "cd"], and we want to check if "abcd" is a concatenated word.
# In the worst case, we need to find all possible substring of a, and there are n^2 of them. We need to do this for each word in words, and then we need to check if each of them is in the "words" list, and the time complexity of that is O(n^4). According to the input size we are given, this will obviously generate the TLE.

# How to speed up the querying speed of checking if a word can be concatened by words of smaller length? The answer is using a Trie. For checking if a word is in a Trie, the time complexity is at worst O(n), where n is the length of the word.

# Before adding words to trie, I sort the list "words" given to us. Why? Becuase the longer words must be formed by the shorter words, but shorter words can not be formed by longer words.

# What words do we need to to add to Trie? Think about another case words = ["a", "b", "ab", "abab"]. When we are processing the "ab", do we need to add it to Trie to increase the time complexity by O(n)? The answer is no. You may notice that "abab" is concatened by "ab", but adding "ab" to Trie is not necessary, becuase "abab" can be further break down in to shorter words "a" and "b", so we don't need to do an extra O(n) operation to add "ab" to the Trie.

class TrieNode:
    def __init__(self, char):
        self.char = char
        self.child = {}
        self.is_word = False

class Trie:
    def __init__(self):
        self.root = TrieNode("")
    
    def insert(self, word):
        curr = self.root
        for c in word:
            if c not in curr.child:
                curr.child[c] = TrieNode(c)
            curr = curr.child[c]
        curr.is_word = True
        return curr
    
    def check_concatenate(self, start, end, word, cnt):
        if start >= end and cnt >= 2:
            return True
        curr = self.root
        for i in range(start, end):
            c = word[i]
            if c not in curr.child:
                return False
            curr = curr.child[c]
            if curr.is_word:
                res = self.check_concatenate(i + 1, end, word, cnt + 1)
                if res:
                    return True
            
        return False

                        
class Solution:
    def findAllConcatenatedWordsInADict(self, words: List[str]) -> List[str]:
        trie = Trie()
        res = []
        words.sort(key = len)
        for word in words:
            if not trie.check_concatenate(0, len(word), word, 0):
                trie.insert(word)
            else:
                res.append(word)
        return res
    
    
#Method-4
# lru cache

class Solution:
    def findAllConcatenatedWordsInADict(self, words: List[str]) -> List[str]:
        wordset = set(words)
        
        @lru_cache(None)
        def dp(s):
            for i in range(1, len(s)):
                if s[:i] not in wordset: continue
                if dp(s[i:]): return 2 # return 2 if can be break into more than 1 word in dictionary
            if s in wordset: return 1
            return 0
        
        return [w for w in words if dp(w) > 1]

    
    
#Method-5

class Solution(object):
    def findAllConcatenatedWordsInADict(self, words):
        # Tracks all words we can use as building blocks for larger words. This
        # includes the initial dictionary, as well as any other words we build
        # from the initial set.
        legos = set(words)
        
        def canBuild(w):
            """Returns a bool indicating if we can build w via concatenation"""
            n = len(w)
            if n == 0:
                return False

            for i in range(n):
                prefix = w[:i + 1]
                suffix = w[i + 1:]
                if prefix in legos and (suffix in legos or canBuild(suffix)):
                    # Add as a building block to help dictionaries with lots of repetitive suffixes.
                    legos.add(w)
                    return True

            return False
            
        return filter(canBuild, words)


#Q14.   Making A Large Island

'''

You are given an n x n binary matrix grid. You are allowed to change at most one 0 to be 1.

Return the size of the largest island in grid after applying this operation.

An island is a 4-directionally connected group of 1s.

 

Example 1:

Input: grid = [[1,0],[0,1]]
Output: 3
Explanation: Change one 0 to 1 and connect two 1s, then we get an island with area = 3.
Example 2:

Input: grid = [[1,1],[1,0]]
Output: 4
Explanation: Change the 0 to 1 and make the island bigger, only one island with area = 4.
Example 3:

Input: grid = [[1,1],[1,1]]
Output: 4
Explanation: Can't change any 0 to 1, only one island with area = 4.
 

Constraints:

n == grid.length
n == grid[i].length
1 <= n <= 500
grid[i][j] is either 0 or 1.

'''
#Solution 

#Method-1

# dfs + set + map


class Solution:
    def largestIsland(self, grid: List[List[int]]) -> int:
        def dfs(i, j, color): # color all components
            grid[i][j], area, points = color, 1, [(i + 1, j), (i - 1, j), (i, j + 1), (i, j - 1)]
            for r, c in points:
                if 0 <= r < n and 0 <= c < n and grid[r][c] == 1:
                    area += dfs(r, c, color)
            return area  
                    
        n, color, water, island = len(grid), 2, set(), {} # put color, area in island map
        for i in range(n):
            for j in range(n):
                if grid[i][j] == 0:
                    water.add((i,j))
                elif grid[i][j] == 1:
                    area = dfs(i, j, color)
                    island[color] = area
                    color += 1
        
        res = island[2] if len(island) > 0 else 0 # is no water, area is island[2], only 1 color
        for i, j in water:
            area, visit, points = 1, set(), [(i + 1, j), (i - 1, j), (i, j + 1), (i, j - 1)]
            for r, c in points:
                if 0 <= r < n and 0 <= c < n:
                    color = grid[r][c]
                    if color not in visit and color in island:
                        area += island[color]
                        visit.add(color)
            res = max(res, area)
        
        return res


#Method-2

# Component Sizes
# Intuition

# As in the previous solution, we check every 0. However, we also store the size of each group, so that we do not have to use depth-first search to repeatedly calculate the same size.

# However, this idea fails when the 0 touches the same group. For example, consider grid = [[0,1],[1,1]]. The answer is 4, not 1 + 3 + 3, since the right neighbor and the bottom neighbor of the 0 belong to the same group.

# We can remedy this problem by keeping track of a group id (or index), that is unique for each group. Then, we'll only add areas of neighboring groups with different ids.

# Algorithm

# For each group, fill it with value index and remember it's size as area[index] = dfs(...).

# Then for each 0, look at the neighboring group ids seen and add the area of those groups, plus 1 for the 0 we are toggling. This gives us a candidate answer, and we take the maximum.

# To solve the issue of having potentially no 0, we take the maximum of the previously calculated areas.


# Complexity Analysis

# Time Complexity: O(N^2)O(Nˆ2), where NN is the length and width of the grid.

# Space Complexity: O(N^2)O(Nˆ2), the additional space used in the depth first search by area.  
 
class Solution(object):
    def largestIsland(self, grid):
        N = len(grid)

        def neighbors(r, c):
            for nr, nc in ((r-1, c), (r+1, c), (r, c-1), (r, c+1)):
                if 0 <= nr < N and 0 <= nc < N:
                    yield nr, nc

        def dfs(r, c, index):
            ans = 1
            grid[r][c] = index
            for nr, nc in neighbors(r, c):
                if grid[nr][nc] == 1:
                    ans += dfs(nr, nc, index)
            return ans

        area = {}
        index = 2
        for r in range(N):
            for c in range(N):
                if grid[r][c] == 1:
                    area[index] = dfs(r, c, index)
                    index += 1

        ans = max(area.values() or [0])
        for r in range(N):
            for c in range(N):
                if grid[r][c] == 0:
                    seen = {grid[nr][nc] for nr, nc in neighbors(r, c) if grid[nr][nc] > 1}
                    ans = max(ans, 1 + sum(area[i] for i in seen))
        return ans
    
#Method-3

# FS to find all the island
# First use dfs to find all island and set their value from 2 to n.
# like:

# [[1, 0, 1], 
# [0, 0, 0], 
# [0, 1, 1]]
# # to
# [[2, 0, 3], 
# [0, 0, 0], 
# [0, 4, 4]]
# Store all island size in a list islands[].

# Try all case to find the answer
# Loop for all point with value 0.
# Find in 4 directions and sum all related islands size.
# Save the maximum answer.

class Solution:
    def largestIsland(self, grid: List[List[int]]) -> int:
        res = 0
        i = 2
        islands = []

        def dfs(grid, x, y, i):
            if x < 0 or x >= len(grid) or y < 0 or y >= len(grid[0]) or grid[x][y] != 1:
                return 0
            else:
                grid[x][y] = i
                return 1+dfs(grid, x-1, y, i)+dfs(grid, x+1, y, i)+dfs(grid, x, y-1, i)+dfs(grid, x, y+1, i)

        for x in range(len(grid)):
            for y in range(len(grid[0])):
                if grid[x][y] == 1:
                    islands.append(dfs(grid, x, y, i))
                    i += 1
       # print(grid)
       # print(islands)
        
        def checkisland(grid, x, y):
            if x < 0 or x >= len(grid) or y < 0 or y >= len(grid[0]) or grid[x][y] == 0:
                return 0
            else:
                return grid[x][y]

        key = True
        for x in range(len(grid)):
            for y in range(len(grid[0])):
                if grid[x][y] == 0:
                    key = False
                    visited = set()
                    visited.add(checkisland(grid, x-1, y))
                    visited.add(checkisland(grid, x, y-1))
                    visited.add(checkisland(grid, x, y+1))
                    visited.add(checkisland(grid, x+1, y))
                    res = max(res, 1+sum(islands[x-2] for x in visited if x != 0))
        if key:
            res = len(grid)*len(grid[0])
        return res
    
#Method-4
#BFS

class Solution:
    # Identify islands first by changing the grid to island id (2,3,...), recording their area
    # For each "0" coordinate calculate the 4 connected total area + 1
    # output the max
    # ########################################################
    # Reused code from Max Area of Island
    # BFS question
    # Find connected components and their area from each point
    def valid(self, x, y, m, n):
        if x < 0:
            return False
        if y < 0:
            return False
        if x >= m:
            return False
        if y >= n:
            return False
        return True
    
    def largestIsland(self, grid: List[List[int]]) -> int:
        m, n = len(grid), len(grid[0])
        visited = set()
        areas = {}
        neig = [[1,0],[-1,0],[0,1],[0,-1]]
        island_id = 2
        
        for i in range(m):
            for j in range(n):
                if grid[i][j] == 1 and (i,j) not in visited:
                    # BFS
                    new_island = set()
                    dq = deque()
                    dq.append((i,j))
                    visited.add((i,j))
                    new_island.add((i,j))
                    count = 0
                    while dq:
                        x = dq.popleft()
                        for k in range(4):
                            xn, yn = x[0]+neig[k][0], x[1]+neig[k][1]
                            if (xn,yn) not in visited and self.valid(xn,yn,m,n) and grid[xn][yn]==1:
                                dq.append((xn,yn))
                                visited.add((xn,yn))
                                new_island.add((xn,yn))
                        count += 1
                    for item in new_island:
                        grid[item[0]][item[1]] = island_id
                    areas[island_id] = count
                    island_id += 1
        
        max_island = 0
        for i in range(m):
            for j in range(n):
                if grid[i][j] == 0:
                    local_area = 0
                    seen = set()
                    for k in range(4):
                        i_n, j_n = i+neig[k][0], j+neig[k][1]
                        if self.valid(i_n,j_n,m,n) and grid[i_n][j_n] > 1 and grid[i_n][j_n] not in seen:
                            local_area += areas[grid[i_n][j_n]]
                            seen.add(grid[i_n][j_n])
                    max_island = max(max_island, 1 + local_area)
        if max_island == 0:
            return max(areas.values())
        else:
            return max_island
        
#Method-5

# o(n**2),s(n**2)


class Solution(object):
    def largestIsland(self, grid):

        mp={}
        r,c=len(grid),len(grid[0])
        self.id=0
        vis=[[False for j in range(c)] for i in range(r)]
#         first we group ny id
        def dfs(i,j,total):
            vis[i][j]=self.id
            total[0]+=1
            li=[[1,0],[-1,0],[0,-1],[0,1]]
            for x,y in li:
                nx=x+i
                ny=y+j
                if 0<=nx<r and 0<=ny<c and vis[nx][ny]==False and grid[nx][ny]==1:
                    dfs(nx,ny,total)
        ans=0
        for i in range(r):
            for j in range(c):
                if grid[i][j]==1 and vis[i][j]==False:
                    self.id+=1
                    total=[0]
                    dfs(i,j,total)
                    mp[self.id]=total[0]
                    ans=max(ans,total[0])
#         now check every zero adj how many diffrent group is present and count total no and update max if max get
        for i in range(r):
            for j in range(c):
                if grid[i][j]==0:
                    s=set()
                    li=[[1,0],[-1,0],[0,-1],[0,1]]
                    for x,y in li:
                        nx=x+i
                        ny=y+j
                        if 0<=nx<r and 0<=ny<c and vis[nx][ny]!=False:
                            s.add(vis[nx][ny])
                    temp=0
                    for key in s:
                        temp+=mp[key]
                    ans=max(ans,temp+1)
        return ans


#Q15 Contain Virus

'''
A virus is spreading rapidly, and your task is to quarantine the infected area by installing walls.

The world is modeled as an m x n binary grid isInfected, where isInfected[i][j] == 0 represents uninfected cells, and isInfected[i][j] == 1 represents cells contaminated with the virus. A wall (and only one wall) can be installed between any two 4-directionally adjacent cells, on the shared boundary.

Every night, the virus spreads to all neighboring cells in all four directions unless blocked by a wall. Resources are limited. Each day, you can install walls around only one region (i.e., the affected area (continuous block of infected cells) that threatens the most uninfected cells the following night). There will never be a tie.

Return the number of walls used to quarantine all the infected regions. If the world will become fully infected, return the number of walls used.

 

Example 1:


Input: isInfected = [[0,1,0,0,0,0,0,1],[0,1,0,0,0,0,0,1],[0,0,0,0,0,0,0,1],[0,0,0,0,0,0,0,0]]
Output: 10
Explanation: There are 2 contaminated regions.
On the first day, add 5 walls to quarantine the viral region on the left. The board after the virus spreads is:

On the second day, add 5 walls to quarantine the viral region on the right. The virus is fully contained.

Example 2:


Input: isInfected = [[1,1,1],[1,0,1],[1,1,1]]
Output: 4
Explanation: Even though there is only one cell saved, there are 4 walls built.
Notice that walls are only built on the shared boundary of two different cells.
Example 3:

Input: isInfected = [[1,1,1,0,0,0,0,0,0],[1,0,1,0,1,1,1,1,1],[1,1,1,0,0,0,0,0,0]]
Output: 13
Explanation: The region on the left only builds two new walls.
 

Constraints:

m == isInfected.length
n == isInfected[i].length
1 <= m, n <= 50
isInfected[i][j] is either 0 or 1.
There is always a contiguous viral region throughout the described process that will infect strictly more uncontaminated squares in the next round.
'''
#Solution


#Method-1

# Simulation [Accepted]
# Intuition

# Let's work on simulating one turn of the process. We can repeat this as necessary while there are still infected regions.

# Algorithm

# Though the implementation is long, the algorithm is straightforward. We perform the following steps:

# Find all viral regions (connected components), additionally for each region keeping track of the frontier (neighboring uncontaminated cells), and the perimeter of the region.

# Disinfect the most viral region, adding it's perimeter to the answer.

# Spread the virus in the remaining regions outward by 1 sq

class Solution(object):
    def containVirus(self, grid):
        R, C = len(grid), len(grid[0])
        def neighbors(r, c):
            for nr, nc in ((r-1, c), (r+1, c), (r, c-1), (r, c+1)):
                if 0 <= nr < R and 0 <= nc < C:
                    yield nr, nc

        def dfs(r, c):
            if (r, c) not in seen:
                seen.add((r, c))
                regions[-1].add((r, c))
                for nr, nc in neighbors(r, c):
                    if grid[nr][nc] == 1:
                        dfs(nr, nc)
                    elif grid[nr][nc] == 0:
                        frontiers[-1].add((nr, nc))
                        perimeters[-1] += 1

        ans = 0
        while True:
            #Find all regions, with associated frontiers and perimeters.
            seen = set()
            regions = []
            frontiers = []
            perimeters = []
            for r, row in enumerate(grid):
                for c, val in enumerate(row):
                    if val == 1 and (r, c) not in seen:
                        regions.append(set())
                        frontiers.append(set())
                        perimeters.append(0)
                        dfs(r, c)

            #If there are no regions left, break.
            if not regions: break

            #Add the perimeter of the region which will infect the most squares.
            triage_index = frontiers.index(max(frontiers, key = len))
            ans += perimeters[triage_index]

            #Triage the most infectious region, and spread the rest of the regions.
            for i, reg in enumerate(regions):
                if i == triage_index:
                    for r, c in reg:
                        grid[r][c] = -1
                else:
                    for r, c in reg:
                        for nr, nc in neighbors(r, c):
                            if grid[nr][nc] == 0:
                                grid[nr][nc] = 1

        return ans

#Method-2

# BFS simulation solution: nothing convoluted


# I guess one should attempt Leetcode 695. Max Area of Island before doing this problem. Just speeds up everything tremendously, no complicated algorithms or concepts at all
# Also, I highly recommend padding the boundary with 2, as a rigid wall is equivalent to a quarantined region

class Solution:
    # Use 2 to pad the boundary
    # Cycle start
    # Use BFS to identify connected components
    # In the process also calculate the perimeter
    # Important point to note: we choose group with largest number of 0 cells neighboring the 1s, not the perimeter
    # Choose region with the affected neighbours to install wall (perimeter), mark the region to be 2
    # Then for all infected regions, expand the boundary for 1
    # Repeat the cycle until all regions become 2 (len(points) <= 1)
    
    def containVirus(self, isInfected: List[List[int]]) -> int:
        # Boundary padding
        self.grid = [[2]*(len(isInfected[0])+2)]
        for row in isInfected:
            self.grid.append([2] + row + [2])
        self.grid.append([2]*(len(isInfected[0])+2))
        
        # reused Leetcode 695. Max Area of Island code
        # BFS from each point with 1 
        m, n = len(self.grid), len(self.grid[0])
        neig = [[1,0],[-1,0],[0,1],[0,-1]]
        wall = 0
        finished = False
        
        while not finished:
            island_perimeters = []
            affected_cells = []
            points = []
            visited = set()
            for i in range(1,m-1):
                for j in range(1,n-1):
                    if self.grid[i][j] == 1 and (i,j) not in visited:
                        # BFS
                        points.append(set())
                        affected_cells.append(set())
                        dq = deque()
                        dq.append((i,j))
                        visited.add((i,j))
                        perimeter = 0
                        while dq:
                            x = dq.popleft()
                            for k in range(4):
                                xn, yn = x[0]+neig[k][0], x[1]+neig[k][1]
                                if (xn,yn) not in visited and self.grid[xn][yn]==1:
                                    dq.append((xn,yn))
                                    visited.add((xn,yn))
                                elif self.grid[xn][yn] == 0:
                                    perimeter += 1
                                    affected_cells[-1].add((xn,yn))
                            points[-1].add(x)
                        island_perimeters.append(perimeter)
            if not points:
                return wall
            max_affected, max_group = 0, 0
            for i, cells in enumerate(affected_cells):
                if len(cells) > max_affected:
                    max_group =  i
                    max_affected = len(cells)
            wall += island_perimeters[max_group]
                                       
            # quarantined regions
            for point in points[max_group]:
                self.grid[point[0]][point[1]] = 2
            # evolve the infection
            if len(points) == 1:
                finished = True
            else:
                for j, point_set in enumerate(points):
                    if j != max_group:
                        for point in point_set:
                            for k in range(4):
                                xn, yn = point[0]+neig[k][0], point[1]+neig[k][1]
                                if self.grid[xn][yn] == 0:
                                    self.grid[xn][yn] = 1
        return wall

#Method-3

class Solution(object):
    def containVirus(self, grid):
        """
        :type grid: List[List[int]]
        :rtype: int
        """
        idxg=[2]
        def grow(): # return NnewWall and modify grid inplace
            groups=collections.defaultdict(set)
            def dfs(pos,idx):
                grid[pos[0]][pos[1]]=idx
                for i,j in [[0,1],[0,-1],[1,0],[-1,0]]:
                    if 0<=pos[0]+i<len(grid) and 0<=pos[1]+j<len(grid[0]):
                        if grid[pos[0]+i][pos[1]+j]==0:
                            groups[idx].add((pos[0]+i,pos[1]+j))
                        elif grid[pos[0]+i][pos[1]+j]==1:
                            dfs((pos[0]+i,pos[1]+j),idx)
            for i in range(len(grid)):
                for j in range(len(grid[0])):
                    if grid[i][j]==1:
                        dfs((i,j),idxg[0])
                        idxg[0]+=1
            wall=0
            if groups:
                blockId=max(groups,key=lambda x: len(groups[x]))
                for idx in groups:
                    if idx==blockId:
                        for x,y in groups[idx]:
                            for i,j in [[0,1],[0,-1],[1,0],[-1,0]]:
                                if 0<=x+i<len(grid) and 0<=y+j<len(grid[0]) and grid[x+i][y+j]==idx:
                                    wall+=1
                    else:
                        for x,y in groups[idx]:
                            grid[x][y]=1
                for i in range(len(grid)):
                    for j in range(len(grid[0])):
                        if grid[i][j] in groups and grid[i][j]!=blockId:
                            grid[i][j]=1
            return wall
        ret=0
        while True:
            tmp=grow()
            if tmp>0:
                ret+=tmp
            else:
                return ret
            
            
#Method-4

# DFS 70 LoC


# Code is pretty much self-explanatory, we use DFS to find groups each turn, then find the maximum group by affected cells using key=affected_cells. After that we count the number of walls needs to be build and change the value of the current group to group_index.

class Solution:
    def containVirus(self, grid: List[List[int]]) -> int:
        d = ((0, 1), (0, -1), (1, 0), (-1, 0))
        def in_grid(i, j):
            return not(i < 0 or j < 0 or i >= len(grid) or j >= len(grid[0]))
        def dfs(i, j, res, visited):
            for di, dj in d:
                ci, cj = i + di, j + dj
                if  not in_grid(ci, cj) or grid[ci][cj] != 1 or (ci, cj) in visited:
                    continue
                res.add((ci, cj))
                visited.add((ci, cj))
                dfs(ci, cj, res, visited)
        def get_groups():
            groups = []
            visited = set()
            for i in range(len(grid)):
                for j in range(len(grid[0])):
                    if grid[i][j] == 1 and (i, j) not in visited:
                        group = set()
                        group.add((i, j))
                        dfs(i, j, group, visited)
                        groups.append(group)
            return groups
        def affected_cells(group):
            res = set()
            for i, j in group:
                for di, dj in d:
                    ci, cj = i + di, j + dj
                    if not in_grid(ci, cj) or grid[ci][cj] > 0:
                        continue
                    res.add((ci, cj))
            return len(res)
        
        def build_walls(group, new_v):
            res = 0
            for i, j in group:
                for di, dj in d:
                    ci, cj = i + di, j + dj
                    if not in_grid(ci, cj) or grid[ci][cj] > 0:
                        continue
                    res += 1
                grid[i][j] = new_v
            return res
        group_index = 2
        walls_count = 0
        def expand_groups(groups):
            cur = []
            for g in groups:
                for i, j in g:
                    cur.append((i, j))
            for i, j in cur:
                for di, dj in d:
                    ci, cj = i + di, j + dj
                    if not in_grid(ci, cj) or grid[ci][cj] > 0:
                        continue
                    grid[ci][cj] = 1
        while True:
            cur_groups = get_groups()
            if not cur_groups:
                break
            max_group = max(cur_groups, key=affected_cells)
            
            walls_count += build_walls(max_group, group_index)
            cur_groups.remove(max_group)
            if not cur_groups:
                break
            expand_groups(cur_groups)
            
            group_index += 1
            
        return walls_count

#Q16. Game

'''

You are given an integer array cards of length 4. You have four cards, each containing a number in the range [1, 9]. You should arrange the numbers on these cards in a mathematical expression using the operators ['+', '-', '*', '/'] and the parentheses '(' and ')' to get the value 24.

You are restricted with the following rules:

The division operator '/' represents real division, not integer division.
For example, 4 / (1 - 2 / 3) = 4 / (1 / 3) = 12.
Every operation done is between two numbers. In particular, we cannot use '-' as a unary operator.
For example, if cards = [1, 1, 1, 1], the expression "-1 - 1 - 1 - 1" is not allowed.
You cannot concatenate numbers together
For example, if cards = [1, 2, 1, 2], the expression "12 + 12" is not valid.
Return true if you can get such expression that evaluates to 24, and false otherwise.

 

Example 1:

Input: cards = [4,1,8,7]
Output: true
Explanation: (8-4) * (7-1) = 24
Example 2:

Input: cards = [1,2,1,2]
Output: false
 

Constraints:

cards.length == 4
1 <= cards[i] <= 9

'''
#Solution

#Method-1
 # Backtracking
    
class Solution:
    # All possible operations we can perform on two numbers.
    def generate_possible_results(self, a: float, b: float) -> List[float]:
        res = [a + b, a - b, b - a, a * b]
        if a:
            res.append(b / a)
        if b:
            res.append(a / b)  
        return res
    
    # Check if using current list we can react result 24.
    def check_if_result_reached(self, cards: List[float]) -> bool:
        # Base Case: We have only one number left, check if it is approximately 24.
        if len(cards) == 1:
            return abs(cards[0] - 24.0) <= 0.1

        for i in range(len(cards)):
            for j in range(i + 1, len(cards)):
                # Create a new list with the remaining numbers and the new result.
                new_list = [number for k, number in enumerate(cards) if (k != i and k != j)]
                
                # For any two numbers in our list, we perform every operation one by one.
                for res in self.generate_possible_results(cards[i], cards[j]):
                    # Add the new result to the list.
                    new_list.append(res)
                    
                    # Check if using this new list we can obtain the result 24.
                    if self.check_if_result_reached(new_list):
                        return True
                    
                    # Backtrack: remove the result from the list.
                    new_list.pop()
                    
        return False
    
    def judgePoint24(self, cards: List[int]) -> bool:
        return self.check_if_result_reached(cards)
    
    
#Method-2

# Recursion

class Solution:
    def judgePoint24(self, cards: List[int]) -> bool:
        
        def calculate(a, b):
            ans = [
                a+b,
                a - b,
                b - a,
                a * b
            ]
            if a != 0:
                ans.append(b/a)
            if b != 0:
                ans.append(a/b)
            return ans
    
        def generate_result(candidate):
            if len(candidate) == 1 and abs(candidate[0] - 24) < 0.1:
                return True
            for i in range(len(candidate)):
                for j in range(i):
                    t = candidate[i+1:] + candidate[j+1: i] + candidate[: j]
                    for value in calculate(candidate[i], candidate[j]):
                        if generate_result(t + [value]):
                            return True
            return False
        return generate_result(cards)
    
#Method-3
# Using reverse polish notation + backtrack

class Solution:
    def judgePoint24(self, cards: List[int]) -> bool:
        used = [False] * 4
        first_expression_pattern = [True, True, False, True, False, True, False]
        second_expression_pattern = [True, True, False, True, True, False, False]
        ops = ['+', '-', '*', '/']
        poland = []
        
        def cal_sum():
            stack = []
            for p in poland:
                if type(p) == str:
                    n1 = stack.pop()
                    n2 = stack.pop()
                    if p == '+':
                        stack.append(n1 + n2)
                    elif p == '-':
                        stack.append(n1 - n2)
                    elif p == '/':
                        if n2 == 0:
                            return -1
                        stack.append(n1 / n2)
                    else:
                        stack.append(n1 * n2)
                else:
                    stack.append(p)
            return stack[-1]
        
        def can_24(idx, expression_pattern):
            if idx == len(expression_pattern):
                if abs(cal_sum() - 24) < 1e-10:
                    return True
                return False
            if expression_pattern[idx]:
                for i in range(4):
                    if used[i]:
                        continue
                    used[i] = True
                    poland.append(cards[i])
                    if can_24(idx + 1, expression_pattern):
                        return True
                    poland.pop()
                    used[i] = False
            else:
                for i in range(4):
                    poland.append(ops[i])
                    if can_24(idx + 1, expression_pattern):
                        return True
                    poland.pop()
        return can_24(0, first_expression_pattern) or can_24(0, second_expression_pattern)

#Method-4

import functools

class Solution:
    # Helper function to get the values for all possible cominations of num1 and num2 using different mathematical operators
    def getRes(self, num1, num2):
        res = [num1+num2, num1-num2, num2-num1, num1*num2]
        if num1 != 0:
            res.append(num2/num1)
        if num2 != 0:
            res.append(num1/num2)
        return res
        
	# Created a new function with tuple as input instead of list as lists are not hashable and cache cannot be used for them
    @functools.lru_cache(maxsize=None)
    def jd(self, cards) -> bool:
        # If only two elements are left in cards, check if their combination can return 24
        if len(cards) == 2:
            for i in self.getRes(cards[0], cards[1]):
                # Need to round off as there can be cases like 23.99999 due to rounding off in previous steps
                if 24.0 == round(i, 5):
                    return True
            return False
            
        for i in range(0, len(cards)):
            for j in range(i+1, len(cards)):
                # Creating a new list after removing the two elements in consideration
                c = [x for t, x in enumerate(cards) if i != t != j]
                vals = self.getRes(cards[i], cards[j])
                # Recursive call after replacing the elements removed above with their combination
                for val in vals:
                    if self.jd(tuple(c)+(val,)):
                        return True
        return False
    
    def judgePoint24(self, cards: List[int]) -> bool:
        return self.jd(tuple(cards))
    
#Method-5

class Solution:
    def __init__(self):
        self.target = 24
        self.eps = 1e-6
        
    def judgePoint24(self, nums: List[int]) -> bool:
        return self.dfs(nums)
    
    def dfs(self, nums):
        n = len(nums)
        if n == 1:
            return abs(nums[0]-self.target) < self.eps
        
        for i in range(n):
            for j in range(n):
                if i == j:
                    continue
                
                new_nums = [0]*(n-1)
                idx = 0
                for k in range(n):
                    if k != i and k != j:
                        new_nums[idx] = nums[k]
                        idx += 1
                        
                if i < j:
                    new_nums[idx] = nums[i]+nums[j]
                    if self.dfs(new_nums):
                        return True
                    new_nums[idx] = 1.0*nums[i]*nums[j]
                    if self.dfs(new_nums):
                        return True
                
                new_nums[idx] = nums[i]-nums[j]
                if self.dfs(new_nums):
                    return True
                
                if nums[j] != 0:
                    new_nums[idx] = 1.0*nums[i]/nums[j]
                    if self.dfs(new_nums):
                        return True
        
        return False


#Q17.  Remove Boxes

'''

You are given several boxes with different colors represented by different positive numbers.

You may experience several rounds to remove boxes until there is no box left. Each time you can choose some continuous boxes with the same color (i.e., composed of k boxes, k >= 1), remove them and get k * k points.

Return the maximum points you can get.

 

Example 1:

Input: boxes = [1,3,2,2,2,3,4,3,1]
Output: 23
Explanation:
[1, 3, 2, 2, 2, 3, 4, 3, 1] 
----> [1, 3, 3, 4, 3, 1] (3*3=9 points) 
----> [1, 3, 3, 3, 1] (1*1=1 points) 
----> [1, 1] (3*3=9 points) 
----> [] (2*2=4 points)
Example 2:

Input: boxes = [1,1,1]
Output: 9
Example 3:

Input: boxes = [1]
Output: 1
 

Constraints:

1 <= boxes.length <= 100
1 <= boxes[i] <= 100

'''
#Solution

#Method-1
# memomization

class Solution:
    def removeBoxes(self, boxes: List[int]) -> int:
        @lru_cache(None)
        def helper(begin: int, end: int, num_left: int) -> int:
            """
			:num_left: extra boxes of color boxes[begin] to the left of A[begin..<end]
			"""
            if begin == end:
                return 0
            mid = next(dropwhile(lambda mid: boxes[mid] == boxes[begin], range(begin, end)), end)
            num_heads = mid - begin + num_left
            option1 = num_heads ** 2 + helper(mid, end, 0)
            option2 = (
                helper(mid, i, 0) + helper(i, end, num_heads)
                for i in range(mid, end) 
                if boxes[i] == boxes[begin]
            )
            return max(0, option1, *option2) # use python function max(arg1, arg2, *args[, key])
        
        return helper(0, len(boxes), 0)

#Method-2
# top-down DP + DFS

class Solution:
    def removeBoxes(self, boxes: List[int]) -> int:
        @lru_cache(None)
        def helper(begin: int, end: int, num_left: int) -> int:
            """
			:num_left: extra boxes of color boxes[begin] to the left of A[begin..<end]
			"""
            if begin == end:
                return 0
            mid = next(dropwhile(lambda mid: boxes[mid] == boxes[begin], range(begin, end)), end)
            num_heads = mid - begin + num_left
            option1 = num_heads ** 2 + helper(mid, end, 0)
            option2 = (
                helper(mid, i, 0) + helper(i, end, num_heads)
                for i in range(mid, end) 
                if boxes[i] == boxes[begin]
            )
            return max(0, option1, *option2) # use python function max(arg1, arg2, *args[, key])
        #
        return helper(0, len(boxes), 0)

#Method-3
class Solution:
    def removeBoxes(self, B):
        
        @lru_cache(None)
        def dp(i, j, k):
            if i > j: return 0
            indx = [m for m in range(i+1, j+1) if B[m] == B[i]]
            ans = (k+1)**2 + dp(i+1, j, 0)
            return max([ans] + [dp(i+1, m-1, 0) + dp(m, j, k+1) for m in indx])   
            
        return dp(0, len(B)-1, 0)
    
#Method-4

class Solution:
    def removeBoxes(self, boxes: List[int]) -> int:
        
        @cache
        def fn(lo, hi, k): 
            """Return max score of removing boxes from lo to hi with k to the left."""
            if lo == hi: return 0 
            while lo+1 < hi and boxes[lo] == boxes[lo+1]: lo, k = lo+1, k+1
            ans = (k+1)*(k+1) + fn(lo+1, hi, 0)
            for mid in range(lo+2, hi): 
                if boxes[lo] == boxes[mid]: 
                    ans = max(ans, fn(lo+1, mid, 0) + fn(mid, hi, k+1))
            return ans 
                
        return fn(0, len(boxes), 0)
    
    
#Method-5

# DP,

# dp(i,j,k) means the max points you can earn between boxes "i" and "j", with "k" boxes before i that has the same color as "i".

# But there are a few important facts that are not clearly mentioned in other posts:

# At the point of "dp(i,j,k)", all boxes before "i" are already removed. "ALL" removed, except for the "k" boxes that has same color as "i". So, literally, at "dp(i,j,k)" you are seeing "k+1" continuous boxes of "i" in the front.
# For dp(i,j,k), we can have 2 choices, either remove box "i", or not.
# If we remove box "i", then we earn the points of "i" together with "k" boxes before it. And the rest dp becomes "dp(i+1,j,0)". "k" becomes zero for the rest becase there are not a single box ahead anymore after removing "i".
# If we don't remove box "i", then k becomes "k+1". In order to use this "k+1", we have to find another box that has the same color as these "k+1" boxes. If there is no such box, then there is no point keeping box "i". If there is such box, then we remove all boxes along the way until this box of same color, so that this box can join "k+1" and makes a pattern in #1

import functools
class Solution:
    def removeBoxes(self, boxes: List[int]) -> int:
        @functools.lru_cache(None)
        def dfs(i,j,k):
            if i>j: return 0
            cnt=0
            while (i+cnt)<=j and boxes[i]==boxes[i+cnt]:
                cnt+=1
            i2=i+cnt
            res=dfs(i2,j,0)+(k+cnt)**2
            for m in range(i2,j+1):
                if boxes[m]==boxes[i]:
                    res=max(res, dfs(i2,m-1,0)+dfs(m,j,k+cnt))
            return res
        return dfs(0,len(boxes)-1,0)


        
