
#Binary Search 

#Q1. Sqrt(x)

'''

Given a non-negative integer x, compute and return the square root of x.

Since the return type is an integer, the decimal digits are truncated, and only the integer part of the result is returned.

Note: You are not allowed to use any built-in exponent function or operator, such as pow(x, 0.5) or x ** 0.5.

 

Example 1:

Input: x = 4
Output: 2
Example 2:

Input: x = 8
Output: 2
Explanation: The square root of 8 is 2.82842..., and since the decimal part is truncated, 2 is returned.
 

Constraints:

0 <= x <= 231 - 1

'''
#Solution 

# Appoach-1

# Binary Search (O(logn))
# binary-search
# sqrt function

class Solution:
    def mySqrt(self, x: int) -> int:
        low = 0
        high = x
        while low<=high:
            mid = (low+high)//2
            if mid*mid == x:
                return mid
            elif mid*mid>x:
                high = mid-1
            else:
                if (mid+1)*(mid+1)>x:
                    return mid
                else:
                    low = mid+1
                    
# Appoach-2

class Solution(object):
    def mySqrt(self, x):
        s=0
        e=x
        if x==0:
             return 0
        ans=0;
        while s<=e:
            mid=s+(e-s)//2;
            if mid==0:
                return 1
            if mid== x/mid:
                return mid
            if  mid < x/mid : 
                s=mid+1;
                ans=mid;
        
            else :
                e=mid-1
        return ans;


# Appoach-3

class Solution:
    def mySqrt(self, x: int) -> int:
        n = 0
        i = 1
        while n < x:
            n += i * 2 + 1
            i += 1
        return i - 1

# Appoach-4

class Solution(object):
    def mySqrt(self, x):
        l, r = 0, x
        while l <= r:
            mid = l + (r-l)//2
            if mid * mid <= x < (mid+1)*(mid+1):
                return mid
            elif x < mid * mid:
                r = mid - 1
            else:
                l = mid + 1
                
# Appoach-5
class Solution:
    def mySqrt(self, x: int) -> int:
        if (x == 0 or x == 1) :
            return x
        start = 1
        end = x  
        while (start <= end) :
            mid = (start + end) // 2
            if (mid*mid == x) :
                return mid             
            if (mid * mid < x) :
                start = mid + 1
                ans = mid
            else :
                end = mid-1
        return ans

#Q2.  Binary Search

'''

Given an array of integers nums which is sorted in ascending order, and an integer target, write a function to search target in nums. If target exists, then return its index. Otherwise, return -1.

You must write an algorithm with O(log n) runtime complexity.

 

Example 1:

Input: nums = [-1,0,3,5,9,12], target = 9
Output: 4
Explanation: 9 exists in nums and its index is 4
Example 2:

Input: nums = [-1,0,3,5,9,12], target = 2
Output: -1
Explanation: 2 does not exist in nums so return -1
 

Constraints:

1 <= nums.length <= 104
-104 < nums[i], target < 104
All the integers in nums are unique.
nums is sorted in ascending order.  

'''

#Solution 

#Approach-1

class Solution:
    def search(self, nums: List[int], target: int) -> int:
        first = 0
        last = len(nums) - 1
        while first <= last:
            mid = first + last
            midval = nums[mid]
            if target > midval:
                first = mid + 1
            elif target < midval:
                last = mid - 1
            else: 
                return mid
            
        return -1

#Approach-2

# Logic
# To search in this data structure, the most intuitive approach would be to use a binary search strategy.
# Why

# Because the list is ordered and we can get a better idea of where to look for with this method, instead of checking on every single item of the list. If the list is sorted in ascending order, we know that if we start from index 0, as we progress, the numbers will be greater than the first.
# Binary search, simply put, splits the list of number by two and checks if the item in the middle (the item where we split the list), is greater than the target. If so, we know that the target is probably in the first half, if existent. If less than or smaller than the target, it is probably on the second half. We continue splitting the half we care about until we reach out target or we cannot longer split the list.



class Solution:
    def search(self, nums: List[int], target: int) -> int:
		# we set a low and high value that will help us select the sublist of the array we want to search in. We start with the             whole array
        low = 0
        high = len(nums) -1
		
		# we iterate over the list to split it by two and check until we cannot longer split it because the start of the range              (low) is greater than the end (high).
        while low <= high:
		    # the mid will be the middle element of a sublist of the full one
            mid = (low + high) // 2
			# we get the middle of that sublist from the original list
            ele = nums[mid]
		
			# if mid equals target, we found it
            if ele == target:
                return mid
			
			# else, if target is more than the mid element of our selected list, we move further and target greater elements
            if target > ele:
                low = mid + 1
			# else, if target is less than the mid element of our selected list, we move closer to the start and target smaller                 elements
            else:
                high = mid - 1

        return -1
    
    
#Approach-3

class Solution:
    def search(self, nums, target):
        index = bisect.bisect_left(nums, target)
        return index if index < len(nums) and nums[index] == target else -1
    
#Approach-4    
class Solution:
    def search(self, nums, target):
        l, r = 0, len(nums) - 1
        while l <= r:
            mid = (l + r) // 2
            if nums[mid] < target:
                l = mid + 1
            elif nums[mid] > target:
                r = mid - 1
            else:
                return mid
        return -1
    
#Approach-5

class Solution:
    def search(self, nums, target):
        """
        :type nums: List[int]
        :type target: int
        :rtype: int
        """
        left = 0
        right = len(nums)-1
        
        while left <= right:
            middle = int((left+right)/2)
            
            if nums[middle] == target:
                return middle
            elif nums[middle] > target:
                right = middle-1
            elif nums[middle] < target:
                left = middle+1
        return -1 

#Q3.  Count Negative Numbers in a Sorted Matrix

'''

Given a m x n matrix grid which is sorted in non-increasing order both row-wise and column-wise, return the number of negative numbers in grid.

 

Example 1:

Input: grid = [[4,3,2,-1],[3,2,1,-1],[1,1,-1,-2],[-1,-1,-2,-3]]
Output: 8
Explanation: There are 8 negatives number in the matrix.
Example 2:

Input: grid = [[3,2],[1,0]]
Output: 0
 

Constraints:

m == grid.length
n == grid[i].length
1 <= m, n <= 100
-100 <= grid[i][j] <= 100
 

Follow up: Could you find an O(n + m) solution?

'''

#Solution 

# Approach-1

# binary search

# Find the first index with negative number
# Total number of negative per row = row length - index
# Sum all the negatives

class Solution:
    def countNegatives(self, grid: List[List[int]]) -> int:
        count = 0
        for g in grid:
            left, right = 0, len(g)
            while left < right:
                mid = left + (right - left) // 2
                if g[mid] >= 0:
                    left = mid + 1
                else:
                    right = mid
                
            count += len(g) - left
        return count
    
# Approach-2

# Using Binary Search + Finding Leftmost Negative Logic!

class Solution:
    #Time-Complexity: O(m*log(n))
    #Space-Complexity: O(1)
    def countNegatives(self, grid: List[List[int]]) -> int:
        
        def binary_search(a):
            #intialize search space to consist of entire array A!
            L, R = 0, (len(a) - 1)
            #initialize index answer as length of array a since initially we assume
            #array a has no negatives until we find one!
            answer = len(a)
            #as long as search space has at least one element to consider...
            while L <= R:
                mid = (L + R) // 2
                middle = a[mid]
                #if current middle is pos. neg elements may exist to the right!
                if(middle >= 0):
                    L = mid + 1
                    continue
                #if current middle element is negative, update the answer!
                else:
                    answer = mid
                    #search to the left of mid to find more leftmost postioned negatives, if it
                    #exists!
                    R = mid - 1
                    continue
            return answer
        #always get dimension of grid!
        r, c = len(grid), len(grid[0])
        #initialize ans: store total number of neg. elements seen so far!
        ans = 0
        #iterate through each and every row of grid!
        for row in grid:
            #perform binary search to find the leftmost index pos. of the first neg. element
            #in given row!
            first_neg_index = binary_search(row)
            #add total number of negatives in current row to accumulator or counter!
            ans += (c - first_neg_index)
        return ans

# Approach-3

# O(min(m,n)) one-pass scanning from right to left

class Solution:
    def countNegatives(self, grid: List[List[int]]) -> int:
        m,n=len(grid),len(grid[0])
        r,c=0,n-1
        res=0
        while r<m and c>=0:
            while r<m and grid[r][c]>=0:
                r+=1
            res+=m-r
            c-=1
        return res

# Approach-4

# O(max(m,n))

class Solution(object):
    def countNegatives(self, grid):
        """
        :type grid: List[List[int]]
        :rtype: int
        """
        if not grid: return 0
        m,n,cnt = len(grid[0]),len(grid),0
        row,col = n-1,0
        while (row>=0 and col<m):
            if grid[row][col]>=0: col+=1
            else: cnt,row = cnt+(m-col),row-1
        return cnt
    
# Approach-5

# O(N+M)->TC || O(1)->SC

# Algo :
# 1.Start from top right
# 2. If neg. then move left and add to count the no of rows
# 3. If pos then move down

class Solution:
	def countNegatives(self, grid: List[List[int]]) -> int:

		count = 0
		m, n = 0, len(grid[0]) - 1

		while m < len(grid) and n >= 0:
			if grid[m][n] < 0:
				count += len(grid) - m
				n -= 1
			else:
				m += 1

		return count

#Q4.Peak Index in a Mountain Array

'''

An array arr a mountain if the following properties hold:

arr.length >= 3
There exists some i with 0 < i < arr.length - 1 such that:
arr[0] < arr[1] < ... < arr[i - 1] < arr[i]
arr[i] > arr[i + 1] > ... > arr[arr.length - 1]
Given a mountain array arr, return the index i such that arr[0] < arr[1] < ... < arr[i - 1] < arr[i] > arr[i + 1] > ... > arr[arr.length - 1].

You must solve it in O(log(arr.length)) time complexity.

 

Example 1:

Input: arr = [0,1,0]
Output: 1
Example 2:

Input: arr = [0,2,1,0]
Output: 1
Example 3:

Input: arr = [0,10,5,2]
Output: 1
 

Constraints:

3 <= arr.length <= 105
0 <= arr[i] <= 106
arr is guaranteed to be a mountain array.

'''
#Solution 

#Approach-1

# binary search solution with explanation

# the search interval is [left, right), so the paek is arr[mid] > arr[mid+1] and arr[mid] > arr[mid-1], so check whether the mid is in decreasing part or increasing part to narrow the search area


class Solution:
    def peakIndexInMountainArray(self, arr: List[int]) -> int:
        left, right= 0 , len(arr)
        while left < right:
            mid = left + (right - left)//2
            if arr[mid] > arr[mid+1] and arr[mid] > arr[mid-1]: return mid
            elif arr[mid] > arr[mid+1] and arr[mid] < arr[mid-1]:
                right = mid
            elif arr[mid] < arr[mid+1] and arr[mid] > arr[mid-1]:
                left = mid + 1
        return -1
 

#Approach-2
# binary search
# but there is a problem, mid maybe is at len(arr) - 1 , and if arr[mid] > arr[mid+1] and arr[mid] > arr[mid-1]: return mid get out of index error, so just change initialization of left and right to [1, len(arr)-1), because the first and the last will not be the peak.


class Solution:
    def peakIndexInMountainArray(self, arr: List[int]) -> int:
        left, right= 1 , len(arr)-1
        while left < right:
            mid = left + (right - left)//2
            if arr[mid] > arr[mid+1] and arr[mid] > arr[mid-1]: return mid
            elif arr[mid] > arr[mid+1] and arr[mid] < arr[mid-1]:
                right = mid
            elif arr[mid] < arr[mid+1] and arr[mid] > arr[mid-1]:
                left = mid + 1
        return -1


#Approach-3

class Solution(object):
    def peakIndexInMountainArray(self, A):
        for i in range(len(A)):
            if A[i] > A[i+1]:
                return i
            
#Approach-4

class Solution(object):
    def peakIndexInMountainArray(self, A):
        """
        :type A: List[int]
        :rtype: int
        """
    
        smaller = 0 
        larger = len(A) - 1
        peak = self.find_peak(smaller, larger, A, -1)
        return peak
    
    def find_peak(self, smaller, larger, A, peak):
        if peak != -1:
            return peak
        else:
            mid = int((smaller + larger)/2)
            mid_left = mid - 1
            mid_right = mid + 1
            if A[mid] > A[mid_left] and A[mid] > A[mid_right]:
                peak = mid
            elif A[mid] > A[mid_left]:
                smaller = mid
                peak = self.find_peak(smaller, larger, A, peak)
            else:
                larger = mid 
                peak = self.find_peak(smaller, larger, A, peak)
            return peak

#Approach-5

# [24,69,100,99,79,78,67,36,26,19]

# find the pivot element based on order and return left when while condition breaks.

class Solution:
    def peakIndexInMountainArray(self, arr: List[int]) -> int:
        left, right = 0, len(arr) - 1
        
        while left <= right:
            mid = left + (right - left)//2
            print(left, mid, right)
            if arr[mid] > arr[mid+1]:       #Decesding order found, so we move towards left direction
                right = mid - 1
            else:
                left = mid + 1
        return left 


 #Q5. Time Based Key-Value Store

'''

Design a time-based key-value data structure that can store multiple values for the same key at different time stamps and retrieve the key's value at a certain timestamp.

Implement the TimeMap class:

TimeMap() Initializes the object of the data structure.
void set(String key, String value, int timestamp) Stores the key key with the value value at the given time timestamp.
String get(String key, int timestamp) Returns a value such that set was called previously, with timestamp_prev <= timestamp. If there are multiple such values, it returns the value associated with the largest timestamp_prev. If there are no values, it returns "".
 

Example 1:

Input
["TimeMap", "set", "get", "get", "set", "get", "get"]
[[], ["foo", "bar", 1], ["foo", 1], ["foo", 3], ["foo", "bar2", 4], ["foo", 4], ["foo", 5]]
Output
[null, null, "bar", "bar", null, "bar2", "bar2"]

Explanation
TimeMap timeMap = new TimeMap();
timeMap.set("foo", "bar", 1);  // store the key "foo" and value "bar" along with timestamp = 1.
timeMap.get("foo", 1);         // return "bar"
timeMap.get("foo", 3);         // return "bar", since there is no value corresponding to foo at timestamp 3 and timestamp 2, then the only value is at timestamp 1 is "bar".
timeMap.set("foo", "bar2", 4); // store the key "foo" and value "bar2" along with timestamp = 4.
timeMap.get("foo", 4);         // return "bar2"
timeMap.get("foo", 5);         // return "bar2"
 

Constraints:

1 <= key.length, value.length <= 100
key and value consist of lowercase English letters and digits.
1 <= timestamp <= 107
All the timestamps timestamp of set are strictly increasing.
At most 2 * 105 calls will be made to set and get.

'''
#Solution

# Approach-1
# Hashmap + Linear Search

# Time complexity:

# In the set() function, in each call, we store a value at (key, timestamp) location, which takes O(L)O(L) time to hash the string.
# Thus, for MM calls overall it will take, O(M \cdot L)O(M⋅L) time.

# In the get() function, in each call, we iterate linearly from timestamp to 1 which takes O(timestamp)O(timestamp) time and again to hash the string it takes O(L)O(L) time.
# Thus, for NN calls overall it will take, O(N \cdot timestamp \cdot L)O(N⋅timestamp⋅L) time.


class TimeMap:
    def __init__(self):
        self.key_time_map = {}

    def set(self, key: str, value: str, timestamp: int) -> None:
        # If the 'key' does not exist in dictionary.
        if not key in self.key_time_map:
            self.key_time_map[key] = {}
            
        # Store '(timestamp, value)' pair in 'key' bucket.
        self.key_time_map[key][timestamp] = value
        

    def get(self, key: str, timestamp: int) -> str:
        # If the 'key' does not exist in dictionary we will return empty string.
        if not key in self.key_time_map:
            return ""
        
        # Iterate on time from 'timestamp' to '1'.
        for curr_time in reversed(range(1, timestamp + 1)):
            # If a value for current time is stored in key's bucket we return the value.
            if curr_time in self.key_time_map[key]:
                return self.key_time_map[key][curr_time]
            
        # Otherwise no time <= timestamp was stored in key's bucket.
        return ""
    
    
# Approach-2: Sorted Map + Binary Search

from sortedcontainers import SortedDict

class TimeMap:
    def __init__(self):
        self.key_time_map = {}

    def set(self, key: str, value: str, timestamp: int) -> None:
        # If the 'key' does not exist in dictionary.
        if not key in self.key_time_map:
            self.key_time_map[key] = SortedDict()
            
        # Store '(timestamp, value)' pair in 'key' bucket.
        self.key_time_map[key][timestamp] = value
        

    def get(self, key: str, timestamp: int) -> str:
        # If the 'key' does not exist in dictionary we will return empty string.
        if not key in self.key_time_map:
            return ""
        
        it = self.key_time_map[key].bisect_right(timestamp)
        # If iterator points to first element it means, no time <= timestamp exists.
        if it == 0:
            return ""
        
        # Return value stored at previous position of current iterator.
        return self.key_time_map[key].peekitem(it - 1)[1]
    
    
# Approach 3: Array + Binary Search

class TimeMap:
    def __init__(self):
        self.key_time_map = {}

    def set(self, key: str, value: str, timestamp: int) -> None:
        # If the 'key' does not exist in dictionary.
        if not key in self.key_time_map:
            self.key_time_map[key] = []
            
        # Store '(timestamp, value)' pair in 'key' bucket.
        self.key_time_map[key].append([ timestamp, value ])
        

    def get(self, key: str, timestamp: int) -> str:
        # If the 'key' does not exist in dictionary we will return empty string.
        if not key in self.key_time_map:
            return ""
        
        if timestamp < self.key_time_map[key][0][0]:
            return ""
        
        left = 0
        right = len(self.key_time_map[key])
        
        while left < right:
            mid = (left + right) // 2
            if self.key_time_map[key][mid][0] <= timestamp:
                left = mid + 1
            else:
                right = mid

        # If iterator points to first element it means, no time <= timestamp exists.
        return "" if right == 0 else self.key_time_map[key][right - 1][1]
    

    
# Approach 4: Dictionary and Binary Search 


class TimeMap:

    def __init__(self):
        self.hashmap = {}
    
    def search(self, key, timestamp):
        vals = self.hashmap[key]['timestamps']
        if timestamp < vals[0]: return ""
        
        if timestamp > vals[-1]: return vals[-1]
        start, end = 0, len(vals)-1
        minimum = float('inf')
        index = 0

        while start <= end:
            mid = start + (end-start)//2
            if abs(timestamp-vals[mid]) < minimum:
                minimum = vals[mid]
                index = mid

            if vals[mid] == timestamp:
                return vals[mid]
            elif vals[mid] > timestamp:
                end = mid-1
            else:
                start = mid+1
                
        if index-1 >= 0 and vals[index] > timestamp:
            return vals[index-1]

        return vals[index]

    def set(self, key: str, value: str, timestamp: int) -> None:
        if key in self.hashmap:
            values = self.hashmap[key]
            values[timestamp] = value
            values['timestamps'].append(timestamp)
        else:
            self.hashmap[key] = { timestamp: value, 'timestamps': [timestamp] }     

    def get(self, key: str, timestamp: int) -> str:
        if key in self.hashmap:
            values = self.hashmap[key]

            key = self.search(key, timestamp) 
            if key: return values[key]
        return ""
        


# Your TimeMap object will be instantiated and called as such:
# obj = TimeMap()
# obj.set(key,value,timestamp)
# param_2 = obj.get(key,timestamp)


# Approach 5: nested dictionary

class Solution:
    def __init__(self):
        self.store = collections.defaultdict(dict)
    def set(self, key: 'str', value: 'str', timestamp: 'int') -> 'None':
        self.store[key][timestamp] = value
    def get(self, key: 'str', timestamp: 'int') -> 'str':
        counter = 0
        while counter != timestamp:
            if timestamp-counter in self.store[key]: 
                return self.store[key][timestamp-counter]
            counter +=1
        return ""

#Q6. Search in Rotated Sorted Array
'''

There is an integer array nums sorted in ascending order (with distinct values).

Prior to being passed to your function, nums is possibly rotated at an unknown pivot index k (1 <= k < nums.length) such that the resulting array is [nums[k], nums[k+1], ..., nums[n-1], nums[0], nums[1], ..., nums[k-1]] (0-indexed). For example, [0,1,2,4,5,6,7] might be rotated at pivot index 3 and become [4,5,6,7,0,1,2].

Given the array nums after the possible rotation and an integer target, return the index of target if it is in nums, or -1 if it is not in nums.

You must write an algorithm with O(log n) runtime complexity.

 

Example 1:

Input: nums = [4,5,6,7,0,1,2], target = 0
Output: 4
Example 2:

Input: nums = [4,5,6,7,0,1,2], target = 3
Output: -1
Example 3:

Input: nums = [1], target = 0
Output: -1
 

Constraints:

1 <= nums.length <= 5000
-104 <= nums[i] <= 104
All values of nums are unique.
nums is an ascending array that is possibly rotated.
-104 <= target <= 104

'''

#Solution

# Approach-1

# Binary Search

class Solution:
    def find_min_idx(self, nums: list[int]) -> int:
        lower, upper = 0, len(nums) - 1
        min_idx = 0

        while lower <= upper:
            pivot = (lower + upper) // 2

            min_val = nums[min_idx]
            val = nums[pivot]

            if val >= min_val:
                lower = pivot + 1
            else:
                min_idx = pivot
                upper = pivot - 1

        return min_idx

    def search(self, nums: list[int], target: int) -> int:
        min_idx = self.find_min_idx(nums)

        lower, upper = 0, len(nums) - 1

        while lower <= upper:
            pivot = (lower + upper) // 2
            idx = (pivot + min_idx) % len(nums)
            val = nums[idx]

            if val == target:
                return idx
            elif val < target:
                lower = pivot + 1
            else:
                upper = pivot - 1

        return -1
    
# Approach-2

# Alternative Binary Search Solution


class Solution:
    def search(self, nums: List[int], target: int) -> int:
        '''
        idea breakdown:
        the original rule for sorted list is that all numbers are given in sorted order
        we will do a binary search, where we will follow the direction of sorted order
        when we find the direction of sorted order, we will partition based on whether it is in range of sorted direction
        if it is in range, we will partition toward that direction, otherwise we will partition in oppoite direction
        
        psuedo code:
        1.0 - initiate left and right pointers
        
        2.0 - while left is less than or equal to right
        
            2.1 - mid is (left + right) // 2
            
            2.2 - if mid is target:
                2.2.1 - return mid index
            
            2.3 - else if left and mid follow sorted order
                2.3.1 - if target is within range of left and mid values:
                    2.3.1.1 - right = mid - 1
                
                2.3.2 - otherwise
                    2.3.2.1 - left = mid + 1
            
            2.4 - otherwise (if left and mid break sorted order)
                2.4.1 - if target is within the range of mid and right values:
                    2.4.1.1 - left = mid + 1
                
                2.4.2 - otherwise
                    2.4.2.1 - right = mid - 1
            
        3.0 - return -1 if target is never found
        '''
        left, right = 0, len(nums) - 1
        
        while left <= right:
            
            mid = (right + left) // 2
            
            if nums[mid] == target:
                return mid
            
            elif nums[mid] >= nums[left]:
                if nums[left] <= target < nums[mid]:
                    right = mid - 1
                
                else:
                    left = mid + 1
            
            else:
                if nums[mid] < target <= nums[right]:
                    left = mid + 1
                
                else:
                    right = mid - 1
            

        return -1
    
    
# Approach-3:  listcomprehension   
class Solution:
    def search(self, nums: List[int], target: int) -> int:
        return [nums.index(target) if target in nums else -1][0]




# Approach-4:  O( log n) runtime O(1) space 

# We need our runtime to be O(log n) so we need to use binary search, but our array has been shifted s.t. that the input array is no longer in ascending order. So we can't run binary search on the entirety of our input array.

# For our sample input array, nums, of len n :
# [4,5,6,7,0,1,2]

# there are two subarrays that we can perform binary search on to find our element. They are separated by the 'shift boundary', i.e. the point where the array is not longer ascending.

# [4,5,6,7] and [0,1,2]

# So our steps are as follows

# find shift boundary
# if there is no shift boundary (case where array is only in ascending order)
# a. perform binary search on entire array
# if shift boundary exists
# a. if target is in [nums[shift_boundary],nums[n-1]] // target is in our second subarray
# 1. perform binary search on nums[shift_boundary,nums[n-1]]
# 2. add our offset of shift_boundary to the index returned by binary search above
# b. if target is in [nums[0],nums[shift_boundary]) // target is in our first subarray:
# 1. perform binary search on nums[0,nums[shift_boundary-1]]
# return -1
# Observe that the array up and until index 0 is always ascending. So to find our shift boundary compare all elements in nums against nums[0] by doing nums[i] < nums[0]

# for [4,5,6,7,0,1,2], gives us:
# [F,F,F,F,T,T,T]

# The First T is our shift boundary and we use binary search to find this index.

class Solution:
    
    def find_shift_boundary(self,nums):
        left = 0
        right = len(nums) - 1
        i = -1
        while left <= right:
            mid = (left + right) // 2
            if nums[mid] < nums[0]:
                i = mid
                right = mid - 1
            else:
                left = mid + 1
        return i
    
    def binary_search(self,nums,target):
        left = 0
        right = len(nums)-1
        while left <= right:
            mid = (left + right) // 2
            if nums[mid] == target:
                return mid
            elif nums[mid] > target:
                right = mid -1
            else:
                left = mid + 1
        return -1
    
    def search(self, nums: List[int], target: int) -> int:
        i = self.find_shift_boundary(nums)
        n = len(nums)
        if i == -1:
            return self.binary_search(nums,target)
        else:
            if nums[i] <= target and target <= nums[n-1]:
                result = self.binary_search(nums[i:n],target)
                return result if result == -1 else result + i
            elif nums[0] <= target and target <= nums[i-1]:
                return self.binary_search(nums[0:i],target)
        return -1
    
    
# Approach-5: Apparently this is a variant of binary search. We still need to divide the array into 2 parts, but in a different condition judgement.

class Solution(object):
    def search(self, nums, target):
        """
        :type nums: List[int]
        :type target: int
        :rtype: int
        """
        L = len(nums)
        begin = 0
        end = L - 1
        mid = int ((begin + end)//2)
        
        while 1:
            # when sub-array length is smaller then 3, just brute force (O(3))
            if end - begin <= 2:
                if target == nums[begin]:
                    return begin
                elif begin + 1 < L and target == nums[begin + 1]:
                    return begin + 1
                elif begin + 2 < L and target == nums[begin + 2]:
                    return begin + 2
                else:
                    return -1
            m = nums[mid]
            b = nums[begin]
            e = nums[end]
            if m == target:
                return mid
            if b == target:
                return begin
            if e == target:
                return end
            
            # (the only) triky part. 
            if b > m:
                if target < m or target > b:
                    begin = begin
                    end = mid - 1
                elif target > m or target < b:
                    begin = mid + 1
                    end = end
           
            elif b < m:
                if target < m and target > b:
                    begin = begin
                    end = mid - 1
                else:
                    begin = mid + 1
                    end = end
            mid = (begin + end)/2   
            
            
            
            
#Approach-6: using binary search


# Once you realize this is a binary search problem, it is not hard at all. The key is to notice that the rotation divides the list into two ascending sub lists and all elements in the left one are bigger than that in the right one. We should be careful when considering different conditions.

class Solution(object):
    def search(self, nums, target):
        """
        :type nums: List[int]
        :type target: int
        :rtype: int
        """
        n = len(nums)
        if n == 0:
            return -1
        i, j, k = 0, n-1, 0
        left = True if target>=nums[0] else False   # indicate the target may be in the left part or right part
        # modified binary search
        while i <= j:
            k = (i+j)//2
            if target == nums[k]:   # target encountered
                return k
            elif (nums[k]>=nums[0] and left and target<nums[k]) or (nums[k]<nums[0] and (left or (not left and target<nums[k]))):
                j = k - 1
            else:
                i = k + 1
        return -1


#Q7. Pow(x, n)

'''

Implement pow(x, n), which calculates x raised to the power n (i.e., xn).

 

Example 1:

Input: x = 2.00000, n = 10
Output: 1024.00000
Example 2:

Input: x = 2.10000, n = 3
Output: 9.26100
Example 3:

Input: x = 2.00000, n = -2
Output: 0.25000
Explanation: 2-2 = 1/22 = 1/4 = 0.25
 

Constraints:

-100.0 < x < 100.0
-231 <= n <= 231-1
-104 <= xn <= 104

'''
#Solution

#Method-1
class Solution:
    def myPow(self, x: float, n: int) -> float:
        return x**n
class Solution:
	def myPow(self, x: float, n: int) -> float:
		return pow(x,n)        
        
#Method-2

# I multiplied the number with itself and doubled the power.
# For an odd number, i would just divide by the power difference.

# For example:
# for calculating 2^10:

# 2x2=4
# 4x4=16
# 16x16=256
# 256x256=2^8
# 2^8x2^8=2^16

# now the power 16>10 hence divide by 2^(16-10) which is returned as 2^16/2^6

class Solution:
    def myPow(self, x: float, n: int) -> float:
        if(n==0):
            return 1
        power=1
        init=x
        while(power<n):
            x=x*x
            power=power*2
        if(power==n):
            return x
        z=self.myPow(init,power-n)
        if(math.isnan(z)):
            return 0
        return x/z
    
#Method-3
# 2^-1 = 1 / 2^1
# 2^4 = 2 * 2 * 2 * 2 = (2^2)^2 = half * half
# 2^5 = 2 * 2 * 2 * 2 * 2 = 2 * (2^2)^2 = 2 * half * half

class Solution:
    def myPow(self, x: float, n: int) -> float:
        if n == 0:
            return 1

        if n < 0:
            return 1 / self.myPow(x, -n)

        half = self.myPow(x, n // 2)
        if n % 2 == 0:
            return half * half

        return x * half * half
    
#Method-4

#Divide and Conquer Solution

class Solution:
    def myPow(self, x: float, n: int) -> float:
        #Base Case
        if(n == 0):
            return 1
        if(x == 0):
            return 0
        if(x == 1):
            return 1
        if(n == 1):
            return x
        if(n < 0):
            return 1/self.myPow(x,-1*n)
        #Divide and Conquer
        half = self.myPow(x,n//2)
        
        #Combine
        if(n % 2 == 0):
            return half*half
        else:
            return x*(half*half)


#Method-5

class Solution:
    def myPow(self, x: float, n: int) -> float:
        return round(x**n, 5)



#Q8. Find First and Last Position of Element in Sorted Array
'''

Given an array of integers nums sorted in non-decreasing order, find the starting and ending position of a given target value.

If target is not found in the array, return [-1, -1].

You must write an algorithm with O(log n) runtime complexity.

 

Example 1:

Input: nums = [5,7,7,8,8,10], target = 8
Output: [3,4]
Example 2:

Input: nums = [5,7,7,8,8,10], target = 6
Output: [-1,-1]
Example 3:

Input: nums = [], target = 0
Output: [-1,-1]
 

Constraints:

0 <= nums.length <= 105
-109 <= nums[i] <= 109
nums is a non-decreasing array.
-109 <= target <= 109

'''
#Solution 

#Approach-1

class Solution:
    def left_bound(self, nums: List[int], target: int) -> int:
        if len(nums) == 0: 
            return -1
        left = 0
        right = len(nums)
        while (left < right):
            mid = left + (right - left)//2
            if nums[mid] == target:
                right = mid
            elif nums[mid] < target:
                left = mid + 1
            elif nums[mid] > target:
                right = mid
        if left >= len(nums) or nums[left] != target:
            return -1 
        return left
            
                
                
    def right_bound(self, nums: List[int], target: int) -> int:
        if len(nums) == 0: 
            return -1
        left = 0
        right = len(nums)
        while (left < right):
            mid = left + (right - left)//2
            if nums[mid] == target:
                left = mid + 1
            elif nums[mid] > target:
                right = mid
            elif nums[mid] < target:
                left = mid + 1
        if left == 0 or nums[left - 1] != target:
            return -1
        return left - 1
                
    def searchRange(self, nums: List[int], target: int) -> List[int]:
        first = self.left_bound(nums, target)
        last = self.right_bound(nums, target)
        return [first, last]
    
    
    
#Approach-2

# Bianry-search

class Solution:
    def searchRange(self, nums: List[int], target: int) -> List[int]:
        start=0
        end=len(nums)-1
        a,b=-1,-1
        while start<=end:
            mid=(start+end)//2
            if nums[mid]==target:
                a=mid
                end=mid-1
            elif nums[mid]>target:
                end=mid-1
            else:
                start=mid+1
        start=0
        end=len(nums)-1
        while start<=end:
            mid=(start+end)//2
            if nums[mid]==target:
                b=mid
                start=mid+1
            elif nums[mid]<target:
                start=mid+1
            else:
                end=mid-1
        return [a,b]
    
    
    
#Approach-3:  O(logn) recursive solution

class Solution:
    # @param {integer[]} nums
    # @param {integer} target
    # @return {integer[]}
    def searchRange(self, nums, target):
        return self.search(nums, target, 0, len(nums) - 1)

    def search(self, nums, target, i, j):
        if i > j:
            return [-1, -1]

        m = (i + j) // 2
        if target < nums[m]:
            # search left for range
            return self.search(nums, target, i, m - 1)
        elif target > nums[m]:
            # search right for range
            return self.search(nums, target, m + 1, j)
        else:
            return [self.searchBorder(nums, target, i, m, -1), self.searchBorder(nums, target, m, j, 1)]

    def searchBorder(self, nums, target, i, j, delta):
        m = (i + j) // 2
        if nums[m] == target and (m + delta < 0 or m + delta >= len(nums) or nums[m + delta] != target):
            return m
        elif nums[m] > target or (nums[m] == target and delta < 0):
            # search left for border
            return self.searchBorder(nums, target, i, m - 1, delta)
        elif nums[m] < target or (nums[m] == target and delta > 0):
            # search right for border
            return self.searchBorder(nums, target, m + 1, j, delta)
        
        
#Approach-4: using binary search


class Solution:
    def searchRange(self, nums: List[int], target: int) -> List[int]:
		# modified binary search
	
        def binarySearch(find):
            left, right = 0, len(nums) - 1
            output = -1        
            while left <= right:
                mid = (left + right) // 2      
                if nums[mid] > target:
                    right = mid - 1
                elif nums[mid] < target:
                    left = mid + 1
                else:
                    output = mid    
					#This is the only modification to a standard binary search
                    if find == 'first': #To find the first occurence, look to the left (shrink from right)
                        right = mid - 1
                    elif find == 'last': #To find the last occurence, look to the right (shrink from left)
                        left = mid + 1           
            return output       
        return [binarySearch('first'), binarySearch('last')]
    
    
    
#Approach-5:log(n), modified binary search

class Solution(object):
    def searchRange(self, nums, target):
        """
        :type nums: List[int]
        :type target: int
        :rtype: List[int]
        """
        result = []
        if len(nums) == 0:
            return [-1,-1]
        if nums[0] > target or nums[-1] < target:
            return [-1,-1]
        
        low = 0
        high = len(nums) - 1
        while low <= high:
            mid = low + int((high - low)/2)
            if nums[mid] > target:
                high = mid - 1
            elif nums[mid] < target:
                low = mid + 1
            elif nums[mid] == target:
                if mid == 0 or nums[mid - 1] < target:
                    result.append(mid)
                    break
                else:
                    high = mid - 1
                
        low = 0
        high = len(nums) - 1        
        while low <= high:
            mid = low + int((high - low)/2)
            if nums[mid] > target:
                high = mid - 1
            elif nums[mid] < target:
                low = mid + 1
            elif nums[mid] == target:
                if mid == len(nums) - 1 or nums[mid + 1] > target:
                    result.append(mid)
                    break
                else:
                    low = mid + 1
                    
        if len(result) == 0: 
            return [-1,-1]
        else:
            return result

#Q9.  Find Peak Element

'''
A peak element is an element that is strictly greater than its neighbors.

Given a 0-indexed integer array nums, find a peak element, and return its index. If the array contains multiple peaks, return the index to any of the peaks.

You may imagine that nums[-1] = nums[n] = -∞. In other words, an element is always considered to be strictly greater than a neighbor that is outside the array.

You must write an algorithm that runs in O(log n) time.

 

Example 1:

Input: nums = [1,2,3,1]
Output: 2
Explanation: 3 is a peak element and your function should return the index number 2.
Example 2:

Input: nums = [1,2,1,3,5,6,4]
Output: 5
Explanation: Your function can return either index number 1 where the peak element is 2, or index number 5 where the peak element is 6.
 

Constraints:

1 <= nums.length <= 1000
-231 <= nums[i] <= 231 - 1
nums[i] != nums[i + 1] for all valid i.

'''
#Solution

#Approach-1

# Basic binary search implemented. Create 2 pointers left and right and set them to list edges. Handle a few edge cases at the start.

# Edge Case 1: List has only 1 element --> return index 0 since it has to be the peak
# Edge Case 2: If the last element is bigger than the 2nd to last element, return that index since its defined to be bigger than out of bounds
# Edge Case 3: Similar to 2 but with element at index 1 vs. index 0 (since 0 is always bigger than out of bounds left)
# Set left/right pointers and grab the middle element between them.
# If that middle element is < element to left and > than one on the right, move the right pointer to its left and the repeat loop to divide list in half.
# Otherwise (so if > element to right and > element left OR less than both right and left, just move left pointer right)
# Escape Case: If ever the middle is greater than both those around it, return that index!


class Solution:
    def findPeakElement(self, nums: List[int]) -> int:
        # Edge cases
        if len(nums) == 1: # List only has 1 element
            return 0
        if nums[len(nums) - 1] > nums[len(nums) - 2]: # Last element > 2nd to last
            return len(nums) - 1 
        if nums[0] > nums[1]: # First element bigger than 2nd
            return 0
     
        left = 1 # No need to start with 0 since we already checked
        right = len(nums)-2 # No need to include last element we already checked
        while (left <= right):
            mid = (left+right)//2
            if (nums[mid-1] < nums[mid]) and (nums[mid+1] < nums[mid]):
                return mid
            elif (nums[mid-1] > nums[mid]) and (nums[mid+1] < nums[mid]):
                right = mid-1
            else: # In all other cases, right is greater so move one right
                left = mid+1
                
#Approach-2

# Binary Search

class Solution:
    def findPeakElement(self, nums: List[int]) -> int:
        # find the first element that bigger than neighbor
        left = 0
        right = len(nums) - 1
        while left < right:
            #find the first turning point
            mid = (right - left ) // 2 + left
            if nums[mid] > nums[mid+1]:
                right = mid
            else:
                left = mid + 1
        return left
    
    
#Approach-3:

class Solution:
    def findPeakElement(self, nums: List[int]) -> int:
        x=max(nums)
        index=nums.index(x)
        return index
    
#Approach-4: binary search

class Solution:
    def findPeakElement(self, nums: List[int]) -> int:
        nums = [-math.inf] + nums + [-math.inf]
        left = 0
        right = len(nums) - 1
        while left <= right:
            mid = (left + right) // 2
            if nums[mid-1] < nums[mid] > nums[mid+1]:
                return mid - 1
            elif nums[mid-1] > nums[mid]:
                right = mid - 1
            else:
                left = mid + 1
                

#Q10. Search a 2D Matrix

'''

Write an efficient algorithm that searches for a value target in an m x n integer matrix matrix. This matrix has the following properties:

Integers in each row are sorted from left to right.
The first integer of each row is greater than the last integer of the previous row.
 

Example 1:


Input: matrix = [[1,3,5,7],[10,11,16,20],[23,30,34,60]], target = 3
Output: true
Example 2:


Input: matrix = [[1,3,5,7],[10,11,16,20],[23,30,34,60]], target = 13
Output: false
 

Constraints:

m == matrix.length
n == matrix[i].length
1 <= m, n <= 100
-104 <= matrix[i][j], target <= 104

'''
#Solution

# Approach-1: Split the Problems into small Pieces


# So many logics in this 2D graph which really resist thinking of programmer. To solve this question, I store the logics with small function and add them together to form a complete graph.

class Solution:
    def searchMatrix(self, matrix: List[List[int]], target: int) -> bool:
        m, n = len(matrix), len(matrix[0])
        x, y = 0, 0
        #if target less than current then return false
        #if bottom have value do (1); else do (3)
        #(3)if right have velue do (2); else return false
        #(1)if target greater than bottom, move down; eles do (2)
        #(2) if target greater than right, move right
        
        def move_right():
            if(y+1)<n:
                if target>=matrix[x][y+1]:
                    return True
            
            return False
        
        def move_down():
            if(x+1)<m:
                if target>=matrix[x+1][y]:
                    return True
            
            return False
        
        while x<m and y<n:
            print(matrix[x][y])
            if target < matrix[x][y]:
                return False

            if target == matrix[x][y]:
                return True
            
            if move_down():
                x+=1
            elif move_right():
                y+=1
            else:
                return False
            
# Approach-2: Search in 2D matrix


class Solution(object):
    def searchMatrix(self, matrix, target):
        """
        :type matrix: List[List[int]]
        :type target: int
        :rtype: bool
        """
        isPresent= False
        for i in matrix:
            for j in i:
                if j==target:
                    isPresent=True
        return isPresent
    
# Approach-3:Binary Search Solution | O(log(mn)) Time | O(1) Space

# * Binary Search Solution | O(log(mn)) Time | O(1) Space
# * m -> The number of rows in the matrix | n -> The number of columns in the matrix


class Solution:
    def searchMatrix(self, matrix: List[List[int]], target: int) -> bool:
        ROWS, COLS = len(matrix), len(matrix[0])

        def get_val_to_pos(val):
            """Returns the corresponding position (row and col) in 2D array from 1D array."""
            return (val // COLS), (val % COLS)

        left, right = 0, (ROWS * COLS) - 1
        while left <= right:
            mid = left + (right - left) // 2
            row, col = get_val_to_pos(mid)
            if matrix[row][col] == target:
                return True
            elif matrix[row][col] < target:
                left = mid + 1
            else:
                right = mid - 1

        return False
    
# Approach-4:

class Solution:
    def searchMatrix(self, matrix: List[List[int]], target: int) -> bool:
        for i in range(len(matrix)):
            if matrix[i][0] <= target:
                if target in matrix[i]:
                    return True
        return False
    
# Approach-5: Using For Loops and Arrays

class Solution:
    def searchMatrix(self, matrix: List[List[int]], target: int) -> bool:
        mat_length = len(matrix)
        done = []
        for numbers in range(0, mat_length):
            for numbers1 in range(0, len(matrix[numbers])):
                numbers2 = matrix[numbers][numbers1]
                if numbers2 == target:
                    return True
                else:
                    done.append(numbers2)
        
        if target in done:
            return True
        else:
            return False

#Q11. Divide Two Integers
'''

Given two integers dividend and divisor, divide two integers without using multiplication, division, and mod operator.

The integer division should truncate toward zero, which means losing its fractional part. For example, 8.345 would be truncated to 8, and -2.7335 would be truncated to -2.

Return the quotient after dividing dividend by divisor.

Note: Assume we are dealing with an environment that could only store integers within the 32-bit signed integer range: [−231, 231 − 1]. For this problem, if the quotient is strictly greater than 231 - 1, then return 231 - 1, and if the quotient is strictly less than -231, then return -231.

 

Example 1:

Input: dividend = 10, divisor = 3
Output: 3
Explanation: 10/3 = 3.33333.. which is truncated to 3.
Example 2:

Input: dividend = 7, divisor = -3
Output: -2
Explanation: 7/-3 = -2.33333.. which is truncated to -2.
 

Constraints:

-231 <= dividend, divisor <= 231 - 1
divisor != 0
'''
#Solution:

#Approach-1

class Solution:
    def divide(self, dividend: int, divisor: int) -> int:
        a=int(dividend/divisor)
        if a>2147483647:
            return 2147483647
        elif a<-2147483647:
            return -2147483648
        else:
            return a
        

#Approach-2:Long Division in Python


class Solution:
    def divide(self, dividend: int, divisor: int) -> int:
        if divisor == 0:
            raise ValueError("divisor may not be zero")

        if dividend == -2147483648 and divisor == -1:
            return 2147483647

        is_negative = divisor < 0 <= dividend or dividend < 0 <= divisor
        divisor = abs(divisor)
        dividend = abs(dividend)

        if dividend < divisor:
            return 0

        current_dividend = 0
        result = 0
        dividend = [int(digit) for digit in str(dividend)[::-1]]  #  doing this backwards so I can use .pop() instead of .pop(0)
        while dividend:
            if current_dividend < divisor:
                result = int(str(result) + "0")
                current_dividend = int(str(current_dividend) + "0")
                current_dividend += dividend.pop()
            while current_dividend >= divisor:
                result += 1
                current_dividend -= divisor

        if is_negative:
            result = 0 - result

        return result
    
    
    
#Approach-3:Divide Two Integers

class Solution:
    def divide(self, dividend: int, divisor: int) -> int:

        if dividend == 0: return 0
        if abs(divisor) == 1:
            if divisor < 0: 
                result = -dividend
            else:
                result = dividend
        else:
            divid_test, quotient = 0, 0
            while divid_test <= abs(dividend):
                if quotient == 0:
                    divid_test = divid_test + abs(divisor)
                    quotient +=1
                    # initialize
                    ref_divid_test = divid_test
                    ref_quotient = 1
                else:
                    if abs(dividend) - divid_test >= ref_divid_test:
                        divid_test = divid_test + ref_divid_test
                        quotient = quotient + ref_quotient
                        ref_divid_test = ref_divid_test + ref_divid_test
                        ref_quotient = ref_quotient + ref_quotient
                    else:
                        if ref_divid_test > abs(divisor): # reinitialization ref_divid_test
                            ref_divid_test = abs(divisor)
                            ref_quotient = 1
                        else:
                            divid_test = divid_test + abs(divisor)
                            quotient +=1

            if dividend < 0 and divisor > 0:
                result = -(quotient - 1)
            elif dividend >= 0 and divisor < 0:
                result = - (quotient - 1)
            else:
                result = quotient - 1
        if result < -2147483648:
            return -2147483648
        elif result > 2147483647:
            return 2147483647
        else:
            return result
        
#Approach-4: Using Shifting Operator

class Solution(object):

	def check_32_bit(self, n):
		return n < 1 << 31

	def divide(self, dividend, divisor):
		"""
		:type dividend: int
		:type divisor: int
		:rtype: int
		"""

		sign = -1 if ((dividend < 0) ^ (divisor < 0)) else 1
		dividend = abs(dividend)
		divisor = abs(divisor)
		quotient = 0
		if divisor == 1:
			quotient = dividend
		while dividend >= divisor != 1:
			numshift = 0
			while dividend >= (divisor << numshift):
				numshift += 1
			quotient += 1 << (numshift - 1)
			dividend -= (divisor << (numshift - 1))
		quotient = -quotient if sign == -1 else quotient
		if self.check_32_bit(quotient):
			return quotient
		else:
			return -((1 << 31) - 1) if sign == -1 else ((1 << 31) - 1)
        
#Approach-5:The idea is to always add the maximum number of divisors that fit into the dividend by doubling the divisor until you are no longer able fit any more.

class Solution:
    def divide(self, dividend: int, divisor: int) -> int:
        is_negative = (dividend < 0) != (divisor < 0)
        divisor, dividend = abs(divisor), abs(dividend)
        quotient = 0

        while divisor <= dividend:
            the_sum = divisor
            num_divisors_added = 1
            while the_sum + the_sum <= dividend:
                the_sum += the_sum
                num_divisors_added += num_divisors_added
            dividend -= the_sum
            quotient += num_divisors_added

        if is_negative:
            return -min(quotient, 2**31)
        else:
            return min(quotient, 2**31-1)


#Q12.Capacity To Ship Packages Within D Days

'''

A conveyor belt has packages that must be shipped from one port to another within days days.

The ith package on the conveyor belt has a weight of weights[i]. Each day, we load the ship with packages on the conveyor belt (in the order given by weights). We may not load more weight than the maximum weight capacity of the ship.

Return the least weight capacity of the ship that will result in all the packages on the conveyor belt being shipped within days days.

 

Example 1:

Input: weights = [1,2,3,4,5,6,7,8,9,10], days = 5
Output: 15
Explanation: A ship capacity of 15 is the minimum to ship all the packages in 5 days like this:
1st day: 1, 2, 3, 4, 5
2nd day: 6, 7
3rd day: 8
4th day: 9
5th day: 10

Note that the cargo must be shipped in the order given, so using a ship of capacity 14 and splitting the packages into parts like (2, 3, 4, 5), (1, 6, 7), (8), (9), (10) is not allowed.
Example 2:

Input: weights = [3,2,2,4,1,4], days = 3
Output: 6
Explanation: A ship capacity of 6 is the minimum to ship all the packages in 3 days like this:
1st day: 3, 2
2nd day: 2, 4
3rd day: 1, 4
Example 3:

Input: weights = [1,2,3,1,1], days = 4
Output: 3
Explanation:
1st day: 1
2nd day: 2
3rd day: 3
4th day: 1, 1
 

Constraints:

1 <= days <= weights.length <= 5 * 104
1 <= weights[i] <= 500

'''
#Solution :

 #Appraoch-1

# binary search


class Solution:
    def shipWithinDays(self, weights: List[int], days: int) -> int:
        l = 1
        h = sum(weights)
        
        def can_ship_withindays(cap):
            c_w = 0
            day = 0
            for w in weights:
                if w > cap:
                    return False
                if c_w + w <= cap:
                    c_w += w
                else:
                    day +=1
                    c_w = w
                    
            return day+1 <= days 
        
        
        while l <= h:
            mid = l + (h-l)//2
            if not  can_ship_withindays(mid):
                l = mid + 1
            else:
                h = mid - 1
        return l
    
#Appraoch-2

# top-down DP (TLE) and binary search using bisect
# DP

# min_weight(i, max_splits) represents the min weight we need to ship if we're just considering weights[0:(i+1)] and we're allowed to make max_splits splits.

# return min_weight(i=len(weights)-1, max_splits=days-1) . E.g. if we have 5 days, we are allowed to make 4 splits.

# base cases:

# if i < 0, the min cost is 0 since we have nothing left to ship
# if max_splits < 0, this is an infeasible solution (we've made too many splits)
# if max_splits == 0, we just have to ship everything in one go, so the min weight is sum(weights[0:(i+1)]).
# recurrence:

# Consider all possibilities for what to include in the last split.
# Consider not including anything in the last split, then we have min_weight(i, max_splits)=min_weight(i, max_splits-1), which will be strictly worse than including something in the last split, assuming the weights are positive. Therefore, we can ignore this case.
# Consider making the last split {i}, and {i, i-1}, and so on until {i, i-1, ..., 0}.
# If we make the split going from {i, i-1, ..., j}, the maximum weight of the split will be max(min_weight(j, max_splits-1), sum(weights[j:(i+1).
# The best split is the one that results in the min value among all the splits we could make.
# Time: O(len(weights)**2 * d)

# Extra Space: O(len(weights) * d)

import functools

class Solution:
    
    def shipWithinDaysDP(self, weights: List[int], days: int) -> int:
        n = len(weights)
        cum_sum = [0] * n  # cum_sum[i] = sum(weights[0] + weights[1] + ... + weights[i])
        for i in range(n):
            cum_sum[i] = weights[i] + (cum_sum[i-1] if i-1 >= 0 else 0)
            
        def sum_i_j(i, j) -> int:
            nonlocal cum_sum
            # sum weights[i] ... weights[j]
            return cum_sum[j] - (cum_sum[i-1] if i-1 >= 0 else 0)
            
        @functools.lru_cache(maxsize=None)
        def min_weight(i_last_weight: int, max_splits: int) -> int:
            if i_last_weight < 0:
                return 0  # no cost left
            if max_splits < 0:
                return float('inf')  # this is an infeasible solution
            if max_splits == 0:
                return sum_i_j(0, i_last_weight)
            
            min_val = float('inf')
            for cut_ind in range(0, i_last_weight+1):
                candidate = max(min_weight(i_last_weight=cut_ind - 1, max_splits=max_splits-1), sum_i_j(cut_ind, i_last_weight))
                min_val = min(min_val, candidate)
            
            return min_val
        
        return min_weight(i_last_weight=n-1, max_splits=days-1)
    
    
#Appraoch-3


# Binary search using bisect
# To use the bisect module we need something that looks like a sorted array.

# We create a class _A, which behaves like an array.

# _A[i] will be 1 if it's possible to ship within d days using at most i weight per ship, otherwise it will be 0.
# We calculate _A[i] using the _is_feasible helper which tries the greedy strategy of loading each ship as close to weight i as possible, and returns True iff it's possible to use at most d ships where each one has <= i weight.
# The "length" of _A is the maximum weight we could possibly need to put per ship to be able to ship within d days.
# E.g. if d=1 then this would be sum(weights) and if d>=1 it would be something smaller, so we just set it to sum(weights).
# As a result _A will look like [0, 0, 0, ..., 0, 1, 1, ..., 1].
# The index of the first 1 in _A will be the minimum feasible weight.
# We use bisect.bisect_left to find the index of the first 1 in _A. From the docs:

# bisect.bisect_left(a, x, lo=0, hi=len(a), *, key=None) The returned insertion point i partitions the array a into two halves so that all(val < x for val in a[lo : i]) for the left side and all(val >= x for val in a[i : hi]) for the right side.

# in other words, if x is in a (we know there is a 1 in _A because of how we set len(A)), then the returned value will be the index of the first x, in our case the index of the first 1, i.e. the minimum feasible weight.

# Time: O(len(weights) * log(sum(weights)))
# Extra space: O(1)


import bisect

class Solution:
    def shipWithinDays(self, weights: List[int], days: int) -> int:
        arr = _A(weights=weights, n_splits=days-1)
        weight = bisect.bisect_left(arr, 1)  # first feasible weight
        return weight
		
		
class _A:
    def __init__(self, weights: List[int], n_splits: int):
        self._max = sum(weights)
        self._weights = weights
        self._n_splits = n_splits
        
    def __len__(self):
        return self._max + 1
    
    def __getitem__(self, max_weight) -> int:  # first 1 -> min feasible weight
        return 0 if not _is_feasible(weights=self._weights, max_weight=max_weight, n_splits=self._n_splits) else 1
    
    
def _is_feasible(weights: List[int], max_weight:int, n_splits: int) -> bool:
    """ can we ship the weights s.t. each split is <= max_weight using at most n_splits?"""
    this_wt = 0
    for w in weights:
        if w > max_weight:
            return False
        if this_wt + w <= max_weight:
            this_wt += w
        else:
            if n_splits == 0:
                return False
            n_splits -= 1
            this_wt = w
    return True


#Appraoch-4

class Solution:
    
    def shipWithinDays(self, weights, D):
        if not weights:
            return 1
        
        lo = max(weights)
        hi = sum(weights)
        
        while lo < hi:
            capacity = lo + (hi - lo) // 2
            
            # Test this capacity
            current_load = 0
            days = 1
            
            for i in range(len(weights)):
                if weights[i] + current_load > capacity:
                    current_load = weights[i]
                    days += 1
                else:
                    current_load += weights[i]
                    
            if days <= D:
                hi = capacity
            else:
                lo = capacity + 1
                
        return lo
    

#Q14. Minimum Limit of Balls in a Bag

'''

You are given an integer array nums where the ith bag contains nums[i] balls. You are also given an integer maxOperations.

You can perform the following operation at most maxOperations times:

Take any bag of balls and divide it into two new bags with a positive number of balls.
For example, a bag of 5 balls can become two new bags of 1 and 4 balls, or two new bags of 2 and 3 balls.
Your penalty is the maximum number of balls in a bag. You want to minimize your penalty after the operations.

Return the minimum possible penalty after performing the operations.

 

Example 1:

Input: nums = [9], maxOperations = 2
Output: 3
Explanation: 
- Divide the bag with 9 balls into two bags of sizes 6 and 3. [9] -> [6,3].
- Divide the bag with 6 balls into two bags of sizes 3 and 3. [6,3] -> [3,3,3].
The bag with the most number of balls has 3 balls, so your penalty is 3 and you should return 3.
Example 2:

Input: nums = [2,4,8,2], maxOperations = 4
Output: 2
Explanation:
- Divide the bag with 8 balls into two bags of sizes 4 and 4. [2,4,8,2] -> [2,4,4,4,2].
- Divide the bag with 4 balls into two bags of sizes 2 and 2. [2,4,4,4,2] -> [2,2,2,4,4,2].
- Divide the bag with 4 balls into two bags of sizes 2 and 2. [2,2,2,4,4,2] -> [2,2,2,2,2,4,2].
- Divide the bag with 4 balls into two bags of sizes 2 and 2. [2,2,2,2,2,4,2] -> [2,2,2,2,2,2,2,2].
The bag with the most number of balls has 2 balls, so your penalty is 2 an you should return 2.
Example 3:

Input: nums = [7,17], maxOperations = 2
Output: 7
 

Constraints:

1 <= nums.length <= 105
1 <= maxOperations, nums[i] <= 109

'''
#Solution

#Approach-1

class Solution:
    def minimumSize(self, nums: List[int], maxOperations: int) -> int:
        left, right = 1, max(nums)
        while left < right:
            mid = (left + right) // 2
            if sum((n - 1) // mid for n in nums) > maxOperations:
                left = mid + 1
            else:
                right = mid
        return left

    

#Approach-2

#TIME COMPLEXITY - O(logn)
#SPACE COMPLEXITY - O(1)
class Solution:
    def minimumSize(self, nums: List[int], maxOperations: int) -> int:
        low,high=1,max(nums)
        while low<high:
            mid=(low+high)>>1
            if sum([(i-1)//(mid) for i in nums])>maxOperations:
                low=mid+1
            else:
                high=mid
        return low
    
#Approach-3

class Solution:
    def minimumSize(self, nums: List[int], maxOperations: int) -> int:
        
        def possible(penalty) -> bool:
            # whether can achieve penalty with no larger than maxOperations
            ans = 0
            for num in nums:
                q, r = divmod(num, penalty)
                ans += q-1+(r>0)
            return ans<=maxOperations
        
        def bs(lo, hi, function):
            while lo<hi:
                mid = lo+(hi-lo>>1)
                if function(mid):
                    hi=mid
                else:
                    lo=mid+1
            return lo
        
        
        return bs(1, max(nums), possible)
    
    
#Approach-4

import math

class Solution:
    """
    approach:
    we can tackle this problem by applying binary search to find the optimal 
    value of penalty
    min_penalty = 1 (when bag has maximum of 1 ball)
    max_penalty = max(nums)
    """
    def check_fulfilment(self, nums, penalty, maxOperations):
        ops = 0
        for num in nums:
            if num <= penalty:
                continue
            else:
                ops+=math.ceil(num/penalty)-1
            
        return ops <= maxOperations
    
    def minimumSize(self, nums: List[int], maxOperations: int) -> int:
        min_penalty = 1
        max_penalty = max(nums)
        while min_penalty <= max_penalty:
            mid = (min_penalty + max_penalty) // 2
            status = self.check_fulfilment(nums, mid, maxOperations)
            if status:
                max_penalty = mid - 1
            else:
                # need to increase penalty to reduce operations
                min_penalty = mid + 1
        return min_penalty


#Approach-5:Binary Search O(nlog(m))


# Time Complexity: O(n·log(m)) m = max(nums) n = nums.length ∵ binary search requires log(m) iterations 
# Space Complexity: O(1) ∵ only 5 integers are stored in memory
# Approach:

# Guess the maximum number that we can achieve after maxOperations.

# Then check if it is possible where each number requires
# math.ceil(num / guess) - 1 operations to have it's largest bag
# be less than or equal to guess.

# Try this for all of the numbers, if it requires more than maxOperations
# then return false and try guessing a higher number.
# Otherwise return True and guess a lower number.
# Repeat until high == low.

class Solution:
    def minimumSize(self, nums: List[int], maxOperations: int) -> int:
        
        def valid(guess):
            """Returns True if we can achieve guess as the 
            largest number after performing maxOperations"""
            count = 0
            for num in nums:
                if num > guess:
                    count += math.ceil(num / guess) - 1
                    if count > maxOperations:
                        return False
            return True
        
        high = max(nums)
        best = high
        low = 1
        while low <= high:
            g = (low + high) // 2
            if valid(g):
                best = min(best, g)
                high = g - 1
            else:
                low = g + 1
                
        return best


#Q15. Median of Two Sorted Arrays

'''

Given two sorted arrays nums1 and nums2 of size m and n respectively, return the median of the two sorted arrays.

The overall run time complexity should be O(log (m+n)).

 

Example 1:

Input: nums1 = [1,3], nums2 = [2]
Output: 2.00000
Explanation: merged array = [1,2,3] and median is 2.
Example 2:

Input: nums1 = [1,2], nums2 = [3,4]
Output: 2.50000
Explanation: merged array = [1,2,3,4] and median is (2 + 3) / 2 = 2.5.
 

Constraints:

nums1.length == m
nums2.length == n
0 <= m <= 1000
0 <= n <= 1000
1 <= m + n <= 2000
-106 <= nums1[i], nums2[i] <= 106 

'''
#Solution 


#Approach-1

class Solution:
    def findMedianSortedArrays(self, nums1: List[int], nums2: List[int]) -> float:  
        arr = (nums1 + nums2)
        arr.sort()
        median = (0 + (len(arr) - 1)) // 2
        if len(arr) % 2 == 0:
            return (arr[median] + arr[median + 1]) / 2
        return arr[median] 
    
#Approach-2

class Solution:
    def findMedianSortedArrays(self, nums1: List[int], nums2: List[int]) -> float:
        nums3 = nums1+nums2
        nums3.sort()
        if(len(nums3)%2==1):
            return nums3[len(nums3)//2]
        else:
            return ((nums3[len(nums3)//2]+nums3[(len(nums3)//2)-1])/2)
        
        
#Approach-3

class Solution:
    def findMedianSortedArrays(self, nums1: List[int], nums2: List[int]) -> float:
        nums1 = nums1+nums2
        nums1.sort()
        l = len(nums1)
        if l%2!=0:
            return nums1[int(l/2)]
        else:
            return (nums1[int(l/2)]+nums1[int(l/2)-1])/2
        
#Approach-4

# O(n/2) 
# I know, I know, this is not the O(logn) solution :) But this is definitely the most intuitive one

class Solution:
    # @return a float
    def findMedianSortedArrays(self, A, B):
        med1 = med2 = i = j = 0
        n = len(A) + len(B)
        
        while (i + j) <= n / 2:
            if i < len(A) and j < len(B):
                med2 = med1
                if A[i] < B[j]:
                    med1 = A[i]
                    i += 1
                else:
                    med1 = B[j]
                    j += 1
            elif i < len(A):
                med2 = med1
                med1 = A[i]
                i += 1
            elif j < len(B):
                med2 = med1
                med1 = B[j]
                j += 1

        if n % 2 == 0:
            return (med1 + med2) / 2.0
        else:
            return med1


#Q16. Count of Smaller Numbers After Self

'''

Given an integer array nums, return an integer array counts where counts[i] is the number of smaller elements to the right of nums[i].

 

Example 1:

Input: nums = [5,2,6,1]
Output: [2,1,1,0]
Explanation:
To the right of 5 there are 2 smaller elements (2 and 1).
To the right of 2 there is only 1 smaller element (1).
To the right of 6 there is 1 smaller element (1).
To the right of 1 there is 0 smaller element.
Example 2:

Input: nums = [-1]
Output: [0]
Example 3:

Input: nums = [-1,-1]
Output: [0,0]
 

Constraints:

1 <= nums.length <= 105
-104 <= nums[i] <= 104  

'''
#Solution

# Approach-1

# MERGE SORT

class Solution:
    def countSmaller(self, nums: List[int]) -> List[int]:
        def mergeSort(arr,l,r,ind,count):
            if l < r:
                #middle of array
                mid=(l+r)//2
                #recursion both side
                mergeSort(arr,l,mid,ind,count)
                mergeSort(arr,mid+1,r,ind,count)
                #initialize variable
                start=l
                l1=mid+1
                li=[]
                cnt=0
                #Take the smallest
                while l <= mid and l1 <= r:
                    if arr[ind[l]] <= arr[ind[l1]]:
                        li.append(ind[l])
                        count[ind[l]]+=cnt
                        l+=1
                    else:
                        li.append(ind[l1])
                        cnt+=1
                        l1+=1

                #Take the LeftOvers
                while l <= mid:
                    li.append(ind[l])
                    count[ind[l]]+=cnt
                    l+=1

                #Take the LeftOvers
                while l1 <= r:
                    li.append(ind[l1])
                    l1+=1
                
                #changing in index track
                for i in range(start,r+1):
                    ind[i]=li[i-start]
                    
        ind=[i for i in range(len(nums))]
        count=[0 for i in range(len(nums))]
        mergeSort(nums.copy(),0,len(nums)-1,ind,count)
        return count
                            
# Approach-2

# Using Bisect Left O(nlogn)

class Solution:
	def countSmaller(self, nums: List[int]) -> List[int]:
		# Time O(nlogn)
		nums_sorted = sorted(nums)
		res = []

		for i in range(len(nums)):
			# leftmost index that is equal to/greater than the curr num
			idx = bisect_left(nums_sorted, nums[i])
			res.append(idx)
			nums_sorted.pop(idx)

		return res
    
# Approach-3

# SortedList | O(nlogn)


from sortedcontainers import SortedList

class Solution(object):
    def countSmaller(self, nums):
        res = []
        sorted_nums = SortedList(nums)
        for e in nums:
            idx = sorted_nums.index(e)
            res.append(idx)
            sorted_nums.remove(e)
        return res
    
# Approach-4
#Usimng segment Tree
# Segmented Tree

class Solution:
    def countSmaller(self, nums: List[int]) -> List[int]:
        # implement segment tree
        def update(index, value, tree, size):
            index += size  # shift the index to the leaf
            # update from leaf to root
            tree[index] += value
            while index > 1:
                index //= 2
                tree[index] += value

        def query(left, right, tree, size):
            # return sum of [left, right)
            result = 0
            left += size  # shift the index to the leaf
            right += size
            while left < right:
                # if left is a right node
                # bring the value and move to parent's right node
                if left % 2 == 1:
                    result += tree[left]
                    left += 1
                # else directly move to parent
                left //= 2
                # if right is a right node
                # bring the value of the left node and move to parent
                if right % 2 == 1:
                    right -= 1
                    result += tree[right]
                # else directly move to parent
                right //= 2
            return result

        offset = 10**4  # offset negative to non-negative
        size = 2 * 10**4 + 1  # total possible values in nums
        tree = [0] * (2 * size)
        result = []
        for num in reversed(nums):
            smaller_count = query(0, num + offset, tree, size)
            result.append(smaller_count)
            update(num + offset, 1, tree, size)
        return reversed(result)

    
# Approach-5

# Two O(nlogn) Solution: (1) bianry indexed tree; (2) binary search and insort

# Solution 1, we can use segment tree as well:

class BIT:
    def __init__(self, n):
        self.n = n
        self.bit = [0] * (n + 1)
        
    def add(self, idx, x):
        while idx <= self.n:
            self.bit[idx] += x
            idx += idx & (-idx)

    def sum(self, idx):
        ret = 0
        while idx > 0:
            ret += self.bit[idx]
            idx -= idx & (-idx)
        return ret

class Solution:
    def countSmaller(self, nums: List[int]) -> List[int]:
        ans, bit = [0] * len(nums), BIT(2 * 10 ** 4 + 1)
        for i in range(len(nums) - 1, -1, -1):
            v = nums[i] + 10 ** 4 + 1
            ans[i] = bit.sum(v - 1)
            bit.add(v, 1)
        return ans
    
    
# Solution 2:

from bisect import bisect_left, insort

class Solution:
    def countSmaller(self, nums: List[int]) -> List[int]:
        ans, cur = [0] * len(nums), [nums[-1]]
        for i in range(len(nums) - 2, -1, -1):
            ans[i] = bisect_left(cur, nums[i])
            insort(cur, nums[i])
        return ans

 
#Q17. Max Sum of Rectangle No Larger Than K

'''

Given an m x n matrix matrix and an integer k, return the max sum of a rectangle in the matrix such that its sum is no larger than k.

It is guaranteed that there will be a rectangle with a sum no larger than k.

 

Example 1:


Input: matrix = [[1,0,1],[0,-2,3]], k = 2
Output: 2
Explanation: Because the sum of the blue rectangle [[0, 1], [-2, 3]] is 2, and 2 is the max number no larger than k (k = 2).
Example 2:

Input: matrix = [[2,2,-1]], k = 3
Output: 3
 

Constraints:

m == matrix.length
n == matrix[i].length
1 <= m, n <= 200
-100 <= matrix[i][j] <= 100
-105 <= k <= 105
 

Follow up: What if the number of rows is much larger than the number of columns?   
'''
#Solution 

#Approach-1

# Prefix sums and binary search
# This is an implementation of a solution provided here.

'''
Use two pointers to generate prefix sums of each rows. Left pointer will go from 0 to n and right pointer will go from left to n. By calculating prefix sums for each row, we reduce all rectangle from 2d to 1d where each rectangle is represented by 1d array of rows prefix sum.

For each row prefix sum, we will calculate column prefix sum and use binary search to find maximum area lesser than k. Start by initialize a list to store previously calculated column prefix sum. Iterate through all values in the row prefix sum. At each iteration, calculate the column prefix sum and check if there exists a previous column prefix sum that is larger than the different between the current column sum and k but the smallest among all previous prefix sums that are greater than the different. Use binary search to find such values. If there is, update the result.

Ex: Given matrix = [[1,0,1],[0,-2,3]], k = 2
l   r   rowSums     colSums     area        res        
0   0   [1, 0]      [1, 1]      [1,  1]     1
0   1   [1, -2]     [1, -1]     [1, -1]     1
0   2   [2, 1]      [2, 3]      [2, None]   2
1   1   [0, -2]     [0, -2]     [0, -2]     2
1   2   [1, 1]      [1, 2]      [1, 2]      2
2   2   [1, 3]      [1, 4]      [1, None]   2
P.S. Kadane Algorithm: Given a list of numbers. You can calculate the maximum area ended at each number by taking the maximum between the current number vs the maximum area of previous number plus the current number.

    area(i) = max(area(i-1) + nums[i], nums[i])
'''

# Complexity:
# Time: O(m**2 n**2)
# Space: O(m)

from bisect import bisect_right, insort
from math import inf


class Solution:
    def maxSumSubmatrix(self, matrix: list[list[int]], k: int) -> int:

        # Get the length of rows and colums
        m, n = len(matrix), len(matrix[0])

        # Initialize the result
        res = -inf

        # Iterate the left pointer from 0 to n
        for l in range(n):

            # Initialize the row prefix sum
            rowSums = [0] * m

            # Iterate the right pointer from left to n
            for r in range(l, n):

                # Calculate the row prefix sum from left to right
                for i in range(m):
                    rowSums[i] += matrix[i][r]

                # Calculate the column prefix sums
                # Initialize a list to store previous column prefix sum
                colSums = [0]

                # Intialize the column prefix sum
                colSum = 0

                # Iterate through all row prefix sums
                for rowSum in rowSums:

                    # Add the current row prefix sum to the column prefix sum
                    colSum += rowSum

                    # Calculate the different between the column prefix sum and k
                    diff = colSum - k

                    # Perform a binary search to find an index of a value is larger but cloest to the different among previously calculated column prefix sums
                    idx = bisect_right(colSums, diff)

                    # Check if the different exists among the previously calculated column prefix sums
                    if idx - 1 >= 0 and colSums[idx - 1] == diff:

                        # If yes, update the result
                        res = max(res, colSum - colSums[idx - 1])

                        # End the search because we found the largest possible result
                        return k

                    # Else, if the different does not exist among the previously calculated column prefix sums, check if there is a previously calculated column prefix sum larger than the different
                    elif idx != len(colSums):

                        # If yes, update the result with the new area if it is larger than previous result
                        res = max(res, colSum - colSums[idx])

                    # Insert the current column prefix sum into the list while maintaining the sorted order
                    insort(colSums, colSum)

        return res

    
#Approach-2

# built-in function 


# I took the standard-solution approach. However I found the usage of the built-in bisect_left function seem to be necessary to pass the tests. I tried replacing bisect_left with a standard binary search implementation (i j pointers) and it got TLE. Doing it by hand is a lot slower than using built-ins I guess...

from sortedcontainers import SortedSet

class Solution:
    def maxSumSubmatrix(self, matrix: List[List[int]], k: int) -> int:
        m, n = len(matrix), len(matrix[0])
        
		# Function to find the subarray sum that is closest to U in the given 1-D array "psr"
        def maxSumSubarray(psr, U: int) -> int:
            ss, ans = SortedSet([0]), -999999
            for c in range(n):
                diff = psr[c] - U
                if diff == 0: return U
                idx = ss.bisect_left(diff)
                if idx < len(ss): ans = max(ans, psr[c]-ss[idx])
                ss.add(psr[c])
            return ans
        
        res = -999999
        
        # construct row-wise prefix sum matrix
        ps = [[] for x in range(m)]
        for r in range(m):
            ps[r].append(matrix[r][0])
            for c in range(1, n):
                ps[r].append(ps[r][-1]+matrix[r][c])
        
		# Run over merged rows
        for router in range(m):
            psr = [0 for x in range(n)]
            for rinner in range(router, m):
                psr = [ x+y for x, y in zip(psr, ps[rinner]) ]  
                res = max(maxSumSubarray(psr, k), res)
                if res == k: return k
                
        return res
    

#Q18. . Split Array Largest Sum

'''

Given an array nums which consists of non-negative integers and an integer m, you can split the array into m non-empty continuous subarrays.

Write an algorithm to minimize the largest sum among these m subarrays.

 

Example 1:

Input: nums = [7,2,5,10,8], m = 2
Output: 18
Explanation:
There are four ways to split nums into two subarrays.
The best way is to split it into [7,2,5] and [10,8],
where the largest sum among the two subarrays is only 18.
Example 2:

Input: nums = [1,2,3,4,5], m = 2
Output: 9
Example 3:

Input: nums = [1,4,4], m = 3
Output: 4
 

Constraints:

1 <= nums.length <= 1000
0 <= nums[i] <= 106
1 <= m <= min(50, nums.length)  

'''

#Solution 

# Approach-1
# Parametric Search
# binary-search

class Solution:
    def splitArray(self, nums: List[int], m: int) -> int:
        lo, hi = max(nums), sum(nums)
        while lo < hi:
            mid = (lo+hi)//2
            tot, cnt = 0, 1
            for num in nums:
                if tot+num<=mid: 
                    tot += num
                else:
                    tot = num
                    cnt += 1
            if cnt>m: lo = mid+1
            else: hi = mid
        return hi


# Approach-2

# Binary Search 

# You can use binary search 

# binary search:

class Solution:
    def splitArray(self, nums: List[int], m: int) -> int:
        l, r = max(nums), sum(nums)
        while l < r:
            mid = (l + r) // 2
            cur_sum = 0
            cnt = 0
            for n in nums:
                if cur_sum + n <= mid:
                    cur_sum += n
                else:
                    cur_sum = n
                    cnt += 1
            if cnt + 1 > m: l = mid + 1
            else: r = mid
        return r

# Approach-3
# dp to solve this problem.
# dp:

class Solution:
    def splitArray(self, nums: List[int], m: int) -> int:
        dp = [[-1] * (m + 1) for _ in nums]
        
        def dfs(idx: int, m: int) -> int:
            if dp[idx][m] != -1:
                return dp[idx][m]
            if m == 1:
                dp[idx][m] = sum(nums[idx:])
                return dp[idx][m]
            res, lsum = float('inf'), nums[idx]
            for r in range(idx + 1, len(nums) - m + 2):
                res = min(max(lsum, dfs(r, m-1)), res)
                lsum += nums[r]
                if lsum >= res: break

            dp[idx][m] = res
            return dp[idx][m]
        
        return dfs(0, m)
 

# Approach-4
# Binary Search simple

class Solution:
    def splitArray(self, nums: List[int], m: int) -> int:
        
        def helper(n):
            total=1
            cur=0
            for el in nums:
                if cur+el<=n:
                    cur+=el
                else:
                    total+=1
                    cur=el
            return total<=m
        
        l=max(nums)
        r=sum(nums)
        while l<r:
            mid=(l+r)//2
            if helper(mid):
                r=mid
            else:
                l=mid+1
        return l
    
# Approach-5

# DP O(n) space optimization


# The m dimension can be optimized because new [j] value only depends on [j - 1], so a 1-D dp array is enough for this problem.
# Note that the calculaiton sequence for i is from large to small, because calculate new f[i] will use old f[k] values in which k < i.

class Solution(object):
    def splitArray(self, nums, m):
        """
        :type nums: List[int]
        :type m: int
        :rtype: int
        """
        if not nums or not m or len(nums) < m:
            return
        
        n = len(nums)
        presum = [0] * (n + 1)
        for i in range(n):
            presum[i + 1] = presum[i] + nums[i]
        
        f = [float("inf")] * (n + 1)
        f[0] = 0
        
        for j in range(m):
            for i in range(n, 0, -1): # must be from n to 1, otherwise results will be wrong
                for k in range(j - 1, i):
                    f[i] = min(f[i], max(f[k], presum[i] - presum[k]))
        
        return f[n]
    

#Q19. Shortest Subarray with Sum at Least K

'''

Given an integer array nums and an integer k, return the length of the shortest non-empty subarray of nums with a sum of at least k. If there is no such subarray, return -1.

A subarray is a contiguous part of an array.

 

Example 1:

Input: nums = [1], k = 1
Output: 1
Example 2:

Input: nums = [1,2], k = 4
Output: -1
Example 3:

Input: nums = [2,-1,2], k = 3
Output: 3
 

Constraints:

1 <= nums.length <= 105
-105 <= nums[i] <= 105
1 <= k <= 109

'''
#Solution

#Approach-1

# Using Sliding Window, Prefix Sum w/ Monotonic Deque with comments

class Solution:
    def shortestSubarray(self, nums: List[int], k: int) -> int:
        n = len(nums)
        if n == 1:
            return 1 if nums[0] >= k else -1
        
        best_len = n + 1 # len of array
        psum = [0] * (n + 1) # prefix sums from left to right with 0 indexex zero sum
        for i in range(1, n + 1):
            psum[i] = psum[i - 1] + nums[i - 1] # calculates prefix sum
        
        mono_queue = collections.deque() # stores indexes
        
        for i in range(n + 1): # go through the prefix sums
            while mono_queue and psum[i] - psum[mono_queue[0]] >= k: # checking if i qualifies as an end point
                best_len = min(best_len, i - mono_queue.popleft()) # this will be the first end point to qualify (shortest) for point at the beginning of queue - drop the point as even if it qualifies for future points the len will be longer and sub-optimal
            while mono_queue and psum[i] <= psum[mono_queue[-1]]: # any point with lower prefix sum and later appearance in the arr will be a better starting point
                mono_queue.pop() # as it will lead to higher sum with a shorter range - all previous start points that are higher in value are not needed
            mono_queue.append(i)
            
        if best_len == n + 1:
            return -1
        return best_len
    
    
#Approach-2

# Sliding Window

'''
We can rephrase this as a problem about the prefix sums of A. Let P[i] = A[0] + A[1] + ... + A[i-1]. We want the smallest y-x such that y > x and P[y] - P[x] >= K.

Motivated by that equation, let opt(y) be the largest x such that P[x] <= P[y] - K. We need two key observations:

If x1 < x2 and P[x2] <= P[x1], then opt(y) can never be x1, as if P[x1] <= P[y] - K, then P[x2] <= P[x1] <= P[y] - K but y - x2 is smaller. This implies that our candidates x for opt(y) will have increasing values of P[x].

If opt(y1) = x, then we do not need to consider this x again. For if we find some y2 > y1 with opt(y2) = x, then it represents an answer of y2 - x which is worse (larger) than y1 - x.

Algorithm

Maintain a "monoqueue" of indices of P: a deque of indices x_0, x_1, ... such that P[x_0], P[x_1], ... is increasing.

When adding a new index y, we'll pop x_i from the end of the deque so that P[x_0], P[x_1], ..., P[y] will be increasing.

If P[y] >= P[x_0] + K, then (as previously described), we don't need to consider this x_0 again, and we can pop it from the front of the deque.
'''
# Time Complexity: O(N)O(N), where NN is the length of A.

# Space Complexity: O(N)O(N).



class Solution(object):
    def shortestSubarray(self, A, K):
        N = len(A)
        P = [0]
        for x in A:
            P.append(P[-1] + x)

        #Want smallest y-x with Py - Px >= K
        ans = N+1 # N+1 is impossible
        monoq = collections.deque() #opt(y) candidates, represented as indices of P
        for y, Py in enumerate(P):
            #Want opt(y) = largest x with Px <= Py - K
            while monoq and Py <= P[monoq[-1]]:
                monoq.pop()

            while monoq and Py - P[monoq[0]] >= K:
                ans = min(ans, y - monoq.popleft())

            monoq.append(y)

        return ans if ans < N+1 else -1
    

#Approach-3

# O(N)

class Solution:
    def shortestSubarray(self, A, K):
        import collections
        from itertools import accumulate

        A_sum = [0] + list(accumulate(A))
        
        
        ret = len(A) + 1
        idx_checking = collections.deque()
        for idx, val in enumerate(A_sum):
            #removing from right to left if the right value is less than val
            # this keeps the deque decreasing
            while idx_checking and val < A_sum[idx_checking[-1]]:
                idx_checking.pop()

            #removing from left to right if the condition satisfied
            while idx_checking and val - A_sum[idx_checking[0]] >= K:
                ret = min(ret, idx - idx_checking.popleft())

            idx_checking.append(idx)
        
        return ret if ret < len(A) + 1 else -1

#Approach-4

# O(N). Explained all assumptions needed.

'''
The solution for this question took me a while to understand.
I will try to explain this as simple as possible. There are a few concepts you have to understand to piece everything together.

(Concept 1): How to find subarray sum given an integer array A for A[i...j] quickly?

Given an array A, if we want to find the subarray sum for A[i...j], we can traverse the array once and record all the prefix sum at all indicies.

Call this array P.

P[i] represents the sum of all elements from A[0...i]

                   i      j
|-----------------|--------|
                    diff
If we want to find sum(A[i...j]), this is equivalent to finding P[j] - P[i - 1]

(Concept 2): How to find a subarray such that it's sum is at least K?

Suppose we recorded the prefix sums of A in array P.

                 i         j
|-----------------|---------|
                    sum >= k
Given index j, we need to find a prefix sum in P such that

P[j] - P[i] >= k
This is because P[j] - P[i] represents subarray sum of P[i + 1 ... j]. If such prefix exists, we know there is a subarray with sum >= k.

We will rearrange this equation to P[j] - k >= P[i]. This way, if we are at P[j], we just have to look over indicies smaller than j and "test" them with this equation for all i.

(Concept 3): Determine what assumptions can be made

Suppose we are now traversing array P with index j, we can already look back on items with indicies < j and find out shortest subarray using concept 2.

This takes O(n^2). How can we do better?

                 j
P [             |     ]
  |-------------|
     storage
This is hardest part. Let's say we store indicies < j in storage.

i) For all index i in storage, we should NEVER find an index i' such that
P[i'] <= P[i] and i' > i. Remember what we want to test: P[j] - k >= P[i]

If i' exists and P[i'] <= P[i] and i' > i, there is no value in storing i because P[j] - k >= P[i] >= P[i']. i' is closer to j and is a better answer.

ii) For all index i in storage, any i' < i implies P[i'] < P[i]. Otherwise, what we derived in i) will be contradicted.

This suggest our storage should be STRICTLY INCREASING P values.
Now, when we are at j, we just have to eliminate all values in storage that violates ii)

'''

from collections import deque
class Solution:
    
    def shortestSubarray(self, A: List[int], K: int) -> int:
        n = len(A)
        P = [0 for _ in range(n)]
        P[0] = A[0]

        for i in range(1, n):
            P[i] = P[i - 1] + A[i]
        
        res = float("inf")
        
        storage = deque([(-1, 0)])
        
        for j in range(n):
            
            while (storage and storage[0][1] <= P[j] - K):
                res = min(res, j - storage.popleft()[0])
                
            while (storage and storage[-1][1] >= P[j]):
                storage.pop()
            
            storage.append((j, P[j]))
            
        return -1 if res == float("inf") else res


        
    
