
#Sliding Window

# Q1.Longest Substring with At Least K Repeating Characters

'''

Given a string s and an integer k, return the length of the longest substring of s such that the frequency of each character in this substring is greater than or equal to k.

 

Example 1:

Input: s = "aaabb", k = 3
Output: 3
Explanation: The longest substring is "aaa", as 'a' is repeated 3 times.
Example 2:

Input: s = "ababbc", k = 2
Output: 5
Explanation: The longest substring is "ababb", as 'a' is repeated 2 times and 'b' is repeated 3 times.
 

Constraints:

1 <= s.length <= 104
s consists of only lowercase English letters.
1 <= k <= 105

'''
#Solution 

#Approach 1: Recursion/Divide and Conquer


class Solution:
    def longestSubstring(self, s: str, k: int) -> int:
		# initialize the maxlength to zero
        maxlength = 0
        
        def checkLongest(s):
            nonlocal maxlength
			# count the letter frequency and sort by frequency in ascending order
            sCounted = Counter(s)
            charFreqSorted = sorted(sCounted.items(), key=lambda x:x[1])
		
            if charFreqSorted[0][1] < k:
                # if the first letter (lowest freq) has a frequency less than k, split the string into substrings with the letter as separator
                tmp = s.split(sep=charFreqSorted[0][0])
                for item in tmp:
				# skipping substrings with length shorter than k
                    if len(item) >= k:
					# recursively call the function on each valid substring
                        checkLongest(item)
            else:
                # since the letter with the lowest frequency has a frequency no less than k, the entire string is valid
                maxlength = max(maxlength, len(s))
        
        checkLongest(s)
        
        return maxlength
    
    
#Approach 2:sliding-window : Version w/o "counter" optimizations:

# Not sure why it's marked as "medium". SW for this one is for sure one of those medium++ problems.

# Simple sliding window will not work as we cannot quickly figure out conditions for expanding/shrinking.
# aaabb, k=3 Should we include b? maybe we should include bb? Maybe we should shrink aaa and work only with bb?

# The problem here is that we do not know if we can form from bb the sequence bbb in the future, or if we can form bbb, but it will be something like bbcb, which does not meet our initial condition that all char frequencies in a substring should be >= k

# How to solve it? The idea is not that easy-coming. It took a while to grasp it.

# What exactly should we track in the sliding window?

# Chars. Which chars? max number of allowed unique chars.

# !!! max number of allowed unique chars needs a clarification: !!!
# !!! We are talking about aaaaabbcccc and unique chars are a, b, and c, so unique_chars_count = 3 and not their frequency count !!! frequency of a in the string is 5.

# Let's see the example:

# aaabb, max_unique_chars_allowed = 1, k = 3.

# We can count 3 a OR 2 b and max unique chars count in the string is 2. Now we can clearly see the conditions: expand until unique_chars_count < 2. If overflow, shrink the window and repeat.

# This is solving the initial problem with the sliding window conditions for expanding/shrinking.

# Now what?

# Repeat the same process for max_unique_chars_allowed = 2, 3, 4, ... and how many unique chars do we have in the initial problem? 26 (lowercase). We can reduce 26 to count of unique chars in the strings later.

# This is S̶P̶A̶R̶T̶A̶ brute-force approach on all unique chars counts!

# Hopefully now you clearly see that we are looking for a max window len in the multitude of all sliding windows with unique chars counts ranging from 1 to max_unique_chars_in_the_string (could be 26)...

# Yes, it's going to be O(26 * n), but it's still O(n).

# </!/\!\/!\> I think it's too smart and hard to figure out quickly the approach. </!\/!/\!\>

# Intuitively from experience we know that it's going to be the sliding window approach, but that it's going to be a brute force over sliding windows is something new, like 'soft deletions' in Sliding Window Median problem.

# P.S. D&C is easy/medium. The sliding window is harder.


class Solution:
    def longestSubstring(self, s: str, k: int) -> int:
        N = len(s)
        
        char_freq = Counter(s)
        
        max_len = 0
        for max_allowed_unique_chars in range(1, len(char_freq.keys()) + 1):
            char_freq = defaultdict(int)
            
            current_unique_chars = 0
            start = 0
            for end in range(N):
				# add new char to the window
                char_freq[s[end]] += 1
                
                if char_freq[s[end]] == 1:
                    current_unique_chars += 1
                
                while current_unique_chars > max_allowed_unique_chars:				
					# remove chars until we get current_unique_chars == max_allowed_unique_chars
                    char_freq[s[start]] -= 1
                    
                    if char_freq[s[start]] == 0:
                        del char_freq[s[start]]
                        current_unique_chars -= 1
                    
                    start += 1

				# are all char_freqs >= k?
                if all(v >= k for v in char_freq.values()):
                    max_len = max(max_len, end - start + 1)
        
        return max_len
    
    
#Approach 3:sliding-window :Version with "counter" optimizations:

class Solution:
    def longestSubstring(self, s: str, k: int) -> int:
        N = len(s)
        max_len = 0
        for max_allowed_unique_chars in range(1, len(Counter(s)) + 1):
            freq_count = defaultdict(int)
            current_unique_chars = 0
            freq_count_greater_or_equal_k = 0
            start = 0
            for end in range(N):
                freq_count[s[end]] += 1
                if freq_count[s[end]] == 1: current_unique_chars += 1
                if freq_count[s[end]] == k: freq_count_greater_or_equal_k += 1
                
                while current_unique_chars > max_allowed_unique_chars:
                    if freq_count[s[start]] == 1: current_unique_chars -= 1
                    if freq_count[s[start]] == k: freq_count_greater_or_equal_k -= 1
                    freq_count[s[start]] -= 1
                    start += 1

                if freq_count_greater_or_equal_k == current_unique_chars:
                    max_len = max(max_len, end - start + 1)
        
        return max_len

#Approach 4:

class Solution:
    def longestSubstring(self, s: str, k: int) -> int:
        n = len(s)
        
        #Base Case
        if n==0 and n<k:
            return 0
        if k<=1:
            return n
            
        counts = Counter(s)
        left = 0
        while left<n and counts[s[left]] >= k:
            left +=1
        if left > n-1:
            return left
        ls1 = self.longestSubstring(s[0:left], k)
        while left<n and counts[s[left]] < k:
            left +=1
        ls2 = self.longestSubstring(s[left:],k) if left<n else 0
        return max(ls1, ls2)
    
    
#Approach 5:recursive solution
class Solution:
    def longestSubstring(self, s: str, k: int) -> int:
        self.longest = 0
        def search(s, k):
            if len(s) <= self.longest:
                return
            counter = collections.Counter(s)
            mini, char = min([(val, key) for key, val in counter.items()])
            if mini >= k:
                self.longest = len(s)
                return
            strs = s.split(char)
            for t in strs:
                search(t, k)
                
        search(s, k)
        return self.longest


#Q2.Max Consecutive Ones III

'''

Given a binary array nums and an integer k, return the maximum number of consecutive 1's in the array if you can flip at most k 0's.

 

Example 1:

Input: nums = [1,1,1,0,0,0,1,1,1,1,0], k = 2
Output: 6
Explanation: [1,1,1,0,0,1,1,1,1,1,1]
Bolded numbers were flipped from 0 to 1. The longest subarray is underlined.
Example 2:

Input: nums = [0,0,1,1,0,0,1,1,1,0,1,1,0,0,0,1,1,1,1], k = 3
Output: 10
Explanation: [0,0,1,1,1,1,1,1,1,1,1,1,0,0,0,1,1,1,1]
Bolded numbers were flipped from 0 to 1. The longest subarray is underlined.
 

Constraints:

1 <= nums.length <= 105
nums[i] is either 0 or 1.
0 <= k <= nums.length

'''

#Solution 

#Approach-1:using sliding windows TC:(N) SC(1)

class Solution:
    def longestOnes(self, nums: List[int], k: int) -> int:
        start  = 0
        mini = 0
        maxFreq = 0
        for end in range(len(nums)):
            if(nums[end] == 1):
                maxFreq += 1
            if((end - start + 1) - maxFreq ) > k:
                if(nums[start] == 1):
                    maxFreq -= 1

                start += 1
            mini = max(mini , end - start + 1)
        return mini
  


#Approach-2:sliding window  O(n)

class Solution:
    def longestOnes(self, nums: List[int], k: int) -> int:
        l =0 
        r = 0
        ans = -1
        s = nums[0]
        while l < len(nums) and r < len(nums):
            if  r-l+1 - s <= k: # number of zero less or equal to k - expand window
                ans = max(ans,  r-l+1)
                r +=1
                if r < len(nums):
                    s+=nums[r]
            else: # shrink widnow 
                s-=nums[l]
                l +=1
        return ans

#Approach-3:
class Solution:
    def longestOnes(self, A: List[int], K: int) -> int:
        zero_idxes = [-1] + [i for i, v in enumerate(A) if v == 0] + [len(A)]
        if len(zero_idxes) - 2 <= K:
            return len(A)
        res = 0
        for i in range(1, len(zero_idxes) - K):
            left = zero_idxes[i - 1]
            right = zero_idxes[i + K]
            res = max(res, right - left - 1)
        return res
    

    
#Approach-4: sliding window solution: consecutive means subarray

class Solution:
    # maximum number of consecutive 1's in the array if you can flip at most k 0's
    # = maximum subarray length with at k 0s
    # Then it's a sliding window problem
    # rule for sliding window:
    # keep count of zeros inside the window
    # i, j
    # if nums[j] == 1 and count <= k: j += 1
    # if nums[j] == 0 and count <= k: j += 1, count += 1
    # if nums[j] == 1 and count > k: i += 1
    # if nums[j] == 0 and count > k: i += 1, count -= 1
    def longestOnes(self, nums: List[int], k: int) -> int:
        i, j, n, count, result = 0, 0, len(nums), 0, 0
        while j < n:
            if count <= k:
                if nums[j] == 0:
                    count += 1
                if count <= k:
                    result = max(result, j-i+1)
                j += 1
            else:
                if nums[i] == 0:
                    count -= 1
                i += 1
        return result
    
#Approach-5:read and understand | sliding window

class Solution:
    def longestOnes(self, nums: List[int], k: int) -> int:
        cnt, ans, i = 0, 0, 0
        for j in range(len(nums)):
            if nums[j] == 0:
                cnt += 1
            while cnt > k:
                if nums[i] == 0:
                    cnt -= 1
                i = i+1
            ans = max(ans, j-i+1)
        return ans

#Q3.Grumpy Bookstore Owner

'''

There is a bookstore owner that has a store open for n minutes. Every minute, some number of customers enter the store. You are given an integer array customers of length n where customers[i] is the number of the customer that enters the store at the start of the ith minute and all those customers leave after the end of that minute.

On some minutes, the bookstore owner is grumpy. You are given a binary array grumpy where grumpy[i] is 1 if the bookstore owner is grumpy during the ith minute, and is 0 otherwise.

When the bookstore owner is grumpy, the customers of that minute are not satisfied, otherwise, they are satisfied.

The bookstore owner knows a secret technique to keep themselves not grumpy for minutes consecutive minutes, but can only use it once.

Return the maximum number of customers that can be satisfied throughout the day.

 

Example 1:

Input: customers = [1,0,1,2,1,1,7,5], grumpy = [0,1,0,1,0,1,0,1], minutes = 3
Output: 16
Explanation: The bookstore owner keeps themselves not grumpy for the last 3 minutes. 
The maximum number of customers that can be satisfied = 1 + 1 + 1 + 1 + 7 + 5 = 16.
Example 2:

Input: customers = [1], grumpy = [0], minutes = 1
Output: 1
 

Constraints:

n == customers.length == grumpy.length
1 <= minutes <= n <= 2 * 104
0 <= customers[i] <= 1000
grumpy[i] is either 0 or 1.
'''

#Solution 

#Approach-1:prefix sum + sliding (fix-length) window

class Solution:
    # clearly, a sliding window problem
    # Basically turning window of size minutes to all 0 and find out which one has the largest gain
    
    def maxSatisfied(self, customers: List[int], grumpy: List[int], minutes: int) -> int:
        prefix_grumpy, prefix, n = [0], [0], len(customers)
        for i, customer in enumerate(customers):
            if grumpy[i] == 0:
                prefix_grumpy.append(prefix_grumpy[-1] + customer)
            else:
                prefix_grumpy.append(prefix_grumpy[-1])
            prefix.append(prefix[-1] + customer)
        max_so_far = 0
        max_index = -1
        for i in range(n - minutes + 1):
            gain = prefix[i+minutes] - prefix[i] - prefix_grumpy[i+minutes] + prefix_grumpy[i]
            if gain > max_so_far:
                max_so_far = gain
                max_index = i
        result = prefix_grumpy[max_index] - prefix_grumpy[0] + prefix[max_index + minutes] - prefix[max_index] + prefix_grumpy[-1] - prefix_grumpy[max_index + minutes]
        return result
    
    
#Approach-2: window of grumpy days

class Solution:
    
    def getFirstWindow(self, c, g, m):
        nos, l, r = 0, 0, 0
        
        while r < m - 1:
            if g[r] == 1:
                nos += c[r]
            r += 1
        return (nos, l, r)
    
    def getGrumpiestWindow(self, nos, l, r, g, c):
        maxl, maxr, maxnos = l, r, nos
        while r < len(g) - 1:
            if g[l] == 1:
                nos -= c[l]
            l += 1
            r += 1
            if g[r] == 1:
                nos += c[r]
            if nos > maxnos:
                maxnos = nos
                maxl = l
                maxr = r
                
        return (maxl, maxr, maxnos)
    
    def maxSatisfied(self, customers: List[int], grumpy: List[int], minutes: int) -> int:
        nos, l, r = self.getFirstWindow(customers, grumpy, minutes)
        maxl, maxr, maxnos = self.getGrumpiestWindow(nos, l, r, grumpy, customers)

        answer = 0
        for i in range(len(customers)):
            if grumpy[i] == 0 or (i >= maxl and i <= maxr):
                answer += customers[i]
        return answer
           

#Approach-3:class Solution:
class Solution:
    def maxSatisfied(self, customers: List[int], grumpy: List[int], minutes: int) -> int:
        satisfy, extra, max_extra = 0, 0, 0
        n = len(customers)
        
        for i in range(n):
            if not grumpy[i]: # not grumpy 
                satisfy += customers[i] # satisfy
            else:
                extra += customers[i] # take extra customers
            
            if i >= minutes and grumpy[i - minutes] == 1: # if times is out, he became angry
                extra -= customers[i - minutes] # remove extra joined customers
            
            max_extra = max(max_extra, extra) # keep what is maximum extra people joined
        
        return satisfy + max_extra # satisfied + extra
     
#Approach-4:Rolling sum.

# The way I approached this problem was to split it into 2 smaller problems.

# The first involves counting how many customers are already satisfied, i.e. those where the shopkeeper is not grumpy. I also set any slots with already satisfied customers to 0, so that we will be left with only the currently unsatisfied customers in the list.

# For the second part, the array now only contains customers who will not be satisfied. We are able to make X adjacent times “happy”, so we want to find the subarray of length X that has the most customers. We can just keep a rolling sum of the last X customers in the array, and then the best solution is the max the rolling sum ever was.

# Finally we return the sum of the 2 parts: the customers who were already satisfied, and the maximum number who can be made satisfied by stopping the shop keeper from being grumpy for X time.

# Note that both parts can be combined into a single loop, but I felt this way was probably easier for understanding, and both are still O(n) time. I'll shortly include code for how to merge it all together.

class Solution:
    def maxSatisfied(self, customers: List[int], grumpy: List[int], X: int) -> int:
        
        # Part 1 requires counting how many customers
        # are already satisfied, and removing them
        # from the customer list.
        already_satisfied = 0
        for i in range(len(grumpy)):
            if grumpy[i] == 0: #He's happy
                already_satisfied += customers[i]
                customers[i] = 0
        
        # Part 2 requires finding the optinal number
        # of unhappy customers we can make happy.
        best_we_can_make_satisfied = 0
        current_satisfied = 0
        for i, customers_at_time in enumerate(customers):
            current_satisfied += customers_at_time # Add current to rolling total
            if i >= X: # We need to remove some from the rolling total
                current_satisfied -= customers[i - X]
            best_we_can_make_satisfied = max(best_we_can_make_satisfied, current_satisfied)
        
        # The answer is the sum of the solutions for the 2 parts.
        return already_satisfied + best_we_can_make_satisfied

#Approach-5: sliding window w/ explanation, 9 lines

# i is the start of the window, j is the end. Only increase i if the max window length has been reached. Keep track of the maximum newly satisfied so far and finally return the sum of the originaly satisfied and maximum newly satisfied.

class Solution(object):
    def maxSatisfied(self, customers, grumpy, X):
        i = original_satisfied = new_satisfied = max_new_satisfied = 0
        for j in range(len(customers)):
            original_satisfied += customers[j] * (not grumpy[j])
            new_satisfied += customers[j] * grumpy[j]                        
            if j - i == X:
                new_satisfied -= customers[i] * grumpy[i]
                i += 1
            max_new_satisfied = max(max_new_satisfied, new_satisfied)
        return original_satisfied + max_new_satisfied


#Q4. Sliding Window Median
'''

The median is the middle value in an ordered integer list. If the size of the list is even, there is no middle value. So the median is the mean of the two middle values.

For examples, if arr = [2,3,4], the median is 3.
For examples, if arr = [1,2,3,4], the median is (2 + 3) / 2 = 2.5.
You are given an integer array nums and an integer k. There is a sliding window of size k which is moving from the very left of the array to the very right. You can only see the k numbers in the window. Each time the sliding window moves right by one position.

Return the median array for each window in the original array. Answers within 10-5 of the actual value will be accepted.

 

Example 1:

Input: nums = [1,3,-1,-3,5,3,6,7], k = 3
Output: [1.00000,-1.00000,-1.00000,3.00000,5.00000,6.00000]
Explanation: 
Window position                Median
---------------                -----
[1  3  -1] -3  5  3  6  7        1
 1 [3  -1  -3] 5  3  6  7       -1
 1  3 [-1  -3  5] 3  6  7       -1
 1  3  -1 [-3  5  3] 6  7        3
 1  3  -1  -3 [5  3  6] 7        5
 1  3  -1  -3  5 [3  6  7]       6
Example 2:

Input: nums = [1,2,3,4,2,3,1,4,2], k = 3
Output: [2.00000,3.00000,3.00000,3.00000,2.00000,3.00000,2.00000]
 

Constraints:

1 <= k <= nums.length <= 105
-231 <= nums[i] <= 231 - 1

'''

#Solution 

#Approach 1: SortedList...

from sortedcontainers import SortedList
class Solution:
    def medianSlidingWindow(self, x: List[int], k: int) -> List[float]:
        l=len(x)
        z=SortedList()
        res=[]
        for i in range(l):
            z.add(x[i])
            if len(z)==k: 
                if k%2==0:
                    res.append((z[k//2]+z[k//2-1])/2)
                else:
                    res.append(z[k//2])
                z.discard(x[i-k+1])
        return res
    
    
#Approach 2: O(n log k) using Bynary Search and insertion Sort

import bisect

class Solution:
    def medianSlidingWindow(self, nums: List[int], k: int) -> List[float]:
        window, output = [], []
        for num in nums[:k-1]: bisect.insort_left(window, num)
        for i, num in enumerate(nums[k-1:]):
            bisect.insort_left(window, num)
            output.append(self.getMedian(window))
            window.pop(bisect.bisect_left(window, nums[i]))
        return output

    def getMedian(self, nums: List[int]) -> float:
        if len(nums)==0: return 0
        elif len(nums)%2!=0: return nums[len(nums)//2]
        else: return (nums[len(nums)//2] + nums[len(nums)//2-1])/2
        
        
#Approach 3:using bisect.insort w/ comments

class Solution:
    def medianSlidingWindow(self, nums: List[int], k: int) -> List[float]:
        
        # Init
        medians = []
        n = len(nums)
        
        # Make median indexes
        m1,m2 = (k//2,k//2) if k%2 else ((k//2)-1,k//2)
       
        # Sort the array and find the first median
        arr = sorted(nums[:k])
        medians.append(float((arr[m1] + arr[m2])/2))
        
        # Find rest medians
        for i in range(0,n-k): 
            arr.remove(nums[i])
            bisect.insort(arr, nums[i+k])
            medians.append(float((arr[m1] + arr[m2])/2))
        
        # return
        return medians
    
    
#Approach 4:Two Heaps

import heapq
class Solution: 
    def get_window_median(self):    
        if len(self.left)==len(self.right):
            result = (self.right[0] - self.left[0])/2
        else:
            result =self.right[0]
        return result
    
    def add_element_to_heaps(self,val):
        if len(self.left)==len(self.right):
            heapq.heappush(self.right, -heapq.heappushpop(self.left, -val))
        else:
            heapq.heappush(self.left, -heapq.heappushpop(self.right,val))
            
    def balance_heaps(self):
        if len(self.left)>len(self.right):
            heapq.heappush(self.right,-heapq.heappop(self.left))
        if len(self.right)-len(self.left)>1:
            heapq.heappush(self.left,-heapq.heappop(self.right)) 
                
    def medianSlidingWindow(self, nums: List[int], k: int) -> List[float]:
        self.left,self.right = [],[]
        for i in range(k):
            self.add_element_to_heaps(nums[i])
                
        result = [self.get_window_median()]
        
        for i in range(k,len(nums)):
                
            if nums[i-k]>=self.right[0]:
                self.right.remove(nums[i-k])
                heapq.heapify(self.right)
                self.balance_heaps()

            else:
                self.left.remove(-nums[i-k])
                heapq.heapify(self.left)
                self.balance_heaps()
                       
            self.add_element_to_heaps(nums[i])                       
            result.append(self.get_window_median())      
            
        return result

#Approach 5:

from bisect import insort
class Solution:
    def medianSlidingWindow(self, nums, k):
        """
        :type nums: List[int]
        :type k: int
        :rtype: List[float]
        """
        if k > len(nums) or not nums: return []
        medians, window = [], sorted(nums[:k])
        medians.append(self.getMedian(window))
        for idx in range(k,len(nums)):
            window.remove(nums[idx-k])
            insort(window,nums[idx])
            medians.append(self.getMedian(window))
        return medians
            
    def getMedian(self,nums):
        if len(nums)%2 != 0:
            return float(nums[len(nums)//2])
        else:
            idx1 = (len(nums)-1)//2
            idx2 = idx1+1
            return (nums[idx1]+nums[idx2])/2.0




