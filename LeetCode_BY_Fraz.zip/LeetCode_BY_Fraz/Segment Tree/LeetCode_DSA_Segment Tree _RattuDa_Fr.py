
#Segment Tree

#Q1. Recursive Approach to Segment Trees

'''

https://leetcode.com/articles/a-recursive-approach-to-segment-trees-range-sum-queries-lazy-propagation/

Recursive Approach to Segment Trees

Brief Introduction

What is a Segment Tree?

A segment tree is a binary tree where each node represents an interval. Generally a node would store one or more properties of an interval which can be queried later.

A typical Segment Tree

Why do we require it? (or What's the point of this?)
Many problems require that we give results based on query over a range or segment of available data. This can be a tedious and slow process, especially if the number of queries is large and repetitive. A segment tree let's us process such queries efficiently in logarithmic order of time.

Segment Trees have applications in areas of computational geometry and geographic information systems. For example, we may have a large number of points in space at certain distances from a central reference/origin point. Suppose we have to lookup the points which are in a certain range of distances from our origin. An ordinary lookup table would require a linear scan over all the possible points or all possible distances (think hash-maps). Segment Trees lets us achieve this in logarithmic time with much less space cost. Such a problem is called Planar Range Searching. Solving such problems efficiently is critical, especially when dealing with dynamic data which changes fast and unpredictably (for example, a radar system for air traffic.)

We will solve the Range Sum Query problem later in this editorial as an example of how Segment Trees help us save loads on runtime costs.

An example Segment Tree We will use the above tree as a practical example of what a Range Sum Query segment tree looks and behaves like.

How do we make one?
Let our data be in an array arr[] of size nn.

The root of our segment tree typically represents the entire interval of data we are interested in. This would be arr[0:n-1].
Each leaf of the tree represents a range comprising of just a single element. Thus the leaves represent arr[0], arr[1] and so on till arr[n-1].
The internal nodes of the tree would represent the merged or union result of their children nodes.
Each of the children nodes could represent approximately half of the range represented by their parent.
A segment tree for an nn element range can be comfortably represented using an array of size \approx 4 \ast n≈4∗n. (Stack Overflow has a good discussion as to why. If you are not convinced, fret not. We will discuss it later on.)

But how?
Children for a specific node are located at well defined indexes

Segment trees are very intuitive and easy to use when built recursively.

Recursive methods for Segment Trees
We will use the array tree[] to store the nodes of our segment tree (initialized to all zeros). The following scheme (0 - based indexing) is used:

The node of the tree is at index 00. Thus tree[0] is the root of our tree.
The children of tree[i] are stored at tree[2*i+1] and tree[2*i+2].
We will pad our arr[] with extra 0 or null values so that n = 2^kn=2 
k
  (where nn is the final length of arr[] and kk is a non negative integer.)
Do we actually need to pad `arr[]` with zeros?
The leaves of the tree occur at indexes 2^k - 12 
k
 −1 to 2^{k+1} - 22 
k+1
 −2.
What if we started by storing the node of tree at index 11 *instead of* index 00? How would the positions of related nodes change?
The structure for a Segment Tree is well defined

We also require only three kinds of methods:

1. Build the tree from the original data.
 The method builds the entire `tree` in a bottom up fashion. When the condition lo = hilo=hi is satisfied, we are left with a range comprising of just a single element (which happens to be `arr[lo]`). This constitutes a leaf of the tree. The rest of the nodes are built by merging the results of their two children. `treeIndex` is the index of the current node of the segment tree which is being processed.
Building the Segment Tree

For example, the tree above is made from the input array: (which we will use throughout this tutorial)

 Can you guess what the `merge` operation is in this example? After building the tree, the `tree[]` array looks like:  Notice the the groups of zeros near the end of the `tree[]` array? Those are `null` values we used as padding to ensure a complete binary tree is formed (since we only had 1010 leaf elements. Had we had, say, 1616 leaf elements, we wouldn't need any `null` elements. Can you prove why?)
NOTE: The merge operation varies from problem to problem. You should closely think of what to store in a node of the segment tree and how two nodes will merge to provide a result before you even start building a segment tree.

2. Read/Query on an interval or segment of the data.
 The method returns a result when the queried range matches exactly with the range represented by a current node. Else it digs deeper into the tree to find nodes which match a portion of the node exactly.
This is where the beauty of the segment tree lies.

Read/Update a Segment Tree In the above example, we are trying to find the sum of the elements in the range [2, 8][2,8]. No segment completely represents the range [2, 8][2,8]. However we can see that [2, 8][2,8] can be built up using the ranges [2, 2], [3, 4], [5, 7][2,2],[3,4],[5,7] and [8, 8].[8,8]. As a quick verification, we can see that sum of input elements at indexes [2, 8][2,8] is 13 + 19 + 15 + 11 + 20 + 12 + 33 = 12313+19+15+11+20+12+33=123. The sum of node values for the nodes representing ranges [2, 2], [3, 4], [5, 7][2,2],[3,4],[5,7] and [8, 8][8,8] are 13 + 34 + 43 + 33 = 123.13+34+43+33=123.

3. Update the value of an element.
 This is similar to `buildSegTree`. We update the value of the leaf node of our tree which corresponds to the updated element. Later the changes are propagated through the upper levels of the tree straight to the root.
Update a Segment Tree Leaf In this example, element at indexes (in original input data) 1, 31,3 and 66 are incremented by +3, -1+3,−1 and +2+2 respectively. You can see how the changes propagate up the tree, all through to the root.

Complexity Analysis
Let's take a look at the build process. We visit each leaf of the segment tree (corresponding to each element in our array arr[]). That makes nn leaves. Also there will be n-1n−1 internal nodes. So we process about 2*n2∗n nodes. This makes the build process run in O(n)O(n) linear complexity.

The update process discards half of the range for every level of recursion to reach the appropriate leaf in the tree. This is similar to binary search and takes logarithmic time. After the leaf is updated, its direct ancestors at each level of the tree are updated. This takes time linear to height of the tree.

The read/query process traverses depth-first through the tree looking for node(s) that match exactly with the queried range. At best, we query for the entire range and get our result from the root of the segment tree itself. At worst, we query for a interval/range of size 11 (which corresponds to a single element), and we end up traversing through the height of the tree. This takes time linear to height of the tree.

Segment Tree Complexity

This is the time to revisit something said before:

A segment tree for an nn element range can be comfortably represented using an array of size \approx 4 \ast n≈4∗n.

This ensures that we build our segment tree as a complete binary tree, which in turn ensures that the height of the tree is upper-bounded by the logarithm of the size of our input.

Voila! Both the read and update queries now take logarithmic O(log_2(n))O(log 
2
​
 (n)) time, which is what we desired.

Range Sum Queries
An example Range Sum Query Segment Tree

The Range Sum Query problem is a subset of the Range Query class of problems. Given an array or sequence of data elements, one is required to process read and update queries which consist of ranges of elements. Segment Trees (along with other Interval-based data structures like the Binary Indexed Tree (a.k.a. Fenwick Tree)) are used to solve this class of problems reasonably fast for practical usage.

The Range Sum Query problem specifically deals with the sum of elements in the queried range. Many variations of the problem exist, including for immutable data, mutable data, multiple updates, single query and multiple updates, multiple queries (each being very costly in terms of computation).

A sample solution solves the Range Sum Query problem for mutable arrays efficiently through the use of a recursive segment tree (pretty much like the one we just discussed.) The merge operation in this case is simply taking the sum of the two nodes (since each node stores the sum of the range it represents.)

Lazy Propagation
Motivation
Till now we have been updating single elements only. That happens in logarithmic time and it's pretty efficient.

But what if we had to update a range of elements? By our current method, each of the elements would have to be updated independently, each incurring some run time cost.

The construction of a tree poses another issue called ancestral locality. Ancestors of adjacent leaves are guaranteed to be common at some levels of the tree. Updating each of these leaves individually would mean that we process their common ancestors multiple times. What if we could reduce this repetitive computation?

Ancestral Locality In the above example, the root is updated thrice and the node numbered 8282 is updated twice. This is because, at some level of the tree, the changes propagated from different leaves will meet.

A third kind of problem is when queried ranges do not contain frequently updated elements. We might be wasting valuable time updating nodes which are rarely going to be accessed/read.

Using Lazy Propagation allows us to overcome all of these problems by reducing wasteful computations and processing nodes on-demand.

How do we use it?
As the name suggests, we update nodes lazily. In short, we try to postpone updating descendants of a node, until the descendants themselves need to be accessed.

For the purpose of applying it to the Range Sum Query problem, we assume that the update operation on a range, increments each element in the range by some amount val.

We use another array lazy[] which is the same size as our segment tree array tree[] to represent a lazy node. lazy[i] holds the amount by which the node tree[i] needs to be incremented, when that node is finally accessed or queried. When lazy[i] is zero, it means that node tree[i] is not lazy and has no pending updates.

1. Updating a range lazily
This is a three step process:

Normalize the current node. This is done by removing laziness. We simple increment the current node by appropriate amount to remove it's laziness. Then we mark its children to be lazy as the descendants haven't been processed yet.
Apply the current update operation to the current node if the current segment lies inside the update range.
Recurse for the children as you would normally to find appropriate segments to update.

2. Querying a lazily propagated tree
This is a two step process:

Normalize the current node by removing laziness. This step is the same as the update step.
Recurse for the children as you would normally to find appropriate segments which fit in queried range.

NOTE: The following lines:are specific to the [Range Sum Query problem.](https://leetcode.com/problems/range-sum-query-mutable/) Different problems may have different updating and merging schemes. In this case, updates are increments of +val+val and nodes contain the sum of the elements of range/segment they represent.
'''

#Q2.The Skyline Problem

'''

A city's skyline is the outer contour of the silhouette formed by all the buildings in that city when viewed from a distance. Given the locations and heights of all the buildings, return the skyline formed by these buildings collectively.

The geometric information of each building is given in the array buildings where buildings[i] = [lefti, righti, heighti]:

lefti is the x coordinate of the left edge of the ith building.
righti is the x coordinate of the right edge of the ith building.
heighti is the height of the ith building.
You may assume all buildings are perfect rectangles grounded on an absolutely flat surface at height 0.

The skyline should be represented as a list of "key points" sorted by their x-coordinate in the form [[x1,y1],[x2,y2],...]. Each key point is the left endpoint of some horizontal segment in the skyline except the last point in the list, which always has a y-coordinate 0 and is used to mark the skyline's termination where the rightmost building ends. Any ground between the leftmost and rightmost buildings should be part of the skyline's contour.

Note: There must be no consecutive horizontal lines of equal height in the output skyline. For instance, [...,[2 3],[4 5],[7 5],[11 5],[12 7],...] is not acceptable; the three lines of height 5 should be merged into one in the final output as such: [...,[2 3],[4 5],[12 7],...]

 

Example 1:


Input: buildings = [[2,9,10],[3,7,15],[5,12,12],[15,20,10],[19,24,8]]
Output: [[2,10],[3,15],[7,12],[12,0],[15,10],[20,8],[24,0]]
Explanation:
Figure A shows the buildings of the input.
Figure B shows the skyline formed by those buildings. The red points in figure B represent the key points in the output list.
Example 2:

Input: buildings = [[0,2,3],[2,5,3]]
Output: [[0,3],[5,0]]
 

Constraints:

1 <= buildings.length <= 104
0 <= lefti < righti <= 231 - 1
1 <= heighti <= 231 - 1
buildings is sorted by lefti in non-decreasing order.

'''
#Solution

#Approach 1: Max Heap with Multiple Stable Sort

import heapq

class Solution:
    def getSkyline(self, buildings: List[List[int]]) -> List[List[int]]:
        
        n=len(buildings)
        
        res=[]
        heap=[]
        heapq.heappush(heap,0)
        maxval=0
        
        # prevx,prevy,prevh=-1,-1,-1
        newb=[]
        for i in range(n):
            x,y,h=buildings[i]
            newb.append([x,h,0])
            newb.append([y,h,1])
            
        # newb=sorted(newb,key=lambda x:(x[0],-x[1]))
        newb.sort(key=lambda x: (x[0],x[1] if x[2] else -x[1])) 
        # print(newb)
    
        for u,v,w in newb:
            if w==0:
                heapq.heappush(heap,-v)
                if heap[0]!=maxval:
                    maxval=heap[0]
                    res.append([u,v])
                    
            else:
                heap.remove(-v)
                heapq.heapify(heap)
                if heap[0]!=maxval:
                    maxval=heap[0]
                    res.append([u,-maxval])
        return res

#APPROACH 2: sweep-line algo

# max-heap
# nlogn
# sweep-line

# This one is an interesting problem. I've been preparing myself mentally to solve it for a while.
# It took ~2h initially, and after a few rounds of code simplification I ended up with one:

class Solution:
    def getSkyline(self, buildings: List[List[int]]) -> List[List[int]]:
		# we need all building [start, height], [end, height] positions + building's [end, 0] markers.
		# r,r,0 is the building end marker - we need to get [position,0] locations
		# so we use 1-size building markers with height 0 to add such information to the buildings array
        buildings = [i for l,r,h in buildings for i in [[l,r,-h],[r,r,0]]]
		# sort by position and if there are building with the same [left,right], sort by tallerst first
		# e.g. [1,5,2],[1,5,5],[1,5,10] -> [1,5,10],[1,5,5],[1,5,2] so that the tallest is the first one
        buildings.sort(key=lambda x: (x[0], x[2]))

		# max_heap with a dummy value #1 to avoid checking if heap is empty or not
        heap = [(0, float(inf))]
		# res with a dummy value #2 to avoid checking if res is empty or not
        res = [[0,0]]
		# p is the sweepline position (aka all buildings start,end positions on the X-line)
        for p,r,h in buildings:
			# push in max_heap height and building right pos
			# during "sweeplining" we need to know until when the current height is valid
			# this is achived by pushing to the heap height + building's right side
            heappush(heap, (h, r))

			# remove all building's heights from the heap which have right side <= sweepline
			# why <= and not < ??? The end of buildings is exclusive, so we need to track [start, end)
			# but we remove the end of a building from the heap!!!
			# the trick is due to "marker buldings" with [r,r] and height=0 we have the following sequence:
			# [1,2,5]... [2,2,0], so technically we remove the building right side by the sweepline,
			# but at the same time we still have the next point [2,2,0] which is
			# not removed by the current sweepline [1,2,5] yet and is used to form the output array
            while heap and heap[0][1] <= p:
                heappop(heap)

			# if max height in the heap is not the same as the last one stored in the output
			# we know that we have a height change, which we need to save. [sweepline_pos, height]
			# could be from a building e.g. [10,5] or it could be from the marker with 0-height [10,0]
			# e.g. end of overlapping buildings or just last building
            if -res[-1][1] != heap[0][0]:
                res.append([p, -heap[0][0]])

		# generator to drop the helper-dummy 1st [0,0] value
        return (res[i] for i in range(1, len(res)))

    
#APPROACH 3:SortedDict O(nlog(n)) Single Sweep - 

# sorteddict


# We will set an initial key/value (-1, 0) to indicate a "floor"
# For each building, we will first attempt to add a point for building_right
# Then we will attempt to add a point for building_left
# Then we will attempt to update any points in between left/right
# Finally, we deduplicate any points on the same line when we return the results


from sortedcontainers import SortedDict

class Solution:
    def getSkyline(self, buildings: List[List[int]]) -> List[List[int]]:
        """
        This solution uses a SortedDict where the key is building positions
        and value is the maximum height at that position.
        
        After we iterate through the buildings, we will have a collection of
        skyline points (note this is not necessarily "key points" because it
        can contain multiple points in a line).
        
        We just need to iterate through the dictionary and ignore any repeated
        height points to get the final list of skyline "key points"
        """
        sorted_dict = SortedDict()
        
        # sets an initial floor of 0
        sorted_dict.setdefault(-1, 0)
        
        for left, right, height in buildings:

            if right not in sorted_dict or sorted_dict.get(right) < height:
                # find the height of the surface this building will
                # sit on (could be the floor or another building)
                #
                # we want to bisect_right in case we have the other
                # building ending on the same position. If so, we will
                # simply use the height from other building
                prev_idx = sorted_dict.bisect_right(right) - 1
                surface_height = sorted_dict.peekitem(prev_idx)[-1]
                if surface_height < height:
                    sorted_dict[right] = surface_height

            if left not in sorted_dict or sorted_dict.get(left) < height:
                # find the height of the surface this point will sit on
                #
                # we want to bisect_left because we want to immediate
                # point to the left to act as the "surface"
                prev_idx = sorted_dict.bisect_left(left) - 1
                surface_height = sorted_dict.peekitem(prev_idx)[-1]
                if surface_height < height:
                    sorted_dict[left] = height
        
            # scan through all points within current building left/right
            # to see if we need to update any previously set points.
            start = sorted_dict.bisect_left(left)
            end = sorted_dict.bisect_left(right)

            for i in range(start, end):
                point = sorted_dict.peekitem(i)
                if point[-1] < height:
                    # previously set point is a lower height
                    # we will update it to the current height
                    sorted_dict[point[0]] = height
        
        
        res = []
        
        # pop all key/value pairs into the result list
        # we skip the first key/value (i.e. (-1, 0))
        # because that is not from a building
        for pos in list(sorted_dict.keys())[1:]:
            height = sorted_dict.pop(pos)
            if res and res[-1][-1] == height:
                # if current point's height is the same
                # as previous, we can skip it.
                continue
            res.append([pos, height])

        return res



