
#Heap

#Q1. K Closest Points to Origin

'''

Given an array of points where points[i] = [xi, yi] represents a point on the X-Y plane and an integer k, return the k closest points to the origin (0, 0).

The distance between two points on the X-Y plane is the Euclidean distance (i.e., √(x1 - x2)2 + (y1 - y2)2).

You may return the answer in any order. The answer is guaranteed to be unique (except for the order that it is in).

 

Example 1:


Input: points = [[1,3],[-2,2]], k = 1
Output: [[-2,2]]
Explanation:
The distance between (1, 3) and the origin is sqrt(10).
The distance between (-2, 2) and the origin is sqrt(8).
Since sqrt(8) < sqrt(10), (-2, 2) is closer to the origin.
We only want the closest k = 1 points from the origin, so the answer is just [[-2,2]].
Example 2:

Input: points = [[3,3],[5,-1],[-2,4]], k = 2
Output: [[3,3],[-2,4]]
Explanation: The answer [[-2,4],[3,3]] would also be accepted.
 

Constraints:

1 <= k <= points.length <= 104
-104 < xi, yi < 104

'''
#Solution

#Approach-1

class Solution:
    def kClosest(self, points: List[List[int]], k: int) -> List[List[int]]:
        return [points[i] for d, i in sorted([(math.sqrt(x**2 + y**2), i) for i, [x, y] in enumerate(points)])[:k]]
    
    
#Approach-2

# heapify | nsmallest 


from heapq import heapify, nsmallest

class Solution:
    def kClosest(self, points: List[List[int]], k: int) -> List[List[int]]:
        heap = [
            (pow(points[i][0], 2) + pow(points[i][1], 2), i) for i in range(len(points))
        ]
        heapify(heap)
        return [points[x[1]] for x in nsmallest(k, heap)]
    
    
#Approach-3:minheap solution O(NlogK)


class Solution:
    def kClosest(self, points: List[List[int]], k: int) -> List[List[int]]:
        dict_ = {}
        for i, item in enumerate(points):
            dict_[i] = item[0]**2 + item[1]**2
        ans = heapq.nsmallest(k, dict_, key = dict_.get)
        output = []
        for item in ans:
            output.append(points[item])
        return output
    
    
#Approach-3:Max Heap with Size k | remove element from when it exceeds k size


# The Idea is simple

# We create a MaxHeap of Size k, we keep inserting given points with their distance as max heap property.

# When number of elements in heap crosses MaxHeap size, remove element from the top which won't be in k smallest anyway.

# At the end of all insertions, our maxheap is left with k elements which are k closest (k minimum)

# Time Complexity: O(N log K) as each insertion takes log K time, and we need to insert N elements
# Space Complexity: O(k) as we are keeping only K elements in the MaxHeap

class Node:
    def evaluateDistance(self, x, y):
        distance = pow(x, 2) + pow(y, 2)
        return distance
    
    def __init__(self, x, y):
        self.x = x
        self.y = y
        self.distance = self.evaluateDistance(x, y)
        
    
class MaxHeap:
    def __init__(self, capacity):
        self.size = 0
        self.capacity = capacity
        self.heap = []
    
    def heapUp(self, index):
        parent = int((index - 1) / 2)
        
        if parent >= 0:
            parentNode = self.heap[parent]
            childNode = self.heap[index]
            if parentNode.distance < childNode.distance:
                self.heap[parent], self.heap[index] = self.heap[index], self.heap[parent]
                self.heapUp(parent)
    
    def heapDown(self, parent):
        c1 = parent * 2 + 1
        c2 = parent * 2 + 2
        
        if c1 >= self.size:
            return
        
        mx = self.heap[parent]
        mxIndex = parent
        # print(c1, self.size, self.heap)
        if c1 < self.size:
            c1Node = self.heap[c1]
            
            if c1Node.distance > mx.distance:
                mx = c1Node
                mxIndex = c1
        
        if c2 < self.size:
            c2Node = self.heap[c2]
            
            if c2Node.distance > mx.distance:
                mx = c2Node
                mxIndex = c2
        
        if mxIndex != parent:
            self.heap[parent], self.heap[mxIndex] = self.heap[mxIndex], self.heap[parent] 
            self.heapDown(mxIndex)
        
    def remove(self):
        if self.size == 0:
            return
        self.heap[0] = self.heap.pop()
        self.size -= 1
        self.heapDown(0)
        
        
    def insert(self, x, y):
        node = Node(x,y)
        self.heap.append(node)
        self.heapUp(self.size)
        self.size += 1
        if self.size > self.capacity:
            self.remove()
        # print(self.getCoordinates())
    
    def getCoordinates(self):
        res = []
        
        for node in self.heap:
            res.append([node.x, node.y])
        
        return res
        

class Solution:
    def kClosest(self, points: List[List[int]], k: int) -> List[List[int]]:
        
        heap = MaxHeap(k)
        
        for point in points:
            heap.insert(point[0], point[1])
        
        return heap.getCoordinates()
    
    
#Approach-4:

class Solution(object):
    def kClosest(self, points, k):
        """
        :type points: List[List[int]]
        :type k: int
        :rtype: List[List[int]]
        """
        t=[]
        for i in points:
            x=i[0]**2+i[1]**2
            t.append([x,i])
        t.sort()
        return([i[1] for i in t[:k]])
    
#Approach-5: without heap


class Solution:
    def kClosest(self, points: List[List[int]], k: int) -> List[List[int]]:
        def Helper(arr,k):
            if len(arr)==k:
                return [ele[1] for ele in arr]
            pivot = random.choice(arr)[0]
            left,equals,right = [],[],[]
            for ele in arr:
                if ele[0]<pivot:
                    left.append(ele)
                elif ele[0]>pivot:
                    right.append(ele)
                else:
                    equals.append(ele)
            if len(left)>=k:
                return Helper(left,k)
            elif len(left)+len(equals)==k:
                return [ele[1] for ele in left] + [ele[1] for ele in equals]
            else:
                return [ele[1] for ele in left] + [ele[1] for ele in equals] + Helper(right,k-len(left)-len(equals))
        arr = []
        for point in points:
            arr.append([point[0]**2 + point[1]**2,point])
        return Helper(arr,k)

#Q2. Kth Largest Element in an Array

'''

Given an integer array nums and an integer k, return the kth largest element in the array.

Note that it is the kth largest element in the sorted order, not the kth distinct element.

You must solve it in O(n) time complexity.

 

Example 1:

Input: nums = [3,2,1,5,6,4], k = 2
Output: 5
Example 2:

Input: nums = [3,2,3,1,2,4,5,5,6], k = 4
Output: 4
 

Constraints:

1 <= k <= nums.length <= 105
-104 <= nums[i] <= 104

'''
#Solution 

#Approach-1

class Solution:
    def findKthLargest(self, nums: List[int], k: int) -> int:
        a = []
        heapq.heapify(a)
        for i in range(k):
            # push items into heap, keep a heap of size k with first k elements.
            heapq.heappush( a , nums[i] )
        for i in range(k , len(nums)): 
            # pop the smallest in list, so the list keep always the k largest.
            heapq.heappushpop(a , nums[i]) 
        return heapq.heappop(a) # pop off the smallest element
    
#Approach-2:O(n) time using heap 

# Solution using heap.
# Time - O(n)

class Solution:
    def findKthLargest(self, nums: List[int], k: int) -> int:
        # Negating all numbers so that the nums min-heap provides the required
        # maximum number
        for i in range(len(nums)):
            nums[i] *= -1
        
        heapify(nums)
        ret_value = 0
        while k>0:
            # heappop gives the minimum number from the heap
            # after negating it we're sure it is the max value and store it in ret_value
            ret_value = -heappop(nums)
            k -= 1
        
        return ret_value
    
#Approach-3:    
# One liner solution using sorted function
# Time-O(nlogn)

class Solution:
    def findKthLargest(self, nums: List[int], k: int) -> int:
        return sorted(nums)[-k]


#Q3.  Reorganize String
'''

Given a string s, rearrange the characters of s so that any two adjacent characters are not the same.

Return any possible rearrangement of s or return "" if not possible.

 

Example 1:

Input: s = "aab"
Output: "aba"
Example 2:

Input: s = "aaab"
Output: ""
 

Constraints:

1 <= s.length <= 500
s consists of lowercase English letters.

'''
#Solution 

#Approach-1: Recursion

# Recursion solution (TLE)

# Heap/Priority Queue

import heapq
class Solution:
    def reorganizeString(self, s: str) -> str:
        ans = ""
        heap = []
        d = {}
        for i in s:
            if i not in d:
                d[i] = 1
            else:
                d[i] += 1
        
        for i in d:
            heapq.heappush(heap, (-1 * d[i], i))
        

        while heap:
            
            top_of_heap = heap[0]
            if len(ans) == 0 or ans[-1] != top_of_heap[1]:
                
                ans += top_of_heap[1]
                if top_of_heap[0] + 1 != 0:
                    heapq.heappushpop(heap,(top_of_heap[0] + 1, top_of_heap[1]))
                else:
                    heapq.heappop(heap)
                
            else:
                
                tmp = []
                tmp.append(heapq.heappop(heap))
                if heap:
                    c2 = heapq.heappop(heap)
                    if c2[0] + 1 != 0:
                        heapq.heappush(heap, (c2[0] + 1, c2[1]))
                    ans += c2[1]                        
                else:
                    break
                heapq.heappush(heap, tmp[0])
        
        if len(ans) == len(s):
            return ans
        else:
            return ""
        
        
        
#Approach-2:Using max heap 

class Solution:
    def reorganizeString(self, s: str) -> str:
        strs = list(map(str, s))
        
        # use max priority queue - for that inverse the char counts
        queue = [(-count, char) for char, count in collections.Counter(strs).items()]
        heapq.heapify(queue)
        
        cooldown = []
        time = 0
        res = ""
        
        while queue:
            # min gap between two same char is 1 here (can be also generalized for n)
            for _ in range(2):
                # if there is some char either in queue or in cooldown, increment the time
                # there can be case, where queue is empty and char in only in cooldown
                if queue or cooldown:
                    time += 1
                
                # get the char with max count
                if queue:
                    count, char = heapq.heappop(queue)
                    res += char
                    # if char count is more than one, complete one and put the rest of it in cooldown
                    if count < -1:
                        cooldown.append((count+1, char))
            
            # add all the char from cooldown to queue again
            while cooldown:
                heapq.heappush(queue, cooldown.pop())
            
            if time > len(s):
                return ""
        return res
                    
                 
#Approach-3:Heap - Clean Code


from heapq import heapify, heappop, heappush
from collections import Counter

class Solution:
    def reorganizeString(self, s: str) -> str:
        frequencies = Counter(s)
        heap = [(-frequency, char) for char, frequency in frequencies.items()]
        heapify(heap)
        result = []
        prevFrequency = 0
        prevChar = ''
 
        while heap:
            frequency, char = heappop(heap)
            result.append(char)
            if prevFrequency < 0: # if prevFrequency >= 0 then there is no more of that char
                heappush(heap, (prevFrequency, prevChar))
            frequency += 1
            # store prev values to use in the next iteration
            prevFrequency = frequency # since we used one occurrence, the frequency has been reduced
            prevChar = char
        
        if len(result) < len(s):
            return ''
        return ''.join(result)

#Approach-4:heaqp, O(n)

from heapq import *
class Solution:
    def reorganizeString(self, s: str) -> str:

        """
        :type s: str
        :rtype: str
        """
        #Counter: dict object that counts list/string elements
        count_dict = Counter(s)
        count_heap = [[-v,k] for k,v in count_dict.items()]
        heapify(count_heap)
        
        #attempt to find solution by popping/queueing heap
        sol=""
        while(count_heap):
            prev="" if sol=="" else sol[-1]
            #pop one
            count, ele = heappop(count_heap)
            if ele==prev: #if most frequent same as prev, pop another
                try:
                    count_2, ele_2 = heappop(count_heap)
                except: #popped empty heap (no non-prev element left in heap)
                    return ""
                heappush(count_heap, [count, ele])
                count, ele = count_2, ele_2
            sol+=ele
            count+=1
            
            #if ele count>0, put ele  back to heapq
            if count:
                heappush(count_heap, [count, ele])
        return sol
    
#Approach-5:O(N) solution without max heap

# As most solutions suggest, we do need to compute frequencies of letters. If any letter has a frequency higher than half the length of the string (for odd length string, it would be len(s) // 2 + 1), no rearrangement is possible. If rearrangement is possible, I propose a two-step rearrangement. First rearrange by frequency (e.g. "ababacc" -> "aaabbcc"). Then take the output of the first rearrangement, break into two halves, and merge the two halves in alternating manner ("aaabbcc" -> "aaab" + "bcc" -> "abacacb"). Since no character has frequency higher than half the length of the original string, which is the length of each half (length of first half if original string has odd length), we're guaranteed that the final output has no adjacent characters that are the same. The total time complexity is O(N + M log (M)), where N is the length of s and M is the size of the alphabet (only relevant if we extend the problem to include characters that are not lowercase english letters). This solution also has linear space complexity to store the intermediate rearrangement.

class Solution:
    def reorganizeString(self, s: str) -> str:
        # store frequencies in list of pairs [char, freq]
		# O(N)
        frequencies = [[c, 0] for c in string.ascii_lowercase]
        for char in s:
            loc = ord(char) - ord('a')
            frequencies[loc][1] += 1

        # sort frequencies in descending order and construct
        # a reordered string
        # can stop early to return "" if rearragement is not possible
		# O(M log M + N)
        frequencies.sort(key=lambda x: x[1], reverse=True) 
        reordered_string = ''
        for char, freq in frequencies:
            if freq > len(s) // 2 + len(s) % 2:
                return ""
            reordered_string += char * freq

        # use two pointers to construct output string
		# O(N)
        pointer1, pointer2 = 0, len(s) // 2 + len(s) % 2
        out = ''
        while pointer2 < len(s):
            out += reordered_string[pointer1]
            out += reordered_string[pointer2]
            pointer1 += 1
            pointer2 += 1
        if len(s) % 2:
            out += reordered_string[pointer1]
        return out


#Q4. You are given an integer array heights representing the heights of buildings, some bricks, and some ladders.
'''

You start your journey from building 0 and move to the next building by possibly using bricks or ladders.

While moving from building i to building i+1 (0-indexed),

If the current building's height is greater than or equal to the next building's height, you do not need a ladder or bricks.
If the current building's height is less than the next building's height, you can either use one ladder or (h[i+1] - h[i]) bricks.
Return the furthest building index (0-indexed) you can reach if you use the given ladders and bricks optimally.

 

Example 1:


Input: heights = [4,2,7,6,9,14,12], bricks = 5, ladders = 1
Output: 4
Explanation: Starting at building 0, you can follow these steps:
- Go to building 1 without using ladders nor bricks since 4 >= 2.
- Go to building 2 using 5 bricks. You must use either bricks or ladders because 2 < 7.
- Go to building 3 without using ladders nor bricks since 7 >= 6.
- Go to building 4 using your only ladder. You must use either bricks or ladders because 6 < 9.
It is impossible to go beyond building 4 because you do not have any more bricks or ladders.
Example 2:

Input: heights = [4,12,2,7,3,18,20,3,19], bricks = 10, ladders = 2
Output: 7
Example 3:

Input: heights = [14,3,19,3], bricks = 17, ladders = 0
Output: 3
 

Constraints:

1 <= heights.length <= 105
1 <= heights[i] <= 106
0 <= bricks <= 109
0 <= ladders <= heights.length

'''
#Solution 

#Approach-1

# Heap...


class Solution:
    def furthestBuilding(self, heights: List[int], bricks: int, k: int) -> int:
        q=[]
        prev=heights[0]
        ans=len(heights)-1
        for j in range(1,len(heights)):
            i=heights[j]
            if prev>=i:
                prev=i
            else:
                if len(q)<k:
                    heappush(q,i-prev)   
                else:
                    if not q or i-prev<=q[0]:
                        if bricks<i-prev:
                            ans=j-1
                            break
                        bricks-=(i-prev)
                    else:
                        a=heappop(q)
                        if bricks<a:
                            ans=j-1
                            break
                        bricks-=a
                        heappush(q,i-prev)
            prev=i
        return ans

    
#Approach-2:Kth Largest Element in a Stream


class Solution:
    # iterate from left to right
    # Keep a min heap with size ladder
    # Afterwards, bricks -= pop out element
    def furthestBuilding(self, heights: List[int], bricks: int, ladders: int) -> int:
        heap = []
        result = 0
        total = 0
        for i in range(len(heights)-1):
            if heights[i+1] > heights[i]:
                heapq.heappush(heap, heights[i+1] - heights[i])
                if ladders < len(heap):
                    bricks -= heapq.heappop(heap)
                    if bricks < 0:
                        return i
            result = i+1
        return result

#Approach-3: 

# Heap | O(N log K) time, O(K) space
# Time complexity: O(N log K), where N is the number of heights and K the number of ladders
# Space complexity: O(K) where K is the number of ladders.
    
    
# Heap Solution
# We are going to use a heap to store the distances between buildings to climb. The plan is to keep always the longest distances in the heap and assume that these distances will be covered by ladders, so basically heap size == number of ladders we have.

# We will keep pushing jumps in the heap until we have as much elements as ladders, then we'll try to replace the shortest leap by bricks.

# The problem will end when we used all laders and cannot cover the shortest jump with bricks.

# Given the array [4,12,2,7,3,18,20,3,19], 2 ladders and 10 bricks, our heap will be filled like this:

# Iteration 1: [8] (12-4)
# Iteration 2: [8] (we don't add anything cause we don't need to climb)
# Iteration 3: [5, 8] (7-2)
# Iteration 4: [5,8] (we don't add anything cause we don't need to climb)
# Iteration 5:[8, 15] (18-3)
# ...
# We can see that we keep filling the heap until we reach 2 (number of ladders), then, if we find a larger distance, we replace that in the heap by the min one (heap root), but only if we have enough bricks to cover the leap, and if we can, we decrease the number of bricks. And then we keep following this process until we cannot use more bricks.

# Note: We have a ternary cause if we don't have ladders, we always need to set the current distance as the smallest one.

class Solution:  
    def furthestBuilding(self, heights: List[int], bricks: int, ladders: int) -> int:
        leap_distances = []
        
        for index in range(len(heights)-1):
            if heights[index] > heights[index+1]:
                continue
                                
            current_distance = heights[index+1]-heights[index]
                  
            if len(leap_distances) == ladders:
                min_distance = leap_distances[0] if len(leap_distances) else current_distance
                            
                if current_distance > min_distance and bricks - min_distance >= 0 :
                    heappop(leap_distances)
                    heappush(leap_distances, current_distance)
                    bricks -= min_distance
                elif current_distance <= min_distance and bricks - current_distance >= 0:
                     bricks -= current_distance
                else:
                    return index
                
                continue

            heappush(leap_distances, current_distance)
            
        return len(heights) - 1


#Approach-4:binary search

# Binary Search + Greedy Check | O(nlogn)


from bisect import bisect_left
class Solution:
    def furthestBuilding(self, heights: List[int], bricks: int, ladders: int) -> int:
        d = [(i, heights[i]-heights[i-1]) for i in range(len(heights)) if i > 0 and heights[i]-heights[i-1] > 0]
        def check(i, bricks, ladders):
            if i == 0: return True
            j = min(len(d)-1, bisect_left(d, (i,0)))
            if d[j][0] > i:
                j -= 1
            diffs = [d[k][1] for k in range(j+1)]
            diffs.sort()
            while diffs:
                cur = diffs.pop()
                if ladders:
                    ladders -= 1
                elif bricks >= cur:
                    bricks -= cur
                else:
                    return False
            return True
        low, high = 0, len(heights) - 1
        while low < high:
            m = (low + high + 1)//2
            if check(m, bricks, ladders):
                low = m
            else:
                high = m - 1
        return low

#Approach-5:

# [NlogN][Heap]Min heap with len of ladders


"""
# Method 1
Binary Search: k furthest to check
check can reach k: O(k) put ladders in the largest gap
O(NlogN)

# Method 2
Min heap with len of ladders
Should always use ladders at the largest len(ladders) gap, other gaps using bricks.
When used up ladders and bricks, return current height index-1
O(NlogN)

"""
import heapq
class Solution:
    def furthestBuilding(self, heights: List[int], bricks: int, ladders: int) -> int:
        hq = []
        hL = len(heights)
        for i in range(1, hL):
            gap = heights[i] - heights[i-1]
            if gap <= 0: continue
            heapq.heappush(hq, gap)
            if len(hq) > ladders:
                bricks -= heapq.heappop(hq)
            if bricks < 0:
                return i-1
        return hL-1


#Q5. Kth Smallest Element in a Sorted Matrix
'''

Given an n x n matrix where each of the rows and columns is sorted in ascending order, return the kth smallest element in the matrix.

Note that it is the kth smallest element in the sorted order, not the kth distinct element.

You must find a solution with a memory complexity better than O(n2).

 

Example 1:

Input: matrix = [[1,5,9],[10,11,13],[12,13,15]], k = 8
Output: 13
Explanation: The elements in the matrix are [1,5,9,10,11,12,13,13,15], and the 8th smallest number is 13
Example 2:

Input: matrix = [[-5]], k = 1
Output: -5
 

Constraints:

n == matrix.length == matrix[i].length
1 <= n <= 300
-109 <= matrix[i][j] <= 109
All the rows and columns of matrix are guaranteed to be sorted in non-decreasing order.
1 <= k <= n2
 

Follow up:

Could you solve the problem with a constant memory (i.e., O(1) memory complexity)?
Could you solve the problem in O(n) time complexity? The solution may be too advanced for an interview but you may find reading this paper fun.
'''

#Solution 

#Approach 1 : O(n2*log(k))

# heapq.heappush and heapq.heappop will take O(log(k)) so the total time complexity is O(n^2*log(k)). Space complexity is the size of the heap which is O(k)

import heapq
class Solution:
    def kthSmallest(self, matrix: List[List[int]], k: int) -> int:
        heap = []
        n = len(matrix)
        for i in range(n):
            for j in range(n):
                heapq.heappush(heap, - matrix[i][j])
                if(len(heap) > k ):
                    heapq.heappop(heap)
        return -heapq.heappop(heap)                
        
#Approach 2 :

class Solution:
    def kthSmallest(self, matrex: List[List[int]], k: int) -> int:
        lst=[]
        for i in matrex:
            for j in i:
                bisect.insort(lst,j)
               
        return lst[k-1]
    
    
#Approach 3:O((row+k)log(row)) with min heap

class Solution:
    def kthSmallest(self, matrix, k):
        heap = [(matrix[0][i], 0, i) for i in range(len(matrix[0]))]
        heapq.heapify(heap)
        for i in range(k-1):
            v, r, c = heapq.heappop(heap)
            if r+1 < len(matrix):
                heapq.heappush(heap, (matrix[r+1][c], r+1, c))
        return heapq.heappop(heap)[0]
    
#Approach 4: binary-search

class Solution:
    def kthSmallest(self, matrix, k):
        n = len(matrix)

        def check(mid):
            i, j = n - 1, 0
            num = 0
            while i >= 0 and j < n:
                if matrix[i][j] <= mid:
                    num += i + 1
                    j += 1
                else:
                    i -= 1
            return num >= k

        left, right = matrix[0][0], matrix[-1][-1]
        while left < right:
            mid = (left + right) // 2
            if check(mid):
                right = mid
            else:
                left = mid + 1
        
        return left


#Approach 5:o(n^2+nlogn)time 


class Solution(object):
    def kthSmallest(self, matrix, k):
        n=len(matrix)
        if n==0:
            return 0
        m=len(matrix[0])
        a=[]
        for i in range(n):
            for j in range(m):
                a.append(matrix[i][j])
        a=sorted(a)
        return a[k-1]

#Q6. Cheapest Flights Within K Stops

'''

There are n cities connected by some number of flights. You are given an array flights where flights[i] = [fromi, toi, pricei] indicates that there is a flight from city fromi to city toi with cost pricei.

You are also given three integers src, dst, and k, return the cheapest price from src to dst with at most k stops. If there is no such route, return -1.

 

Example 1:


Input: n = 4, flights = [[0,1,100],[1,2,100],[2,0,100],[1,3,600],[2,3,200]], src = 0, dst = 3, k = 1
Output: 700
Explanation:
The graph is shown above.
The optimal path with at most 1 stop from city 0 to 3 is marked in red and has cost 100 + 600 = 700.
Note that the path through cities [0,1,2,3] is cheaper but is invalid because it uses 2 stops.
Example 2:


Input: n = 3, flights = [[0,1,100],[1,2,100],[0,2,500]], src = 0, dst = 2, k = 1
Output: 200
Explanation:
The graph is shown above.
The optimal path with at most 1 stop from city 0 to 2 is marked in red and has cost 100 + 100 = 200.
Example 3:


Input: n = 3, flights = [[0,1,100],[1,2,100],[0,2,500]], src = 0, dst = 2, k = 0
Output: 500
Explanation:
The graph is shown above.
The optimal path with no stops from city 0 to 2 is marked in red and has cost 500.
 

Constraints:

1 <= n <= 100
0 <= flights.length <= (n * (n - 1) / 2)
flights[i].length == 3
0 <= fromi, toi < n
fromi != toi
1 <= pricei <= 104
There will not be any multiple flights between two cities.
0 <= src, dst, k < n
src != dst

'''
#Solution 

# class Solution:
#     def findCheapestPrice(self, n: int, flights: List[List[int]], src: int, dst: int, k: int) -> int:
        

# Approach 1: bfs  

class Solution:
    def findCheapestPrice(self, n: int, flights: List[List[int]], src: int, dst: int, k: int) -> int:
        routes = defaultdict(list)
        for frm, to, price in flights:
            routes[frm].append((to, price))
        cities = [(src, 0)]
        dest_prices = defaultdict(int)
        dest_prices[src] = 0
        while k >= 0:
            k -= 1
            next_cities = []
            for city, price in cities:
                for next_city, next_price in routes[city]:
                    if next_city not in dest_prices or dest_prices[next_city] > price + next_price:
                        next_cities.append((next_city, price + next_price))
                        dest_prices[next_city] = price + next_price
            cities = next_cities
        if dst in dest_prices:
            return dest_prices[dst]
        return -1

# Approach 2:DFS with Memorisation
# dp topdown
# dfs with recursion

class Solution:
    def findCheapestPrice(self, n: int, fli: List[List[int]], src: int, dst: int, k: int) -> int:
        
        g = defaultdict(dict)
        for i,j,d in fli:
            g[i][j] = d
        
        dp = defaultdict(lambda :float('inf'))
        def dfs(v, k, d):
            nonlocal dst
            if v==dst:
                return 0
            if k<0:
                return float('inf')
            if (v, k) not in dp:
                for u in g[v]:
                    dp[v,k] = min(dp[v,k], dfs(u, k-1, d)+g[v][u])
                
            return dp[v,k]
        
        res = dfs(src, k, 0) 
        return res if res!=float('inf') else -1
    
# Approach 3:bellman ford

class Solution:
    def findCheapestPrice(self, n: int, flights: List[List[int]], src: int, dst: int, k: int) -> int:
        prices = [float("inf")] * n
        prices[src] = 0
        
        for i in range(k + 1):
            tempPrices = prices.copy()
            
            for s,d,p in flights:
                if prices[s] == float("inf"):
                    continue
                if prices[s] + p < tempPrices[d]:
                    tempPrices[d] = prices[s] + p
            prices = tempPrices
        return -1 if prices[dst] == float("inf") else prices[dst]

    
# Approach 4: Priority Stack Solution


class Solution(object):
    def findCheapestPrice(self, n, flights, src, dst, k):
        """
        :type n: int
        :type flights: List[List[int]]
        :type src: int
        :type dst: int
        :type k: int
        :rtype: int
        """
        graph = defaultdict(list)
        for (s, t, p) in flights:
            graph[s].append((t, p))
        
        dist = defaultdict(dict)
        dist[src][k+1] = 0
        
        stack = []
        heappush(stack, (0, src, k+1))
        while stack:
            leng, start, step = heappop(stack)
            if start == dst:
                return leng
            if step == 0:
                continue
            for (t, p) in graph[start]:
                temp = leng + p
                if t not in dist or step-1 not in dist[t] or (dist[t][step-1] > 0 and dist[t][step-1] > temp):
                    dist[t][step-1] = temp
                    heappush(stack, (temp, t, step-1))
        return -1

    
#Approach-5:Bellman-Ford with Queue implement
# queue
# bellman-ford

from collections import deque, defaultdict

class Solution:
    def findCheapestPrice(self, n: int, flights: List[List[int]], src: int, dst: int, k: int) -> int:
        '''
        have a var min_cost = -1
        SPFA, declare a. queue with one item tuple(source, 0, cur_dis), traverse thru each node, while q:
            A, stops = q.popleft()
            for loop traverse thru graph:
                get @cur_dis and @cost to B                
                if cur_dis + cost < distances[B]:
                    distances[B] = cur_dis + cost
                    if B == dst and stops + 1 <= k: 
                        min_cost = distances[B]
                    add a tuple(B, stops + 1) to queue 
    
        '''
        #declare graph
        graph = defaultdict(list)
        for A,B,cost in flights:
            graph[A].append([B,cost])
        
        #declare queue and shortest cost distance array
        distances = [float('inf')] * n
        distances[src] = 0
        queue = deque([(src,-1,0)])
        min_cost = -1
        
        while queue:
            A, stops, cur_dis = queue.popleft()
            
            #traverse thru edges of A: 
            for B, cost in graph[A]:
                #check if new distance < distances[B]
                if cur_dis + cost < distances[B]:
                    #if it is, assign new value
                    distances[B] = cur_dis + cost
                    #increase stops by 1 bc it be traversed to one more stop
                    new_stops = stops + 1 
                    #if it meets the requirement, then assign min_cost to new distance
                    if B == dst and new_stops <= k:
                        min_cost = distances[B]
                    #add to the queue
                    if new_stops < k:
                        queue.append((B,new_stops,distances[B]))
        
        return min_cost
                        
#Q7. Find the Most Competitive Subsequence
'''

Given an integer array nums and a positive integer k, return the most competitive subsequence of nums of size k.

An array's subsequence is a resulting sequence obtained by erasing some (possibly zero) elements from the array.

We define that a subsequence a is more competitive than a subsequence b (of the same length) if in the first position where a and b differ, subsequence a has a number less than the corresponding number in b. For example, [1,3,4] is more competitive than [1,3,5] because the first position they differ is at the final number, and 4 is less than 5.

 

Example 1:

Input: nums = [3,5,2,6], k = 2
Output: [2,6]
Explanation: Among the set of every possible subsequence: {[3,5], [3,2], [3,6], [5,2], [5,6], [2,6]}, [2,6] is the most competitive.
Example 2:

Input: nums = [2,4,3,3,5,4,9,6], k = 4
Output: [2,3,3,4]
 

Constraints:

1 <= nums.length <= 105
0 <= nums[i] <= 109
1 <= k <= nums.length

'''
#Solution:

#Approach-1
# Monotonic Stack

# Solution:
# Use a monotonically increasing stack to solve this problem. We will place a range limit on the stack size. Let n be the length of nums and k be the desired result. Initially, the minimum and the maximum stack size will be k-n and k respectively.

# Iterate through all numbers. While the current number is larger than the number on top of the stack, pop such number as long as the stack size is not less than the minimum stack size. Then, if the stack has not reach its maximum, append the current number on it. Lastly, increment the minimum stack size.

#     Ex: nums = [2,4,3,3,5,4,2,1], k = 4
#         stack       num         minSize     maxSize 
#         []          2           -4          4
#         [2]         4           -3          4
#         [2,4]       3           -2          4
#         [2,3]       3           -1          4
#         [2,3,3]     5            0          4
#         [2,3,3,5]   4            1          4
#         [2,3,3,4]   2            2          4
#         [2,3,2]     1            3          4
#         [2,3,2,1]   _            4          4
# Complexity:
# Time: O(n)
# Space: O(k)

class Solution:
    def mostCompetitive(self, nums: list[int], k: int) -> list[int]:

        # Initialize the stack
        stack = []

        # Initiliaze the minimum and the maximum stack size
        minSize, maxSize = k - len(nums), k

        # Iterate through all numbers
        for num in nums:

            # While there is a number on top of the stack and it is larger than the current number
            while stack and stack[-1] > num:

                # If the stack size reaches the minimum, end the removal
                if len(stack) == minSize:
                    break

                # Else, pop a number from top of the stack
                stack.pop()

            # If the stack hasn't reach its maximum, add the current number onto it
            if len(stack) < maxSize:
                stack.append(num)

            # Increment the minimum size of the stack
            minSize += 1

        return stack

#Approach-2:
class Solution:
	def mostCompetitive(self, nums: List[int], k: int) -> List[int]:
		end = len(nums) - k
		ans = []
		for num in nums:
			while end and ans and num < ans[-1] :
				ans.pop()
				end -= 1
			ans.append(num)
		
		return ans[:k]
    
#Approach-3:Stack with O(n) Time Complexity and O(1) Space Complexity


class Solution:
    def mostCompetitive(self, nums: List[int], k: int) -> List[int]:
        stack = []
        
        n = len(nums)
        
    
        for i, num in enumerate(nums):
            while stack and num < stack[-1] and (len(stack) + n - i) > k:
                stack.pop()
            #Stack size will never be more than k, which is size of answer    
            if len(stack) < k:                
                stack.append(num)
                
        return stack

#Approach-4:Min Heap, Mono Decreasing Queue, Mono Increasing Stack

# Solution 1: Min Heap
# Complexity:

# Time: O(NlogN)
# Space: O(N)

class Solution(object):
    def mostCompetitive(self, nums, k):
        minHeap = []
        ans = []
        skipElement = defaultdict(int)
        j = 0
        for i, e in enumerate(nums):
            heappush(minHeap, (e, i)) # sorted by `e` (element) then `i` (index)
            if i >= len(nums) - k:
                while skipElement[minHeap[0][0]] > 0: # Discard skip elements of top min heap
                    skipElement[minHeap[0][0]] -= 1
                    heappop(minHeap)
                choose = heappop(minHeap)
                ans.append(choose[0])
                while j < choose[1]:
                    skipElement[nums[j]] += 1
                    j += 1
                j += 1
        return ans

# Solution 2: Mono Decreasing Queue
# Complexity:

# Time: O(N)
# Space: O(N)
class Solution(object):
    def mostCompetitive(self, nums, k):
        decreaseQ = deque([])
        ans = []
        for i, e in enumerate(nums):
            while decreaseQ and e < decreaseQ[0]: # Remove elements that are larger than new element
                decreaseQ.popleft()
            decreaseQ.appendleft(e)
            if i >= len(nums) - k:
                ans.append(decreaseQ.pop())
        return ans

# Solution 3: Mono Increasing Stack
# Complexity:

# Time: O(N)
# Space: O(N)

class Solution(object):
    def mostCompetitive(self, nums, k):
        stack = []
        needDeleteCount = len(nums) - k
        for e in nums:
            while stack and e < stack[-1] and needDeleteCount > 0:
                needDeleteCount -= 1
                stack.pop()
            stack.append(e)
        return stack[:k]


#Q8. . Ugly Number II
'''

An ugly number is a positive integer whose prime factors are limited to 2, 3, and 5.

Given an integer n, return the nth ugly number.

 

Example 1:

Input: n = 10
Output: 12
Explanation: [1, 2, 3, 4, 5, 6, 8, 9, 10, 12] is the sequence of the first 10 ugly numbers.
Example 2:

Input: n = 1
Output: 1
Explanation: 1 has no prime factors, therefore all of its prime factors are limited to 2, 3, and 5.
 

Constraints:

1 <= n <= 1690
'''

#Solution:
#Approach-1 : Math


class Solution:
    # def nthUglyNumber(self, n: int) -> int:
    def nthUglyNumber(self, n):
        nums = [1]
        i2 = i3 = i5 = 0
        for i in range(1,n):
            val = min(nums[i2]*2, nums[i3]*3, nums[i5]*5)
            nums.append(val)
            if val == nums[i2]*2:
                i2 += 1
            if val == nums[i3]*3:
                i3 += 1
            if val == nums[i5]*5:
                i5 += 1
        return nums[-1]

#Approach-2:three pointer approach

# T: O(n) S: O(n)

class Solution:
    def nthUglyNumber(self, n: int) -> int:
        u = [1]                                     # initial list of ugly numbers
        p2, p3, p5 = 0, 0, 0                        # pointers to 3 lists - 2, 3 and 5

        # repeat until the length of list becomes equal to n
        while len(u) < n:
            cur = (u[p2]*2, u[p3]*3, u[p5]*5)       # cur ugly numbers in 3 lists
            minU = min(cur)                         # minimum of ugly numbers at 3 positions
            u.append(minU)                          # becomes next ugly number

            if minU == cur[0]:                      # if minU is in list pointed by p2
                p2 += 1                             # - forward the p2 pointer

            if minU == cur[1]:                      # if minU is in list pointed by p3
                p3 += 1                             # - forward the p3 pointer

            if minU == cur[2]:                      # if minU is in list pointed by p5
                p5 += 1                             # - forward the p5 pointer

        return u[-1]                                # return last ugly number


#Approach-3: dynamic programming

class Solution:
    def nthUglyNumber(self, n):
        ugly = [0] * n
        nxt = ugly[0] = 1
        i2 = i3 = i5 = 0
        nxt2, nxt3, nxt5 = ugly[i2]*2, ugly[i3]*3, ugly[i5]*5
        for i in range(1, n):
            nxt = min(nxt2, nxt3, nxt5)
            ugly[i] = nxt
            if nxt == nxt2:
                i2 += 1
                nxt2 = ugly[i2]*2
            if nxt == nxt3:
                i3 += 1
                nxt3 = ugly[i3]*3
            if nxt == nxt5:
                i5 += 1
                nxt5 = ugly[i5]*5
        return nxt # ugly[-1]

#Q9. Merge k Sorted Lists

'''

You are given an array of k linked-lists lists, each linked-list is sorted in ascending order.

Merge all the linked-lists into one sorted linked-list and return it.

 

Example 1:

Input: lists = [[1,4,5],[1,3,4],[2,6]]
Output: [1,1,2,3,4,4,5,6]
Explanation: The linked-lists are:
[
  1->4->5,
  1->3->4,
  2->6
]
merging them into one sorted list:
1->1->2->3->4->4->5->6
Example 2:

Input: lists = []
Output: []
Example 3:

Input: lists = [[]]
Output: []
 

Constraints:

k == lists.length
0 <= k <= 104
0 <= lists[i].length <= 500
-104 <= lists[i][j] <= 104
lists[i] is sorted in ascending order.
The sum of lists[i].length will not exceed 104.
'''
#Solution:
# Definition for singly-linked list.
# class ListNode:
#     def __init__(self, val=0, next=None):
#         self.val = val
#         self.next = next
# class Solution:
#     def mergeKLists(self, lists: List[Optional[ListNode]]) -> Optional[ListNode]:
        
#Approach 1: 

class Solution(object):
    def mergeKLists(self, lists):
        """
        :type lists: List[ListNode]
        :rtype: ListNode
        """
        test = []
        for i in range(len(lists)):
            curr = lists[i]
            while curr:
                test.append(curr.val)
                curr=curr.next
        test.sort(reverse=True)
        res = None
        for x in test:
            res = ListNode(x, next=res)
        return res
    
    
#Approach 2: Merge k Sorted Lists

# Definition for singly-linked list.
# class ListNode:
#     def __init__(self, val=0, next=None):
#         self.val = val
#         self.next = next
class Solution:
    def mergeKLists(self, lists: List[Optional[ListNode]]) -> Optional[ListNode]:
        def merge2Lists(list1, list2): # Time Complexity O(n)
            merged_head = pointer = ListNode()
            while list1 and list2:
                if list1.val <= list2.val:
                    pointer.next = list1
                    list1 = list1.next
                else:
                    pointer.next = list2
                    list2 = list2.next
                pointer = pointer.next
            if list1:
                pointer.next = list1
            else:
                pointer.next = list2
            return merged_head.next
        k = len(lists)
        if k == 0:
            return None
        gap = 1
        while gap <= (k-1): # there are only k lists, and gap is capped at k-1
            for left in range(0, k, 2*gap):
                if left+gap <= (k-1): # to ensure left+gap is capped at k-1 as well
                    lists[left] = merge2Lists(lists[left], lists[left+gap])
            gap *= 2
        return lists[0]
    
    # Time Complexity O(n log k), it means we do merge2Lists (log k) times, and each time it scales to O(n)
    # Space Complexity O(1), as it's in-place
    
    
#Approach 3:Brute Force
'''
Intuition & Algorithm

Traverse all the linked lists and collect the values of the nodes into an array.
Sort and iterate over this array to get the proper value of nodes.
Create a new sorted linked list and extend it with the new nodes.
'''

# Time complexity : O(N\log N)O(NlogN) where NN is the total number of nodes.

# Collecting all the values costs O(N)O(N) time.
# A stable sorting algorithm costs O(N\log N)O(NlogN) time.
# Iterating for creating the linked list costs O(N)O(N) time.
# Space complexity : O(N)O(N).

# Sorting cost O(N)O(N) space (depends on the algorithm you choose).
# Creating a new linked list costs O(N)O(N) space.

class Solution(object):
    def mergeKLists(self, lists):
        """
        :type lists: List[ListNode]
        :rtype: ListNode
        """
        self.nodes = []
        head = point = ListNode(0)
        for l in lists:
            while l:
                self.nodes.append(l.val)
                l = l.next
        for x in sorted(self.nodes):
            point.next = ListNode(x)
            point = point.next
        return head.next
    
#Approach 4:Merge with Divide And Conquer


class Solution(object):
    def mergeKLists(self, lists):
        """
        :type lists: List[ListNode]
        :rtype: ListNode
        """
        amount = len(lists)
        interval = 1
        while interval < amount:
            for i in range(0, amount - interval, interval * 2):
                lists[i] = self.merge2Lists(lists[i], lists[i + interval])
            interval *= 2
        return lists[0] if amount > 0 else None

    def merge2Lists(self, l1, l2):
        head = point = ListNode(0)
        while l1 and l2:
            if l1.val <= l2.val:
                point.next = l1
                l1 = l1.next
            else:
                point.next = l2
                l2 = l1
                l1 = point.next.next
            point = point.next
        if not l1:
            point.next=l2
        else:
            point.next=l1
        return head.next
    
    
#Approach 5: Recursive Solution. How to compute the Complexity in recursive Algorithm?[166ms]


# n is the length of input-list
# m is the expected length of Linked-List

# Time Complexity: O(nlognm)
# Space Complexity: O(nlognm)

# Is That RIGHT?

# Definition for singly-linked list.
# class ListNode:
#     def __init__(self, x):
#         self.val = x
#         self.next = None

class Solution:
    # @param {ListNode} l1
    # @param {ListNode} l2
    # @return {ListNode}
    def mergeTwoLists(self, l1, l2):
        l = ListNode(0)
        c = l
        p = None
        if l1 is None:
            return l2
        if l2 is None:
            return l1
        
        while l1 is not None and l2 is not None:
            if l1.val < l2.val:
                c.next = l1
                l1 = l1.next
            else:
                c.next = l2
                l2 = l2.next
            c = c.next
        if l1 is None:
            c.next = l2
        if l2 is None:
            c.next = l1
            
        return l.next
    # @param {ListNode[]} lists
    # @return {ListNode}
    def mergeKLists(self, lists):
        if len(lists) == 0:
            return None
        elif len(lists) == 1:
            return lists[0]
        elif len(lists) == 2:
            return self.mergeTwoLists(*lists)
        else:
            half = int(len(lists)/2 + len(lists)%2)
            return self.mergeKLists([self.mergeKLists(lists[:half]), 
                                     self.mergeKLists(lists[half:])])



#Q10. Sliding Window Maximum
'''
You are given an array of integers nums, there is a sliding window of size k which is moving from the very left of the array to the very right. You can only see the k numbers in the window. Each time the sliding window moves right by one position.

Return the max sliding window.

 

Example 1:

Input: nums = [1,3,-1,-3,5,3,6,7], k = 3
Output: [3,3,5,5,6,7]
Explanation: 
Window position                Max
---------------               -----
[1  3  -1] -3  5  3  6  7       3
 1 [3  -1  -3] 5  3  6  7       3
 1  3 [-1  -3  5] 3  6  7       5
 1  3  -1 [-3  5  3] 6  7       5
 1  3  -1  -3 [5  3  6] 7       6
 1  3  -1  -3  5 [3  6  7]      7
Example 2:

Input: nums = [1], k = 1
Output: [1]
 

Constraints:

1 <= nums.length <= 105
-104 <= nums[i] <= 104
1 <= k <= nums.length

'''
#Solution 

#Approach 1: deque

class Solution:
    def maxSlidingWindow(self, nums: List[int], k: int) -> List[int]:
        from collections import deque
        q = deque()
        maxq = []
        
        for i in range(len(nums)):
            n = nums[i]
            if q and q[0]<=i-k: 
                q.popleft()
            while q and nums[q[-1]]<=n: 
                q.pop() 
            q.append(i)
            if 1+i>=k: 
                maxq.append(nums[q[0]])
        return maxq
            
#Approach 2: Max Sliding Window and Deque


# Use the properties of sliding window to djuge the time to pop and add in result array. Also, the benifit of deque over queue gives a convient method popleft() to handle the number that doesn't fit the condition anymore.

from collections import deque
class Solution:
    def maxSlidingWindow(self, nums: List[int], k: int) -> List[int]:
        q = deque()
        res = []
        for i, cur in enumerate(nums):
            while q and nums[q[-1]] <= cur:
                q.pop()
            q.append(i)
            if q[0] == i - k:
                q.popleft()
            if i >= k - 1:
                res.append(nums[q[0]])
        return res

#Q11. Trapping Rain Water II
'''

Given an m x n integer matrix heightMap representing the height of each unit cell in a 2D elevation map, return the volume of water it can trap after raining.

 

Example 1:


Input: heightMap = [[1,4,3,1,3,2],[3,2,1,3,2,4],[2,3,3,2,3,1]]
Output: 4
Explanation: After the rain, water is trapped between the blocks.
We have two small ponds 1 and 3 units trapped.
The total volume of water trapped is 4.
Example 2:


Input: heightMap = [[3,3,3,3,3],[3,2,2,2,3],[3,2,1,2,3],[3,2,2,2,3],[3,3,3,3,3]]
Output: 10
 

Constraints:

m == heightMap.length
n == heightMap[i].length
1 <= m, n <= 200
0 <= heightMap[i][j] <= 2 * 104

'''
#Solution

# Approach 1: O(mn log(mn)) | Heap Explained


# The idea is to set the height of the water at the boundary and work our way inwards.
# First, set the the (water) height of all boundary points to their heightMap values, then iteratively choose the lowest boundary point and set its neighbors. To choose the lowest, we maintain a min heap containing the boundary coordinates, with priority given by their (water) height.

import heapq
class Solution:
    def trapRainWater(self, heightMap: List[List[int]]) -> int:
        m = len(heightMap)
        n = len(heightMap[0])
        
        # initialize heap containing boundary points
        heights = {}
        heap = []
        for r in range(m):
            for c in range(n):
                if r == 0 or r == m - 1 or c == 0 or c == n - 1:
                    h = heightMap[r][c]
                    heights[(r, c)] = h
                    heapq.heappush(heap, (h, (r, c)))
        
        # set height of neighbors for the lowest boundary point at each step
        total = 0
        while len(heap) > 0:
            _, (r, c) = heapq.heappop(heap)
            for r_o, c_o in [(r + 1, c), (r - 1, c), (r, c + 1), (r, c - 1)]:
                if 0 <= r_o < m and 0 <= c_o < n and (r_o, c_o) not in heights:
                    h = max(heights[(r, c)], heightMap[r_o][c_o])
                    heights[(r_o, c_o)] = h
                    total += h - heightMap[r_o][c_o]
                    heapq.heappush(heap, (h, (r_o, c_o)))
        return total
    
    
#Approach 2:

class Solution:
    def trapRainWater(self, hm: List[List[int]]) -> int:
        if not hm:
            return 0
        n,m,h,res = len(hm),len(hm[0]),[],0
        arr = [[0]*m for _ in range(n)]
        for i in range(n):
            if i==0 or i==n-1:
                for j in range(m):
                    arr[i][j] = 1
                    heapq.heappush(h,(hm[i][j],i,j))
            else:
                arr[i][0] = 1
                heapq.heappush(h,(hm[i][0],i,0))
                arr[i][m-1] = 1
                heapq.heappush(h,(hm[i][m-1],i,m-1))
        dy = [0,1,0,-1]
        dx = [1,0,-1,0]
        while h:
            c,i,j = heapq.heappop(h)
            for k in range(4):
                x = i + dx[k]
                y = j + dy[k]
                if x < 0 or y < 0 or x >= n or y>= m:
                    continue
                if arr[x][y] == 0:
                    arr[x][y] = 1
                    if c > hm[x][y]:
                        res += c - hm[x][y]
                        heapq.heappush(h, (c, x, y))
                    else:
                        heapq.heappush(h, (hm[x][y], x, y))
        return res
    
    
#Approach 3:    
# bsearch with BFS
# python
# binary-search

from itertools import chain, product
import numpy as np

class Solution:
    def adj(self, P):
        return [
            (P[0] - 1, P[1]),
            (P[0] + 1, P[1]),
            (P[0], P[1] - 1),
            (P[0], P[1] + 1)
        ]
    
    def bfs(self, M, h, P):
        B = set()
        BFS = [P]
        while len(BFS):
            Q = BFS.pop()
            if Q[0] < 0 or Q[0] >= M.shape[0]\
            or Q[1] < 0 or Q[1] >= M.shape[1]:
                return None
            
            B |= {Q}
            
            if M[Q] >= h:
                continue
            
            for A in self.adj(Q):
                if A not in B:
                    BFS += [A]
        return B
    
    def bsearch(self, fn, n):
        low = 0  
        high = n - 1  
        mid = 0  
        
        vals = {n:False}

        while low <= high:  
            mid = (high + low) // 2
            vals[mid] = fn(mid)
            if vals[mid]:  
                if mid+1 in vals and not vals[mid+1]:
                    return vals[mid], mid
                low = mid + 1
            else:  
                if mid-1 in vals and vals[mid-1]:
                    return vals[mid-1], mid-1
                high = mid - 1
        return None, None
    
    def trapRainWater(self, heightMap: List[List[int]]) -> int:
        M = np.array(heightMap)
        H = sorted(set(chain(*heightMap)))
        D = -1*np.ones_like(heightMap)
        for P in product(*map(range, D.shape)):
            if D[P] > -1:
                continue
                
            B, hidx = self.bsearch(lambda idx:self.bfs(M, H[idx], P), len(H))
            h = H[hidx]
            for Q in B:
                D[Q] = max(0, h - M[Q])
        return sum(sum(D))

#Q12. Minimum Number of Refueling Stops
'''

A car travels from a starting position to a destination which is target miles east of the starting position.

There are gas stations along the way. The gas stations are represented as an array stations where stations[i] = [positioni, fueli] indicates that the ith gas station is positioni miles east of the starting position and has fueli liters of gas.

The car starts with an infinite tank of gas, which initially has startFuel liters of fuel in it. It uses one liter of gas per one mile that it drives. When the car reaches a gas station, it may stop and refuel, transferring all the gas from the station into the car.

Return the minimum number of refueling stops the car must make in order to reach its destination. If it cannot reach the destination, return -1.

Note that if the car reaches a gas station with 0 fuel left, the car can still refuel there. If the car reaches the destination with 0 fuel left, it is still considered to have arrived.

 

Example 1:

Input: target = 1, startFuel = 1, stations = []
Output: 0
Explanation: We can reach the target without refueling.
Example 2:

Input: target = 100, startFuel = 1, stations = [[10,100]]
Output: -1
Explanation: We can not reach the target (or even the first gas station).
Example 3:

Input: target = 100, startFuel = 10, stations = [[10,60],[20,30],[30,30],[60,40]]
Output: 2
Explanation: We start with 10 liters of fuel.
We drive to position 10, expending 10 liters of fuel.  We refuel from 0 liters to 60 liters of gas.
Then, we drive from position 10 to position 60 (expending 50 liters of fuel),
and refuel from 10 liters to 50 liters of gas.  We then drive to and reach the target.
We made 2 refueling stops along the way, so we return 2.
 

Constraints:

1 <= target, startFuel <= 109
0 <= stations.length <= 500
1 <= positioni < positioni+1 < target
1 <= fueli < 109

'''

#Solution

#Method-1

class Solution(object):
    def minRefuelStops(self, target, startFuel, stations):
        dp = [startFuel] + [0] * len(stations)
        for i, (location, capacity) in enumerate(stations):
            for t in range(i, -1, -1):
                if dp[t] >= location:
                    dp[t+1] = max(dp[t+1], dp[t] + capacity)

        for i, d in enumerate(dp):
            if d >= target: return i
        return -1
    

#Method-2
# greedy
# heap

class Solution:
    def minRefuelStops(self, target: int, fuel: int, stations: List[List[int]]) -> int:
        """
        Notes:
        1- We want to make sure we are able to reach target
        2- We have initial start fuel, we can stop and recharge
        3- Goal is to minimize our stops
    
        Algorithm:
        
        1- Keep the car moving, once we meet a station we add it to our priority queue
        2- Once we run out of gas we take the station with most gas
        3- We know that we can drop by this station because its added in our heap which means
            the moment we added it we have already reached it
        
        """
        
        max_heap = []
        current_pos = 0
        station_count = 0
        stations = stations[::-1]
        while current_pos != target:
            #consume all fuel and go to new position
            current_pos += fuel
            #if we have reached our target then return answer
            if current_pos >= target:
                return station_count
            fuel = 0
            #we are out of gas so we process the stations that we could have dropped by
            #and add them to our heap
            while stations and stations[-1][0] <= current_pos:
                heapq.heappush(max_heap, -1 * stations.pop()[1])
            #out of fuel and no stations can be reached so return -1
            if not max_heap:
                return -1
            #drop by the station that gives most fuel
            fuel = fuel + -1 * heapq.heappop(max_heap)
            #increment answer
            station_count += 1
        return station_count

#Method-3

class Solution:
	def minRefuelStops(self, target: int, startFuel: int, stations: List[List[int]]) -> int:
		num_stations = len(stations)
		dp = [startFuel for _ in range(1+num_stations)]

		for i in range(num_stations): 
			for j in range(i+1, 0, -1): 
				if dp[j-1]>=stations[i][0]:
					dp[j] = max(dp[j], dp[j-1]+stations[i][1])

		for i in range(1+num_stations): 
			if dp[i]>=target: 
				return i
		return -1    
    
#Method-4

# Heap | O(nlogn)

from heapq import heappush, heappop
class Solution:
    def minRefuelStops(self, target: int, startFuel: int, stations: List[List[int]]) -> int:
        que = []
        res, i, cur = 0, 0, startFuel
        while cur < target:
            while i < len(stations) and stations[i][0] <= cur:
                heappush(que, -stations[i][1])
                i += 1
            if not que: return -1
            cur += -heappop(que)
            res += 1
        return res
    
#Method-5

# PriorityQueue w/ Memoization Solution


# We simply try to pass every station with possibly minimum refill and maximum fuel, so heapq is prioritized by refill and then -fuel. Remember that every station is located subsequently in an increasing position, we try to reach last station index + 1, which is n, with enough fuel to drive between last station and target.

class Solution:
    def minRefuelStops(self, target, startFuel, stations):
        q, n, memo = [(0, -startFuel, 0, 0)], len(stations), set()
        while q:
            refill, fuel, pos, index = heapq.heappop(q)
            fuel *= -1
            if index == n:
                if fuel - (target - pos) >= 0:
                    return refill
            else:
                sPos, add = stations[index]
                if (index, refill) not in memo and fuel - (sPos - pos) >= 0:
                    memo.add((index, refill))
                    f1 = (fuel - (sPos - pos) + add) * -1
                    f2 = (fuel - (sPos - pos)) * -1
                    heapq.heappush(q, (refill + 1, f1, sPos, index + 1))
                    heapq.heappush(q, (refill, f2, sPos, index + 1))
        return -1



#Q13. Swim in Rising Water
'''

You are given an n x n integer matrix grid where each value grid[i][j] represents the elevation at that point (i, j).

The rain starts to fall. At time t, the depth of the water everywhere is t. You can swim from a square to another 4-directionally adjacent square if and only if the elevation of both squares individually are at most t. You can swim infinite distances in zero time. Of course, you must stay within the boundaries of the grid during your swim.

Return the least time until you can reach the bottom right square (n - 1, n - 1) if you start at the top left square (0, 0).

 

Example 1:


Input: grid = [[0,2],[1,3]]
Output: 3
Explanation:
At time 0, you are in grid location (0, 0).
You cannot go anywhere else because 4-directionally adjacent neighbors have a higher elevation than t = 0.
You cannot reach point (1, 1) until time 3.
When the depth of water is 3, we can swim anywhere inside the grid.
Example 2:


Input: grid = [[0,1,2,3,4],[24,23,22,21,5],[12,13,14,15,16],[11,17,18,19,20],[10,9,8,7,6]]
Output: 16
Explanation: The final route is shown.
We need to wait until time 16 so that (0, 0) and (4, 4) are connected.
 

Constraints:

n == grid.length
n == grid[i].length
1 <= n <= 50
0 <= grid[i][j] < n2
Each value grid[i][j] is unique.
'''
#Solution

#Approach-1

# BFS solution


class Solution:
    def swimInWater(self, grid: List[List[int]]) -> int:
        def neighbour(node):
            x, y = node
            n = [(x - 1, y), (x + 1, y), (x, y - 1), (x, y + 1)]
            return filter(
                lambda pt:
                    pt[0] >= 0 and pt[1] >= 0
                    and pt[0] < len(grid) and pt[1] < len(grid[0]),
                n)

        heap = [(grid[0][0], (0, 0))]
        seen = set([(0, 0)])
        maximum = 0
        end = (len(grid) - 1, len(grid[0]) - 1)

        while heap:
            cost, node = heapq.heappop(heap)
            maximum = max(maximum, cost)
            if node == end:
                return maximum
            for n in neighbour(node):
                if n not in seen:
                    heapq.heappush(heap, (grid[n[0]][n[1]], n))
                    seen.add(n)
                    
#Approach-2                    
# using minheap and bfs
# minheap

class Solution:
    def swimInWater(self, grid: List[List[int]]) -> int:
        vis,n,m=set([(0,0)]),len(grid),len(grid[0])
        hp=[[grid[0][0],0,0]]
        heapq.heapify(hp)
        moves=[(1,0),(0,1),(-1,0),(0,-1)]
        while hp:
            val,r,c=heapq.heappop(hp)
            if r==n-1 and c==m-1:
                return val
            for move in moves:
                tx=r+move[0]
                ty=c+move[1]
                if tx in range(n) and ty in range(m) and (tx,ty) not in vis:
                    vis.add((tx,ty))
                    heapq.heappush(hp,[max(val,grid[tx][ty]),tx,ty])
                    
                    
#Approach-3 

# bfs
# heapq

import heapq
class Solution(object):
    def swimInWater(self, grid):
        """
        :type grid: List[List[int]]
        :rtype: int
        """
        r = len(grid)
        pq = [(0,(0,0))]
        visited = set()
        res = grid[0][0]
        while pq:
            currTime,currIndex = heapq.heappop(pq)
            if currIndex in visited:
                continue
            visited.add(currIndex)
            res = max(res,currTime)
            if currIndex == (r-1,r-1):
                return res
            for item in [(-1,0),(0,-1),(1,0),(0,1)]:
                newX = currIndex[0]+item[0]
                newY = currIndex[1]+item[1]
                if 0<=newX<r and 0<=newY<r:
                    heapq.heappush(pq,(grid[newX][newY],(newX,newY)))
        return res
        

#Approach-4        
# binary-search

import collections
class Solution:
    def swimInWater(self, grid: List[List[int]]) -> int:
        high = max([max(l) for l in grid])
        left = 0
        m = len(grid)
        n = len(grid[0])

        def isConnect(t):
            dir = [-1, 0, 1, 0, -1]
            visit = collections.defaultdict(bool)

            def dfs(s):
                if not (0 <= s[0] <= m - 1) or not (0 <= s[1] <= n - 1):
                    return False
                if visit[s]:
                    return False
                visit[s] = True
                if grid[s[0]][s[1]] > t:
                    return False
                if s == (m - 1, n - 1):
                    return True
                for i in range(4):
                    x, y = s[0] + dir[i], s[1] + dir[i+1]
                    if dfs((x, y)):
                        return True
                return False

            return dfs((0, 0))

        while left < high:
            mid = left + (high - left) // 2
            if isConnect(mid):
                high = mid
            else:
                left = mid + 1
        return high
    
#Approach-5    
# Dijkstra's also
# dfs
# dijakstra

import heapq
class Solution:
    def swimInWater(self, grid: List[List[int]]) -> int:
        # func to check if the co-ordinate is valid
        def isValid(r,c):
            if r<0 or r>=rows: return False
            if c<0 or c>=cols: return False
            return True
        # initialize a minHeap with grid[r][c],r,c
        rows,cols=len(grid),len(grid[0])
        minHeap=[(grid[0][0],0,0)]
        # initialize a set visited
        visited=set()
        t=0
        # while minHeap is not empty
        while minHeap:
            # pop one of the minimal items
            val,r,c=heapq.heappop(minHeap)
            # if it's already visited, continue
            if (r,c) in visited: continue
            # update t, max elevation visited so far
            t=max(t,grid[r][c])
            # if we have reached the end column, return
            if r==rows-1 and c==cols-1: return t  
            # otherwise mark the r,c as visited
            visited.add((r,c))
            # push all the valid neighbors to the heap
            nei=[(r+1,c),(r-1,c),(r,c+1),(r,c-1)]
            for r1,c1 in nei:
                if isValid(r1,c1): heapq.heappush(minHeap,(grid[r1][c1],r1,c1))
          
        return t      
            
#Q14.  Shortest Path to Get All Keys

'''

You are given an m x n grid grid where:

'.' is an empty cell.
'#' is a wall.
'@' is the starting point.
Lowercase letters represent keys.
Uppercase letters represent locks.
You start at the starting point and one move consists of walking one space in one of the four cardinal directions. You cannot walk outside the grid, or walk into a wall.

If you walk over a key, you can pick it up and you cannot walk over a lock unless you have its corresponding key.

For some 1 <= k <= 6, there is exactly one lowercase and one uppercase letter of the first k letters of the English alphabet in the grid. This means that there is exactly one key for each lock, and one lock for each key; and also that the letters used to represent the keys and locks were chosen in the same order as the English alphabet.

Return the lowest number of moves to acquire all keys. If it is impossible, return -1.

 

Example 1:


Input: grid = ["@.a..","###.#","b.A.B"]
Output: 8
Explanation: Note that the goal is to obtain all the keys not to open all the locks.
Example 2:


Input: grid = ["@..aA","..B#.","....b"]
Output: 6
Example 3:


Input: grid = ["@Aa"]
Output: -1
 

Constraints:

m == grid.length
n == grid[i].length
1 <= m, n <= 30
grid[i][j] is either an English letter, '.', '#', or '@'.
The number of keys in the grid is in the range [1, 6].
Each key in the grid is unique.
Each key in the grid has a matching lock.

'''
#Solution

#Approach-1

# bfs
# visited

class Solution:
    def shortestPathAllKeys(self, grid: List[str]) -> int:
        
        m=len(grid)
        n=len(grid[0])
        visited=set()
        
        steps=0
        q=deque([])
        keyCt=0
        
        for i in range(m):
            for j in range(n):
                if grid[i][j]=="@":
                    q.append((i,j,''))
                elif grid[i][j].islower():
                    keyCt+=1
        
        while q:
            for _ in range(len(q)):
                curr_x,curr_y,keys = q.popleft()
                if (curr_x,curr_y,keys) in visited:
                    continue
                
                visited.add((curr_x,curr_y,keys))
                
                if len(keys)==keyCt:
                    return steps
                
                for x,y in ((0,1),(1,0),(-1,0),(0,-1)):
                    nx=curr_x+x
                    ny=curr_y+y
                    if nx<0 or ny<0 or nx>=m or ny>=n or grid[nx][ny]=='#' or (nx,ny,keys) in visited:
                        continue
                        
                    curr=grid[nx][ny]                    
                    if curr in 'abcdef' and curr not in keys:
                        q.append((nx,ny,keys+curr))                            
                    elif curr.isupper() and curr.lower() not in keys:
                        continue
                    else:
                        q.append((nx,ny,keys))
            steps+=1
        
        return -1
    
#Approach-2

# Time: O(N•M•log(N•M))
# Space: O(N•M•NK)

# python
# bitmask
# dijstra

# Find start (sx,sy) and then push it into heap [(0,mask,sx,sy)] mask here represents and integer number with mask & (1 <<k) != 0 if for that case we found the key with index k somehwere before
# We keep track of the distances to start as D[(mask,x,y)] and move only to the cells (if we can) where it's currently bigger
# If the cell has key update mask
# If the cell has lock: check if we have key as above
# Interate until we see first mask == T, where T is number that corresponds to all found keys
# from string import ascii_lowercase

class Solution:
    def shortestPathAllKeys(self, A: List[str]) -> int:
        N, M = len(A), len(A[0])
        
        ind = {} # letter to key index mapping (we need it to check if we have the key for the lock)
        k = 0
        for i in range(N):
            for j in range(M):
                if A[i][j] in ascii_lowercase:
                    ind[A[i][j]] = k
                    k += 1
                
                if A[i][j] == "@":
                    sx = i
                    sy = j
        
        
        NK = len(ind) # number of of keys
        T = (1 << NK) - 1 # target (if all keys are found)
        
        
        
        D = defaultdict(lambda : inf) # distance from start
        D[(0,0,sx,sy)] = 0
        
        
        h = [(0,0,sx,sy)]
        while h:
            d, mask, i, j = heappop(h)
            if mask == T: return d
            for dx,dy in [(1,0),(-1,0),(0,1),(0,-1)]:
                x = i + dx
                y = j + dy
                if  0 <= x < N and 0 <= y < M and A[x][y] != "#" and D[(mask,x,y)] > d + 1:
                    if A[x][y].isupper():
                        k = ind[A[x][y].lower()]
                        if mask & (1 <<k) == 0: continue
                        D[(mask,x,y)] = d + 1
                        heappush(h,(d + 1,mask ,x,y))
                        
                    if A[x][y].islower():
                        k = ind[A[x][y]]
                        D[(mask,x,y)] = d + 1
                        heappush(h,(d + 1,mask | (1 <<k),x,y))
                        
                    if A[x][y] in {".","@"}:
                        D[(mask,x,y)] = d + 1
                        heappush(h,(d + 1,mask ,x,y))
                    
        return -1


#Approach-3

from heapq import heapify,heappop,heappush
class Solution(object):
    def shortestPathAllKeys(self, grid):
        """
        :type grid: List[str]
        :rtype: int
        """
        row,col = len(grid),len(grid[0])
        target = 0
        for i in range(row):
            for j in range(col):
                if grid[i][j] in 'abcdef':
                    target |= 1 << (ord(grid[i][j]) - ord('a'))
                if grid[i][j] == '@':
                    r,c = i,j
        queue,visited = [(0,r,c,0)],set([(r,c,0)])
        steps = [(0,1),(0,-1),(1,0),(-1,0)]
        while queue:
            cur_step,x,y,cur_key = heappop(queue)
            if cur_key == target:
                return cur_step
            for dx,dy in steps:
                i,j = x + dx,y + dy
                if i < 0 or i >= row or j < 0 or j >= col:
                    continue
                elif grid[i][j] == '#':
                    continue
                elif grid[i][j] in 'abcdef':
                    next_key = cur_key | 1 << (ord(grid[i][j]) - ord('a'))
                    if (i,j,next_key) in visited:
                        continue
                    visited.add((i,j,next_key))
                    heappush(queue,(cur_step + 1,i,j,next_key))
                elif grid[i][j] in 'ABCDEF':
                    if 1 << (ord(grid[i][j]) - ord('A')) & cur_key:
                        if (i,j,cur_key) in visited:
                            continue
                        visited.add((i,j,cur_key))
                        heappush(queue,(cur_step + 1,i,j,cur_key))
                else:
                    if (i,j,cur_key) in visited:
                        continue
                    visited.add((i,j,cur_key))
                    heappush(queue,(cur_step + 1,i,j,cur_key))
        return - 1


#Q15. Minimum Cost to Hire K Workers

'''

There are n workers. You are given two integer arrays quality and wage where quality[i] is the quality of the ith worker and wage[i] is the minimum wage expectation for the ith worker.

We want to hire exactly k workers to form a paid group. To hire a group of k workers, we must pay them according to the following rules:

Every worker in the paid group should be paid in the ratio of their quality compared to other workers in the paid group.
Every worker in the paid group must be paid at least their minimum wage expectation.
Given the integer k, return the least amount of money needed to form a paid group satisfying the above conditions. Answers within 10-5 of the actual answer will be accepted.

 

Example 1:

Input: quality = [10,20,5], wage = [70,50,30], k = 2
Output: 105.00000
Explanation: We pay 70 to 0th worker and 35 to 2nd worker.
Example 2:

Input: quality = [3,1,10,10,1], wage = [4,8,2,2,7], k = 3
Output: 30.66667
Explanation: We pay 4 to 0th worker, 13.33333 to 2nd and 3rd workers separately.
 

Constraints:

n == quality.length == wage.length
1 <= k <= n <= 104
1 <= quality[i], wage[i] <= 104

'''
#Solution

# Approach 1:priority queue + sort || faster than 94% || time: O(n) || space: O(n)


class Solution:
	def mincostToHireWorkers(self, quality: List[int], wage: List[int], k: int) -> float:
		if k==0:
			return 0
		elif k==1:
			return min(wage)
		quality_len = len(quality)
		wage_len = len(wage)
		if quality_len>wage_len or quality_len<wage_len:
			return False
		import heapq
		priority_queue = list()
		zipped_list = list()
		for i in range(quality_len): 
			curr_quality = quality[i]
			curr_wage = wage[i]
			curr_ratio = wage[i]/quality[i]
			zipped_list.append([curr_ratio, curr_wage, curr_quality])
		zipped_list.sort(key=lambda d: d[0])    

		res = float('inf')
		curr_total_quality = 0
		for item in zipped_list:
			curr_ratio, curr_wage, curr_quality = item
			curr_total_quality += -1*curr_quality
			heapq.heappush(priority_queue, -1*curr_quality)
			if len(priority_queue)>k: 
				curr_total_quality -= heapq.heappop(priority_queue) 
			if len(priority_queue)==k: 
				if res> curr_total_quality*(-1*curr_ratio):
					# print(curr_total_quality*(-1*curr_ratio))
					res = curr_total_quality*(-1*curr_ratio) 

		return res
    
# Approach 2:
# Binary Search || Sorting || O(NlogN)


# First sort both lists based on wages/quality.The intuition is that all elements before captain ,after normalising
# their wages w.r.t captain will always have wages >= their minimum wages.
# Take a sliding window of k,last element will always be captain.Captain will always be paid exact amount as his wages.
# So at every index,your job is just to find k elements before captain whose quality is least.Just add all those quality and your answer is-
# (wage_cap/quality_cap)*(sum of all k-1 qualities of elements having least quality)+wage of captain

class Solution:
    def mincostToHireWorkers(self, quality: List[int], wage: List[int], k: int) -> float:
        ratio=sorted(((q,w) for q,w in zip(quality,wage)),key=lambda x:(x[1]/x[0]))
        n=len(ratio)
        L=[]
        ans=sys.maxsize
        flag=True
        Sum=0 
        for i in range(n):
            idx=bisect_left(L,ratio[i][0])
            if len(L)==k-1:
                ans=min(ans,ratio[i][1]+(ratio[i][1]/ratio[i][0])*Sum)
                if idx!=k-1:
                    Sum-=L.pop()
                    L.insert(idx,ratio[i][0])
                    Sum+=ratio[i][0]
            else:
                L.insert(idx,ratio[i][0])
                Sum+=ratio[i][0]
        return ans


#Q16. K-th Smallest Prime Fraction
'''

You are given a sorted integer array arr containing 1 and prime numbers, where all the integers of arr are unique. You are also given an integer k.

For every i and j where 0 <= i < j < arr.length, we consider the fraction arr[i] / arr[j].

Return the kth smallest fraction considered. Return your answer as an array of integers of size 2, where answer[0] == arr[i] and answer[1] == arr[j].

 

Example 1:

Input: arr = [1,2,3,5], k = 3
Output: [2,5]
Explanation: The fractions to be considered in sorted order are:
1/5, 1/3, 2/5, 1/2, 3/5, and 2/3.
The third fraction is 2/5.
Example 2:

Input: arr = [1,7], k = 1
Output: [1,7]
 

Constraints:

2 <= arr.length <= 1000
1 <= arr[i] <= 3 * 104
arr[0] == 1
arr[i] is a prime number for i > 0.
All the numbers of arr are unique and sorted in strictly increasing order.
1 <= k <= arr.length * (arr.length - 1) / 2
 

Follow up: Can you solve the problem with better than O(n2) complexity? 

'''
#Solution


#Approach-1: Heap

class Solution:
    def kthSmallestPrimeFraction(self, arr: List[int], k: int) -> List[int]:
        L = len(arr)
        h = [(arr[0] / arr[L-1], 0, L-1)]
        seen = set()
        seen.add((0, L-1))
        while k > 0:
            fraction, i, j = heapq.heappop(h)
            if (i+1, j) not in seen:
                heapq.heappush(h, (arr[i+1] / arr[j], i+1, j))
                seen.add((i+1, j))
            if (i, j-1) not in seen:            
                heapq.heappush(h, (arr[i] / arr[j-1], i, j-1))
                seen.add((i, j-1))
            k -= 1
            if k == 0:
                return [arr[i], arr[j]]
            
#Approach-2:            
class Solution:
    def kthSmallestPrimeFraction(self, arr: List[int], k: int) -> List[int]:
        dic = {}
        for i in range(len(arr)-1):
            for j in range(i+1, len(arr)):
                dic[round(arr[i]/arr[j], 10)] = [arr[i], arr[j]]
        dic_sort = sorted(dic.keys())      
        return dic[dic_sort[k-1]]