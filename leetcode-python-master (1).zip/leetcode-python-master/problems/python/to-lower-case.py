#https://leetcode.com/problems/to-lower-case/
class Solution(object):
    def toLowerCase(self, str):
        return str.lower()